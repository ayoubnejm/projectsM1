
Binome : Sara El arbaoui & Ayoub Nejmeddine

**************************************************************************************************************************************
**************************************************************************************************************************************

	3-	Modélisation de l’utilisation du verrou
	-------------------------------------------------


Q1.	Voir fichier UtilisationDuVerrou/verrou.pml


Q2.
	1.	Il ne contient pas d'interblocage : on ne peut pas exprimer cette propriété en ltl

	2.	ltl aEtBAccedentAuVerrouEnExclusionMutuelle { [] ! (etatA==actif && etatB==actif) }		VRAI

	3.	ltl aNePeutPasResterIndefinimentDansLetatActif { [] ( etatA==actif -> <> etatA==inactif ) }	VRAI

	4.	ltl aNestActifQueSiLeVerrouEstOccupe { []((etatA==actif)->(verrou==occupe))}		VRAI


Q3.
	1.	ltl toutEtatDattentePourAEstForcementSuiviDUnEtatActif { [] ( etatA == enAttente -> <> etatA == actif)  }	FAUX


Q4.
	1.	ltl EtatInactifEstSuiviDEtatAttente {[](((etatA==inactif) ->((etatA==inactif) U (etatA== enAttente))) && ((etatB==inactif) ->((etatB==inactif) U (etatB== enAttente))))}		FAUX
	
		un état d'inactivité peut très bien rester dans le même érat sans passer à un état d'attente,
		par exemple si le process termine et on ne le relance pas, comme ça il ne revient jamais à l'etat enAttente:
			 etatA  =  inactif
			 etatB  =  inactif
			 verrou  =  libre

	2.	ltl EtatActifEstSuiviDEtatInactif {[](((etatA==actif) ->((etatA==actif) U (etatA==inactif)))&& ((etatB==actif) ->((etatB==actif) U (etatB== inactif))))}		VRAI

		Comme un état ne peut pas rester indéfinimenet dans l'etat actif, un etat d'activité sera forcement suivi d'un etat d'inactivité


**************************************************************************************************************************************
**************************************************************************************************************************************

	4-	Travail préliminaire sur l’association verrou et préemption
	--------------------------------------------------------------------

	Voir fichier VerrouEtPreemption/verrou_priorite.pml
	Q1. 

	Senario	1 :	
	    le processus Haut prend le verrou , et se met en activité , puis il lache le verrou après avoir été mis en etat inactif, ensuite le processus Bas prend le verrou et se met en activité après avoir testé si le verrou est libre et l etatHaut est inactif . Et puis après, le processus Haut se met en attente, dans ce cas le processus Bas ne peut rien faire parce que l'etatHaut n'est pas dans un etat inactif (etatHaut=enAttente) , et le processus Haut , ne peut egalement rien faire parce que le verrou est deja pris par le processus Bas. Ce qui produit en fin de compte un interblocage.

		 etatBas  =  inactif
		 etatHaut  =  enAttente
		 verrou  =  occupe

	Senario 2 :	
	    Le processus Bas prend le verrou parce qu'au debut etatHaut=inactif  et verrou= libre, ensuite il se met en activité ( etatBas=actif ) après le test de etatHaut == inactif . Après, le processus Haut se met en attente , et ne pourra rien faire parce que le verrou est pris. Le processus Bas ne peut rien faire aussi parce que le processus Haut n'est plus inactif 

		 etatBas  =  actif
		 etatHaut  =  enAttente
		 verrou  =  occupe

	senario 3 :	
	    Le processus Bas prend le verrou parce qu'au debut etatHaut=inactif  et verrou= libre. Après, le processus Haut se met en attente , et ne pourra rien faire parce que le verrou est pris. Le processus Bas reste en attente et ne peut rien faire aussi parce que le processus Haut n'est plus inactif ( il est en attente )

		 etatBas  =  enAttente
		 etatHaut  =  enAttente
		 verrou  =  occupe

	Q2. On a enlevé le test (etatHaut == inactif) a la fin du processus Bas() afin d'autoriser Bas a relacher le verrou independemment de l'etat de Haut.
	
		/*	
			proctype Bas(){
			do
				:: (etatHaut == inactif) -> etatBas = enAttente;
				   atomic{etatHaut == inactif -> verrou == libre -> verrou=occupe;}
				   etatHaut == inactif -> etatBas=actif; 
				   etatHaut == inactif -> etatBas = inactif; 
				   verrou=libre;
			od;
		}
		*/
		On constate que l'interblocage correspondant au senario 1 disparait 

		 etatBas  =  inactif
		 etatHaut  =  enAttente
		 verrou  =  occupe

**************************************************************************************************************************************
**************************************************************************************************************************************

	5-	Modélisation des trois tâches avec priorité
	-----------------------------------------------------
	
	Q1.	Voir le fichier "TroisTachesAvecPriorite/verrou_priorite_trois_taches.pml"


	Q2.	senario1: 
		Le processus Bas() prend le verrou, et se met en activité, et les processus Haut() et Moyen() se mettent en attente, 
		et ils ne peuvent pas prendre le verrou parce qu'il 		est occupé par le processus Bas, 
		ce dernier ne peut rien faire aussi parce que le processus Moyen() n'est plus dans un etat inactif .	
			 etatBas  =  actif
			 etatHaut  =  enAttente
			 etatMoyen  =  enAttente
			 verrou  =  occupe
		

		senario2:
		Cet interblocage a lieu quand les trois etats sont en attente et que le verrou est occupé par le processu Bas()
			 etatBas  =  enAttente
			 etatHaut  =  enAttente
			 etatMoyen  =  enAttente
			 verrou  =  occupe
		 
		senario3:
		Le verrou est occupé par le processus Bas(). 
				Le processus Moyen() est dans un etat actif
				Le processus Haut() se met en attente
				=> Interblocage parce que les trois processus ne peuvent ni prendre /lacher le verrou ni changer d'etat
			 etatBas  =  actif
			 etatHaut  =  enAttente
			 etatMoyen  =  actif
			 verrou  =  occupe


		senario4 :
		Le processus Bas() prend le verrou et reste dans un etat en attente. Le processus Haut() est en attente , 
				  et le processus Moyen() est actif.
				  Ici il n'y aura aucun progrès parce que le verrou est occupé, et le processus Bas() ne peut pas le lacher puisque le processus Moyen() n'est pas inactif	
			 etatBas  =  enAttente
			 etatHaut  =  enAttente
			 etatMoyen  =  actif
			 verrou  =  occupe


	Q3.
		on a enlevé du processus Moyen la ligne "etatHaut == inactif -> etatMoyen = enAttente ; " parce que ce processus ne prend pas la ressource donc il ne va rien attendre, du coup , il n'a pas besoin de se mette dans un état d'attente
		
