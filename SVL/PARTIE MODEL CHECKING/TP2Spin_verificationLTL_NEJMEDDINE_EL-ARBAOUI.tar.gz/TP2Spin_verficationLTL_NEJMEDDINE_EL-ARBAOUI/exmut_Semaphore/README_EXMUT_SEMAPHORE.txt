 


Q 5.2 : L’utilisation de la ressource en exclusion mutuelle.

	Nous avons testé l'exclusion mutuelle en utilisant la proprieté suivante:
	ltl ilNestPasPossibleQueLesDeuxProcessusPrennentLaRessourceEnMemeTemps { [] ! (ressource1 && ressource2)  }  VRAI

	On utilise un canal de taille 0, donc l'émission et la réception d'un message sur le canal ne peut se faire que d'une manière simultanée.
	Dans notre programme, la réception se fait au début de chaque processus et l'émission se fait à la fin.
	Donc le processus 'proc2()' (respectivement proc1()) n'aura la ressource 
	qu'après l'émission du processus 'proc1()'  (respectivement proc2())

	-> cela évite que la ressource soit utilisée en même temps.

