

Q 5.4 Les resultats pour les proprietes version semaphore :

ltl ilNestPasPossibleQueLesDeuxProcessusGagne {[] ! (incrementeEstGagne && decrementeEstGagne)  } 	VRAI

ltl unDesProcessusGagneraForcement { <> ((incrementeEstGagne || decrementeEstGagne)&& !(incrementeEstGagne && decrementeEstGagne)) } 	FAUX : Il est intrinsequement fausse
Explication : ça peut arriver qu'aucun processus gagne : par exemple : quand chaqu'un des deux processus prend la main juste apres l'autre une seule fois, dans ce cas la ça boucle a l'infini. 

ltl LeCompteurEstToujoursComprisEntreZeroEtCinq {  [] ( compteur >= 0  && compteur <= 5 )  } 	VRAI

ltl SiIncrementeAgagneAlorsLeCompteurVautCinq { [] (incrementeEstGagne -> (compteur == 5)) } 	VRAI

ltl IncrementeAGangneSsiLeCompteurVautCinq { [] (incrementeEstGagne -> (compteur == 5)) &&  ((compteur == 5) -> incrementeEstGagne) } 	VRAI




