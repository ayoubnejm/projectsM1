
Les resultats pour les proprietes :

	ltl aEtBNePeuventPasEntrerEnMemeTempsEnSectionCritique { [] ( ! ( sectionCritiqueA && sectionCritiqueB ) ) }	VRAI

	ltl aNeResteraPasInfinimentLongtempsEnSectionCritique { [] ( sectionCritiqueA -> <> ! sectionCritiqueA ) }		VRAI

	ltl aEntreraEnSectionCritiqueInfinimentSouvent { [] <> sectionCritiqueA }		FAUX , B rentrera surement en section critique chose qui rend cette propriété fausse

	ltl touteDemandeDEntreeEnSectionCritiqueSeraPriseEnCompte { [] ((  reqA ->  <> reqAsatisfaite  ) ||  (  reqB ->  <> reqBsatisfaite  ) ) }	VRAI

Modifications faites :
	
	Nous avons ajouté les deux variables bouleenes reqAsatisfaite et reqBsatisfaite, pour verifier si les requêtes demandées sont prises en compte,
	Nous avons fais ces modifications pour que notre programme satisfasse la dernière propriété  
