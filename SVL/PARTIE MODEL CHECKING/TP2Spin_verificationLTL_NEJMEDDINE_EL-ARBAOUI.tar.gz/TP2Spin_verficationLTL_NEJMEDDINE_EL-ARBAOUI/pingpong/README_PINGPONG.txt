
	Les resultats pour les proprietes :


	ltl pingJoueEnPremier {(<>pingJoue) U pongJoue}		VRAI

	ltl quandPingJouePongNePeutPasJouer { [] (pingJoue -> !(pongJoue))  }		VRAI	
	
	ltl siPingJouePongJoueraEnsuite  { [] ( pingJoue->(<>(!pingJoue U pongJoue) ) ) }		VRAI

	ltl pingJoueInfinimentSouvent { [] <> pingJoue }		VRAI
