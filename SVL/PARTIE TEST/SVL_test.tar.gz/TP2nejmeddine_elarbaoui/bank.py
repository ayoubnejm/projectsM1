# -*- coding: utf-8 -*-

"""
Le module banque propose des objets pour manipuler des comptes
bancaires avec historiques.

Un client ouvre un compte bancaire. ::

  >>> storage = OperationStorage()
  >>> account = Account(storage)

Un compte est par défaut Ã  0. ::

  >>> account.balance()
  0

Un client crédite son compte. ::

  >>> account.credit(10)
  >>> account.balance()
  10

Un client debit son compte. ::

  >>> account.debit(10)     
  >>> account.balance()
  0
  
  
Un client credit et debite son compte. ::
  
  >>> account.credit(100)
  >>> account.debit(50)
  >>> account.balance()
  50

Un client debit son compte avec un solde insuffisant. ::

  >>> account.credit(10) 
  >>> account.debit(80) 
  Traceback (most recent call last):
    File "/usr/lib/python2.6/doctest.py", line 1248, in __run
      compileflags, 1) in test.globs
    File "<doctest bank[10]>", line 1, in <module>
      account.debit(80)
    File "/home/m1/ouannane/svl/bank.py", line 69, in debit
      raise ValueError("amount should be lower than balance, received: {0}".format(amount))
  ValueError: amount should be lower than balance, received: 80

  >>> account.balance()  
  60
"""



__date__ = 'Mon Jan 14 09:12:01 2013'



class Transfert(object):

	"""Faire des transferts entre comptes."""

	def __init__(self):
		pass

	def transaction(self, account1, account2, amount):
		""" faire un transfert entre account1 et account2. """
		account1.debit(amount)
		account2.credit(amount)





class Account(object):
    """Compte bancaire avec historique des opérations."""

    def __init__(self, storage):
        self.operations = storage

    def balance(self):
        """Retourne la balance courante du compte."""
        return sum(self.operations.select())

    def history(self):
        """Retourne une copie de l'historique des opérations."""
        return list(self.operations)  # return a copy of the list

    def credit(self, amount):
        """Crédite le compte du montant passé en paramètre.

        ValueError est levée si le montant est négatif.
        """
        self._negative_amount_raises_value_error(amount)
        self.operations.insert(amount)

    def debit(self, amount):
        """Débite le compte du montant passé en paramètre.

        ValueError est levée si le montant est négatif.
        """
        self._negative_amount_raises_value_error(amount)
        balance = self.balance()
        if amount > balance:
            raise ValueError(
                "amount {0} should be lower than balance {1}".format(amount, balance))
        self.operations.insert(-amount)

    def _negative_amount_raises_value_error(self, amount):
        if amount < 0:
            raise ValueError(
                "amount should be positive, received: {0}".format(amount))


# eof
