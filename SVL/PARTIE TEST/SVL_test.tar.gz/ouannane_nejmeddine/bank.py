# -*- coding: utf-8 -*-

"""
Le module banque propose des objets pour manipuler des comptes
bancaires avec historiques.

Un client ouvre un compte bancaire. ::

  >>> account = Account()

Un compte est par défaut Ã  0. ::

  >>> account.balance()
  0

Un client crédite son compte. ::

  >>> account.credit(10)
  >>> account.balance()
  10

Un client debit son compte. ::

  >>> account.debit(10)     
  >>> account.balance()
  0
  
  
Un client credit et debite son compte. ::
  
  >>> account.credit(100)
  >>> account.debit(50)
  >>> account.balance()
  50

Un client debit son compte avec un solde insuffisant. ::

  >>> account.credit(10) 
  >>> account.debit(80) 
  Traceback (most recent call last):
    File "/usr/lib/python2.6/doctest.py", line 1248, in __run
      compileflags, 1) in test.globs
    File "<doctest bank[10]>", line 1, in <module>
      account.debit(80)
    File "/home/m1/ouannane/svl/bank.py", line 69, in debit
      raise ValueError("amount should be lower than balance, received: {0}".format(amount))
  ValueError: amount should be lower than balance, received: 80

  >>> account.balance()  
  60
"""

import unittest

__date__ = 'Mon Jan 14 09:12:01 2013'


class Account(object):

    def __init__(self):
        self.operations = list()

    def balance(self):
        return sum(self.operations)

    def history(self):
        return list(self.operations)  # return a copy

    def credit(self, amount):
        if amount < 0:
            raise ValueError("amount should be positive, received: {0}".format(amount))
        self.operations.append(amount)
        
    def debit(self, amount):
        if amount < 0:
            raise ValueError("amount should be positive, received: {0}".format(amount))
        if amount > self.balance():
            raise ValueError("amount should be lower than balance, received: {0}".format(amount))    
        self.operations.append(-amount)
            


class TestJohnOuvreUnCompte(unittest.TestCase):
    
    def test_un_nouveau_compte_a_un_solde_de_0(self):
        """un nouveau compte a un solde de 0"""
        account = Account()
        balance = account.balance()
        self.assertEquals(0, balance)
       
class TestJohnCrediteSonCompte(unittest.TestCase):
    
    def test_le_solde_est_augmente_du_montant_du_credit(self):
        """le solde est augmente du montant du credit"""
        account = Account()
        amount = 10
        old_balance = account.balance()
        account.credit(amount)
        new_balance = account.balance()
        self.assertEquals(old_balance+amount, new_balance)

    def test_le_credit_est_ajoute_a_l_historique(self):
        """le credit est ajoute a l historique"""
        account = Account()
        amount = 10
        account.credit(amount)
        history = account.history()
        self.assertTrue(amount in history, "le credit est dans l'historique")

    def test_un_montant_negatif_leve_une_exception(self):
        """un montant negatif leve une exception"""
        account = Account()
        montant_negatif = -1
        self.assertRaises(ValueError, account.credit, montant_negatif)

class TestJohnDebiteSonCompte(unittest.TestCase):
    
    def test_le_solde_est_deminue_du_montant_du_debit(self):       
        """Le solde est deminue du montant du debit"""

        account = Account()
        amount = 10
        account.credit(amount)
        old_balance = account.balance()
        account.debit(amount)
        new_balance = account.balance()
        self.assertEquals(old_balance-amount, new_balance)
     
    def test_le_debit_est_ajoute_a_l_historique(self):
        """le debit est ajoute a l historique"""
        account = Account()
        amount = 10
        account.credit(amount) 
        account.debit(amount)
        history = account.history()
        self.assertTrue(amount in history, "le debit est dans l'historique")
     
        
    def test_un_montant_negatif_leve_une_exception(self):
        """un montant negatif leve une exception"""
        account = Account()
        montant_negatif = -1
        self.assertRaises(ValueError, account.debit, montant_negatif)    
          
# eof

