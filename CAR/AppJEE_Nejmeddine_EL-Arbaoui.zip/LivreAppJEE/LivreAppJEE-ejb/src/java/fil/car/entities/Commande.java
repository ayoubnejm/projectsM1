package fil.car.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

/**
 *
 * @author Ayoub && Sara
 */
@Entity
public class Commande implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "CMD_ID")
    private Long numCommande;
    @ManyToMany
    @JoinTable(name = "COMMANDES_LIVRES",
            joinColumns =
            @JoinColumn(name = "CI_CMD_ID", referencedColumnName = "CMD_ID"),
            inverseJoinColumns =
            @JoinColumn(name = "CI_LIVRE_ID", referencedColumnName = "LIVRE_ID"))
    private List<Livre> livresCommandes;

    public Commande() {
    }

    public Commande(List<Livre> livresCommandes) {

        this.livresCommandes = livresCommandes;
    }

    public Long getNumCommande() {
        return numCommande;
    }

    public List<Livre> getLivresCommandes() {
        return livresCommandes;
    }

    public void setNumCommande(Long numCommande) {
        this.numCommande = numCommande;
    }

    public void setLivresCommandes(List<Livre> livresCommandes) {
        this.livresCommandes = livresCommandes;
    }

    
    public int hashCode() {
        int hash = 0;
        hash += (numCommande != null ? numCommande.hashCode() : 0);
        return hash;
    }

   
    public boolean equals(Object object) {
         
        if (!(object instanceof Commande)) {
            return false;
        }
        Commande other = (Commande) object;
        if ((this.numCommande == null && other.numCommande != null) || (this.numCommande != null && !this.numCommande.equals(other.numCommande))) {
            return false;
        }
        return true;
    }

     
    public String toString() {
        return "fil.car.entities.Commande[ id=" + numCommande + " ]";
    }
}
