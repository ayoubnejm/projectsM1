package fil.car.usecaseimpl;

import fil.car.dao.DaoCommande;
import fil.car.dao.DaoLivre;
import fil.car.dao.DaoUtilisateur;
import fil.car.entities.Commande;
import fil.car.usecase.UseCaseBean;
import fil.car.entities.Livre;
import fil.car.entities.Utilisateur;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;

/**
 *
 * @author Ayoub && Sara
 */
@Stateless
@LocalBean
public class UseCaseBeanImpl implements UseCaseBean {

    @EJB
    DaoLivre doaLivre;
    @EJB
    DaoCommande daoCommande;
    @EJB
    DaoUtilisateur daoUtilisateur;

    public List<Livre> listerLivres() {
        return doaLivre.findAll();
    }

    public void creerLivre(String titre, String auteur, int annee) {

        if (annee > Calendar.getInstance().get(Calendar.YEAR)) {
            System.out.println("date : " + Calendar.getInstance().get(Calendar.YEAR));
            throw new IllegalArgumentException("Année invalide car supérieur à l'année en cours.");
        }
        doaLivre.create(new Livre(titre, auteur, annee));

    }

    public long creerCommande(List<String> livresACommander) {
        List<Livre> lst = new ArrayList<Livre>();
        for (String livre : livresACommander) {
            Livre livreRecup = doaLivre.find(livre);
            livreRecup.setUtilise(true);
            doaLivre.edit(livreRecup);
            lst.add(livreRecup);
        }
        return daoCommande.createCommande(new Commande(lst));
    }

    public void supprimerLivres(List<String> livresSelectionnes) {
        for (String livre : livresSelectionnes) {
            Livre livreTemp = doaLivre.find(livre);
            doaLivre.remove(livreTemp);
        }
    }

    public Livre getLivre(String selected) {
        return doaLivre.find(selected);
    }

    public void miseAJour(String titre, String nom, int annee) {
        Livre livre = doaLivre.find(titre);
        livre.setAuteur(nom);
        livre.setAnneeDeParution(annee);
        doaLivre.edit(livre);
    }

    public List<Livre> afficherCommande(long idCommande) {
        Commande cmd = daoCommande.find(idCommande);
        return new ArrayList<Livre>(cmd.getLivresCommandes());
    }

    @PostConstruct
    public void initialiser() {
        Utilisateur userRoot = new Utilisateur("root", "root@fil.fr", "root", true, true);
        Utilisateur rep = daoUtilisateur.find(userRoot.getLogin());
        if (rep == null) {
            daoUtilisateur.create(userRoot);
        }
    }

    public boolean login(String login, String mdp) {
        Utilisateur userInDb = daoUtilisateur.find(login);
        if (userInDb != null && userInDb.authentification(mdp)) {
            return true;
        }
        return false;
    }

    public Utilisateur getUtilisateur(String login) {
        return daoUtilisateur.find(login);
    }

    @SuppressWarnings("CallToThreadDumpStack")
    public boolean creerUtilisateur(String login, String email, String pswd, boolean isClient, boolean isAdmin) {
        Utilisateur utilisateur = new Utilisateur(login, email, pswd, isAdmin, isClient);

        try {
            daoUtilisateur.create(utilisateur);
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Livre> listerLivresQuiPeuventEtreSupprimer() {
        return doaLivre.listerLivresQuiPeuventEtreSupprimer();
    }
}
