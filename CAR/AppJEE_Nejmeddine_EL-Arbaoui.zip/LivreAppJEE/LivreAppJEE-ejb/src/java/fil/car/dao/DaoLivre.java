package fil.car.dao;

import fil.car.entities.Livre;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Ayoub && Sara
 */
@Local
public interface DaoLivre {

    void create(Livre livre);

    void edit(Livre livre);

    void remove(Livre livre);

    Livre find(Object id);

    List<Livre> findAll();

    List<Livre> findRange(int[] range);

    int count();

    public List<Livre> listerLivresQuiPeuventEtreSupprimer();
    
}
