package fil.car.entities;

import fil.car.util.Constantes;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Size;

/**
 *
 * @author Ayoub && Sara
 */
@Entity
public class Utilisateur implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Size(min = Constantes.MIN_PSEUDO_LENGTH, max = Constantes.MAX_PSEUDO_LENGTH)
    private String login;
    @Column(unique = true)
    private String email;
    @Size(min = Constantes.MIN_PASSWORD_LENGTH, max = Constantes.MAX_PASSWORD_LENGTH)
    private String mdp;
    private Boolean isAdmin;
    private Boolean isClient;

    public Utilisateur() {
    }

    public Utilisateur(String login, String email, String mdp, Boolean isAdmin, Boolean isClient) {
        this.login = login;
        this.email = email;
        this.mdp = mdp;
        this.isAdmin = isAdmin;
        this.isClient = isClient;
    }

    public String getLogin() {
        return login;
    }

    public String getEmail() {
        return email;
    }

    public String getMdp() {
        return mdp;
    }

    public Boolean getIsAdmin() {
        return isAdmin;
    }

    public Boolean getIsClient() {
        return isClient;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setMdp(String mdp) {
        this.mdp = mdp;
    }

    public void setIsAdmin(Boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    public void setIsClient(Boolean isClient) {
        this.isClient = isClient;
    }

    public boolean authentification(String mdp) {
        return this.mdp.equals(mdp);
    }

    public int hashCode() {
        int hash = 0;
        hash += (login != null ? login.hashCode() : 0);
        return hash;
    }

    public boolean equals(Object object) {

        if (!(object instanceof Utilisateur)) {
            return false;
        }
        Utilisateur other = (Utilisateur) object;
        if ((this.login == null && other.login != null) || (this.login != null && !this.login.equals(other.login))) {
            return false;
        }
        return true;
    }

    public String toString() {
        return "fil.car.entities.Utilisateur[ id=" + login + " ]";
    }
}
