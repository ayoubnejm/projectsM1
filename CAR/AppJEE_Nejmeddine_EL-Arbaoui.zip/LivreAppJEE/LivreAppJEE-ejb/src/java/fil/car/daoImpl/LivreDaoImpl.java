package fil.car.daoImpl;

import fil.car.dao.DaoLivre;
import fil.car.entities.Livre;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Ayoub
 */
@Stateless
public class LivreDaoImpl extends AbstractDaoImpl<Livre> implements DaoLivre {

    @PersistenceContext(unitName = "LivreAppJEE-ejbPU")
    private EntityManager em;

    protected EntityManager getEntityManager() {
        return em;
    }

    public LivreDaoImpl() {
        super(Livre.class);
    }

    public List<Livre> listerLivresQuiPeuventEtreSupprimer() {
        String queryString = "select OBJECT(l) from Livre l "
                + "where l.utilise = false ";

        Query q = em.createQuery(queryString);
        List<Livre> lst = (List<Livre>) q.getResultList();
        return new ArrayList<Livre>(lst);
    }
}
