package fil.car.util;

import java.util.regex.Pattern;

/**
 *
 * @author  Ayoub && Sara
 */
public class Util {
    
    public static void CheckMail(String email){
       if(!Pattern.compile(Constantes.EMAIL_PATTERN).matcher(email).matches()){
           throw new IllegalArgumentException("E-mail is invalid.");
       }
    }
    
}
