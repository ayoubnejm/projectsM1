package fil.car.util;

public class Constantes {

    /**
     *
     * @author Ayoub && Sara
     */
    public static final int MAX_VIDEO_SIZE = 15;
    public static final int MAX_PICTURE_SIZE = 2;
    public static final int MAX_TEXT_LENGTH = 500;
    public static final int MIN_TEXT_LENGTH = 10;
    public static final int MAX_PSEUDO_LENGTH = 18;
    public static final int MIN_PSEUDO_LENGTH = 3;
    public static final int MIN_PASSWORD_LENGTH = 3;
    public static final int MAX_PASSWORD_LENGTH = 128;
    public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    public static final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=[^\\s]+$).{" + MIN_PASSWORD_LENGTH + "," + MAX_PASSWORD_LENGTH + "})";
    public static final String LOGIN_PATTERN = "^[a-zA-Z0-9_]*$";
    public static final int PASSWORD_ITERATION = 3;
}
