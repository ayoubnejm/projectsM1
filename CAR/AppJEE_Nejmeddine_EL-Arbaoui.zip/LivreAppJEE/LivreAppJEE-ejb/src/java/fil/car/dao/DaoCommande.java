package fil.car.dao;

import fil.car.entities.Commande;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Ayoub && Sara
 */
@Local
public interface DaoCommande {

    void create(Commande commande);

    void edit(Commande commande);

    void remove(Commande commande);

    Commande find(Object id);

    List<Commande> findAll();

    List<Commande> findRange(int[] range);

    int count();
    
    public long createCommande(Commande entity) ;
    
}
