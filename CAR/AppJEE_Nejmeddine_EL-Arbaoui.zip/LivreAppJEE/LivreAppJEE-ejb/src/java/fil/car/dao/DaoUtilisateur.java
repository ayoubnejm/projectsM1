package fil.car.dao;

import fil.car.entities.Utilisateur;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Ayoub && Sara
 */
@Local
public interface DaoUtilisateur {

    void create(Utilisateur utilisateur);

    void edit(Utilisateur utilisateur);

    void remove(Utilisateur utilisateur);

    Utilisateur find(Object id);

    List<Utilisateur> findAll();

    List<Utilisateur> findRange(int[] range);

    int count();
}
