package fil.car.daoImpl;

import fil.car.dao.DaoCommande;
import fil.car.entities.Commande;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Ayoub && Sara
 */
@Stateless
public class CommandeDaoImpl extends AbstractDaoImpl<Commande> implements DaoCommande {

    @PersistenceContext(unitName = "LivreAppJEE-ejbPU")
    private EntityManager em;

    protected EntityManager getEntityManager() {
        return em;
    }

    public CommandeDaoImpl() {
        super(Commande.class);
    }

    public long createCommande(Commande entity) {
        super.create(entity);
        return entity.getNumCommande();
    }
}
