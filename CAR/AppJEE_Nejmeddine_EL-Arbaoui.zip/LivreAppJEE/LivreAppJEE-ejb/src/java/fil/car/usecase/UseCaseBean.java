package fil.car.usecase;

import fil.car.entities.Livre;
import fil.car.entities.Utilisateur;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Ayoub && Sara
 * 
 */
@Local
public interface UseCaseBean {
    public List<Livre> listerLivres();

    public void creerLivre(String titre, String nom, int anneeConvert);
    
    public long creerCommande(List<String> livresACommander);

    public void supprimerLivres(List<String> livresSelectionnes);

    public Livre getLivre(String selected);

    public void miseAJour(String titre, String nom, int anneeConvert);

    public List<Livre> afficherCommande(long idCommande);

    public boolean login(String login, String mdp);

    public Utilisateur getUtilisateur(String login);

    public boolean creerUtilisateur(String login, String email, String pswd, boolean client, boolean admin);

    public List<Livre> listerLivresQuiPeuventEtreSupprimer();


}
