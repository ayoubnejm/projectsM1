package fil.car.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author Ayoub && Sara
 */
@Entity
public class Livre implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "LIVRE_ID")
    private String titre;
    private String auteur;
    private int anneeDeParution;
    private Boolean utilise;

    public Livre() {
    }

    public Livre(String titre, String auteur, int anneeDeParution) {
        this.titre = titre;
        this.auteur = auteur;
        this.anneeDeParution = anneeDeParution;
        this.utilise = false;
    }

    public String getTitre() {
        return titre;
    }

    public String getAuteur() {
        return auteur;
    }

    public int getAnneeDeParution() {
        return anneeDeParution;
    }

    public Boolean getUtilise() {
        return utilise;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setAuteur(String auteur) {
        this.auteur = auteur;
    }

    public void setAnneeDeParution(int anneeDeParution) {
        this.anneeDeParution = anneeDeParution;
    }

    public void setUtilise(Boolean utilise) {
        this.utilise = utilise;
    }

    public int hashCode() {
        int hash = 0;
        hash += (titre != null ? titre.hashCode() : 0);
        return hash;
    }

    public boolean equals(Object object) {

        if (!(object instanceof Livre)) {
            return false;
        }
        Livre other = (Livre) object;
        if ((this.titre == null && other.titre != null) || (this.titre != null && !this.titre.equals(other.titre))) {
            return false;
        }
        return true;
    }

    public String toString() {
        return "fil.car.entities.Livre[ id=" + titre + " ]";
    }
}
