package fil.car.servlets;
 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServletRequest; 

/**
 *
 * @author Ayoub && Sara
 */
@WebServlet(name = "Util", urlPatterns = {"/Util"})
        
class Util {

    static boolean getClientDroit(HttpServletRequest request) {
        Boolean right = (Boolean)request.getSession(true).getAttribute("client");
        return right!=null && right;
    }

    static boolean getAdminDroit(HttpServletRequest request) {
    Boolean right = (Boolean)request.getSession(true).getAttribute("admin");
        return right!=null && right;   
    
   }
}

