/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package restftp;

import java.io.IOException;
import java.net.SocketException;
import java.util.Arrays;
import javax.ejb.embeddable.EJBContainer;
import org.apache.commons.net.ftp.FTPClient;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ayoub
 */
public class PassrelleFtpTest {

    public PassrelleFtpTest() {
    }

    public static void setUpClass() {
    }

    public static void tearDownClass() {
    }
    private PassrelleFtp passrelleFtp;

    public void setUp() throws SocketException, IOException {
        passrelleFtp = new PassrelleFtp();

    }

    /**
     * Test of retr method, of class PassrelleFtp.
     */
    @Test
    public void testRetr() throws Exception {
  
    }

    /**
     * Test of connect method, of class PassrelleFtp.
     */
    @Test
    public void testConnect_String_String() throws Exception {

        final FTPClient ftpClient = new FTPClient();
        ftpClient.connect("localhost", 1088);
        final boolean login = ftpClient.login("ayoubnejm", "aa");
        assertTrue("Login must be true", login);
        assertEquals("Reply code must be 230", 230, ftpClient.getReplyCode());
        ftpClient.logout();
    }

    /**
     * Test of store method, of class PassrelleFtp.
     */
    @Test
    public void testStore() throws Exception {
         final FTPClient ftpsClient = new FTPClient(); 
                ftpsClient.connect("localhost", 1088);
                final boolean login = ftpsClient.login("ayoubnejm", "aa");
                assertTrue("Login must be true", login);
                assertEquals("Reply code must be 230", 230, ftpsClient.getReplyCode());
                final String[] filenames = ftpsClient.listNames();
                assertNotNull(filenames);
                assertTrue("At least one file", filenames.length > 0);
                final boolean containsFile = Arrays.asList(filenames).add("exo1.sql");
                assertTrue("Must list the exo1.sql file", containsFile);
                ftpsClient.logout();
    }

    /**
     * Test of delete method, of class PassrelleFtp.
     */
    @Test
    public void testDelete() throws Exception {
                final FTPClient ftpsClient = new FTPClient(); 
                ftpsClient.connect("localhost", 1088);
                final boolean login = ftpsClient.login("ayoubnejm", "aa");
                assertTrue("Login must be true", login);
                assertEquals("Reply code must be 230", 230, ftpsClient.getReplyCode());
                final String[] filenames = ftpsClient.listNames();
                assertNotNull(filenames);
                assertTrue("At least one file", filenames.length > 0);
                final boolean containsFile = Arrays.asList(filenames).contains("grouping_id_fr.pdf");
                assertFalse("Must not exist the grouping_id_fr.pdf file", containsFile);
                ftpsClient.logout();
    }

       public void listningFile() throws IOException {
                
               
                final FTPClient ftpsClient = new FTPClient(); // implicit = false
                ftpsClient.connect("localhost", 1088);
                final boolean login = ftpsClient.login("ayoubnejm", "aa");
                assertTrue("Login must be true", login);
                assertEquals("Reply code must be 230", 230, ftpsClient.getReplyCode());
                final String[] filenames = ftpsClient.listNames();
                assertNotNull(filenames);
                assertTrue("At least one file", filenames.length > 0);
                final boolean containsFile = Arrays.asList(filenames).contains("grouping_id_fr.pdf");
                assertTrue("Must list the grouping_id_fr.pdf file", containsFile);
                ftpsClient.logout();
               
        }
}