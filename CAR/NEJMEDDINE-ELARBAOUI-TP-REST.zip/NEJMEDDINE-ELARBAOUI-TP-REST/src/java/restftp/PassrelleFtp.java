package restftp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;
import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

/**
 * Passrelle REST
 *
 * @author NEJMEDDINE & EL ARBAOUI
 */
@Stateless
@Path("/helloWorld")
public class PassrelleFtp {
    //@EJB

    private final FTPClient ftp;
    private final int port = 1088;
    private int auth;
    private int cptStore = 0;
    private String racine = "C:\\Users\\Ayoub\\Desktop\\Local\\";

    public PassrelleFtp() throws SocketException, IOException {

        this.auth = 0;
        ftp = new FTPClient();
        ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out), true));

        ftp.connect("127.0.0.1", port);
        int reply = ftp.getReplyCode();
        System.out.println("Connected to sever FTP  on " + this.port);

        if (!FTPReply.isPositiveCompletion(reply)) {
            ftp.disconnect();
            System.err.println("FTP server refused connection.");
            System.exit(1);
        }
    }

    @GET
    @Produces("text/html")
    public String getHtml() throws IOException {

        String html;
        FTPFile[] files = ftp.listFiles();
        System.out.println("listning ...");
        System.out.println(files.length);
        String chemin = "<html><head> <title>Ftp connect</title> "
                + "<script> \n"
                + "function visibilite(thingId) \n"
                + "{ \n"
                + "var targetElement; \n"
                + "targetElement = document.getElementById(thingId) ; \n"
                + "if (targetElement.style.display == \"none\") \n"
                + "{ \n"
                + "targetElement.style.display = \"\" ; \n"
                + "} else { \n"
                + "targetElement.style.display = \"none\" ; \n"
                + "} \n"
                + "} \n"
                + "</script> </head> <body>";

        String form = ""
                + "<a href='/PasserelleRestFTP/resources/helloWorld/logout/' >Deconnecter le serveur</a> <br/><form action='/PasserelleRestFTP/resources/helloWorld/store' method='POST'>"
                + "<label>Le nom du fichier :</label><input type='text' name='fichier' style='width:272px'/><br/>"
                + "<label>Le repertoire : </label><input type='text' name='repertoire' style='width:300px'/><br/>"
                + "<input type='submit' value='Envoyer' />"
                + "</form>";
        if (this.auth == 0) {
            html = " <h1>login</h1>\n"
                    + "        <form action=\"/PasserelleRestFTP/resources/helloWorld/connect\" method=\"POST\">\n" + //resources/helloWorld/connect
                    "            Username:<input type=\"text\" name=\"username\"/><br/>\n"
                    + "            Password:<input type=\"password\" name=\"password\"/><br/>\n"
                    + "            <input type=\"submit\" value=\"Login\"/>\n"
                    + "         </form>";
        } else {
            if (ftp.isConnected()) {
                html = form + chemin + listingFile(ftp, files, 0);
            } else {
                html = chemin + listingFile(ftp, files, 0);
            }
        }
        return html;
    }

    @Path("/retr{file: .*}")
    @GET
    @Produces("application/octet-stream")
    public String retr(@PathParam("file") String file) throws IOException {

        OutputStream out;

        out = new FileOutputStream(new File(racine + "\\" + file));
        ftp.retrieveFile(file, out);
        out.close();
        return "<h3>Telechargement reussi</h3>" + this.getHtml();
    }

    @Path("/logout")
    @GET
    public String connect() throws IOException {

        try {

            ftp.logout();
            this.auth = 0;

        } catch (IOException e) {
            e.getStackTrace();
        } finally {
            try {
                ftp.disconnect();

            } catch (IOException e) {
                e.getStackTrace();
            }
        }
        return "<h3> Serveur deconnecter ! </h3>";
    }

    @Path("/connect")
    @POST
    public String connect(@FormParam("username") String username, @FormParam("password") String password) throws SocketException, IOException {

        String html;
        ftp.login(username, password);
        if (ftp.isConnected()) {
            System.out.println("Remote system is " + ftp.getSystemType());
            ftp.setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);
            this.auth = 1;
            html = "<h3> Vous etes bien connecter</h3>" + this.getHtml();
        } else {
            html = "<h3> Login ou password incorrect ! </h3>";
        }

        return html;
    }

    @Path("/store")
    @POST
    public String store(@FormParam("fichier") String remote, @FormParam("repertoire") String rep) throws IOException {
        //ftp.pasv();
        InputStream input;
        String local;
        if (!remote.isEmpty() && !rep.isEmpty()) {

            if (ftp.getSystemType().equals("Unix")) {
                local = rep + "/" + remote;
            } else {
                local = rep + "\\" + remote;
            }
            input = new FileInputStream(local);
            ftp.storeFile(remote, input);
            input.close();
        } else {
            return "<h3>Vous devez saisir un fichier et un repertoire !</h3>";
        }

        return "<h3>Transfert reussi</h3>" + this.getHtml();
    }

   
    String listingFile(FTPClient f, FTPFile[] tabFiles, int s) {
        int i = 0;
        String listFile = "";
        try {
            if (s == tabFiles.length) {
                return listFile;
            } else {
                FTPFile file = tabFiles[s];
                if (file.isFile()) {
                    listFile += "<br/> <a href='/PasserelleRestFTP/resources/helloWorld/delete/" + file.getName() + "'> x </a> <a href='/PasserelleRestFTP/resources/helloWorld/retr/" + file.getName() + "'>" + file.getName() + "</a>";
                    i++;
                    listFile += listingFile(f, tabFiles, s + 1);
                } else {
                    listFile += "<br/><a href=\"\" onclick=\"javascript:visibilite('divid" + i + "'); return false;\">"
                            + file.getName() + "</a> " + "<div id=\"divid" + i + "\" style=\"display:none;\"><br> \n";
                    i++;
                    f.changeWorkingDirectory(file.getName());
                    listFile += listingFile(f, f.listFiles(), 0) + "\n </div> ";
                    f.changeToParentDirectory();
                    i++;
                    listFile += listingFile(f, tabFiles, s + 1);
                }
                return listFile;
            }
        } catch (IOException ex) {
            Logger.getLogger(PassrelleFtp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listFile;

    }

    @DELETE
    @Path("/delete{file: .*}")
    public String delete(@PathParam("file") String file) throws IOException {
        boolean del;
        //delete the file
        del = ftp.deleteFile(file);

        if (del) {
            return "<h3>Supression reussite</h3>" + this.getHtml();
        } else {
            return "<h3>Supression echouee</h3>" + this.getHtml();
        }

    }

    @Consumes("text/plain")
    public void putXml(String content) {
    }
}
