/**
 * Permet de quitter en laissant un message
 */
package utils;

/**
 * 		@authors
 *  Ayoub NEJMEDDINE
 * 	Sara EL ARBAOUI
 *
 */

public class Tools {

	// Singleton
	public static final Tools INSTANCE = new Tools();

	/**
	 * Constructeur vide
	 */
	private Tools () {}
	
	/**
	 * Permet de quitter l application en laissant un message
	 * @param message le message
	 */
	public static void leave (String message) {
		System.out.println(message);
		System.exit(-1);
	}
}