package utils;

public enum FTPCommandEnum {
	USER, PASS, QUIT, UNKNOWN, RETR, STOR, DELE, LIST, CWD, PWD, CDUP, SYST , TYPE, PORT, PASV
}
