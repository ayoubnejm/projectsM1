package utils;

/**
 * Permet de savoir si un utilisateur est connecte
 */
public enum StatusConnect {
	ONLINE,
	OFFLINE;
}

