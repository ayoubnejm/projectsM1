package utils;

import java.io.IOException;

public class FtpCommand {
	private final FTPCommandEnum cmd;
	private final String argument;

	public FtpCommand(String request) throws IOException {
		
		this.cmd = decodeCommand(request);

		int firstSpaceIndex = request.indexOf(' ');

		// Cmd without arg like quit, list, ...
		if (firstSpaceIndex == -1) {
			this.argument = null;
		} else {
			this.argument = request.substring(firstSpaceIndex + 1);
		}
	}

	private static FTPCommandEnum decodeCommand(String request) throws IOException {
		
		String[] splitResult = request.split("\\s");
		String cmd = splitResult[0].toLowerCase();

		if (cmd.equals("user"))
			return FTPCommandEnum.USER;

		if (cmd.equals("pass"))
			return FTPCommandEnum.PASS;

		if (cmd.equals("quit"))
			return FTPCommandEnum.QUIT;

		if (cmd.equals("retr"))
			return FTPCommandEnum.RETR;

		if (cmd.equals("stor"))
			return FTPCommandEnum.STOR;
		
		if (cmd.equals("dele"))
			return FTPCommandEnum.DELE;

		if (cmd.equals("list"))
			return FTPCommandEnum.LIST;
		
		if (cmd.equals("cwd"))
			return FTPCommandEnum.CWD;

		if (cmd.equals("cdup"))
			return FTPCommandEnum.CDUP;
		
		if (cmd.equals("type"))
			return FTPCommandEnum.TYPE;

		if (cmd.equals("pwd"))
			return FTPCommandEnum.PWD;
		
		if (cmd.equals("syst"))
			return FTPCommandEnum.SYST;
		

		if (cmd.equals("port"))
			return FTPCommandEnum.PORT;
		
		if (cmd.equals("pasv"))
			return FTPCommandEnum.PASV;

		return FTPCommandEnum.UNKNOWN;
	}

	public FTPCommandEnum getCmd() {
		return cmd;
	}

	public String getArgument() {
		return argument;
	}

	public String toString() {
		return this.cmd.toString() + " " + this.argument;
	}
}
