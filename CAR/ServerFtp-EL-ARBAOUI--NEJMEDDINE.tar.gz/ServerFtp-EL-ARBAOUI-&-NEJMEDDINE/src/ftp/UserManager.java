package ftp;

import java.util.Map;
import java.util.Set;
import utils.CommandException;
import ftp.FtpRequest;
import utils.StatusConnect;

public class UserManager {

	/**
	 * @param args
	 */

	// nom d'utilisateur
	private String username;

	private FtpRequest ftpr;

	/** Status */
	public StatusConnect status = StatusConnect.OFFLINE;

	/** Couple mot de passe user */
	private Map<String, String> directories;

	/** Couple mot de passe user */
	private Map<String, String> password;

	/** Path */
	public static final String path = "ressource/xml/user.xml";

	/** Repertoire du serveur */
	private String directory;
	public static final UserManager INSTANCE = new UserManager();

	private UserManager() {

		// Les repertoire du fichier xml
		directories = XMLParserDom.INSTANCE.getDirectories();

		// Les mots de passe du fichier xml
		this.password = XMLParserDom.INSTANCE.getPasswords();

	}

	/**
	 * Permet de recuperer les mots de passe des utilisateurs
	 * 
	 * @return une map contenant les noms des utilisateurs et les mots de passe
	 */
	public Map<String, String> getPasswords() {
		return this.password;
	}

	/**
	 * Permet d obtenir les repertoire des utilisateur
	 * 
	 * @return la map des utilisateurs et des repertoire
	 */
	public Map<String, String> getDirectories() {
		return this.directories;
	}

	/**
	 * Permet d obtenir le repertoire de base du server
	 * 
	 * @return une String representant le repertoire
	 */
	public String getDirectory() {
		return this.directory;
	}

	/**
	 * Permet de recuperer les noms des utilisateurs
	 * 
	 * @return un ensemble de noms d uitlisateurs
	 */
	public Set<String> getUsers() {
		return this.directories.keySet();
	}
	
	public String getUserName(){
		return this.username;
	}

	void checkLogin() throws CommandException {
		if (status == StatusConnect.OFFLINE)
			throw new CommandException(530, "Please login with USER and PASS.");
	}

	/**
	 * Permet de traiter le requete USER Definit l utilisateur a l aide du nom
	 * passe en parametre
	 */
	public class ReponseCouple {
		int code;
		String msg;
	}

	public ReponseCouple handleUser(String argument) throws CommandException {
		ReponseCouple r = new ReponseCouple();
		if (argument.equals("anonymous")) {
			this.username = argument;
			r.code = 331;
			r.msg = "Guest login ok.";

		} else if (UserManager.INSTANCE.getUsers().contains(argument)) {
			this.username = argument;
			r.code = 331;
			r.msg = "User name okay, need password for " + argument + ".";
		} else {
			r.code = 430;
			r.msg = "Invalid username.";
		}
		return r;

	}

	/**
	 * Permet de traiter la requete PASS Se connecte a l aide d un mot de passe
	 * donne
	 */

	public ReponseCouple handlePass(String argument) throws CommandException {
		ReponseCouple r = new ReponseCouple();
		if (this.username.equals("anonymous")) {
			r.code = 230;
			r.msg = "Guest login ok, access restrictions apply.";
			this.status = StatusConnect.ONLINE;
			System.out.println(this.username + " is authentified");

		} else if (this.username.isEmpty()) {
			throw new CommandException(503, "Login with USER first.");

		} else {
			if (UserManager.INSTANCE.getPasswords().get(username)
					.equals(argument)) {
				this.status = StatusConnect.ONLINE;
				System.out.println(this.username + " is authentified");
				r.code = 230;
				r.msg = "User " + username + " logged in.";
			} else
				throw new CommandException(503, "Authentification fail..");

		}
		return r;
	}

}