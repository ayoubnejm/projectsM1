package ftp;

import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Hashtable;

/**
 * Cette classe manipule les fichiers de l'envoi ou de la réception.
 */
public class TransmissionMode {

	private static Hashtable transmissionModes = new Hashtable();

	private static final int BUFSIZ = 1024;

	public static TransmissionMode get(char code) {
		return (TransmissionMode) transmissionModes.get(new Character(code));
	}

	private char code;

	protected TransmissionMode() {
		this.code = 'S';

		transmissionModes.put(new Character(code), this);
	}

	public final char getCode() {
		return code;
	}

	/**
	 * Lit le contenu du fichier in, et écrit les données dans la socket passés
	 * en parametre.
	 * 
	 * @param in
	 * @param s
	 * @throws IOException
	 */
	public void sendFile(InputStream in, Socket s) throws IOException {
		OutputStream out = s.getOutputStream();
		byte buf[] = new byte[BUFSIZ];
		int nread;
		while ((nread = in.read(buf)) > 0) {
			out.write(buf, 0, nread);
		}
		out.close();
	}

	/**
	 * Reads data from the given socket and converts it from the specified
	 * representation to local representation, writing the result to a file via
	 * "out".
	 */
	/**
	 * Lit les données à partir de la socket passée en parametre, et écrit le
	 * résultat dans un fichier via "out".
	 * 
	 * @param s
	 * @param out
	 * @throws IOException
	 */
	public void receiveFile(Socket s, OutputStream out) throws IOException {
		InputStream in = s.getInputStream();
		byte buf[] = new byte[BUFSIZ];
		int nread;
		while ((nread = in.read(buf, 0, BUFSIZ)) > 0) {
			out.write(buf, 0, nread);
		}
		in.close();
	}
}