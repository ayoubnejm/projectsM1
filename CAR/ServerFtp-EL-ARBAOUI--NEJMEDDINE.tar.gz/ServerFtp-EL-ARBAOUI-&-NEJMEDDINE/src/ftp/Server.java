package ftp;

/**
 * 		@authors
 *  Ayoub NEJMEDDINE
 * 	Sara EL ARBAOUI
 *
 */

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	/**
	 * @param args
	 */

	/** Numero de port */
	public static final int PORT = 2505;

	public Server() {
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		Server server = new Server();
		server.start();

	}

	public void start() throws Exception {
		System.out.println("----- FTP-SERVER---- -----");

		System.out.println("****************************");
		System.out.println("Server Started...");
		System.out.println("Waiting for connections...");
		System.out.println("-");

		try {
			// Creation du ServerSocket
			ServerSocket serverSocket = new ServerSocket(PORT);

			// Sert plusieurs clients
			while (true) {

				// création d’une socket quand une demande de connexion a été
				// acceptée
				Socket clientS = serverSocket.accept();
				System.out.println("Connexion etablie");
				// créer un thread pour traiter la damande du client
				FtpRequest ftpr = new FtpRequest(clientS);
				new Thread(ftpr).start();

			}

		} catch (IOException e) {
			throw new RuntimeException(e);
		}

	}

}
