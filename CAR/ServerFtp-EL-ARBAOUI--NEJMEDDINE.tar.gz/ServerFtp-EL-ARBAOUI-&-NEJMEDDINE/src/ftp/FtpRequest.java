package ftp;

/***
 * Cette classe permet de traiter les commandes ftp
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.NoSuchElementException;
import ftp.UserManager.ReponseCouple;
import utils.FtpCommand;
import utils.CommandException;

public class FtpRequest implements Runnable {
	/**
	 * Le client
	 */
	private Socket clientS;

	/**
	 * Un Reader pour lire à partir du socket client
	 */
	private BufferedReader reader;

	/**
	 * Un Writer pour écrire dans le socket client.
	 */
	private PrintWriter writer;

	/**
	 * Repertoire courant du serveur Systeme.getProperty : Cette méthode renvoie
	 * la valeur de la propriété spécifiée. Pour obtenir la valeur de la
	 * propriété user.dir, on utilise:
	 */
	private String currentDir = System.getProperty("user.dir");

	/**
	 * Le processus de transfert de données pour transférer des fichiers vers et
	 * à partir de le client.
	 */
	private FileTransfer transfert;

	public FtpRequest(Socket clientS) throws IOException {

		this.clientS = clientS;
		reader = new BufferedReader(new InputStreamReader(
				clientS.getInputStream()));
		writer = new PrintWriter(new OutputStreamWriter(
				clientS.getOutputStream()), true);
		transfert = new FileTransfer(this);

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			// The actual interpreter loop.
			//
			loop();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				clientS.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * La lecture de chaque commande en utilisant processRequest() pour appeler
	 * la méthode appropriée gestionnaire pour cette commande.
	 * 
	 * @throws Exception
	 */
	private void loop() throws Exception {
		// TODO Auto-generated method stub
		reply(220, "localhost FTP server ready.");

		String request = null;
		try {

			while ((request = this.reader.readLine()) != null) {
				this.processRequest(request);
			}

		} catch (CommandException ce) {
			// TODO Auto-generated catch block
			reply(ce.getCode(), ce.getText());
		}

	}

	/**
	 * Permet de traiter la requete correspondante Lance un message d'erreur
	 * quand la requete n'existe pas
	 * 
	 * @param request
	 * @throws CommandException
	 * @throws IOException
	 */
	private void processRequest(String request) throws CommandException,
			IOException {
		// TODO Auto-generated method stub
		FtpCommand cmd = new FtpCommand(request);

		switch (cmd.getCmd()) {

		case USER:
			this.processUSER(cmd.getArgument());
			break;

		case PASS:
			this.processPASS(cmd.getArgument());
			break;

		case PWD:
			this.processPWD();
			break;

		case CDUP:
			this.processCDUP(cmd.getArgument());
			break;

		case CWD:
			this.processCWD(cmd.getArgument());
			break;

		case SYST:
			this.processSYST();
			break;

		case TYPE:
			this.processTYPE(cmd.getArgument());
			break;

		case PORT:
			this.processPORT(cmd.getArgument());
			break;

		case PASV:
			this.processPASV();
			break;

		case LIST:
			this.processLIST();
			break;

		case DELE:
			this.processDELE(cmd.getArgument());
			break;

		case STOR:
			this.processSTOR(cmd.getArgument());
			break;

		case RETR:
			this.processRETR(cmd.getArgument());
			break;

		case QUIT:
			this.processQUIT();
			break;

		default:
			reply(502, "Command not implemented");
			break;
		}
	}

	/**
	 * Permet de traiter la requete USER Definit l utilisateur a l aide d
	 * argument passe en parametre
	 * 
	 * @param argument
	 * @throws CommandException
	 */
	public int processUSER(String argument) throws CommandException {

		ReponseCouple r;
		r = UserManager.INSTANCE.handleUser(argument);
		return reply(r.code, r.msg);

	}

	/**
	 * Permet de traiter la requete PASS Se connecte a l aide d un mot de passe
	 * donne
	 * 
	 * @param argument
	 * @throws CommandException
	 */
	public int processPASS(String argument) throws CommandException {

		ReponseCouple r;
		r = UserManager.INSTANCE.handlePass(argument);
		return reply(r.code, r.msg);

	}

	/**
	 * Traite la commande CWD Permet de se deplacer dans les repertoires
	 * 
	 * @param argument
	 * @return
	 * @throws CommandException
	 */
	private int processCWD(String argument) throws CommandException {
		// TODO Auto-generated method stub

		UserManager.INSTANCE.checkLogin();
		String newDir = argument;
		if (newDir.length() == 0)
			newDir = "/";

		File file = new File(newDir);
		if (!file.exists())
			throw new CommandException(550, argument + ": no such directory");
		if (!file.isDirectory())
			throw new CommandException(550, argument + ": not a directory");

		currentDir = newDir;
		System.out.println("CWD command successful");
		return reply(250, "CWD command successful.");
	}

	/**
	 * Traite la commande CDUP Permet de revenir dans le repertoire parent
	 * 
	 * @param argument
	 * @return
	 * @throws CommandException
	 */
	private int processCDUP(String argument) throws CommandException {
		// TODO Auto-generated method stub
		return processCWD(argument);

	}

	/**
	 * Traite la commande SYST
	 * @return
	 * @throws CommandException
	 */
	private int processSYST() throws CommandException {
		// TODO Auto-generated method stub
		return reply(215, "UNIX TYPE : L8");
	}
	
	/**
	 * Permet de traiter la commande TYPE
	 * @param argument
	 * @return
	 * @throws CommandException
	 */
	private int processTYPE(String argument) throws CommandException {
		// TODO Auto-generated method stub

		if (argument.length() != 1)
			throw new CommandException(500, "TYPE: invalid argument '"+ argument + "'");
		return reply(200, "Type set to " + argument);
	}

	/**
	 * Traite la commande PWD 
	 * Permet de connaire le repertoire courant de
	 * travail distant
	 * @throws CommandException
	 */
	private int processPWD() throws CommandException {
		// TODO Auto-generated method stub
		UserManager.INSTANCE.checkLogin();
		if (this.currentDir.charAt(0) != '/') {
			File aFile = new File(this.currentDir);
			try {
				this.currentDir = aFile.getCanonicalPath();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}
		}

		return reply(257, " \"" + this.currentDir + "\" is current directory \n\r");
	}
	
	/**
	 * Permet de traiter la requete LIST Liste le contenu du dossier
	 * 
	 * @return
	 * @throws CommandException
	 */
	private int processLIST() throws CommandException {
		// TODO Auto-generated method stub
		UserManager.INSTANCE.checkLogin();
		String path = null;
		path = currentDir;
		return transfert.sendList(path);
	}
	/**
	 * Permet de recevoir un fichier du client
	 * @param argument
	 * @return
	 * @throws CommandException
	 */
	private int processSTOR(String argument) throws CommandException {
		UserManager.INSTANCE.checkLogin();
		String path = null;
		try {
			path = this.currentDir + "/" + argument;
		} catch (Exception e) {
			throw new NoSuchElementException(e.getMessage());
		}

		return transfert.receiveFile(path);

	}
	
	/**
	 * Permet de traiter la requete RETR
	 * Envoi un fichier vers le client
	 * @param argument
	 * @return
	 * @throws CommandException
	 */
	private int processRETR(String argument) throws CommandException {
		// TODO Auto-generated method stub
		UserManager.INSTANCE.checkLogin();
		String path = null;
		try {
			path = this.currentDir + "/" + argument;
		} catch (Exception e) {
			throw new NoSuchElementException(e.getMessage());
		}

		return transfert.sendFile(path);
	}
	
	/**
	 * Permet de traiter la commande DELE
	 * Supprime un fichier
	 * @param argument
	 * @return
	 * @throws CommandException
	 */
	private int processDELE(String argument) throws CommandException {
		// TODO Auto-generated method stub
		UserManager.INSTANCE.checkLogin();
		System.out.println(argument);
		File file = new File(this.currentDir + "/" + argument);
		if (!file.exists())
			throw new CommandException(550, argument + " : file does not exist");
		if (!file.delete())
			throw new CommandException(550, argument
					+ " : could not delete file");

		return reply(250, "DELE command successful.");
	}

	/**
	 * Permet de traiter la commande PASV
	 * Connecte au mode passif
	 * @return
	 * @throws CommandException
	 */
	private int processPASV() throws CommandException {
		// TODO Auto-generated method stub
		
		 /* int p1,p2 ;
		  
		  p2 = transfert.dataPort%256; 
		  p1= (transfert.dataPort-p2)/256;
		 
		return reply(227, " Entering Passive Mode (127,0,0,1,"+p1+","+p2+") \n");*/
		return reply(530,"");
		
	}

	/**
	 * Permet de traiter la commande PORT
	 * connecte au mode actif
	 * @param argument
	 * @return
	 * @throws CommandException
	 */
	private int processPORT(String argument) throws CommandException {
		// TODO Auto-generated method stub

		String[] portStr = argument.split(",");
		String h1 = portStr[0];
		String h2 = portStr[1];
		String h3 = portStr[2];
		String h4 = portStr[3];
		int p1 = Integer.parseInt(portStr[4]);
		int p2 = Integer.parseInt(portStr[5]);

		String dataHost = h1 + "." + h2 + "." + h3 + "." + h4;
		int dataPort = (p1 << 8) | p2;

		transfert.setDataPort(dataHost, dataPort);

		return reply(200, "PORT command successful.");

	}


	/**
	 * Permet de traiter la requete QUIT 
	 * Quitte le serveur
	 * @return
	 * @throws CommandException
	 */
	private int processQUIT() throws CommandException {
		// TODO Auto-generated method stub
		UserManager.INSTANCE.checkLogin();
		System.out.println("User log out");
		return reply(221, "Goodbye.");

	}

	/**
	 * represente la reponse du serveur
	 * @param code
	 * @param message
	 * @return
	 */
	public int reply(int code, String message) {

		writer.println(code + " " + message);
		return code;
	}

}