package ftp;

/**
 * Permet de recuperer les informations de l xml
 */

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import utils.Tools;

/**
 * @authors Ayoub NEJMEDDINE Sara EL ARBAOUI
 * 
 */
public class XMLParserDom {

	/** Mot de passe pour chaque user */
	private Map<String, String> passwords;

	/** Repertoire courant pour chaque user */
	private static Map<String, String> directories;

	/** DTD path */
	public final String path = "ressource/dtd/user.dtd";

	// Singleton
	public static final XMLParserDom INSTANCE = new XMLParserDom();

	/**
	 * Constructeur
	 */
	private XMLParserDom() {
		this.passwords = new HashMap<String, String>();
		directories = new HashMap<String, String>();
		this.init();
	}

	public void init() {

		// List de noeuds
		NodeList list;

		Element child, name, directory, password;

		// Permet de recuperer un BuilderFactory
		DocumentBuilderFactory docFactory = DocumentBuilderFactory
				.newInstance();

		// Validation de la DTD
		docFactory.setValidating(true);
		docFactory.setNamespaceAware(true);

		// Permet de parser un document XML
		DocumentBuilder docBuilder = null;

		// Representation du fichier XML
		Document doc = null;

		// Recuperation du parser
		try {
			docBuilder = docFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			Tools.leave("Probleme lors de la recuperation du parser");
		}

		// Affectation du gestionnaire d erreur
		docBuilder.setErrorHandler(new SimpleErrorHandler());

		// Recuperation de la representation XML
		try {
			doc = docBuilder.parse(UserManager.INSTANCE.path);
		} catch (SAXException e) {
			Tools.leave("Probleme de convertion de l xml");
		} catch (IOException e) {
			Tools.leave("Erreur d'ouverture de fichier");
		}

		// Recuperation des elements user
		list = doc.getElementsByTagName("user");

		// Ajout des elements
		for (int i = 0; i < list.getLength(); i++) {

			// Recuperation des noeuds user
			child = (Element) list.item(i);

			// Position des noeuds
			int positionLogin = 1, positionPass = 3, positionDir = 5;

			// Recuperation
			name = (Element) child.getChildNodes().item(positionLogin);
			password = (Element) child.getChildNodes().item(positionPass);
			directory = (Element) child.getChildNodes().item(positionDir);

			// Insertion dans les maps
			this.passwords
					.put(name.getTextContent(), password.getTextContent());
			directories.put(name.getTextContent(), directory.getTextContent());
		}
	}

	/**
	 * Getter password
	 * 
	 * @return une map des mots de passe associes aux noms d utilisateur
	 */
	public Map<String, String> getPasswords() {
		return passwords;
	}

	/**
	 * Getter directories
	 * 
	 * @return une map des repertoire associes aux noms d utilisateur
	 */
	public Map<String, String> getDirectories() {
		return directories;
	}

	public static void main(String[] args) {

	}

	/** Error handler */
	private class SimpleErrorHandler implements ErrorHandler {

		public void warning(SAXParseException e) throws SAXException {
			Tools.leave(e.getMessage());
		}

		public void error(SAXParseException e) throws SAXException {
			Tools.leave(e.getMessage());
		}

		public void fatalError(SAXParseException e) throws SAXException {
			Tools.leave(e.getMessage());
		}

	}

}