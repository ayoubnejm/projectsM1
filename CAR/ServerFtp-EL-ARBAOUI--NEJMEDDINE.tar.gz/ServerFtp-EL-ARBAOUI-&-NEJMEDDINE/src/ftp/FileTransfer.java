package ftp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ConnectException;
import java.net.Socket;
import java.sql.Date;
import java.text.SimpleDateFormat;

import utils.CommandException;

public class FileTransfer {

	/**
	 *  le host de  data socket.
	 */
	private String dataHost;
	/**
	 * Mode de Transmission
	 */
	private TransmissionMode transmissionMode = new TransmissionMode();
	/**
	 * le port de data socket.
	 */
	public int dataPort = -1;
	/**
	 * FtpRequest qui utilise ce processus de transfert de fichiers
	 */
	private FtpRequest ftpr;

	public FileTransfer(FtpRequest ftpr) {
		this.ftpr = ftpr;
	}
	/**
	 * Définit le port de données pour une transmission.
	 * @param host
	 * @param port
	 */
	public void setDataPort(String host, int port) {
		dataHost = host;
		dataPort = port;
	}

	/**
	 * Ouvre la connexion de donnée
	 * @param path
	 * @return
	 * @throws CommandException
	 */
	public int sendList(String path) throws CommandException {
		int reply = 0;
		Socket dataSocket = null;
		try {
			File dir = new File(path);
			String fileNames[] = dir.list();
			int numFiles = fileNames != null ? fileNames.length : 0;

			dataSocket = new Socket(this.dataHost, this.dataPort);
			PrintWriter writer = new PrintWriter(dataSocket.getOutputStream());

			// Envoi la liste des fichiers
			//  Mode par default Ascii
			ftpr.reply(150, "Opening ascii mode data connection.");

			// Le nombre totale de fichiers.
			//
			writer.print("total " + numFiles + "\n");

			// Boucle sur chaque fichier et affiche son nom, sa taille
			// sa date de modification ...
			//
			for (int i = 0; i < numFiles; i++) {
				String fileName = fileNames[i];

				File file = new File(dir, fileName);
				listFile(file, writer);
			}

			writer.flush();

			reply = ftpr.reply(226, "Transfer complete.");
		} catch (ConnectException e) {
			throw new CommandException(425, "Can't open data connection.");
		} catch (Exception e) {
			e.printStackTrace();
			throw new CommandException(550, "No such directory.");
		} finally {
			try {
				if (dataSocket != null)
					dataSocket.close();
			} catch (IOException e) {
			}
		}
		return reply;
	}

	/**
	 * LIster un seul fichier au format long
	 * @param file
	 * @param writer
	 */
	private void listFile(File file, PrintWriter writer) {

		Date date = new Date(file.lastModified());
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd hh:mm");
		String dateStr = dateFormat.format(date);

		long size = file.length();
		String sizeStr = Long.toString(size);
		int sizePadLength = Math.max(8 - sizeStr.length(), 0);
		String sizeField = pad(sizePadLength) + sizeStr;

		writer.print(file.isDirectory() ? 'd' : '-');
		writer.print("rwxrwxrwx");
		writer.print(" ");
		writer.print("  1");
		writer.print(" ");
		writer.print("ftp     ");
		writer.print(" ");
		writer.print("ftp     ");
		writer.print(" ");
		writer.print(sizeField);
		writer.print(" ");
		writer.print(dateStr);
		writer.print(" ");
		writer.print(file.getName());

		writer.print('\n');
	}

	/**
	 * Ouvre la connexion de données, lit les données , et l'écrit dans le fichier local "path"
	 * @param path
	 * @return
	 * @throws CommandException
	 */
	public int receiveFile(String path) throws CommandException {
		int reply = 0;
		FileOutputStream fos = null;
		Socket dataSocket = null;
		try {
			File file = new File(path);
			if (file.exists())
				throw new CommandException(550, "File exists in that location.");

			fos = new FileOutputStream(file);

			if (dataPort == -1)
				throw new CommandException(500,
						"Can't establish data connection: no PORT specified.");
			dataSocket = new Socket(dataHost, dataPort);

			// Lire le contenu du fichier
			
			ftpr.reply(150, "Opening ascii mode data connection.");
			transmissionMode.receiveFile(dataSocket, fos);
			reply = ftpr.reply(226, "Transfer complete.");
		} catch (ConnectException e) {
			throw new CommandException(425, "Can't open data connection.");
		} catch (IOException e) {
			throw new CommandException(550, "Can't write to file");
		} finally {
			try {
				if (fos != null)
					fos.close();
				if (dataSocket != null)
					dataSocket.close();
			} catch (IOException e) {
			}
		}
		return reply;
	}

	/**
	 * Ouvre la connexion de données lit le fichier local spécifié 
	 * et l'écrit dans la data socket
	 * @param path
	 * @return
	 * @throws CommandException
	 */
	public int sendFile(String path) throws CommandException {
		int reply = 0;
		FileInputStream fis = null;
		Socket dataSocket = null;
		try {
			File file = new File(path);
			if (!file.isFile())
				throw new CommandException(550, "Not a plain file.");

			fis = new FileInputStream(file);

			
			if (dataPort == -1)
				throw new CommandException(500,"Can't establish data connection: no PORT specified.");
			dataSocket = new Socket(dataHost, dataPort);

			// envoyer le contenu de fichier.
			//
			ftpr.reply(150, "Opening ASCII mode data connection.");
			transmissionMode.sendFile(fis, dataSocket);
			reply = ftpr.reply(226, "Transfer complete.");
		} catch (FileNotFoundException e) {

			throw new CommandException(550, "No such file.");
		} catch (ConnectException e) {
			throw new CommandException(425, "Can't open data connection.");
		} catch (IOException e) {

			throw new CommandException(553, "Not a regular file.");
		} finally {
			try {
				if (fis != null)
					fis.close();
				if (dataSocket != null)
					dataSocket.close();
			} catch (IOException e) {
			}
		}
		return reply;
	}

	
	private static String pad(int length) {
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < length; i++)
			buf.append((char) ' ');
		return buf.toString();
	}

}