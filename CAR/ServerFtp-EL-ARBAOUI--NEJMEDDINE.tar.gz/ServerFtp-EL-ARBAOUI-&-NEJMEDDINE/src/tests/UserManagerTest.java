package tests;
import static junit.framework.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.*;

import ftp.Server;
import ftp.UserManager;

public class UserManagerTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testUser() throws Exception {
		Server mockServer = mock(Server.class);
		UserManager mockUser = mock(UserManager.class);
		String user = null;
		mockServer.start();
		when(mockUser.getUserName()).thenReturn(user);
		assertEquals("sara", user);

	}

	
}