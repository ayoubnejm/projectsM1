Tp Réalisé par Binome :
	Sara EL ARBAOUI	
	Ayoub NEJMEDDINE


Pour tester le tp :

1- lancer dans un 1ere terminal le Makefile : 
	
	> make all (il va créér la racine du l'arborescence)

2- lancer dans un 2ème terminal le neoud : 
	
	> java -classpath clas-Djava.rmi.server.codebase=file:classes/ server.Server 2

3- lancer dans un 3ème terminal le neoud : 

	> java -classpath clas-Djava.rmi.server.codebase=file:classes/ server.Server 3

4- lancer dans un 4ème terminal le neoud : 
	
	> java -classpath clas-Djava.rmi.server.codebase=file:classes/ server.Server 4

5- lancer dans un 5ème terminal le neoud : 
	
	> java -classpath clas-Djava.rmi.server.codebase=file:classes/ server.Server 5

6- lancer dans un 6ème terminal le neoud : 
	
	> java -classpath clas-Djava.rmi.server.codebase=file:classes/ server.Server 6

Après veuillez créer l'arborescence dans la class Client.java (Par défaut c'est l'arbre de l'enoncé du tp) et puis recompiler les sources avec la commande > make compile

7- lancer dans un 7ème terminal le client : 
	
	> java -classpath classes client.Client

Finalement vous pouvez propager les messages entre les sites.

Remarque : pour relancer le test veuillez arreter le rmiregestry avec la commande > kill [PID]

