

// une description d'iris
public class Iris {
	private double sepalLength; 
	private double sepalWidth; 
	private double petalLength; 
	private double petalWidth; 
	private IrisClasse laClasse;
	
	// voir le calcul de la distance
	private static double c1=1; 
	private static double c2=1; 
	private static double c3=25; 
	private static double c4=16; 
	
	public Iris( double petalLength, double petalWidth,
			double sepalLength, double sepalWidth,IrisClasse cl) {
		super();
		this.laClasse=cl; 
		this.petalLength = petalLength;
		this.petalWidth = petalWidth;
		this.sepalLength = sepalLength;
		this.sepalWidth = sepalWidth;
	}

	/**
	 * @return the sepalLength
	 */
	public double getSepalLength() {
		return sepalLength;
	}

	/**
	 * @return the sepalWidth
	 */
	public double getSepalWidth() {
		return sepalWidth;
	}

	/**
	 * @return the petalLength
	 */
	public double getPetalLength() {
		return petalLength;
	}

	/**
	 * @return the petalWidth
	 */
	public double getPetalWidth() {
		return petalWidth;
	}

	/**
	 * @return the laClasse
	 */
	public IrisClasse getLaClasse() {
		return laClasse;
	} 
	
	// Distance euclidienne
	// les termes c1,..,c4 controlent l'influence de chacun des attributs
	public double distance(Iris b){
		double term=this.sepalLength-b.sepalLength;
		double sum=term*term/c1; 
		term=this.sepalWidth-b.sepalWidth;
		sum+=term*term/c2; 
		term=this.petalLength-b.petalLength;
		sum+=term*term/c3;
		term=this.petalWidth-b.petalWidth;
		sum+=term*term/c4;
		return Math.sqrt(sum); 
	}
	
	public String toString(){
		String s=this.sepalLength+" "+this.sepalWidth+" "+this.petalLength+" "+this.petalWidth; 
		return s; 
	}

	// permet de fixer les coefficients controlant l'influence de chaque attribut
	// a partir de la lecture des donnees (voir Kmeans.java)
	public static void setCoef(double d, double e, double f, double g) {
		c1=d*d; 
		c2=e*e; 
		c3=f*f;
		c4=g*g;
		
	}

}