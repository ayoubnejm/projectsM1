import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Kmeans {
	// Liste des 150 exemples
	private ArrayList<Iris> lesDonnees=new ArrayList<Iris>(); 
	// Nombre de clusters voulus
	private int nbClust=3; 
	// Liste des centres
	private Iris centers[]=new Iris[nbClust]; 
	
	// Lire les donnees depuis le fichier
	public void readData(){
		double slmin=1000,slmax=0,swmin=1000,
		swmax=0,plmin=1000,plmax=0,pwmin=1000,pwmax=0 ;
		 try{
		       File source = new File("./iris.data");
		       BufferedReader in = new BufferedReader(new FileReader(source));
		       String ligne = in.readLine();

		  while(ligne!=null){
		        Scanner rl=new Scanner(ligne); 
			rl.useLocale(Locale.US); 
		        rl.useDelimiter(","); 
			double sepalLength=rl.nextDouble();
			double sepalWidth=rl.nextDouble();
			double petalLength=rl.nextDouble(); 
			double petalWidth=rl.nextDouble();
			
			// Mettre a jour les valeurs min et max des atributs
			if(slmin>sepalLength)slmin=sepalLength; 
			if(slmax<sepalLength) slmax=sepalLength; 
			if(swmin>sepalWidth) swmin=sepalWidth; 
			if(swmax<sepalWidth) swmax=sepalWidth; 
			if(plmin>petalLength) plmin=petalLength; 
			if(plmax<petalLength) plmax=petalLength;
			if(pwmin>petalWidth) pwmin=petalWidth; 
			if(pwmax<petalWidth) pwmax=petalWidth;
			String classe=rl.next();
			IrisClasse lacl=null; 
			if(classe.equals("Iris-setosa")) lacl=IrisClasse.setosa; 
			if(classe.equals("Iris-virginica")) lacl=IrisClasse.virginica;
			if(classe.equals("Iris-versicolor")) lacl=IrisClasse.versicolor;
			//System.out.println(sepalLength+","+sepalWidth+","+petalLength+","+petalWidth+","+classe);
			// Ajouter un nouvel exemple a l'ensemble des exemples
			lesDonnees.add(new Iris(sepalLength,sepalWidth,petalLength,petalWidth,lacl));
			ligne=in.readLine(); 
		    }	
		}
		catch(Exception e){ e.printStackTrace();System.out.println(e+" : Autre probleme");   }
		// fixer les coefficients servant pour calculer la distance
		Iris.setCoef(slmax-slmin,swmax-swmin,plmax-plmin,pwmax-pwmin); 
		
		}
	
	public static void main(String[] args) {
		Random gene=new Random();
		Kmeans kama=new Kmeans(); 
		//lire les donnÃ©es
		kama.readData(); 
		 
		System.out.println(kama.lesDonnees.size());
		// Initialiser les centres
		for(int i=0;i<kama.nbClust;i++){
			kama.centers[i]=new Iris(300*gene.nextDouble(),10*gene.nextDouble(),5*gene.nextDouble(),30*gene.nextDouble(),null); 
		}
		// Iterer
		ArrayList[] lesClusters=null;
		for(int i=0;i<1000;i++){
			// Une liste d'exemples par cluster
			lesClusters=new ArrayList[kama.nbClust]; 
			System.out.println("*******************************************************************************************"); 
			for(int j=0;j<kama.nbClust;j++)	
				lesClusters[j]=new ArrayList<Iris>();
			// Pour chaque exemple, rechercher le centre le plus proche
			for(Iris d:kama.lesDonnees){	
				double dmin=1000;
				int indexmin=-1; 
				for(int j=0;j<kama.nbClust;j++){
					double dist=d.distance(kama.centers[j]); 
					if(dist<dmin){
						dmin=dist; 
						indexmin=j; 
					}
				}// j
				// Ajouter l'exemple au cluster du centre le plus proche
				lesClusters[indexmin].add(d); 
			}// for d
			// Calculer les nouveaux centres 
			for(int j=0;j<kama.nbClust;j++){
				System.out.print("Cluster  "+j+"   "); 
				double nb=lesClusters[j].size();
				System.out.println("	"+kama.centers[j]); 
				System.out.println("	number of clustered instance :"+nb);
				System.out.println();
				double sw=0; 
				double sl=0; 
				double pl=0;
				double pw=0; 
				for(Object o:lesClusters[j]){
					Iris d=(Iris)o; 
					sw+=d.getSepalWidth(); 
					sl+=d.getSepalLength(); 
					pw+=d.getPetalWidth(); 
					pl+=d.getPetalLength(); 
				}// object o
				if(nb!=0)
				kama.centers[j]=new Iris(pl/nb,pw/nb,sl/nb,sw/nb,null);
				else
				// Si le cluster est vide, choisir un nouveau centre	
				kama.centers[j]=new Iris(3*gene.nextDouble(),1*gene.nextDouble(),5*gene.nextDouble(),3*gene.nextDouble(),null); 
			}
			
		}// nb iterations (i)

		// verifier l'homogeneite des clusters
		System.out.println("*************************************"); 
		System.out.println(" Clusteres Instances ");
		System.out.println("*************************************"); 
		for(int j=0;j<kama.nbClust;j++){
			int repClasse[]=new int[kama.nbClust]; 
			for(Object o: lesClusters[j]){
				Iris d=(Iris)o;
				repClasse[d.getLaClasse().ordinal()]++; 
			}//o
			// Imprime a l'ecran, pour chaque cluster, le nombre
			// d'exemples de chaque classe qu'il contient
			System.out.print("Cluster"+j+"   "); 
			for(int k=0;k<kama.nbClust;k++)
				System.out.print(repClasse[k]+" "); 
			System.out.println(); 
		}
		System.out.println(); 
	}

}