

public enum IrisClasse {
	setosa,virginica,versicolor; 

}