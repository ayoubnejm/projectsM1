/*Sara El Arbaoui & Ayoub Nejmeddine*/

/*
Exercice 1:
*/

SELECT  DEPT.DEPTNO, ENAME, SAL,RANK() OVER  ( PARTITION BY DEPT.DEPTNO ORDER BY  SAL DESC ) "RANG"  
FROM EMP,DEPT 
WHERE EMP.DEPTNO=DEPT.DEPTNO AND (EMP.DEPTNO=10 OR EMP.DEPTNO=30);

/*
Question 1.2:
*/
SELECT  DEPT.DEPTNO, ENAME, SAL,DENSE_RANK() OVER  ( PARTITION BY DEPT.DEPTNO ORDER BY  SAL DESC ) "RANG" 
FROM EMP,DEPT
WHERE EMP.DEPTNO=DEPT.DEPTNO AND  (EMP.DEPTNO=10 OR EMP.DEPTNO=30);

/*
Question 1.3:
*/

SELECT DISTINCT DEPT.DEPTNO, SAL,DENSE_RANK() OVER  ( PARTITION BY DEPT.DEPTNO ORDER BY SAL DESC ) "RANG" 
FROM EMP,DEPT 
WHERE EMP.DEPTNO=DEPT.DEPTNO AND (EMP.DEPTNO=10 OR EMP.DEPTNO=20) ORDER BY  DEPT.DEPTNO;

/*
Question 1.4:

Reponses sans GROUP BY:
*/

SELECT DISTINCT  JOB, SUM(SAL) OVER (PARTITION BY JOB) "TOT_SAL_JOB"
FROM EMP ;

/*
Reponses avec GROUP BY:
*/

SELECT DISTINCT  JOB, SUM(SAL) 
FROM EMP group by JOB ;

/*
Question 1.5:

	Diff�rence entre un PARTITION BY et un GROUP BY :

PARTITION BY est � utiliser avec les fonctions de classement, mais GROUP BY est utilis� avec  les fonctions d'agr�gation.
PARTITION BY  permet d'organiser le jeu de r�sultats en groupes logiques, d'apr�s les diff�rentes valeurs de l'expression sp�cifi�e. Cela correspond � peu de chose pr�s � la clause GROUP BY lorsque vous utilisez des agr�gats directement dans une requ�te.

*/

/*
Question 1.6:
*/

SELECT  DEPTNO,JOB, SUM(SAL) SAL  FROM  EMP GROUP BY  ROLLUP(DEPTNO , JOB) ;

/*Question 1.7:
*/

SELECT  decode(grouping(DEPTNO),1,'TousDep',DEPTNO) AS   DEPARTEMENT , 
		decode(grouping(JOB),1,'TousEmployes',JOB) AS  JOB	,
		SUM(SAL) 
FROM EMP 
GROUP BY  ROLLUP(DEPTNO , JOB) ;
