/*Sara El Arbaoui & Ayoub Nejmeddine*/
/*
 Exercice 3
 */
 
SELECT  AVG(ventes.pu) AS MoyenneVentes , temps.annee, produits.category, clients.cl_state
FROM ventes,produits,temps,clients 
WHERE (temps.annee=2009 OR temps.annee=2010)
AND ventes.pid=produits.pid 
AND temps.tid=ventes.tid 
AND ventes.cid =clients.cl_id
GROUP BY ROLLUP (temps.annee , clients.cl_state, produits.category);


SELECT AVG(ventes.pu) AS MoyenneVentes , temps.annee, clients.cl_state
FROM ventes,temps,clients 
WHERE (temps.annee=2009 OR temps.annee=2010) 
AND temps.tid=ventes.tid 
AND ventes.cid =clients.cl_id
GROUP BY ROLLUP (temps.annee , clients.cl_state);


SELECT AVG(ventes.pu) AS MoyenneVentes , temps.annee
FROM ventes,temps 
WHERE (temps.annee=2009 OR temps.annee=2010) 
AND temps.tid=ventes.tid 
GROUP BY ROLLUP (temps.annee );



SELECT  AVG(ventes.pu) AS MoyenneVentes , temps.annee, produits.category, clients.cl_state
FROM ventes,produits,temps,clients 
WHERE (temps.annee=2009 OR temps.annee=2010)
AND ventes.pid=produits.pid 
AND temps.tid=ventes.tid 
AND ventes.cid =clients.cl_id
GROUP BY CUBE (temps.annee , clients.cl_state, produits.category);
