import java.io.*;
import java.lang.String;
import java.util.*;
import java.lang.Class;
import java.lang.System;
import java.lang.Math;


public class Mesure{


    /** tSize[] contient, par ordre croissant, toutes les tailles de
     * donnees pour lesquelles les temps d'execution des algorithmes
     * seront mesures par l'une des methodes mesureNomAlgorithme sur
     * l'objet de type Mesure. */
    int tSize[];
    /** tRep[i] contient le nombre de donnees differentes toutes de
     * taille tSize[i] sur lequel la moyenne des temps d'executions
     * sera calculee par l'une des methodes mesureNomAlgorithme sur
     * l'objet de type Mesure.*/
    int tRep[];
    /** tRes[i] contient a l'issue d'une mesure effectuee par une
     * methode mesureNomAlgorithme le temps moyen d'execution de
     * l'algorithme NomAlgorithme sur tRep[i] donnees differentes de
     * taille tSize[i] .*/
    double tRes[];

    /**************************************************************************
     **************************************************************************
     **************************** CONSTRUCTEUR ********************************
     **************************************************************************
     *************************************************************************/

    public Mesure(int[] tSize, int[] tRep){
	this.tSize = tSize;
	this.tRep = tRep;
	this.tRes = new double[tSize.length];

	for(int i = 0; i < this.tRes.length ; i++){
	    this.tRes[i] = 0;
	} 
	
    }
  

    /**************************************************************************
     **************************************************************************
     ************************ MESURE DES ALGORITHMES **************************
     **************************************************************************
     *************************************************************************/


    /** ecrit dans tRes[] les moyennes de temps de calcul de rechercheL
     * sur les nombres contenus dans tRep[] d'executions sur des donnees
     * dont les tailles sont indiquees dans tSize[], pour la recherche
     * de l'element 0 qui est contenu dans L */

    public void mesureRechercheL(){
	double startTime;
	double totalTime;
	boolean present;

	this.resetRes();
	
	  for (int i=0; i < this.tSize.length; i++){

	      Methodes M = new Methodes(this.tSize[i]);

	      for(int j = 0; j < this.tRep[i]; j++){	      

		  M.aleaL(); /** nouvelle instance */
		  
		  startTime = System.nanoTime();
		  present = M.rechercheL(0);
		  totalTime = (System.nanoTime() - startTime);
		  this.tRes[i] = this.tRes[i] + totalTime;
	      }
	      this.tRes[i] = this.tRes[i]/this.tRep[i];
	
	  }
    }
   /** ecrit dans tRes[] les moyennes de temps de calcul de rechercheT
     * sur les nombres contenus dans tRep[] d'executions sur des donnees
     * dont les tailles sont indiquees dans tSize[], pour la recherche
     * de l'element 0 qui est contenu dans T */

    public void mesureRechercheT(){
	double startTime;
	double totalTime;
	boolean present;

	this.resetRes();
	
	  for (int i=0; i < this.tSize.length; i++){

	      Methodes M = new Methodes(this.tSize[i]);

	      for(int j = 0; j < this.tRep[i]; j++){	      

		  M.aleaT(); /** nouvelle instance */
		  
		  startTime = System.nanoTime();
		  present = M.rechercheT(0);
		  totalTime = (System.nanoTime() - startTime);
		  this.tRes[i] = this.tRes[i] + totalTime;
	      }
	      this.tRes[i] = this.tRes[i]/this.tRep[i];
	
	  }
    }


    /** ecrit dans tRes[] les moyennes de temps de calcul de
     * minimumSimpleL sur les nombres contenus dans tRep[] d'executions
     * sur des donnees dont les tailles sont indiquees dans tSize[] */

    public void mesureMinimumSimpleL(){
	double startTime;
	double totalTime;
	int min;

	this.resetRes();
	
	  for (int i=0; i < this.tSize.length; i++){

	      Methodes M = new Methodes(this.tSize[i]);

	      for(int j = 0; j < this.tRep[i]; j++){	      

		  M.aleaL(); /** nouvelle instance */
		  
		  startTime = System.nanoTime();
		  min = M.minimumSimpleL();
		  totalTime = (System.nanoTime() - startTime);
		  this.tRes[i] = this.tRes[i] + totalTime;
	      }
	      this.tRes[i] = this.tRes[i]/this.tRep[i];
	
	  }
    }
    /** ecrit dans tRes[] les moyennes de temps de calcul de
     * minimumSimpleT sur les nombres contenus dans tRep[] d'executions
     * sur des donnees dont les tailles sont indiquees dans tSize[] */

    public void mesureMinimumSimpleT(){
	double startTime;
	double totalTime;
	int min;
	
	this.resetRes();

	  for (int i=0; i < this.tSize.length; i++){

	      Methodes M = new Methodes(this.tSize[i]);

	      for(int j = 0; j < this.tRep[i]; j++){	      

		  M.aleaT(); /** nouvelle instance */
		  
		  startTime = System.nanoTime();
		  min = M.minimumSimpleT();
		  totalTime = (System.nanoTime() - startTime);
		  this.tRes[i] = this.tRes[i] + totalTime;
	      }
	      this.tRes[i] = this.tRes[i]/this.tRep[i];
	
	  }
    }

    /** ecrit dans tRes[] les moyennes de temps de calcul de minimumTriL
     * sur les nombres contenus dans tRep[] d'executions sur des donnees
     * dont les tailles sont indiquees dans tSize[] */

    public void mesureMinimumTriL(){
	double startTime;
	double totalTime;
	int min;
	
	this.resetRes();

	  for (int i=0; i < this.tSize.length; i++){

	      Methodes M = new Methodes(this.tSize[i]);

	      for(int j = 0; j < this.tRep[i]; j++){	      

		  M.aleaL(); /** nouvelle instance */
		  
		  startTime = System.nanoTime();
		  min = M.minimumTriL();
		  totalTime = (System.nanoTime() - startTime);
		  this.tRes[i] = this.tRes[i] + totalTime;
	      }
	      this.tRes[i] = this.tRes[i]/this.tRep[i];
	
	  }
    }
    /** ecrit dans tRes[] les moyennes de temps de calcul de minimumTriT
     * sur les nombres contenus dans tRep[] d'executions sur des donnees
     * dont les tailles sont indiquees dans tSize[] */

    public void mesureMinimumTriT(){
	double startTime;
	double totalTime;
	int min;
	
	this.resetRes();

	  for (int i=0; i < this.tSize.length; i++){

	      Methodes M = new Methodes(this.tSize[i]);

	      for(int j = 0; j < this.tRep[i]; j++){	      

		  M.aleaT(); /** nouvelle instance */
		  
		  startTime = System.nanoTime();
		  min = M.minimumTriT();
		  totalTime = (System.nanoTime() - startTime);
		  this.tRes[i] = this.tRes[i] + totalTime;
	      }
	      this.tRes[i] = this.tRes[i]/this.tRep[i];
	
	  }
    }


    /** ecrit dans tRes[] les moyennes de temps de calcul de mystereL sur
     * les nombres contenus dans tRep[] d'executions sur des donnees
     * dont les tailles sont indiquees dans tSize[] */

    public void mesureMystereL(){
	double startTime;
	double totalTime;
	
	this.resetRes();

	  for (int i=0; i < this.tSize.length; i++){

	      Methodes M = new Methodes(this.tSize[i]);

	      for(int j = 0; j < this.tRep[i]; j++){	      

		  M.aleaL(); /** nouvelle instance */
		  
		  startTime = System.nanoTime();
		  M.mystereL();
		  totalTime = (System.nanoTime() - startTime);
		  this.tRes[i] = this.tRes[i] + totalTime;
	      }
	      this.tRes[i] = this.tRes[i]/this.tRep[i];
	
	  }
    }
    /** ecrit dans tRes[] les moyennes de temps de calcul de mystereT sur
     * les nombres contenus dans tRep[] d'executions sur des donnees
     * dont les tailles sont indiquees dans tSize[] */

    public void mesureMystereT(){
	double startTime;
	double totalTime;
	
	this.resetRes();

	  for (int i=0; i < this.tSize.length; i++){

	      Methodes M = new Methodes(this.tSize[i]);

	      for(int j = 0; j < this.tRep[i]; j++){	      

		  M.aleaT(); /** nouvelle instance */
		  
		  startTime = System.nanoTime();
		  M.mystereT();
		  totalTime = (System.nanoTime() - startTime);
		  this.tRes[i] = this.tRes[i] + totalTime;
	      }
	      this.tRes[i] = this.tRes[i]/this.tRep[i];
	
	  }
    }

    /** ecrit dans tRes[] les moyennes de temps de calcul de aleaL sur
     * les nombres contenus dans tRep[] d'executions sur des donnees
     * dont les tailles sont indiquees dans tSize[] */
    
    public void mesureAleaL(){
	double startTime;
	double totalTime;
	
	this.resetRes();

	for (int i=0; i < this.tSize.length; i++){
	    
	    Methodes M = new Methodes(this.tSize[i]);
	    
	    for(int j = 0; j < this.tRep[i]; j++){	      
		startTime = System.nanoTime();
		M.aleaL();
		totalTime = (System.nanoTime() - startTime);
		this.tRes[i] = this.tRes[i] + totalTime;
	    }
	    this.tRes[i] = this.tRes[i]/this.tRep[i];	
	}
    }
     /** ecrit dans tRes[] les moyennes de temps de calcul de aleaT sur
     * les nombres contenus dans tRep[] d'executions sur des donnees
     * dont les tailles sont indiquees dans tSize[] */
    
    public void mesureAleaT(){
	double startTime;
	double totalTime;

	this.resetRes();
	
	for (int i=0; i < this.tSize.length; i++){
	    
	    Methodes M = new Methodes(this.tSize[i]);
	    
	    for(int j = 0; j < this.tRep[i]; j++){	      
		startTime = System.nanoTime();
		M.aleaT();
		totalTime = (System.nanoTime() - startTime);
		this.tRes[i] = this.tRes[i] + totalTime;
	    }
	    this.tRes[i] = this.tRes[i]/this.tRep[i];	
	}
    }
   
    /**************************************************************************
     **************************************************************************
     *********************** FONCTIONS DE REFERENCE ***************************
     **************************************************************************
     *************************************************************************/


    /** ecrit dans tRes[] les valeurs de la fonction de reference log n
     * pour les valeurs de n contenues dans tSize[] */
    public void refLog (double k){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] = Math.log(Math.pow(this.tSize[i],k));
	    }
    }

    /** ecrit dans tRes[] les valeurs de la fonction de reference n^k
     * pour les valeurs de n contenues dans tSize[] */
        public void refNpK (double k){
	for (int i=0; i < this.tSize.length; i++){
		this.tRes[i] = Math.pow(this.tSize[i],k);
	    }
    }

    /** ecrit dans tRes[] les valeurs de la fonction de reference n log n
     * pour les valeurs de n contenues dans tSize[] */
    public void refNlogn (){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] = Math.log(this.tSize[i])*((double)this.tSize[i]);
	    }
    }

    /** ecrit dans tRes[] les valeurs de la fonction de reference exp
     * pour les valeurs de n contenues dans tSize[] */
    public void refExp (){
	for (int i=0; i < this.tSize.length; i++){
		this.tRes[i] = Math.exp(this.tSize[i]);
	    }
    }

    /** ecrit dans tRes[] les valeurs de la fonction de reference k^n
     * pour les valeurs de n contenues dans tSize[] */
    public void refKpN (double k){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] = Math.pow(k,this.tSize[i]);
	    }
    }

    /**************************************************************************
     **************************************************************************
     ****************** RAPPORTS ENTRE FONCTIONS DE REFERENCE *****************
     **************************************************************************
     *************************************************************************/

    /** ecrit dans tRes[] les valeurs du rapport log(n)/log(n^k) pour
     * les valeurs de n contenues dans tSize[] */
     public void rapportLogLogK (double k){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] =  Math.log(this.tSize[i])/Math.log(Math.pow(this.tSize[i],k));
	    }
    }
    /** ecrit dans tRes[] les valeurs du rapport log(n^k)/log(n) pour
     * les valeurs de n contenues dans tSize[] */
    public void rapportLogKLog (double k){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] =  Math.log(Math.pow(this.tSize[i],k))/Math.log(this.tSize[i]);
	    }
    }

    /** ecrit dans tRes[] les valeurs du rapport (n^epsi)/log(n) pour
    * les valeurs de n contenues dans tSize[] */
    public void rapportNepsiLog (double epsi){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] =  Math.pow(this.tSize[i],epsi)/Math.log(this.tSize[i]);
	    }
    }

    /** ecrit dans tRes[] les valeurs du rapport log(n)/(n^epsi) pour
    * les valeurs de n contenues dans tSize[] */
    public void rapportLogNepsi (double epsi){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] = Math.log(this.tSize[i])/ Math.pow(this.tSize[i],epsi);
	    }
    }

    /** ecrit dans tRes[] les valeurs du rapport (2^n)/(n^k) pour les
    * valeurs de n contenues dans tSize[] */
    public void rapport2pNNpK (double k){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] = Math.pow(2,this.tSize[i])/Math.pow(this.tSize[i],k);
	    }
    }

    /** ecrit dans tRes[] les valeurs du rapport (n^k)/(2^n) pour les
    * valeurs de n contenues dans tSize[] */
    public void rapportNpK2pN (double k){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] = Math.pow(this.tSize[i],k)/Math.pow(2,this.tSize[i]);
	    }
    }

    /** ecrit dans tRes[] les valeurs du rapport (k^n)/(2^n) pour les
    * valeurs de n contenues dans tSize[] */
    public void rapportKpN2pN (double k){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] = Math.pow(k,this.tSize[i])/Math.pow(2,this.tSize[i]);
	    }
    }
    /** ecrit dans tRes[] les valeurs du rapport (2^n)/(k^n) pour les
    * valeurs de n contenues dans tSize[] */
    public void rapport2pNKpN (double k){
	for (int i=0; i < this.tSize.length; i++){
	    this.tRes[i] = Math.pow(2,this.tSize[i])/Math.pow(k,this.tSize[i]);
	    }
    }

    /**************************************************************************
     **************************************************************************
     ************************* RESULTATS DES MESURES **************************
     **************************************************************************
     *************************************************************************/

    /** remise à 0 du tableau tRes[] */
    public void resetRes(){
	for (int i = 0; i < this.tRes.length; i++){
	    this.tRes[i] = 0;
	}
    }
   
    /** retourne une copie du tableau tRes[], pour recuperer les
     * resultats entre deux appels a des methodes mesureNomAlgorithme
     * ou refNomFonctionDeReference ou encore rapportNomsFonctions*/
    public double[] getRes(){
	
	double copie[] = new  double[this.tRes.length];
	for (int i = 0; i < this.tRes.length; i++){
	    copie[i] = this.tRes[i];
	}
	return copie;
    }

    
    /** retourne une copie du tableau tRes[] dont chaque element a ete
     * multiplie par le facteur factor */
    public double[] scaledRes(double factor){
	double[] tmp = new double[this.tRes.length];

	for (int i=0; i < this.tRes.length; i++){
	    tmp[i] = factor * this.tRes[i];
	}
	return tmp;
    }
  
    
    /** affiche les valeurs contenues dans le tableau a deux dimension
     * res en faisant preceder chaque ligne de la taille de donnee
     * contenue dans tSize[]. Les tableaux res[j] pour j verifiant 0
     * <= j < res.length sont ainsi affiches en colonnes successives
     * apres la colonne tSize[]. */
    public void output (double[][] res){
    
	    for (int i = 0 ; i < res[0].length ; i++) {
			System.out.print(""+this.tSize[i]);
		for (int j = 0 ; j < res.length ; j++) {
		    System.out.print(" "+res[j][i]);
		}
		System.out.print("\n");
	    }
	
    }

    /**************************************************************************
     **************************************************************************
     ********************************* MAIN ***********************************
     **************************************************************************
     *************************************************************************/


    public static void main(String[] arg) throws Exception {
	
	if (arg.length < 1){
	    System.out.println("toto !");
	}
	else {

	    int size0[] = {2,10,20,30,40,50,100,150,200,300,400,500,1000,1500,2000,5000,10000,25000,50000,75000,100000,250000,500000};
	    int rep0[] = {1,1,1,1,1,1,2,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1};
//
	    int repetitionFaible[] = {100,200,300,400,100,300,300,400,500,600,800,600,500,4,7,5,87,9,1,1,1,1,1};	    
//
	    double scale0[] = {200,300,400,500,600};

	    int choix = Integer.parseInt(arg[0]);
	    int nbCourbe0 = scale0.length + 1;
	    double[][] res0 = new double[nbCourbe0][size0.length];
		
		Mesure M0 = new Mesure(size0,rep0);
		Mesure mesureFaibleRepetition = new Mesure(size0,repetitionFaible);

	    switch (choix) {
	    case 0:   
		
		M0.mesureAleaT();
		res0[0] = M0.getRes();

		M0.mesureAleaL();
		res0[1] = M0.getRes();

		mesureFaibleRepetition.mesureAleaT();
		res0[2] = mesureFaibleRepetition.getRes();
 
		mesureFaibleRepetition.mesureAleaL();
		res0[3] = mesureFaibleRepetition.getRes();

		M0.output(res0);

	    break;  
            case 1:   
		
		M0.mesureRechercheT();
		res0[0] = M0.getRes();

		M0.mesureRechercheL();
		res0[1] = M0.getRes();

		mesureFaibleRepetition.mesureRechercheT();
		res0[2] = mesureFaibleRepetition.getRes();
 
		mesureFaibleRepetition.mesureRechercheL();
		res0[3] = mesureFaibleRepetition.getRes();

		M0.output(res0);

	    break;
	    
	    case 2: 
  
		M0.mesureMinimumSimpleT();
		res0[0] = M0.getRes();

		M0.mesureMinimumSimpleL();
		res0[1] = M0.getRes();

		mesureFaibleRepetition.mesureMinimumSimpleT();
		res0[2] = mesureFaibleRepetition.getRes();
 
		mesureFaibleRepetition.mesureMinimumSimpleL();
		res0[3] = mesureFaibleRepetition.getRes();

		M0.output(res0);

	    break;     
  
	    case 3: 
  
		M0.mesureMinimumTriT();
		res0[0] = M0.getRes();

		M0.mesureMinimumTriL();
		res0[1] = M0.getRes();

		mesureFaibleRepetition.mesureMinimumTriT();
		res0[2] = mesureFaibleRepetition.getRes();
 
		mesureFaibleRepetition.mesureMinimumTriL();
		res0[3] = mesureFaibleRepetition.getRes();

		M0.output(res0);

	    break;   
   

	    case 4: 
  
		M0.mesureMinimumTriT();
		res0[0] = M0.getRes();

		M0.mesureMinimumSimpleT();
		res0[1] = M0.getRes();

		mesureFaibleRepetition.mesureMinimumTriT();
		res0[2] = mesureFaibleRepetition.getRes();
 
		mesureFaibleRepetition.mesureMinimumSimpleT();
		res0[3] = mesureFaibleRepetition.getRes();

		M0.output(res0);

	    break;  

		case 5: 
  
		M0.mesureMinimumTriL();
		res0[0] = M0.getRes();

		M0.mesureMinimumSimpleL();
		res0[1] = M0.getRes();

		mesureFaibleRepetition.mesureMinimumTriL();
		res0[2] = mesureFaibleRepetition.getRes();
 
		mesureFaibleRepetition.mesureMinimumSimpleL();
		res0[3] = mesureFaibleRepetition.getRes();

		M0.output(res0);

	    break;  

 		case 6:
		int nbCourbeCas6 = 5;
		double [][] resCas6 = new double[nbCourbeCas6][size0.length];

		//pour k = 2
		M0.refLog(2.);
		resCas6[0] = M0.getRes();

		//pour k = 2
		M0.refNpK(2.);
		resCas6[1] = M0.getRes();
		
		M0.refNlogn();
		resCas6[2] = M0.getRes();
		
		M0.refExp();
		resCas6[3] = M0.getRes();
		
		//pour k = 2
		M0.refKpN(2.);
		resCas6[4] = M0.getRes();

		M0.output(resCas6);
        
		break;
		
	    case 7:

		//pour k = 2
		M0.rapportLogKLog(2.);
		res0[0] = M0.getRes();

		//pour k = 3
		M0.rapportLogKLog(3.);
		res0[1] = M0.getRes();
		
		//pour k = 4
		M0.rapportLogKLog(4.); 
		res0[2] = M0.getRes();
		
		//pour k = 5
		M0.rapportLogKLog(5.);
		res0[3] = M0.getRes();

		M0.output(res0);
        
		break;
				
	    case 8:
		int nbCourbeCas8 = 6;
		double [][] resCas8 = new double[nbCourbeCas8][size0.length];

		//pour e = 1
		M0.rapportNepsiLog(1.);
		resCas8[0] = M0.getRes();

		//pour e = 2
		M0.rapportNepsiLog(2.);
		resCas8[1] = M0.getRes();

		//pour e = 3
		M0.rapportNepsiLog(3.);
		resCas8[2] = M0.getRes();
		
		//pour e = 4
		M0.rapportNepsiLog(4.);
		resCas8[3] = M0.getRes();
		
		//pour e = 5
		M0.rapportNepsiLog(5.);
		resCas8[4] = M0.getRes();

		M0.output(resCas8);
        
		break;

		case 9:
		int nbCourbeCas9 = 6;
		double [][] resCas9 = new double[nbCourbeCas9][size0.length];

		//pour e = 1
		M0.rapportLogNepsi(1.);
		resCas9[0] = M0.getRes();
		
		//pour e = 2
		M0.rapportLogNepsi(2.);
		resCas9[1] = M0.getRes();

		//pour e = 3
		M0.rapportLogNepsi(3.);
		resCas9[2] = M0.getRes();
		
		//pour e = 4
		M0.rapportLogNepsi(4.);
		resCas9[3] = M0.getRes();
		
		//pour e = 5
		M0.rapportLogNepsi(5.);
		resCas9[4] = M0.getRes();

		M0.output(resCas9);
        
		break;

		case 10:
		int nbCourbeCas10 = 5;
		double [][] resCas10 = new double[nbCourbeCas10][size0.length];
		
		//pour k = 1
		M0.rapportNpK2pN(1.);
		resCas10[0] = M0.getRes();
		
		//pour k = 2
		M0.rapportNpK2pN(2.);
		resCas10[1] = M0.getRes();

		//pour k = 3
		M0.rapportNpK2pN(3.);
		resCas10[2] = M0.getRes();
		
		//pour k = 4
		M0.rapportNpK2pN(4.);
		resCas10[3] = M0.getRes();
		
		//pour k = 5
		M0.rapportNpK2pN(5.);
		resCas10[4] = M0.getRes();

		M0.output(resCas10);
        
		break;
		
	    case 11:
		int nbCourbeCas11 = 5;
		double [][] resCas11 = new double[nbCourbeCas11][size0.length];

		M0.rapport2pNNpK(1.);//pour k = 1
		resCas11[0] = M0.getRes();
		
		M0.rapport2pNNpK(2.);//pour k = 2
		resCas11[1] = M0.getRes();

		M0.rapport2pNNpK(3.);//pour k = 3
		resCas11[2] = M0.getRes();
		
		M0.rapport2pNNpK(4.);//pour k = 4
		resCas11[3] = M0.getRes();
		
		M0.rapport2pNNpK(5.);//pour k = 5
		resCas11[4] = M0.getRes();

		M0.output(resCas11);

		break;


 		case 12:
		int nbCourbeCas12 = 3;
		double [][] resCas12 = new double[nbCourbeCas12][size0.length];

		M0.rapportKpN2pN(3.);//pour k = 3
		resCas12[0] = M0.getRes();
		
		M0.rapportKpN2pN(4.);//pour k = 4
		resCas12[1] = M0.getRes();

		M0.rapportKpN2pN(5.);//pour k = 5
		resCas12[2] = M0.getRes();
	
		M0.output(resCas12);
        
		break;
		
	     case 13:
		int nbCourbeCas13 = 3;
		double [][] resCas13 = new double[nbCourbeCas13][size0.length];

		M0.rapport2pNKpN(3.);//pour k = 3
		resCas13[0] = M0.getRes();
		
		M0.rapport2pNKpN(4.);//pour k = 4
		resCas13[1] = M0.getRes();

		M0.rapport2pNKpN(5.);//pour k = 5
		resCas13[2] = M0.getRes();


		M0.output(resCas13);
        
		break;

	    default:
		break;

	    }	    

	}
    }
}
