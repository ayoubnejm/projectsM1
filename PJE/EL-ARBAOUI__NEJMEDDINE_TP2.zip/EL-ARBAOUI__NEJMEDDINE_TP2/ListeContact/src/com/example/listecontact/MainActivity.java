package com.example.listecontact;

import java.util.ArrayList;
import java.util.List;



import com.example.listecontact.R;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	public static final int CODE_RETOUR = 0;
	ArrayList<Contact> listPers = new ArrayList<Contact>();
	ListView contactListe;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
        Button button = (Button) findViewById(R.id.Ajouter);
        
        button.setOnClickListener(new OnClickListener() {        	
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	Intent intent = new Intent(MainActivity.this, DisplayAddContactActivity.class);
            	startActivityForResult(intent,CODE_RETOUR );
            }
        });
        

		contactListe = (ListView)findViewById(R.id.contactListe);
		List<Contact> maListContact = RemplirLaListeContacts();
		ContactAdapter adapter = new ContactAdapter(this, maListContact);
		
		contactListe.setAdapter(adapter);

	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	
	
	
	/**
	 * Initialise une liste de Contacts
	 * @return une liste de "Contact"
	 */

	private List<Contact> RemplirLaListeContacts() {
		
		
		listPers.add(new Contact("Ayoub", "NEJMEDDINE", "0619345678"));
		listPers.add(new Contact("Sara", "EL ARBAOUI", "0622345678"));
		listPers.add(new Contact("Rasha", "EL MAJDOUB", "0632345678"));
		listPers.add(new Contact("Sacha", "DUFOUR", "0642345678"));
		listPers.add(new Contact("Omar", "EL ARBAOUI", "0652345678"));
		listPers.add(new Contact("Malika", "CHYAT", "0662345678"));
		
		
		return listPers;
	}
	
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

    	// Vérification du code de retour
    	if(requestCode == CODE_RETOUR) {

    		// Vérifie que le résultat est OK
    		if(resultCode == RESULT_OK) {

    			// On récupére le paramètre "Nom" de l'intent
    			String nom = data.getStringExtra("Nom");
    			String prenom = data.getStringExtra("Prenom");
    			String telephone = data.getStringExtra("Telephone");
    			String email = data.getStringExtra("Email");
    			
    			listPers.add(new Contact(nom,prenom,telephone)) ;
    			
    			 contactListe =(ListView)findViewById(R.id.contactListe);
    		     ContactAdapter adapter = new  ContactAdapter(this, listPers);      		        
    		     contactListe.setAdapter(adapter);
    		        
    			// Test : On affiche le résultat
      			Toast.makeText(this, "Votre nom est : " + nom, Toast.LENGTH_SHORT).show();
				Toast.makeText(this, "Votre prenom est : " + prenom, Toast.LENGTH_SHORT).show();
    			Toast.makeText(this, "Votre telephon est : " + telephone, Toast.LENGTH_SHORT).show();
    			Toast.makeText(this, "Votre mail est : " + email, Toast.LENGTH_SHORT).show();

    		// Si l'activité est annulé
    		} else if (resultCode == RESULT_CANCELED) {

    			// On affiche que l'opération est annulée
    			Toast.makeText(this, "Opération annulé", Toast.LENGTH_SHORT).show();

    		}

    	}

    }

}
