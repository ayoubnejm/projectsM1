package com.example.listecontact;

public class Contact {
		
	public String nom;
	public String prenom;
	public String tel;
	
	public Contact(String aPrenom, String aNom, String aTel) {
		prenom = aPrenom; 
		nom = aNom;
		tel = aTel;
	}
	
	
	public String getNom() {
		return nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public String getTel() {
		return tel;
	}

	public void setNom(String n){
		this.nom = n;
	}
	
	public void setPrenom(String p){
		this.prenom = p;
	}
	
	public void setTel(String t){
		this.tel = t;
	}
	
	

}