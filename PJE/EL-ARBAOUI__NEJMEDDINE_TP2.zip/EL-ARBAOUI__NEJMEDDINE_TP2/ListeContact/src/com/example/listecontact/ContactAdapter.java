package com.example.listecontact;

import java.util.List;

import com.example.listecontact.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ContactAdapter extends BaseAdapter {

	
	List<Contact> listContacts;

	LayoutInflater inflater;

	public ContactAdapter(Context context,List<Contact> listContacts) {
		inflater = LayoutInflater.from(context);
		this.listContacts = listContacts;
	}
	
	@Override
	public int getCount() {
		return listContacts.size();
	}

	@Override
	public Object getItem(int position) {
		return listContacts.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	
	private class ViewHolder {
		TextView nomEtPrenom;
		TextView tel;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder holder;

		if(convertView == null) {
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.itemcontact, null);

			holder.nomEtPrenom = (TextView)convertView.findViewById(R.id.nomEtPrenom);
			holder.tel = (TextView)convertView.findViewById(R.id.tel);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		holder.nomEtPrenom.setText(listContacts.get(position).getPrenom()+" "+listContacts.get(position).getNom());
		holder.tel.setText(listContacts.get(position).getTel());

		return convertView;

	}
}
