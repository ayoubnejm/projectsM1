package com.example.listecontact;



import android.os.Build;
import android.os.Bundle;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.support.v4.app.NavUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;


public class DisplayAddContactActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_contact);
		// Show the Up button in the action bar.
		final EditText nom = (EditText) findViewById(R.id.enom);
		final EditText prenom = (EditText) findViewById(R.id.eprenom);
		final EditText telephone = (EditText) findViewById(R.id.etele);
		final EditText email = (EditText) findViewById(R.id.eemail);
		
		
		Button button = (Button) findViewById(R.id.Valider);
        
        button.setOnClickListener(new OnClickListener() {        	
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	Intent intent = new Intent(DisplayAddContactActivity.this, MainActivity.class);
            	intent.putExtra("Nom", nom.getText().toString());
            	intent.putExtra("Prenom", prenom.getText().toString());
            	intent.putExtra("Telephone", telephone.getText().toString());
            	intent.putExtra("Email", email.getText().toString());
            	
        		setResult(RESULT_OK, intent);
        		finish();
            }
        });
		setupActionBar();
	}

	/**
	 * Set up the {@link android.app.ActionBar}, if the API is available.
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private void setupActionBar() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			getActionBar().setDisplayHomeAsUpEnabled(true);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.add_contact, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			
			NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
