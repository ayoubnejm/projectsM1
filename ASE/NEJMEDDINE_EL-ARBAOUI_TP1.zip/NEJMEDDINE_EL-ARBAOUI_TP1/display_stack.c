#include <stdio.h>

#include "try.h"

int main (void) {
 
  void* x, *y;

	/* Position ESP */
  asm ("movl %%esp, %0"
       : "=r" (y)
       );

	/* Position EBP */
  asm ("movl %%ebp, %0"
       : "=r" (x)
       );

	/* Affichage des adresses de Esp et Ebp */
   printf("Ebp value: %p\nEsp value: %p\n",x,y);

   return 0;
}
