#include "try.h"
#include <stdio.h>
#include <stdlib.h>

static int status = 1;
static ctx_s contexte;

static int
mul(int depth)
{
  int i;

  if (!depth && status) {
    printf ("Try done\n");
    return 1*(try (&contexte,mul,depth+1));
  } else if (!status) {
    return 0;
  }	  
    switch (scanf("%d", &i)) {
    case EOF :
      printf ("EOF\n");
      return 1; /* neutral element */
    case 0 :
      printf ("error\n");
      return mul(depth+1); /* erroneous read */
    case 1 :
      if (i) {
	printf ("Value not null\n");
	return i * mul(depth+1);
      } else {
	printf ("Value null\n");
	status = throw(&contexte,0);
      }
  }

}

int
main()
{
  int product;
  printf("A list of int, please\n");
  product = mul(0);
  printf("product = %d\n", product);
  return 0;
}
