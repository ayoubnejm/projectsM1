#include "try.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

/* Fonction "try" */ 

int try(ctx_s *pctx, func_t *f, int arg) {

	/* Extraction du pointeur ESP */
  asm ("movl %%esp, %0"
       : "=r" (pctx->ctx_esp)
       );

	/* Extraction du pointeur EBP */
  asm ("movl %%ebp, %0"
       : "=r" (pctx->ctx_ebp)
       );
  
  return f(arg);
}

int throw(ctx_s *pctx, int r) {

  asm ("movl %0, %%esp"
       :
       : "r" (pctx->ctx_esp)
       );

  asm ("movl %0, %%ebp"
       :
       : "r" (pctx->ctx_ebp)
       );

  return r;
}
