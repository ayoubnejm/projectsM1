

#ifndef _MOUNT_H_
#define _MOUNT_H_

/*  initialize hardware, mount the "current" volume
    configuration with the $HW_CONFIG and $CURRENT_VOLUME environment
    variables. 
 */
void mount();
void umount();

#endif
