

#ifndef _CONFIG_H_
#define _CONFIG_H_

#define DEFAULT_HW_CONFIG "hardware.ini"

#endif
