#include <stdio.h>
#include <stdlib.h>

#include "vol.h"
#include "drive.h"

#define MAX_ARG     3

int main(int argc, char** argv)
{
    char* volume_string;
    char* nom;
    char resp;

    unsigned int serial;
    unsigned int volume;

    volume_string = getenv("$CURRENT_VOLUME");
    
    if (!volume_string)
    {
        printf("ATTENTION: Aucun volume declare dans $CURRENT_VOLUME ou sa valeur est incorrecte, le volume 0 sera utilise.\n");
        volume = 0;
    }
    else
        volume = atoi(volume_string);
    
    if (argc < MAX_ARG)
    {
        printf("Usage: %s Nom Serial\n", argv[0]);
        printf("Cree un nouveau systeme de fichier sur le volume designe par $CURRENT_VOLUME (0 par defaut) avec pour nom Nom et numero de serie Serial.\n");
        exit(EXIT_SUCCESS);
    }
    
    nom = argv[1];
    serial = atoi(argv[2]);
    
    printf("Creation du systeme de fichier de nom %s, de numero de serie %u sur le volume %u.\n", nom, serial, volume);
    do
    {
        printf("\n");
        printf("Est-ce correct (o/n) ? ");
    }
    while (scanf("%c", &resp) != 1 || (resp != 'o' && resp != 'n'));
    
    if (resp == 'n')
    {
        printf("Abandon de la procedure par l'utilisateur.\n");
        exit(EXIT_SUCCESS);
    }
    
    /* All ok, go */
    loadDiskInfo();
    init_super(volume);
    set_name(nom);
    set_serial(serial);
    
    exit(EXIT_SUCCESS);
}

