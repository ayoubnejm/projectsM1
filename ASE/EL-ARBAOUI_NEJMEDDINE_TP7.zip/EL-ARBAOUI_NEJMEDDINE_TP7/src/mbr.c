#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "tools/tools.h"
#include "mbr.h"
#include "drive.h"

static mbr_t mbr;

uint getMbrVolumeNumber()        { return mbr.mbr_n_vol; }

vol_t* getVolume(uint vol)
{
    if (vol >= MAX_VOLUME || vol >= mbr.mbr_n_vol)
        return NULL;
    
    return &mbr.mbr_vol[vol];
}

void addVolume(uint place, vol_t vol)
{
    if (place >= MAX_VOLUME || place > mbr.mbr_n_vol)
        return;

    if (mbr.mbr_n_vol > 0)
        for (uint j = mbr.mbr_n_vol - 1; j > place; --j)
            mbr.mbr_vol[j + 1] = mbr.mbr_vol[j];
    
    mbr.mbr_vol[place] = vol;
    mbr.mbr_n_vol += 1;
}

void delVolume(uint place)
{
    if (mbr.mbr_n_vol > 1)
        for (uint j = place; j < mbr.mbr_n_vol - 1; ++j)
            mbr.mbr_vol[j] = mbr.mbr_vol[j + 1];
        
    mbr.mbr_n_vol -= 1;
}

int load_mbr()
{
    /* Le mbr est il deja charge ? */
    if (mbr.mbr_magic == MBR_MAGIC)
        return RETURN_SUCCESS;

    unsigned char* buffer;

    if (sizeof(mbr_t) > getSectorSize())
        return ERROR_MBR_TOO_LARGE;
    /* malloc car n'oublions pas que getSectorSize() est une variable */
    buffer = (unsigned char*)malloc(sizeof(char)*getSectorSize());

    read_sector(0, 0, buffer);
    
    memcpy(&mbr, buffer, sizeof(mbr_t));
    free(buffer);

    if (mbr.mbr_magic != MBR_MAGIC)
    {
        mbr.mbr_magic = MBR_MAGIC;
        mbr.mbr_n_vol = 0;
        return ERROR_BAD_STRUCTURE_FORMAT;
    }
    
    return RETURN_SUCCESS;
}

int save_mbr()
{
    unsigned char* buffer;

    if (sizeof(mbr_t) > getSectorSize())
        return ERROR_MBR_TOO_LARGE;

    /* Ne pas enregistrer un MBR incorrect */
    if (mbr.mbr_magic != MBR_MAGIC)
        return ERROR_BAD_STRUCTURE_FORMAT;
        
    buffer = (unsigned char*)malloc(sizeof(char)*getSectorSize());
        
    memcpy(buffer, &mbr, sizeof(mbr_t));
    
    write_sector(0, 0, buffer);
    
    free(buffer);
    return RETURN_SUCCESS;
}

int block_to_sector(uint num_vol, uint num_block, uint* num_cylinder, uint* num_sector)
{
    unsigned int max_sect;

    if (num_vol >= mbr.mbr_n_vol)
        return RETURN_FAILURE;
        
    max_sect = getMaxSectorPerCyl();

    /* Moins de block que necessaire pour passer au cylinbdre suivant */
    if (mbr.mbr_vol[num_vol].vol_first_sector + num_block < max_sect)
    {
        *num_cylinder = mbr.mbr_vol[num_vol].vol_first_cylinder;
        *num_sector = mbr.mbr_vol[num_vol].vol_first_sector + num_block;
        return RETURN_SUCCESS;
    }
    
    /* On enleve le nombre de block permettant de passer au cylinder suivant, ce qui fait qu'on ajoutera 1 apres */
    int nb_more_block = num_block - (max_sect - mbr.mbr_vol[num_vol].vol_first_sector);
    
    /* (nb_more_block / MAX_SECTOR) => resultat division entiere */
    *num_cylinder = mbr.mbr_vol[num_vol].vol_first_cylinder + 1 + (nb_more_block / max_sect);
    *num_sector = nb_more_block % max_sect;
    return RETURN_SUCCESS;
}

int sector_pos_to_block(uint cyl_start, uint sec_start, uint cyl_end, uint sec_end)
{
    if (cyl_end < cyl_start)
        return 0;
    
    if (cyl_start == cyl_end)
    {
        if (sec_start > sec_end)
            return 0;
        else
            return sec_end - sec_start - 1; /* -1 => on veut le nombre de bloc libre entre */
    }
    /* place restante sur le premier cylindre + taille des cylindre libres intermediaires + nombre de block avt le sec_end */
    return (getMaxSectorPerCyl() - sec_start - 1) + ((cyl_end - (cyl_start + 1)) * getMaxSectorPerCyl()) + (sec_end - 1);
}

void read_block(uint vol, uint nblock, unsigned char* buffer)
{
    uint cylinder;
    uint sector;
    
    if (block_to_sector(vol, nblock, &cylinder, &sector) == RETURN_SUCCESS)
        read_sector(cylinder, sector, buffer);
}

void write_block(uint vol, uint nblock, const unsigned char* buffer)
{
    uint cylinder;
    uint sector;
    
    if (block_to_sector(vol, nblock, &cylinder, &sector) == RETURN_SUCCESS)
        write_sector(cylinder, sector, buffer);
}

void format_vol(uint vol)
{
    uint cylinder_start, cylinder_end;
    uint sector_start, sector_end;
    
    /* Le check sur l'existence du volume est fait dans le 1er block_to_sector, on peux 
     * donc utiliser mbr_vol[vol] dans le second avec l'evaluation paresseuse */
    if (block_to_sector(vol, 0, &cylinder_start, &sector_start) == RETURN_SUCCESS
        && block_to_sector(vol, mbr.mbr_vol[vol].vol_n_bloc, &cylinder_end, &sector_end) == RETURN_SUCCESS)
    {
        /* on formate la fin du cylindre principal s'il n'y en a qu'un
         * sur une taille de sector_end - sector_start secteurs */
        if (cylinder_start == cylinder_end)
        {
            format_sector(cylinder_start, sector_start, sector_end - sector_start, 0x00);
            return;
        }
        /* Si le volume s'etent sur plus d'un cylindre, on formate completement les cylindre intermediaires */
        for (uint i = cylinder_start + 1;i < cylinder_end; ++i) 
            format_sector(i, 0, getMaxSectorPerCyl(), 0x00);
        
        /* enfin, on formate les secteur restants sur le dernier cylindre */
        format_sector(cylinder_end, 0, sector_end, 0x00);
    }
        
}

/*Fonction type_to_string*/
char * type_to_string (enum vol_type_e type) {
	
if (type == BASE) return "base";
if (type == ANNEXE) return "annexe";
if (type == OTHER) return "other";

exit(EXIT_FAILURE);
}

/* Procédure "mbr_info" */
void mbr_info() {
	int i;
		
	printf("Nombre de volumes : %d \n", mbr.mbr_n_vol);
	
	char couleur[8][6]= {"\033[37m","\033[31m","\033[32m","\033[33m","\033[34m","\033[35m","\033[36m","\033[37m"};
	
	for (i=0; i < mbr.mbr_n_vol; i++) {
		printf("%s\033[40m volume n°%d : (%d,%d,%d,%s)\033[00m\n",
		couleur[i],
		i,
		mbr.mbr_vol[i].vol_first_cylinder,
		mbr.mbr_vol[i].vol_first_sector,
		mbr.mbr_vol[i].vol_n_bloc,
		type_to_string(mbr.mbr_vol[i].type_vol)
		);
	}
	printf("\n");
}

