#ifndef _VOL_H_
#define _VOL_H_

#define SUPER_MAGIC    0xDEADFACE
#define BLOCK_MAGIC    0xDEADBABE
#define MAX_NAMESIZE   32

typedef struct free_space_s {

    unsigned int block_magic;

    unsigned int first_block;

    unsigned int size;

    unsigned int next;

} free_space_t;

typedef struct super_s {

    unsigned int super_magic; /* SUPER_MAGIC */ 

    unsigned int super_root;

    char super_name[MAX_NAMESIZE];

    unsigned int super_serial;

    unsigned int first_free_block;

} super_t;

extern unsigned int current_volume;

void setCurrent_Volume(unsigned int vol);

unsigned int getCurrent_Volume();

void init_super(unsigned int vol);

int load_super(unsigned int vol);

void save_super();

unsigned int new_bloc();

void free_bloc(unsigned int bloc);

void set_name(char* name);

void set_serial(unsigned int serial);

char* get_volume_name();

unsigned int get_volume_serial();

unsigned int get_total_space();

unsigned int get_free_space();

#endif

