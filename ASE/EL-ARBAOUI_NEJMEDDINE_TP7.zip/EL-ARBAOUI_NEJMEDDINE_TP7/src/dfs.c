#include <stdio.h>

#include "tools/tools.h"
#include "tools/mount.h"
#include "mbr.h"
#include "drive.h"
#include "vol.h"

int main()
{
    mount();
    
    uint max_vol = getMbrVolumeNumber();
    for (uint i = 0; i < max_vol; ++i)
    {
        if (load_super(i) == RETURN_SUCCESS)
        {
            printf("Volume %u : dispose d'un systeme de fichier.\n", i);
            printf("%s : Nb total de blocs => %u, nb bloc libres => %u.\n", get_volume_name(), get_total_space(), get_free_space());
        }
        else
        {
            printf("Volume %u : pas de systeme de fichier.\n", i);
        }
    }
    
    umount();
}
