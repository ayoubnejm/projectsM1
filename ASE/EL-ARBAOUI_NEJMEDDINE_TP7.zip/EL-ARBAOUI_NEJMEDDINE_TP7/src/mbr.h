#ifndef _MBR_H_
#define _MBR_H_

#define MBR_MAGIC                   0xB16B00B5
#define MAX_VOLUME                  8

#define ERROR_MBR_TOO_LARGE         -1
#define ERROR_BAD_STRUCTURE_FORMAT  -2


typedef unsigned int uint;

enum vol_type_e {BASE, ANNEXE, OTHER};

typedef struct vol_s 
{
    uint vol_first_cylinder;
    uint vol_first_sector;
    uint vol_n_bloc;
    enum vol_type_e type_vol;
} vol_t;

typedef struct mbr_s
{
    uint mbr_magic;
    uint mbr_n_vol;
    vol_t mbr_vol[MAX_VOLUME];
} mbr_t;

uint getMbrVolumeNumber();

vol_t* getVolume(uint vol);

void addVolume(uint place, vol_t vol);

void delVolume(uint place);

void mbr_info();

int load_mbr();

int save_mbr();

/* block_to_sector: range dans num_cylinder et num_sector la position sur le 
 * disque du block num_block (a partir de 0) du volume num_vol
 * retourne RETURN_FAILURE en cas d'echec.
 */
int block_to_sector(uint num_vol, uint num_block, uint* num_cylinder, uint* num_sector);

/* sector_pos_to_block: retourne le nombre de bloc entre deux positions
 * sur le disque.
 */
int sector_pos_to_block(uint cyl_start, uint sec_start, uint cyl_end, uint sec_end);

void read_block(uint vol, uint nblock, unsigned char* buffer);

void write_block(uint vol, uint nblock, const unsigned char* buffer);

void format_vol(uint vol);

#endif

