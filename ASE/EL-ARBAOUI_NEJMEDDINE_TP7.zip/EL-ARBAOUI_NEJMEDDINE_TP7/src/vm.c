/* ------------------------------
   $Id: vm-skel.c,v 1.1 2002/10/21 07:16:29 marquet Exp $
   ------------------------------------------------------------

   Volume manager skeleton.
   Philippe Marquet, october 2002

   1- you must complete the NYI (not yet implemented) functions
   2- you may add commands (format, etc.)
   
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tools/tools.h"
#include "tools/mount.h"

#include "mbr.h"
#include "drive.h"

#define MAX_CHAR    256

/* ------------------------------
   command list
   ------------------------------------------------------------*/
struct _cmd {
    char *name;
    void (*fun) (struct _cmd *c);
    char *comment;
};

static void dvol(struct _cmd *c);
static void mkvol(struct _cmd *c);
static void del(struct _cmd *c);
static void help(struct _cmd *c) ;
static void save(struct _cmd *c);
static void quit(struct _cmd *c);
static void xit(struct _cmd *c);
static void infoMbr(struct _cmd *c) ;
static void none(struct _cmd *c) ;

static struct _cmd commands [] = {
    {"dvol", dvol, 	"display the partition table"},
	{"infoMbr", infoMbr,  "display the mbr info"},
    {"mkvol",  mkvol,	"make a new volume"},
    {"del",  del,	"delete a partition"},
    {"save", save,	"save the MBR"},
    {"quit", quit,	"save the MBR and quit"},
    {"exit", xit,	"exit (without saving)"},
    {"help", help,	"display this help"},
    {0, none, 		"unknown command, try help"}
} ;

/* ------------------------------
   dialog and execute 
   ------------------------------------------------------------*/

static void
execute(const char *name)
{
    struct _cmd *c = commands; 
  
    while (c->name && strcmp (name, c->name))
	c++;
    (*c->fun)(c);
}

static void
loop(void)
{
    char name[64];
    
    while (printf("> "), scanf("%62s", name) == 1)
	execute(name) ;
}

/* ------------------------------
   command execution 
   ------------------------------------------------------------*/
static void
dvol(struct _cmd *c)
{
    uint nbVol = getMbrVolumeNumber();

    if (!nbVol)
    {
        printf("No volumes or MBR loading failed.\n");
        return;
    }
    printf("Volume  :    cyl dep    :    sect dep   :   nb blocs    :      type\n");
    for (uint i = 0; i < nbVol; ++i)
    {
        vol_t* vol = getVolume(i);
        if (vol)
            printf("%i\t:\t%i\t:\t%i\t:\t%i\t:\t%i\n", i, vol->vol_first_cylinder, vol->vol_first_sector, vol->vol_n_bloc, vol->type_vol);
    }
    printf("Type: %i = BASE, %i = ANNEXE, %i = OTHER\n", BASE, ANNEXE, OTHER);
}


static void
infoMbr(struct _cmd *c)
{
	mbr_info();
}
static void
mkvol(struct _cmd *c)
{
    int size;
    uint nbVol = getMbrVolumeNumber();

    printf("Creation de volume : Entrez la taille (en nombre de blocs) souhaitee\n");
    if (scanf("%i", &size) != 1 || size < 1)
    {
        printf("Valeur incorrecte, entrez un entier superieur a 1.\n");
        printf("Operation annulee.\n");
        return;
    }
    
    /* peut on encore en creer ? */
    if (nbVol == MAX_VOLUME)
    {
        printf("Le disque contient deja le nombre maximum de volume possible.\n");
        return;
    }
    /* on sait maintenant qu'il y a au moins 1 place en fin de liste des volumes */

    struct vol_s new_vol;
    
    new_vol.vol_n_bloc = size;
    /* TODO: quel type ? decide par l'user ou defini ? */
    new_vol.type_vol = BASE;
    
    uint cyl_last_vol, sec_last_vol;
    int i = 0;
    /* on verifie si on peut caser la partition entre deux autres existantes (s'il y en a au moins 2) */
    if (nbVol > 1)
        for (; i < nbVol - 1; ++i)
        {
            uint cyl_start_vol2, sec_start_vol2;
            vol_t* vol = getVolume(i);
            if (!vol)
                continue;            
            
            block_to_sector(i, vol->vol_n_bloc - 1, &cyl_last_vol, &sec_last_vol);
            block_to_sector(i + 1, 0, &cyl_start_vol2, &sec_start_vol2);
            
            
            if (sector_pos_to_block(cyl_last_vol, sec_last_vol, cyl_start_vol2, sec_start_vol2) >= size)
                break; /* On va pouvoir creer le volume a cet endroit */
        }

    /* la boucle est elle allee jusqu'au bout ? ou simplement */
    if (i == nbVol - 1)
    {
        /* Pas d'espace entre les volumes existants pouvant etre exploite, 
         * y a t il assez de bloc entre le dernier volume et la fin du disque ?
         */
         
        vol_t* vol = getVolume(nbVol - 1);
        if (!vol) /*TODO: handle error ? It should NOT happen ! */
            return;

        block_to_sector(nbVol - 1, vol->vol_n_bloc - 1, &cyl_last_vol, &sec_last_vol);
        
        if (sector_pos_to_block(cyl_last_vol, sec_last_vol, getMaxCyl() - 1, getMaxSectorPerCyl() - 1) < size)
        {
            /* il n'y pas assez d'espace pour creer le nouveau volume */
            printf("Espace insuffisant pour creer un volume a la taille demandee !\n");
            return;
        }
    }
    else if (nbVol < 2)
    {
        /* 0 ou 1 volume, on regarde simplement la place derriere */
        if (nbVol)
        {
            vol_t* vol = getVolume(0);
            if (!vol) /*TODO: handle error ? It should NOT happen ! */
                return;
            block_to_sector(1, vol->vol_n_bloc - 1, &cyl_last_vol, &sec_last_vol);
        }
        else
        {
            cyl_last_vol = 0;
            sec_last_vol = 1; /* secteur 0 = MBR */
            i = -1;
        }
        
        if (sector_pos_to_block(cyl_last_vol, sec_last_vol, getMaxCyl() - 1, getMaxSectorPerCyl() - 1) < size)
        {
            /* il n'y pas assez d'espace pour creer le nouveau volume */
            printf("Espace insuffisant pour creer un volume a la taille demandee !\n");
            return;
        }
    }
    
    /* on a trouvé un espace a la taille demandee, on va creer le nouveau volume... */
    if (sec_last_vol == (getMaxSectorPerCyl() - 1))
    {
        new_vol.vol_first_cylinder =  cyl_last_vol + 1;
        new_vol.vol_first_sector = 0;
    }
    else
    {
        new_vol.vol_first_cylinder = cyl_last_vol;
        new_vol.vol_first_sector = sec_last_vol + 1;
    }
    /* ... et l'inserer a sa place, en decalant les autres dans la liste, pour conserver un ordre! */
    addVolume(i + 1, new_vol);
    
    printf("Volume %i cree avec succes !\n", i + 1);
    return;
}

static void
del(struct _cmd *c)
{
    int vol;

    printf("Suppression de volume : Entrez le numero du volume a supprimer\n");
    if (scanf("%i", &vol) != 1 || vol < 0 || vol >= getMbrVolumeNumber())
    {
        printf("Valeur incorrecte, entrez un entier positif et inferieur a %i.\n", getMbrVolumeNumber());
        printf("Operation annulee.\n");
        return;
    }
    
    delVolume(vol);

    printf("Volume %i supprime avec succes !.\n", vol);
}

static void
save(struct _cmd *c)
{
    if (save_mbr() == RETURN_SUCCESS)
        printf("MBR saved successfully.\n"); 
}

static void
quit(struct _cmd *c)
{
    int res = save_mbr();
    if (res == RETURN_SUCCESS)
    {
        printf("MBR saved successfully. Bye !\n"); 
        exit(EXIT_SUCCESS);
    }
    else
        printf("MBR save failed. Please check the MBR and try again or quit with exit to discard changes. (error code : %i)\n", res); 
}

static void
do_xit()
{
    exit(EXIT_SUCCESS);
}

static void
xit(struct _cmd *dummy)
{
    do_xit(); 
}

static void
help(struct _cmd *dummy)
{
    struct _cmd *c = commands;
  
    for (; c->name; c++) 
	printf ("%s\t-- %s\n", c->name, c->comment);
}

static void
none(struct _cmd *c)
{
    printf ("%s\n", c->comment) ;
}

int
main(int argc, char **argv)
{
    //mount();
    loadDiskInfo();
    
    /* Load MBR and current volume */
    int res = load_mbr();
    if (res != RETURN_SUCCESS)
        printf ("WARNING: Failed to load original MBR. (error code : %i)\n", res);
    /* dialog with user */ 
    loop();

    /* abnormal end of dialog (cause EOF for xample) */
    do_xit();
    
    //umount();
    
    /* make gcc -W happy */
    exit(EXIT_SUCCESS);
}
