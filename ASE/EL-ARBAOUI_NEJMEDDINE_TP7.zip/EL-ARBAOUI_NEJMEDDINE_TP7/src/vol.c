#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tools/tools.h"
#include "mbr.h"
#include "drive.h"
#include "vol.h"

static super_t super_block;
static free_space_t freeblock;
static vol_t* vol_p;
static uint vol_number;


/*static*/ unsigned int current_volume;

void setCurrent_Volume(unsigned int vol) { current_volume = vol; }

unsigned int getCurrent_Volume() { return current_volume; }

void set_name(char* name)
{
    strncpy(super_block.super_name, name, MAX_NAMESIZE);
    /* ensure super_name finish with null char */
    super_block.super_name[MAX_NAMESIZE - 1] = '\0';
    save_super();
}

void set_serial(unsigned int serial)
{
    super_block.super_serial = serial;
    save_super();
}

char* get_volume_name()          { return super_block.super_name; }

unsigned int get_volume_serial() { return super_block.super_serial; }

void write_freeblock(free_space_t block_to_write, uint nblock)
{
    unsigned char* buffer;
    buffer = (unsigned char*)malloc(sizeof(char)*getSectorSize());

    if (sizeof(free_space_t) > getSectorSize())
        return; /* TODO: handle error */

    memcpy(buffer, &block_to_write, sizeof(free_space_t));

    write_block(vol_number, nblock, buffer);
    
    free(buffer);
}

void init_super(unsigned int vol)
{
    /* we need mbr infos */
    if (load_mbr() != RETURN_SUCCESS)
        return; /* TODO: handle error */

    /* le volume existe ? (no need du test negatif, on travaille sur des uint) */
    if (vol >= getMbrVolumeNumber())
        return; /* TODO: handle error */

    super_block.super_magic = SUPER_MAGIC; 
    super_block.super_root = 1;              /* block 0 = superblock, block 1 = root, block 2 = first free block. Designera un inode plus tard, pas un bloc*/
    super_block.super_name[0] = '\0';        /* empty string ? demander a l'utilisateur ? */
    super_block.super_serial = 0;            /* A generer ? */
    super_block.first_free_block = 2;        /* freeblock sera a ecrire dans le bloc 2 */
    
    /* initialisation des blocs libres*/
    vol_p = getVolume(vol);
    if (!vol_p)
        return; /* should NEVER happen, we checked vol earlier */

    freeblock.block_magic = BLOCK_MAGIC;
    freeblock.first_block = 2;
    freeblock.size = vol_p->vol_n_bloc - 2;
    freeblock.next = 0;                      /* 0 sera la valeur de fin de liste, on ne va evidemment pas ecrire sur le bloc 0 */
    
    vol_number = vol;
    
    write_freeblock(freeblock, super_block.first_free_block);

    save_super();
}

void load_freeblock(free_space_t* block, unsigned int block_number)
{
    unsigned char* buffer;
    buffer = (unsigned char*)malloc(sizeof(char)*getSectorSize());

    if (sizeof(free_space_t) > getSectorSize())
        return; /* TODO: handle error */

    read_block(vol_number, block_number, buffer);
    
    memcpy(block, buffer, sizeof(free_space_t));

    free(buffer);
}

void save_super()
{
    unsigned char* buffer;
    buffer = (unsigned char*)malloc(sizeof(char)*getSectorSize());
    
    if (sizeof(super_t) > getSectorSize())
        return; /* TODO: handle error */
    
    /* on verifie quand meme que le superbloc n'est pas mauvais (ne devrait pas arriver) */
    if (super_block.super_magic != SUPER_MAGIC)
        return; /* TODO: handle error */

    memcpy(buffer, &super_block, sizeof(super_t));

    write_block(vol_number, 0, buffer);
    
    free(buffer);
}

int load_super(unsigned int vol)
{
    /* le volume existe ?*/
    if (vol >= getMbrVolumeNumber())
        return RETURN_FAILURE; /* TODO: handle error */

    unsigned char* buffer;
    vol_p = getVolume(vol);
    if (!vol_p)
        return RETURN_FAILURE; /* should NEVER happen, we checked vol earlier */
    
    buffer = (unsigned char*)malloc(sizeof(char)*getSectorSize());
    
    if (sizeof(free_space_t) > getSectorSize())
        return RETURN_FAILURE; /* TODO: handle error */

    read_block(vol, 0, buffer);
    
    memcpy(&super_block, buffer, sizeof(super_t));
    
    free(buffer);
    
    /* on a recupere de la bonne came ? */
    if (super_block.super_magic != SUPER_MAGIC)
        return RETURN_FAILURE;

    vol_number = vol;

    load_freeblock(&freeblock, super_block.first_free_block);

    return RETURN_SUCCESS;
}

unsigned int new_bloc()
{
    /* 
     * ATTENTION: implementation=> plusieurs possibles
     * 
     * 1) charger toute );la liste chainee des blocs libres au chargement du super
     * bloc et initialiser tous es blocs libre a l'initialisation (+ rapide, - sur)
     * 2) recuperer/ecrire les blocs libre sur le disque directement au fur et 
     * a mesure de leur allocation. (- rapide, + sur)
     *
     * Deux methodes avec avantage et inconvenient. Ici pour l'instant on fait 
     * la methode 2 : plus lente (plein de lecture/ecrire sur le disque) mais plus
     * fiable car les infos sont directement ecrites sur le disque.
     */

    /* plus assez d'espace ! On va ecrire constamment sur le dernier bloc libre connu. */
    if (freeblock.size == 0)
        return freeblock.first_block;

    uint bloc = freeblock.first_block;
    
    /* le premier bloc libre etait seul, le prochain premier bloc libre est donc le suivant */
    if (freeblock.size == 1)
    {
        if (freeblock.next == 0)    /* on alloue le dernier block libre, la. */
            freeblock.size -= 1;
        else    /* on charge le suivant dans freeblock depuis le disque */
            load_freeblock(&freeblock, freeblock.next);
    }
    else
    {
        /* le premier bloc fait partie d'un groupe, on enleve un bloc au groupe */
        freeblock.first_block = freeblock.first_block + 1;
        freeblock.size -= 1;
        write_freeblock(freeblock, freeblock.first_block);
        
    }
    
    /* on a consomme le premier bloc libre (pas le dernier dans un soucis de garder 
     * l'ordre de l'ecture sur les cylindres. On update donc le super bloc */
    super_block.first_free_block = freeblock.first_block;
    
    /* pour une surete maximale on devrait re ecrire le super bloc tout de suite */
    /* si on ne le fait pas la, quand le faire ? Quand on quitte le programme ? Et en cas de crash, quel sera l'etat du super bloc/ de l'allocation ? */
    save_super();
    
    return bloc;
}


void free_bloc(unsigned int bloc)
{
    /* PAS le bloc 0 */
    if (!bloc)
        return;

    free_space_t current_fb = freeblock;
    free_space_t previous_fb = freeblock;

    do {
        short int is_first = current_fb.first_block == freeblock.first_block;
        /* 1ere POSSIBILITE=> Le bloc a liberer precede t il le current_fb ? */
        if (bloc < current_fb.first_block)
        {
            /* directement ... */
            if (bloc == current_fb.first_block - 1)
            {
                current_fb.size += 1;
            }
            else /* ... ou de loin */
            {
                current_fb.size = 1;
                current_fb.next = current_fb.first_block;
            }

            current_fb.first_block = bloc;
            write_freeblock(current_fb, current_fb.first_block);
            
            /* MaJ le precedent de la liste */
            if (is_first) /* il devient le nouveau premier block libre */
            {
                freeblock = current_fb;
                super_block.first_free_block = current_fb.first_block;
                save_super();
            }
            else
            {
                previous_fb.next = bloc;
                /* si le precedent est le premier, on maj freeblock ! */
                if (previous_fb.first_block == freeblock.first_block)
                    freeblock = previous_fb;
                write_freeblock(previous_fb, previous_fb.first_block);
            }
            return;
        }
        /* 2eme POSSIBILITE=> le bloc est donc apres current_fb. */
        /* Peut il etre accole directement a la fin de freeblock ? */
        else if (bloc == current_fb.first_block + current_fb.size)
        {
            /* le bloc a liberer suit directement le bloc libre, on l'y accole et on update la section de bloc libre */
            current_fb.size += 1;
            write_freeblock(current_fb, current_fb.first_block);
            
            if (is_first)
                freeblock = current_fb;

            /* on ecrit quand meme une structure type free_space_t sur le bloc a liberer pour le marquer comme free et pas le liberer deux fois 
             * (pour qu'il soit marque du magic des free block ) */
            current_fb.first_block = bloc;
            current_fb.size = 1;
            write_freeblock(current_fb, bloc);
            
            return;
        }
        else /* bloc sera a placer quelque part plus loin que freeblock */
        {
            previous_fb = current_fb;
            /* on charge le bloc suivant */
            if (previous_fb.next != 0)
                load_freeblock(&current_fb, freeblock.next);
            /* et on recommence */
        }
    } while (previous_fb.next != 0); /* tant qu'on a pas fait le tour (dc revenu au debut) */

    /* Si on arrive ici on libere un bloc qui est quelque part plus loin que le dernier libre (actuellement dans previous_fb) */
    current_fb.first_block = bloc;
    current_fb.size = 1;
    current_fb.next = 0;
    write_freeblock(current_fb, current_fb.first_block);
    previous_fb.next = bloc;
    write_freeblock(previous_fb, previous_fb.first_block);
    if (previous_fb.first_block == freeblock.first_block)
        freeblock = previous_fb;
}

unsigned int get_total_space()
{
    return vol_p->vol_n_bloc;
}

unsigned int get_free_space()
{
    free_space_t current_fb = freeblock;
    unsigned int res = freeblock.size;

    /* On va parcourir la liste des blocs libres */
    while (current_fb.next != 0)
    {
        load_freeblock(&current_fb, current_fb.next);
        res += current_fb.size;
    }
    
    return res;
}

