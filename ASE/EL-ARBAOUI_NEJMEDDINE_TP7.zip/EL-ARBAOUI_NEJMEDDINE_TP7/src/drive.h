#ifndef _DRIVE_H_
#define _DRIVE_H_

#define DISKNFO_MAGIC   0xDEADBEEF 
#define HDA_CMDREG      0x3F6        /* registre de commande du disque maitre */
#define HDA_DATAREGS    0x110        /* base des registres de données (r,r+1,r+2,...r+15) */
#define HDA_IRQ         14           /* Interruption du disque */

#define SECTOR_SIZE     getSectorSize()

typedef struct disknfo_s {
    unsigned int dsknfo_magic;
    unsigned int nb_sector;
    unsigned int nb_cylinder;
    unsigned int sector_size;
} disknfo_t;

void loadDiskInfo();

void read_sector(unsigned int cylinder, unsigned int sector, unsigned char* buffer);

void write_sector(unsigned int cylinder, unsigned int sector, const unsigned char* buffer);

void format_sector(unsigned int cylinder, unsigned int sector, unsigned int nsector, unsigned int value);

unsigned int getMaxSectorPerCyl();

unsigned int getMaxCyl();

unsigned int getSectorSize();

#endif

