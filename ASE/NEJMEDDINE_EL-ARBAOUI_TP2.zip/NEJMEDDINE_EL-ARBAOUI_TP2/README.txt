Sara EL ARBAOUI
&
Ayoub NEJMEDDINE
Groupe 3
TP-2
-----------------------------------------------------------------
Question :
Pourquoi n'a t on pas besoin du registre d'instruction ??
-----------------------------------------------------------------
Réponse : 

On a pas besoin du registre d'instruction parce qu'on enregistre toujours le sommet et le bas de la pile ( ESP et le EBP )lorsqu'on fait appelle a switch_to_ctx.


