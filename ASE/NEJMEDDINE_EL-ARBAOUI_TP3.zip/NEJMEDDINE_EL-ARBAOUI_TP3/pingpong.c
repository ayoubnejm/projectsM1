#include <stdio.h>
#include <stdlib.h>
#include "ctx.h"
#define FAKE_TIMER 100000



void f_ping(void *arg);
void f_pong(void *arg);
void f_pang(void *arg);


int main(int argc, char *argv[]) {
  create_ctx( 16384, f_ping, NULL);
  create_ctx( 16384, f_pong, NULL);
  create_ctx( 16384, f_pang, NULL);
  start_sched();
  exit(EXIT_SUCCESS);
}

void
f_pong(void *arg)
{
  int i;
  while(1) {
    printf("1") ;
    for(i=0; i<FAKE_TIMER; i++);
    printf("2") ;
    for(i=0; i<FAKE_TIMER; i++);
  }
}

void f_ping(void *args)
{
  int i;
  while(1) {
    printf("A") ;
    for(i=0; i<FAKE_TIMER; i++);
    printf("B") ;
    for(i=0; i<FAKE_TIMER; i++);
    printf("C") ;
    for(i=0; i<FAKE_TIMER; i++);
  }
}

void f_pang(void *args)
{
  int i;
  while(1) {
    printf("#") ;
    for(i=0; i<FAKE_TIMER; i++);
  }
}
