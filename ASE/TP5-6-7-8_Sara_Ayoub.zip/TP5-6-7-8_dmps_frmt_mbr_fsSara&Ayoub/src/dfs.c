#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tools/tools.h"
#include "tools/mount.h"
#include "mbr.h"
#include "drive.h"
#include "vol.h"

int main(int argc, char** argv)
{
	
	mount();
	uint i;
	uint max_vol ;
	uint nbrBloc;

    

    nbrBloc=mbr.mbr_vol[current_volume].vol_n_bloc;
    max_vol = mbr.mbr_n_vol;

	if (argc > 1)
    {
        printf("Usage: ./dfs\n");
        printf("Display file System\n");
        exit(EXIT_SUCCESS);
    }
	
    for (i = 0; i < max_vol; ++i)
    {	
        if (load_super(i) == RETURN_SUCCESS)
        {
            printf("Volume %u : dispose d'un systeme de fichier.\n", i);
            printf("%s : Nb total de blocs => %u , numero de série du volume => %d ,nb bloc libres => %u.\n", super.super_name, nbrBloc, super.super_serial,super.super_nb_free);
			umount();
        }
        else
        {
            printf("Volume %u : pas de systeme de fichier.\n", i);
        }
    }
    

}










