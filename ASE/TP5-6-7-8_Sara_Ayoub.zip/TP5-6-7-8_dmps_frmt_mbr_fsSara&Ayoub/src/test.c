#include <stdio.h>
#include <stdlib.h>

#include "tools/tools.h"
#include "mbr.h"
#include "drive.h"
#include "vol.h"


int main(int argc, char** argv)
{

    if (argc < 2)
        return 0;
    
    int block_to_get = atoi(argv[2]);
    
    /* load the MBR (it initializes the virtual hardware too) */
    int res = load_mbr();
    if (res != RETURN_SUCCESS)
        printf ("WARNING: Failed to load original MBR. (error code : %i)\n", res);
    
    
    if (load_super(0) == RETURN_SUCCESS)
    {
 
        if (atoi(argv[1]) == 0){
            for (unsigned int i = 0; i < block_to_get; ++i)
                printf("got block %u\n", new_bloc());

        }else{
            free_bloc(block_to_get);
	}
    }
        
}
