

typedef struct file_desc_t {

    unsigned int fds_inumber;
    unsigned int fds_size;  /* size in char */
    unsigned int fds_pos;   /* pos in char */
    unsigned char fds_buf[BLOC_SIZE];
    char fds_dirty;

} filed_desc_t;

unsigned int create_ifile(enum file_type_e type);

int delete_ifile(unsigned int  inumber);

int open_ifile(file_desc_t* fd, unsigned int  inumber);

void close_ifile(file_desc_t* fd);

void flush_ifile(file_desc_t* fd);

void seek_ifile(file_desc_t* fd, int r_offset); /* relatif */

void seek2_ifile(file_desc_t* fd, int a_offset); /* absolu */



