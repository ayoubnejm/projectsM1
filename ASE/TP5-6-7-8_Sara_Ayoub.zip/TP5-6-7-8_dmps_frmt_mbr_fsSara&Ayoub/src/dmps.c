#include <stdio.h>
#include <stdlib.h>

#include "drive.h"

void print_usage()
{
    printf("USAGE:\n");
    printf("dmps [cylinder] [sector]\n");
    printf("[cylinder] & [sector] as positive integers\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char** argv)
{
    int num_cyl, num_sec;
    unsigned int sector_size;
    unsigned char* buffer;

    if (argc != 3)
    {
        printf("%i is not enough/too much arguments.\n", argc);
        print_usage();
    }

    num_cyl = atoi(argv[1]);
    num_sec = atoi(argv[2]);
    
    if (num_cyl < 0 || num_sec < 0)
    {
        printf("ERROR: bad arguments.\n");
        print_usage();
    }

    loadDiskInfo();    

    if (num_cyl > getMaxCyl() || num_sec > getMaxSectorPerCyl())
    {
        printf("ERROR: wrong cylinder/sector number.\n");
        print_usage();
    }

    sector_size = getSectorSize();

    buffer = (unsigned char*)malloc(sizeof(char)*sector_size);

    read_sector(num_cyl, num_sec, buffer);
    
    for (int i = 1; i <= sector_size; ++i)
    {
        if ((*buffer) < 16)
            printf("0");

        printf("%X ", (*buffer));

        if (i % 8 == 0)
            printf("\t");
        if (i % 16 == 0)
            printf("\n");

        buffer = buffer + 1;
    }
    printf("\n");
    
    exit(EXIT_SUCCESS);
}

