/* ------------------------------
   $Id: vm-skel.c,v 1.1 2002/10/21 07:16:29 marquet Exp $
   ------------------------------------------------------------

   Volume manager skeleton.
   Philippe Marquet, october 2002

   1- you must complete the NYI (not yet implemented) functions
   2- you may add commands (format, etc.)
   
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tools/tools.h"
#include "tools/mount.h"

#include "mbr.h"
#include "drive.h"

#define MAX_CHAR    256

/* ------------------------------
   command list
   ------------------------------------------------------------*/
struct _cmd {
    char *name;
    void (*fun) (struct _cmd *c);
    char *comment;
};

static void list(struct _cmd *c);
static void new(struct _cmd *c);
static void del(struct _cmd *c);
static void write(struct _cmd *c);
static void read(struct _cmd *c);
static void help(struct _cmd *c) ;
static void save(struct _cmd *c);
static void quit(struct _cmd *c);
static void format(struct _cmd *c);
static void xit(struct _cmd *c);
static void none(struct _cmd *c) ; 

static struct _cmd commands [] = {
    {"list", list, 	"display the partition table"},
    {"new",  new,	"create a new partition"},
    {"del",  del,	"delete a partition"},
    {"read", read,	"read un bloc"},
    {"write", write,	"write dans un bloc"},
    {"format", format,	"format a partition"},
    {"save", save,	"save the MBR"},
    {"quit", quit,	"save the MBR and quit"},
    {"exit", xit,	"exit (without saving)"},
    {"help", help,	"display this help"},
    {0, none, 		"unknown command, try help"}
} ;

/* ------------------------------
   dialog and execute 
   ------------------------------------------------------------*/

static void
execute(const char *name)
{
    struct _cmd *c = commands; 
  
    while (c->name && strcmp (name, c->name))
	c++;
    (*c->fun)(c);
}

static void
loop(void)
{
    char name[64];
    
    while (printf("> "), scanf("%62s", name) == 1)
	execute(name) ;
}

/* ------------------------------
   command execution 
   ------------------------------------------------------------*/
static void
list(struct _cmd *c)
{
    uint nbVol = getMbrVolumeNumber();

    if (!nbVol)
    {
        printf("No volumes or MBR loading failed.\n");
        return;
    }
    printf("Volume  :    cyl dep    :    sect dep   :   nb blocs    :      type\n");
    for (uint i = 0; i < nbVol; ++i)
    {
        vol_t* vol = getVolume(i);
        if (vol)
            printf("%i\t:\t%i\t:\t%i\t:\t%i\t:\t%i\n", i, vol->vol_first_cylinder, vol->vol_first_sector, vol->vol_n_bloc, vol->type_vol);
    }
    printf("Type: %i = BASE, %i = ANNEXE, %i = AUTRE\n", BASE, ANNEXE, AUTRE);
}

static void
new(struct _cmd *c)
{
   	unsigned int nbrbloc;
	char input[64];
	enum vol_type_e type;
	printf("> ");
	printf("Donnez le nombre de bloc du volume que vous voulez créer : ");
	if(scanf("%62s", input)){
		type = BASE;
		nbrbloc = atoi(input);
		init_vol(nbrbloc,type);
	}
	else{
		printf("> ");
		printf("Erreur creation partition\n");
	}
}


static void format(struct _cmd *c)
{
	unsigned int vol;
	char input[64];
	printf("> ");
	printf("Donnez le numéro de volume que vous voulez formater: ");
	if(scanf("%62s", input)){
		vol = atoi(input);
		format_vol(vol);
	}
	else{
		printf("> ");
		printf("Erreur format partition\n");
	}
}

static void write(struct _cmd *c)
{
	char input[64];
        char inputdeux[64];
        int t;
	t= getSectorSize();
	 char  buffer[t];

	printf("> ");
        printf("Donner le vol puis le bloc dans lesquels vous voulez écrire puis ce que vous voulez écrire  \n");
        if(scanf("%62s %62s", input, inputdeux)){
	  unsigned int vol = atoi(input);
	  unsigned int bloc= atoi(inputdeux);
		if(bloc > mbr.mbr_vol[vol].vol_n_bloc){
			printf(" le bloc que dans lequel vous voulez écrire n'existe pas dans ce volume \n");
		
		}else{
		  fgets(buffer,t,stdin);
		  write_block(vol, bloc, (unsigned char *) buffer);
		  printf(".... written\n");
		}
	}
}

static void read(struct _cmd *c)
{       
    	char input[64];
        char inputdeux[64];
        int t=getSectorSize();
	unsigned char  buffer[t];
	printf("> ");
	printf("Donner le vol et le bloc a lire : ");
        if(scanf("%62s %62s", input, inputdeux)){
	  unsigned int vol = atoi(input);
	  unsigned int bloc= atoi(inputdeux);
		if(bloc > mbr.mbr_vol[vol].vol_n_bloc){
			printf(" le bloc que vous voulez lire n'existe pas dans ce volume\n");
		
		}else{
			  read_block(vol, bloc, buffer);
			  fprintf(stdout,"%s",buffer);
		}
	
	}
}



static void
del(struct _cmd *c)
{
    /* Déclaration des variables */
	char name[8];
	unsigned int vol;


	/* Saisie de la partition désirée */
	do
	{
		fprintf(stdout, "Partition to delete : \033[32m(integer)\033[00m ");
		fgets(name,8, stdin);
		vol = atoi(name);

		if( vol < 0 || vol > MAX_VOLUME)
		{
			fprintf(stdout, "\033[31mPartition incorrect!\033[00m\r\n");
		}
	}
	while(vol < 0 || vol > MAX_VOLUME);

	/* Affichage du warning */
	fprintf(stdout, "\033[31mBE CAREFUL !\033[00m\r\n");
	fprintf(stdout, "\033[31mIf you continue, you will erase all informations on this partition.\033[00m\r\n");
	fprintf(stdout, "\033[31mErase can not be undone !\033[00m\r\n");
	fprintf(stdout, "\r\n");
	fprintf(stdout, "If you want continue, enter 'y' : ");

	/* Demande confirmation */
	if (getchar() == 'y')
	{
		/* Affichage "en cours" */
		fprintf(stdout, "Erasing in progress...\r\n");

		/* Suppression de la partition */
		del_vol(vol);
	}
	else
	{
		/* Affichage "annulé" */
		fprintf(stdout, "Erasing canceled.\r\n");
	}

	/* Retrait du saut à la ligne */
	getchar();
}

static void
save(struct _cmd *c)
{
    if (save_mbr() == RETURN_SUCCESS)
        printf("MBR saved successfully.\n"); 
}

static void
quit(struct _cmd *c)
{
    int res = save_mbr();
    if (res == RETURN_SUCCESS)
    {
        printf("MBR saved successfully. Bye !\n"); 
        exit(EXIT_SUCCESS);
    }
    else
        printf("MBR save failed. Please check the MBR and try again or quit with exit to discard changes. (error code : %i)\n", res); 
}

static void
do_xit()
{
    exit(EXIT_SUCCESS);
}

static void
xit(struct _cmd *dummy)
{
    do_xit(); 
}

static void
help(struct _cmd *dummy)
{
    struct _cmd *c = commands;
  
    for (; c->name; c++) 
	printf ("%s\t-- %s\n", c->name, c->comment);
}

static void
none(struct _cmd *c)
{
    printf ("%s\n", c->comment) ;
}

int
main(int argc, char **argv)
{
    //mount();
    loadDiskInfo();
    
    /* Load MBR and current volume */
    int res = load_mbr();
    if (res != RETURN_SUCCESS)
        printf ("WARNING: Failed to load original MBR. (error code : %i)\n", res);
    /* dialog with user */ 
    loop();

    /* abnormal end of dialog (cause EOF for xample) */
    do_xit();
    
    //umount();
    
    /* make gcc -W happy */
    exit(EXIT_SUCCESS);
}
