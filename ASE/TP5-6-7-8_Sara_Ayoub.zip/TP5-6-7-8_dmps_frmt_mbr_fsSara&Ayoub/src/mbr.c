#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "tools/tools.h"
#include "mbr.h"
#include "drive.h"



int load_mbr()
{ 
	loadDiskInfo();
    /* Le mbr est il deja charge ? */
    if (mbr.mbr_magic == MBR_MAGIC)
        return RETURN_SUCCESS;

    unsigned char* buffer;

    if (sizeof(mbr_t) > getSectorSize())
        return ERROR_MBR_TOO_LARGE;
    /* malloc car n'oublions pas que getSectorSize() est une variable */
    buffer = (unsigned char*)malloc(sizeof(char)*getSectorSize());

    read_sector(0, 0, buffer);
    
    memcpy(&mbr, buffer, sizeof(mbr_t));
    free(buffer);

    if (mbr.mbr_magic != MBR_MAGIC)
    {
        mbr.mbr_magic = MBR_MAGIC;
        mbr.mbr_n_vol = 0;
        /*return ERROR_BAD_STRUCTURE_FORMAT;*/
		save_mbr();
    }
    
    return RETURN_SUCCESS;
}

int save_mbr()
{
    unsigned char* buffer;

    if (sizeof(mbr_t) > getSectorSize())
        return ERROR_MBR_TOO_LARGE;

    /* Ne pas enregistrer un MBR incorrect */
    if (mbr.mbr_magic != MBR_MAGIC)
        return ERROR_BAD_STRUCTURE_FORMAT;
        
    buffer = (unsigned char*)malloc(sizeof(char)*getSectorSize());
        
    memcpy(buffer, &mbr, sizeof(mbr_t));
    
    write_sector(0, 0, buffer);
    
    free(buffer);
    return RETURN_SUCCESS;
}



/************************************/


void init_vol(unsigned int taille, enum vol_type_e type){
	unsigned int cylinder, sector;
	 
         
	if(enoughPlace(taille)){
	  /* premier volume doit commencer au cylibdre 0 mais au secteur 1 */
	  if(mbr.mbr_n_vol == 0){
	    cylinder = 0;
	    sector = 1;
	  }
	  /* nombre maximal de volume */
	  else if(mbr.mbr_n_vol == MAX_VOLUME ) {
	    printf("- Erreur, aucun volume ne peut être créé\n");
	    return;
	  }
	  /* cas normal, créer le volume */
	  else{ /* problème si il y a un volume(pas la dernière) qui est supprimé */
		//le cylindre calculé grace au cylindre du volume précédent et du nombre de secteurs de celui ci
	    cylinder = mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_cylinder
			 + (mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_sector + mbr.mbr_vol[mbr.mbr_n_vol-1].vol_n_bloc) / getMaxSectorPerCyl();
	    //le secteur calculé grace au secteur du volume précédent et du nombre de secteurs de celui ci 
	    sector = (mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_sector + mbr.mbr_vol[mbr.mbr_n_vol-1].vol_n_bloc) % getMaxSectorPerCyl();
	  }
	  mbr.mbr_vol[mbr.mbr_n_vol].vol_first_cylinder = cylinder;
	  mbr.mbr_vol[mbr.mbr_n_vol].vol_first_sector = sector;
	  mbr.mbr_vol[mbr.mbr_n_vol].vol_n_bloc = taille;
	  mbr.mbr_vol[mbr.mbr_n_vol].type_vol = type;
	  printf("- Volume %d est crée sur le disk.\n", mbr.mbr_n_vol);
	  mbr.mbr_n_vol++;
	}else{
	  printf("- Pas assez de place dans le disque.\n" );
	}	
}


/**
 * Retourne 1 s'il ya assez de place pour crééer un volume de taille 'taille'
 * après le dernier volume existant.
 *
 */
int enoughPlace(int taille){
  int cy=infoCyl();
  int sec=infoSect();
  int dernier_sector_vol = (mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_sector + mbr.mbr_vol[mbr.mbr_n_vol-1].vol_n_bloc) % sec;
  int dernier_cylinder_vol = mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_cylinder
			 + (mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_sector + mbr.mbr_vol[mbr.mbr_n_vol-1].vol_n_bloc) / sec;
  int place_restante = ((cy-dernier_cylinder_vol+1)*sec)-dernier_sector_vol;

  if(place_restante >= taille){
    return 1;
  }else{
    return 0;
  }
}



void del_vol(unsigned int vol){
	int i;
	if(mbr.mbr_n_vol > vol){
	 /* format_sector(mbr.mbr_vol[vol].vol_first_cylindre, mbr.mbr_vol[vol].vol_first_sector, mbr.mbr_vol[vol].vol_n_bloc, 0);*/
	  for(i = vol; i < mbr.mbr_n_vol-1; i++) {
	    mbr.mbr_vol[i] = mbr.mbr_vol[i+1];
	  }
	  mbr.mbr_n_vol--;	
		
	  fprintf(stdout, "\033[32mErasing successfull !\033[00m\r\n");
	  printf("- Volume %d est supprimé du disk.\n", vol);
	
	}
	else{
	  printf("- Erreur, ce volume n'existe pas!\n");
	}
}

/************************************/

uint getMbrVolumeNumber()        { return mbr.mbr_n_vol; }

vol_t* getVolume(uint vol)
{
    if (vol >= MAX_VOLUME || vol >= mbr.mbr_n_vol)
        return NULL;
    
    return &mbr.mbr_vol[vol];
}





/****/

unsigned int cylinder_of_bloc(unsigned int vol, unsigned int bloc){

    if (vol >= mbr.mbr_n_vol)
        return RETURN_FAILURE;
	if(vol >= MAX_VOLUME)
        return RETURN_FAILURE;
	if(bloc >= mbr.mbr_vol[vol].vol_n_bloc)
		 return RETURN_FAILURE;

  return ( mbr.mbr_vol[vol].vol_first_cylinder + ( mbr.mbr_vol[vol].vol_first_sector  + bloc ) /  getMaxSectorPerCyl() ) ;
	

}

unsigned int sector_of_bloc(unsigned int vol, unsigned int bloc){

  
    if (vol >= mbr.mbr_n_vol)
        return RETURN_FAILURE;
	if(vol >= MAX_VOLUME )
        return RETURN_FAILURE;
	if(bloc >= mbr.mbr_vol[vol].vol_n_bloc)
		 return RETURN_FAILURE;


  return (( mbr.mbr_vol[vol].vol_first_sector  + bloc ) %  getMaxSectorPerCyl() ); 


}


/* Fonction "read_bloc" */
void read_block(unsigned int vol, unsigned int nblock, unsigned char *buffer){
  
  if(nblock>mbr.mbr_vol[vol].vol_n_bloc)
	return;
  read_sector(cylinder_of_bloc(vol,nblock),sector_of_bloc(vol,nblock),buffer);

}

/* Fonction "write_bloc"
void write_block(uint vol, uint nblock, const unsigned char* buffer){
  write_sector(cylinder_of_bloc(vol,nblock),sector_of_bloc(vol,nbloc),buffer);
} */

void write_block(uint vol, uint nblock, const unsigned char* buffer)
{
  if(nblock>mbr.mbr_vol[vol].vol_n_bloc)
	return;
	
  write_sector(cylinder_of_bloc(vol,nblock),sector_of_bloc(vol,nblock),buffer);
}

void format_vol(unsigned int vol){
	
	int i, nbBloc;
	nbBloc = mbr.mbr_vol[vol].vol_n_bloc;
	if(mbr.mbr_n_vol > vol){
		for(i=0; i < nbBloc; i++) {
			format_sector (cylinder_of_bloc(vol,i), sector_of_bloc(vol,i), 1, 42);
		}
		printf("- Volume %d est formaté.\n", vol);
	}
	else{
		printf("- Erreur, ce volume n'existe pas!\n");
	}
}

