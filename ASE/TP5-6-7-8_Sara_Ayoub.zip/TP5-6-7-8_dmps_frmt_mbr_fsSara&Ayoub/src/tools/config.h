/* ------------------------------
   $Id: config.h,v 1.1 2009/11/16 05:38:07 marquet Exp $
   ------------------------------------------------------------

   file system configuration file
   
   Philippe Marquet, Nov 2009
   
*/

#ifndef _CONFIG_H_
#define _CONFIG_H_

#define DEFAULT_HW_CONFIG "hardware.ini"

#endif
