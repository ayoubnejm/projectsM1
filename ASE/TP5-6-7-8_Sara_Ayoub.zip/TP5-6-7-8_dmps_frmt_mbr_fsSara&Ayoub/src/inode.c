#include <string.h>
#include <stdio.h>

#include "tools/tools.h"
#include "inode.h"
#include "mbr.h"
#include "vol.h"

/* rendu "public" pour la compatibilite avec les fichier de M. Marquet */
/*static*/ unsigned int current_volume;

void setCurrent_Volume(unsigned int vol) { current_volume = vol; }

unsigned int getCurrent_Volume() { return current_volume; }

void read_inode(unsigned int inumber, struct inode_s* inode)
{
    read_block(current_volume, inumber, (unsigned char*)inode);
}

void write_inode(unsigned int inumber, struct inode_s* inode)
{
    write_block(current_volume, inumber, (unsigned char*)inode);
}

/* TODO: des magics numbers sur l'inode pour s'assurer de leur bon etat ?*/ 

unsigned int create_inode(enum file_type_e type)
{
    inode_t new_inode;
    unsigned int bloc;

    new_inode.ind_size = 0;
    new_inode.ind_type = type;

    memset(new_inode.ind_direct, BLOC_NULL, N_DIRECT_BLOCS * sizeof(int));
    new_inode.inode_magic = INODE_MAGIC;
    new_inode.ind_indirect = BLOC_NULL;
    new_inode.ind_d_indirect = BLOC_NULL;
    
    bloc = new_bloc();
    
    write_inode(bloc, &new_inode);
    
    return bloc;
}

int delete_inode(unsigned int inumber)
{
    inode_t inode;
    /*  lire l'inode en question */
    read_inode(inumber, &inode);
    
    /* On check que le block n'a pas deja ete transforme en block libre. */
    /* TODO: supprimer l'inode magic pr economiser de la place et utiliser l'arbo des inodes ou la liste des block libre */
    if (inode.inode_magic != INODE_MAGIC)
        return RETURN_FAILURE;

    /* liberer les block en addr direct */
    for (unsigned int i = 0; i < N_DIRECT_BLOCS; ++i)
    {
        free_bloc(inode.ind_direct[i]);
    }
    /* liberer les block en addr indirect */
    if (inode.ind_indirect)
    {
        unsigned int indirection[N_DIRECT_BLOCS + INODE_FIELDS]; 
        read_block(current_volume, inode.ind_indirect, (unsigned char*)&indirection);
        for (unsigned int i = 0; i < N_DIRECT_BLOCS + INODE_FIELDS; ++i)
        {
            free_bloc(indirection[i]);
        }
    }
    /* liberer les block en addr d_indirect */
    if (inode.ind_d_indirect)
    {
        unsigned int d_indirection[N_DIRECT_BLOCS + INODE_FIELDS]; 
        read_block(current_volume, inode.ind_d_indirect, (unsigned char*)&d_indirection);
        
        for (unsigned int i = 0; i < N_DIRECT_BLOCS + INODE_FIELDS; ++i)
        {
            if (d_indirection[i])
            {
                unsigned int indirection[N_DIRECT_BLOCS + INODE_FIELDS]; 
                read_block(current_volume, d_indirection[i], (unsigned char*)&indirection);
                for (unsigned int j = 0; j < N_DIRECT_BLOCS + INODE_FIELDS; ++j)
                {
                    free_bloc(indirection[i]);
                }
            }
        }
    }
    /* liberer l'inode, free le bloc */
    free_bloc(inumber);
    
    return RETURN_SUCCESS;  
}

unsigned int vbloc_of_fbloc_simple(unsigned int inumber, unsigned int fbloc)
{
    return vbloc_of_fbloc(inumber, fbloc, FALSE);
}

unsigned int vbloc_of_fbloc(unsigned int inumber, unsigned int fbloc, bool_t do_allocate)
{
    inode_t inode;
    /*  lire l'inode en question */
    read_inode(inumber, &inode);

    /* si pas un bloc direct */
    if (fbloc >= N_DIRECT_BLOCS)
    {
        fbloc -= N_DIRECT_BLOCS;
        /* bloc indirect ? */
        if (fbloc < N_DIRECT_BLOCS + INODE_FIELDS)
        {
            if (inode.ind_indirect != BLOC_NULL)
            {
                /* recuperer la liste de pointeur du bloc inode.ind_indirect */
                /* Pas un inode donc pas besoin des 4 uint reserves de la structure ! que des pointeurs ici. */
                unsigned int indirection[N_DIRECT_BLOCS + INODE_FIELDS]; 
                read_block(current_volume, inode.ind_indirect, (unsigned char*)&indirection);
                return indirection[fbloc % N_DIRECT_BLOCS];
            }
            else
            {
                if (do_allocate == FALSE)
                    return BLOC_NULL;
                else
                {
                    /* allocate indirect block */
                    unsigned int indirection_bloc = new_bloc();
                    unsigned int data_bloc = new_bloc();
                    
                    inode.ind_indirect = fbloc;
                    /*inode.size += BLOC_SIZE;*/
                    write_inode(inumber, &inode);
                    
                    unsigned int indirection[N_DIRECT_BLOCS + INODE_FIELDS];
                    memset(indirection, BLOC_NULL, N_DIRECT_BLOCS + INODE_FIELDS);
                    indirection[fbloc % N_DIRECT_BLOCS] = data_bloc;
                    
                    write_block(current_volume, indirection_bloc, (const unsigned char*)(&indirection));
                    return data_bloc;
                }
            }
        }
        else
        {
            fbloc -= N_DIRECT_BLOCS + INODE_FIELDS;
            /* on a demandé un bloc plus grand que la taille max d'un fichier */
            if (fbloc < (N_DIRECT_BLOCS + INODE_FIELDS) * (N_DIRECT_BLOCS + INODE_FIELDS))
                return BLOC_NULL;

            if (inode.ind_d_indirect != BLOC_NULL)
            {
                /* recuperer la liste de pointeur de double indirection du bloc inode.ind_d_indirect */
                unsigned int d_indirection[N_DIRECT_BLOCS + INODE_FIELDS], indirection[N_DIRECT_BLOCS + INODE_FIELDS]; 
                read_block(current_volume, inode.ind_d_indirect, (unsigned char*)&d_indirection);
                
                /* dans cette liste on recupere la liste de pointeur de simple indirection */
                if (d_indirection[fbloc / (N_DIRECT_BLOCS + INODE_FIELDS)] != BLOC_NULL)
                {
                    read_block(current_volume, d_indirection[fbloc / (N_DIRECT_BLOCS + INODE_FIELDS)], (unsigned char*)&indirection);
                    if (indirection[fbloc % N_DIRECT_BLOCS] != BLOC_NULL)
                        return indirection[fbloc % N_DIRECT_BLOCS];
                    else
                    {
                        if (do_allocate == FALSE)
                            return BLOC_NULL;
                        else
                        {
                            /* allocate direct block */
                            unsigned int bloc = new_bloc();
                            indirection[fbloc % N_DIRECT_BLOCS] = bloc;
                            write_block(current_volume, d_indirection[fbloc / (N_DIRECT_BLOCS + INODE_FIELDS)], (const unsigned char*)&indirection);
                            
                            /*inode.size += BLOC_SIZE;
                            write_inode(inumber, &inode);*/
                            return bloc;
                        }
                    }
                }
                else
                {
                    if (do_allocate == FALSE)
                        return BLOC_NULL;
                    else
                    {
                        /* allocate indirect block */
                        unsigned int indirection_bloc = new_bloc();
                        unsigned int data_bloc = new_bloc();
                        /** fix from here => what block are we looking to build ? **/
                        /*write_block(current_volume, d_indirection[fbloc / (N_DIRECT_BLOCS + 4)], &indirection);*/
                        d_indirection[fbloc / (N_DIRECT_BLOCS + INODE_FIELDS)] = indirection_bloc;
                        write_block(current_volume, inode.ind_d_indirect, (const unsigned char*)&d_indirection);
                        
                        unsigned int indirection[N_DIRECT_BLOCS + INODE_FIELDS];
                        memset(indirection, BLOC_NULL, N_DIRECT_BLOCS + INODE_FIELDS);
                        indirection[fbloc % N_DIRECT_BLOCS] = data_bloc;
                        
                        write_block(current_volume, indirection_bloc, (const unsigned char*)(&indirection));
                        
                        /*inode.size += BLOC_SIZE;
                        write_inode(inumber, &inode);*/
                        return data_bloc;
                    }
                }
            }
            else /* pas de ind_d_indirect */
            {
                if (do_allocate == FALSE)
                    return BLOC_NULL;
                else
                {
                    /* allocate d_indirect block */
                    unsigned int d_indirection_bloc = new_bloc();
                    unsigned int indirection_bloc = new_bloc();
                    unsigned int data_bloc = new_bloc();
                    /** fix from here => what block are we looking to build ? **/
                    inode.ind_d_indirect = d_indirection_bloc;
                    /*inode.size += BLOC_SIZE;*/
                    write_inode(inumber, &inode);
                    
                    unsigned int d_indirection[N_DIRECT_BLOCS + INODE_FIELDS];
                    memset(d_indirection, BLOC_NULL, N_DIRECT_BLOCS + INODE_FIELDS);
                    
                    d_indirection[fbloc / (N_DIRECT_BLOCS + INODE_FIELDS)] = indirection_bloc;
                    write_block(current_volume, inode.ind_d_indirect, (const unsigned char*)&d_indirection);
                    
                    unsigned int indirection[N_DIRECT_BLOCS + INODE_FIELDS];
                    memset(indirection, BLOC_NULL, N_DIRECT_BLOCS + INODE_FIELDS);
                    indirection[fbloc % N_DIRECT_BLOCS] = data_bloc;
                    
                    write_block(current_volume, indirection_bloc, (const unsigned char*)(&indirection));
                    return data_bloc;
                }
            }
        }
    }
    
    /* retournera BLOC_NULL si inode.ind_direct[fbloc] == BLOC_NULL */
    if (do_allocate == FALSE || inode.ind_direct[fbloc] != BLOC_NULL)
        return inode.ind_direct[fbloc];
    else
    {
        /* allocate direct block */
        unsigned int bloc = new_bloc();
        inode.ind_direct[fbloc] = bloc;
        /*inode.size += BLOC_SIZE;*/
        write_inode(inumber, &inode);
        return bloc;
    }

}

