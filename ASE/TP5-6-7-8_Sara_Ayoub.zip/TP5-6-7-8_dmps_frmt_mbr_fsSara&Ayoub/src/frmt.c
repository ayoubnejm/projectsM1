#include <stdio.h>
#include <stdlib.h>

#include "drive.h"

int main()
{
    loadDiskInfo();
    unsigned int maxCyl = getMaxCyl();
    for (unsigned int i = 0; i < maxCyl; ++i)
        format_sector(i, 0, getMaxSectorPerCyl(), 0);

    printf("Formatage termine avec succes.\n");
    
    exit(EXIT_SUCCESS);
}

