#ifndef _INODE_H_
#define _INODE_H_

#include "tools/tools.h"
#include "drive.h"

#define BLOC_SIZE       256     /* inscrit en dur pour ind_direct[N_DIRECT_BLOC] qui n'accepte pas les tableaux de taille variable */

/*#define BLOC_SIZE       SECTOR_SIZE*/
#define INODE_MAGIC     0xCAFEBABE
#define INODE_FIELDS    5
#define N_DIRECT_BLOCS   ((BLOC_SIZE)/(sizeof(int)) - INODE_FIELDS )
#define DATA_BLOC_SIZE  BLOC_SIZE
#define BLOC_NULL       0

/*enum file_type_e { ORDINARY, DIRECTORY, SPECIAL };*/
enum file_type_e {FILE_FILE = 1, FILE_DIRECTORY = 2, FILE_SPECIAL = 3};

typedef struct inode_s {

    unsigned int inode_magic;  /* on passe par ca pour etre sur qu'on recupere un inode. prends de la place pour rien, on s'en passera avec l'arborescence des inode plus tard */

    unsigned int ind_size;  /* size in char */
    
    enum file_type_e ind_type;
    
    unsigned int ind_direct[N_DIRECT_BLOCS]; 

    unsigned int ind_indirect;
    
    unsigned int ind_d_indirect;

} inode_t;


void read_inode(unsigned int inumber, struct inode_s* inode);

void write_inode(unsigned int inumber, struct inode_s* inode);

void setCurrent_Volume(unsigned int vol);

unsigned int getCurrent_Volume();

unsigned int create_inode(enum file_type_e type);

int delete_inode(unsigned int inumber);

unsigned int vbloc_of_fbloc_simple(unsigned int inumber, unsigned int fbloc);

unsigned int vbloc_of_fbloc(unsigned int inumber, unsigned int fbloc, bool_t do_allocate);

#endif


