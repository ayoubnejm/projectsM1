#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hardware.h"
#include "drive.h"

static disknfo_t disknfo;

void irq()
{
}

static inline int charToShort(char msb, char lsb)
{
    return (msb << 8) | lsb;    
}

unsigned int getMaxSectorPerCyl() { return disknfo.nb_sector;   }

unsigned int getMaxCyl()          { return disknfo.nb_cylinder; }

unsigned int getSectorSize()      { return disknfo.sector_size; }

void loadDiskInfo()
{
    char* hard_ini; 
    /* disque deja initialisee, eventuellement reset le maic number pour forcer le
     * reload (via une fonction force_reload() par exemple)
     */
    if (disknfo.dsknfo_magic == DISKNFO_MAGIC)
        return;
        
    hard_ini = getenv("HW_CONFIG");
    
    if (!hard_ini)
    {
        /*printf("ATTENTION: Aucun chemin declare dans $HW_CONFIG, le fichier hardware.ini du repertoire de travail courant sera utilise pour initialiser le materiel.\n");*/
        hard_ini = "./hardware.ini";
    }

    if (!init_hardware(hard_ini))
    {
        printf("ERROR: Cannot initialize hardware. Is hardware.ini file present in current directory or is $HW_CONFIG correct ?\n");
        exit(EXIT_FAILURE);
    }

    /* On initialise le tableau d'IRQ ici par convenience, il peut toujours etre redefini ailleurs */
    for (int i = 0; i < 16; ++i)
        IRQVECTOR[i] = irq;

    _out(HDA_CMDREG, CMD_DSKINFO);

    disknfo.dsknfo_magic = DISKNFO_MAGIC;
    disknfo.nb_cylinder = charToShort(_in(HDA_DATAREGS + 0), _in(HDA_DATAREGS + 1));
    disknfo.nb_sector   = charToShort(_in(HDA_DATAREGS + 2), _in(HDA_DATAREGS + 3));
    disknfo.sector_size = charToShort(_in(HDA_DATAREGS + 4), _in(HDA_DATAREGS + 5));
}



/*atteindre un cylindre et un secteur passé en argument */
void seek(int cylinder, int sector){
 /* Octet de poid fort d'abord */
    _out(HDA_DATAREGS + 0, (cylinder >> 8) & 0xFF);
    /* Puis octet de poid faible */
    _out(HDA_DATAREGS + 1, cylinder & 0xFF);

    _out(HDA_DATAREGS + 2, (sector >> 8) & 0xFF);
    _out(HDA_DATAREGS + 3, sector & 0xFF);

    _out(HDA_CMDREG, CMD_SEEK);
    _sleep(HDA_IRQ);

}


void read_sector(unsigned int cylinder, unsigned int sector, unsigned char* buffer)
{
    if (cylinder >= disknfo.nb_cylinder || sector >= disknfo.nb_sector)
        return;

   seek(cylinder,sector);
    _out(HDA_DATAREGS, 0);
    _out(HDA_DATAREGS + 1, 1);
    _out(HDA_CMDREG, CMD_READ);
    _sleep(HDA_IRQ);
    
    memcpy(buffer, MASTERBUFFER, disknfo.sector_size);
}



void write_sector(unsigned int cylinder, unsigned int sector, const unsigned char* buffer)
{
    if (cylinder >= disknfo.nb_cylinder || sector >= disknfo.nb_sector)
        return;

    for (int i = 0; i < disknfo.sector_size; ++i)
        MASTERBUFFER[i] = buffer[i];


   seek(cylinder,sector);
    _out(HDA_DATAREGS, 0);
    _out(HDA_DATAREGS + 1, 1);
    _out(HDA_CMDREG, CMD_WRITE);
    _sleep(HDA_IRQ);
}

void format_sector(unsigned int cylinder, unsigned int sector, unsigned int nsector, unsigned int value)
{
	int j;
    if (cylinder >= disknfo.nb_cylinder || sector >= disknfo.nb_sector)
        return;

    /* on formate tous les secteurs : ne semble pas fonctionner si on demande x
     * secteurs depuis le secteur sector, cela n'en formate qu'un a chaque fois.
     * on formate donc ici secteur par secteur.
     */

  for(j=sector; j< (sector+nsector);j++){
 
        seek(cylinder,j);
        /* on formate 1 secteur*/
        _out(HDA_DATAREGS + 0, 0);
        _out(HDA_DATAREGS + 1, 1);
        /* on formate avec la valeur value */
        _out(HDA_DATAREGS + 2, (value >> 24) & 0xFF);
        _out(HDA_DATAREGS + 3, (value >> 16) & 0xFF);
        _out(HDA_DATAREGS + 4, (value >> 8) & 0xFF);
        _out(HDA_DATAREGS + 5, value & 0xFF);
        
        _out(HDA_CMDREG, CMD_FORMAT);
        _sleep(HDA_IRQ);
    }
}


int infoCyl(){
	_out(HDA_CMDREG,CMD_DSKINFO);
	return _in(HDA_DATAREGS+1);
}

int infoSect(){
	_out(HDA_CMDREG,CMD_DSKINFO);
	return _in(HDA_DATAREGS+3);
}

int tailleSect(){
	unsigned int r;
	_out(HDA_CMDREG,CMD_DSKINFO);
	r=_in(HDA_DATAREGS+4)<<8;
	r=r|_in(HDA_DATAREGS+5);
	return r;
}


