
#include "inode.h"

unsigned int create_ifile(enum file_type_e type)
{
    return create_inode(type);
}

int delete_ifile(unsigned int  inumber)
{
    return delete_inode(inumber);
}

int open_ifile(file_desc_t* fd, unsigned int  inumber)
{
    struct inode_s inode;
    read_inode(inumber, &inode);
    fd->fds_inumber = inumber;
    fd->fds_size = inode->size;
    fd->fds_pos = 0;
    fd->fds_buf[BLOC_SIZE];
    fd->fds_dirty = 0;
    
    return RETURN_SUCCESS;
}

void close_ifile(file_desc_t* fd)
{
    
}

void flush_ifile(file_desc_t* fd)
{
    if (!fd->fds_dirty)
        return;
    
    unsigned int block_to_write = vbloc_of_fbloc(unsigned int inumber, unsigned int fbloc, TRUE);
}

void seek_ifile(file_desc_t* fd, int r_offset) /* relatif */
{
    
}

void seek2_ifile(file_desc_t* fd, int a_offset) /* absolu */
{
    
{
}

