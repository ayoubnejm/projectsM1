#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "drive.h"
#include "hardware.h"

void seek(int numcyl, int numsec){
  _out(HDA_DATAREGS, (numcyl >> 8)&0xFF);
  _out(HDA_DATAREGS+1, numcyl&0xFF);
  _out(HDA_DATAREGS+2, (numsec >> 8)&0xFF);
  _out(HDA_DATAREGS+3, numsec&0xFF);
  _out(HDA_CMDREG, CMD_SEEK);
  _sleep(HDA_IRQ);

}

static void
frmt(unsigned int cylindre, unsigned int sector, unsigned int nsector, unsigned int valeur){
	int i,j;
	      for(i=0; i < cylindre; i++ ){
		for(j=0; j< sector;j++){
			seek(i,j);
  			_out(HDA_DATAREGS,0);
  			_out(HDA_DATAREGS+1,1);
  			_out(HDA_DATAREGS+2,(valeur >> 24)&0xFF);
  			_out(HDA_DATAREGS+3,(valeur >> 16)&0xFF);
  			_out(HDA_DATAREGS+4,(valeur >> 8)&0xFF);
  			_out(HDA_DATAREGS+5,(valeur >> 0)&0xFF);
  			_out(HDA_CMDREG,CMD_FORMAT);
  			_sleep(HDA_IRQ);
		}
	      }
}


int infoCyl(){
_out(HDA_CMDREG,CMD_DSKINFO);
return _in(HDA_DATAREGS+1);
}

int infoSect(){
_out(HDA_CMDREG,CMD_DSKINFO);
return _in(HDA_DATAREGS+3);
}

static void
empty_it()
{
    return;
}

int main(int argc, char **argv){
  int cylindre, sector, i;
  if(init_hardware("hardware.ini") == 0){
      fprintf(stderr, "Error in hardware initialization\n");
      exit(EXIT_FAILURE);
  }

  for(i=0; i<16; i++)
    IRQVECTOR[i] = empty_it;
  _mask(1);;
    cylindre=infoCyl();
    sector=infoSect();
 

  if(argc == 1){
  	 frmt(cylindre,sector,sector,0);
	 printf(".............. done ............... \n");
	 exit(0);
  }
  else{
    printf("Utilisation : ./frmt\n");
    exit(1);
  }
}


