#define MAX_VOL 8
#define MBR_MAGIC 0xAEF123

enum vol_type_e{base,annexe,other};

static char* vol_type_table[3] = {"base","annexe","other"};

struct  vol_descr_s{
  unsigned int vol_first_cylindre;
  unsigned int vol_first_sector;
  unsigned int vol_n_bloc;
  enum vol_type_e vol_type;
};

struct mbr_descr_s{
  unsigned int mbr_n_vol;
  struct vol_descr_s mbr_vol[MAX_VOL];
  unsigned mbr_magic;
};

struct mbr_descr_s mbr;

int load_mbr();
void save_mbr();

unsigned int cylinder_of_bloc(unsigned int vol, unsigned bloc);
unsigned int sector_of_bloc(unsigned int vol, unsigned bloc);



void read_bloc(unsigned int vol, unsigned int bloc, unsigned char *buffer);
void write_bloc(unsigned int vol, unsigned int bloc, unsigned char *buffer);

