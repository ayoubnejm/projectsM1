/* LIBRAIRIES */
/* ---------- */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include <assert.h>

/* Entêtes */
#include "mbr.h"
#include "drive.h"


/* Fonction "load_mbr" */

int load_mbr(){	
  assert(sizeof(struct mbr_descr_s) <= HDA_SECTORSIZE);
  unsigned char buffer[HDA_SECTORSIZE];
  int i;
  read_sector(0, 0, buffer);
  memcpy((char *)&mbr,buffer,sizeof(struct mbr_descr_s));
  // printf("mbr.mbr_magic := %d\n",mbr.mbr_magic);
  if(mbr.mbr_magic != MBR_MAGIC){
    
      printf("MBR n'a pas encore été initialisé\n");
       for(i=0; i < HDA_MAXSECTOR; i++ ){
	 format_sector(i, 0,HDA_MAXCYLINDER, 0);
      }
       printf("Le disque est formaté\n");
       mbr.mbr_magic = MBR_MAGIC;
       mbr.mbr_n_vol = 0;
       save_mbr();
    }
  return 0;
}






/* Procédure "save_mbr" */
void save_mbr(){
 char buffer[HDA_SECTORSIZE];
  memcpy(buffer,(char*)&mbr,HDA_SECTORSIZE);
  write_sector(0,0,buffer);
}



unsigned int cylinder_of_bloc(unsigned int vol, unsigned int bloc){

  assert(vol <= MAX_VOL);
  assert(bloc <= mbr.mbr_vol[vol].vol_n_bloc);
  return ( mbr.mbr_vol[vol].vol_first_cylindre + ( mbr.mbr_vol[vol].vol_first_sector  + bloc ) /  HDA_MAXSECTOR ) ;
	

}

unsigned int sector_of_bloc(unsigned int vol, unsigned int bloc){

  assert(vol <= MAX_VOL);
  assert(bloc <= mbr.mbr_vol[vol].vol_n_bloc);
  return ( mbr.mbr_vol[vol].vol_first_sector + ( mbr.mbr_vol[vol].vol_first_sector  + bloc ) %  HDA_MAXSECTOR ); 


}

/* Fonction "read_bloc" */
void read_bloc(unsigned int vol, unsigned int bloc, unsigned char *buffer){
  read_sector(cylinder_of_bloc(vol,bloc),sector_of_bloc(vol,bloc),buffer);

}

/* Fonction "write_bloc" */
void write_bloc(unsigned int vol, unsigned int bloc, unsigned char *buffer){
  write_sector(cylinder_of_bloc(vol,bloc),sector_of_bloc(vol,bloc),buffer);
}











