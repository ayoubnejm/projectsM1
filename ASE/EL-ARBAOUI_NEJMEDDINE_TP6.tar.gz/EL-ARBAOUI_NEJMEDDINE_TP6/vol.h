#include "mbr.h"
#include "drive.h"
#define HDA_BLOC_SIZE 256

void format_vol(unsigned int vol);

void info_vol(unsigned int vol);

void del_vol(unsigned int vol);

void init_vol(unsigned int taille, enum vol_type_e type);

int enoughPlace(int taille);

void list_vols();
