#include <stdlib.h>                      
#include <stdio.h>
#include <string.h>
#include "hardware.h"
#include "drive.h"

/*atteindre un cylindre et un secteur passé en argument */
void seek(int numcyl, int numsec){
  _out(HDA_DATAREGS, (numcyl >> 8)&0xFF);
  _out(HDA_DATAREGS+1, numcyl&0xFF);
  _out(HDA_DATAREGS+2, (numsec >> 8)&0xFF);
  _out(HDA_DATAREGS+3, numsec&0xFF);
  _out(HDA_CMDREG, CMD_SEEK);
  _sleep(HDA_IRQ);

}

/*lire secteur*/
void read_sector(unsigned int cylindre, unsigned int sector,unsigned char *buffer){
  seek(cylindre,sector);
  _out(HDA_DATAREGS,0);
  _out(HDA_DATAREGS+1,1);
  _out(HDA_CMDREG,CMD_READ);
  _sleep(HDA_IRQ);
  memcpy(buffer, MASTERBUFFER,HDA_SECTORSIZE);  
}

/*ecrire sur un secteur*/
void write_sector(unsigned int cylindre, unsigned int sector,const unsigned char *buffer){
  seek(cylindre,sector);
  memcpy(MASTERBUFFER,buffer,HDA_SECTORSIZE);
  _out(HDA_DATAREGS,0);
  _out(HDA_DATAREGS+1,1);
  _out(HDA_CMDREG,CMD_WRITE);
  _sleep(HDA_IRQ); 
    
}
/* formater un N sector*/
void format_sector(unsigned int cylindre, unsigned int sector, unsigned int nsector, unsigned int value){
int j;
  for(j=sector; j< (sector+nsector);j++){
	     seek(cylindre,j);
        _out(HDA_DATAREGS,0x00);
		_out(HDA_DATAREGS+1, 0x01);
		_out(HDA_DATAREGS+2, (value >> 24) & 0xFF);
		_out(HDA_DATAREGS+3, (value >> 16) & 0xFF);
		_out(HDA_DATAREGS+4, (value >> 8) & 0xFF);
		_out(HDA_DATAREGS+5, value & 0xFF);
		_out(HDA_CMDREG,CMD_FORMAT);
		_sleep(HDA_IRQ);
		}
}

static void
empty_it()
{
    return;
}

/*sysnopsis des commandes read,write et format*/
void menu(){
   printf("**************MENU**************\n");
   printf("pour lire un secteur taper : ./drive -r num_cylindre num_secteur\n");
   printf("pour ecrire sur un secteur taper : ./drive -w num_cylindre num_secteur\n");
   printf("pour formater un secteur taper : ./drive -f num_cylindre num_secteur nbr_sec\n");
}

int infoCyl(){
	_out(HDA_CMDREG,CMD_DSKINFO);
	return _in(HDA_DATAREGS+1);
}

int infoSect(){
	_out(HDA_CMDREG,CMD_DSKINFO);
	return _in(HDA_DATAREGS+3);
}

int tailleSect(){
	unsigned int r;
	_out(HDA_CMDREG,CMD_DSKINFO);
	r=_in(HDA_DATAREGS+4)<<8;
	r=r|_in(HDA_DATAREGS+5);
	return r;
}

/*int
main(int argc, char **argv)
{
    unsigned int i;
	int t,cy,sec;
    char * cmdname = argv[0];
   //init hardware 
    if(init_hardware("hardware.ini") == 0) {
	fprintf(stderr, "Error in hardware initialization\n");
	exit(EXIT_FAILURE);
    }
    
    // Interreupt handlers 
    for(i=0; i<16; i++)
	IRQVECTOR[i] = empty_it;

    // Allows all IT 
    _mask(1);
   
     t=tailleSect();
     cy=infoCyl();
     sec=infoSect();
    unsigned char  buffer[t];
   
    //synopsis commande incorrecte
    if((argc != 5)&&(argc !=  3) &&(argc != 4)){
      menu();
      return 1;
    }
    //adresse inexistant sur le disque
    if(atoi(argv[2])>cy-1||atoi(argv[3])>sec-1){
      printf("Adresse inexistant sur le disque\n");
      return 0;
    }
    
   if((strcmp(argv[1],"-r") == 0)&&(argc == 4)){
      read_sector(atoi(argv[2]), atoi(argv[3]), buffer);
      fprintf(stdout,"%s",buffer);
      return 0;
    }
    else if((strcmp(argv[1],"-w") == 0)&&(argc == 4)){
	  fgets(buffer,t,stdin);
	  write_sector(atoi(argv[2]), atoi(argv[3]), buffer);
	  return 0;
	}
	//on formate un secteur seulement
    else if((strcmp(argv[1],"-f") == 0)&&(argc == 5)){
	    format_sector(atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), 0);
	    return 0;
	  }

    else{
	      menu();
	      return 1;
	    }
   

}
*/



