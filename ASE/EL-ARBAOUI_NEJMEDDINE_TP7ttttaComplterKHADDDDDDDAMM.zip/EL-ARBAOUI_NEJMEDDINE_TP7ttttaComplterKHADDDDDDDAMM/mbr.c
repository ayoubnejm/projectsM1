/* LIBRAIRIES */
/* ---------- */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include <assert.h>

/* Entêtes */
#include "mbr.h"
#include "drive.h"


/* Fonction "load_mbr" */

int load_mbr(){	
  assert(sizeof(struct mbr_descr_s) <= HDA_SECTORSIZE);
  unsigned char buffer[HDA_SECTORSIZE];
  int i;
  read_sector(0, 0, buffer);
  memcpy(&mbr,buffer,sizeof(struct mbr_descr_s));
  // printf("mbr.mbr_magic := %d\n",mbr.mbr_magic);
  if(mbr.mbr_magic != MBR_MAGIC){
    
      printf("MBR n'a pas encore été initialisé\n");
       for(i=0; i < HDA_MAXSECTOR; i++ ){
	 format_sector(i, 0,HDA_MAXCYLINDER, 0);
      }
       printf("Le disque est formaté\n");
       mbr.mbr_magic = MBR_MAGIC;
       mbr.mbr_n_vol = 0;
       save_mbr();
    }
  return 0;
}

/* Procédure "save_mbr" */
void save_mbr(){
 char buffer[HDA_SECTORSIZE];
  memcpy(buffer,(char*)&mbr,HDA_SECTORSIZE);
  write_sector(0,0,buffer);
}

/*Fonction type_to_string*/
char * type_to_string (enum vol_type_e type) {
	
if (type == base) return "base";
if (type == annexe) return "annexe";
if (type == other) return "other";

exit(EXIT_FAILURE);
}


/* Procédure "mbr_info" */
void mbr_info() {
	int i;
		
	printf("Nombre de volumes : %d \n", mbr.mbr_n_vol);
	
	char couleur[8][6]= {"\033[37m","\033[31m","\033[32m","\033[33m","\033[34m","\033[35m","\033[36m","\033[37m"};
	
	for (i=0; i < mbr.mbr_n_vol; i++) {
		printf("%s\033[40m volume n°%d : (%d,%d,%d,%s)\033[00m\n",
		couleur[i],
		i,
		mbr.mbr_vol[i].vol_first_cylindre,
		mbr.mbr_vol[i].vol_first_sector,
		mbr.mbr_vol[i].vol_n_bloc,
		type_to_string(mbr.mbr_vol[i].vol_type)
		);
	}
	printf("\n");
}



unsigned int cylinder_of_bloc(unsigned int vol, unsigned int bloc){

  assert(vol <= MAX_VOL);
  assert(bloc <= mbr.mbr_vol[vol].vol_n_bloc);
  return ( mbr.mbr_vol[vol].vol_first_cylindre + ( mbr.mbr_vol[vol].vol_first_sector  + bloc ) /  HDA_MAXSECTOR ) ;
	

}

unsigned int sector_of_bloc(unsigned int vol, unsigned int bloc){

  assert(vol <= MAX_VOL);
  assert(bloc <= mbr.mbr_vol[vol].vol_n_bloc);


  return (( mbr.mbr_vol[vol].vol_first_sector  + bloc ) %  HDA_MAXSECTOR ); 


}

/* Fonction "read_bloc" */
void read_bloc(unsigned int vol, unsigned int bloc, unsigned char *buffer){
  read_sector(cylinder_of_bloc(vol,bloc),sector_of_bloc(vol,bloc),buffer);

}

/* Fonction "write_bloc" */
void write_bloc(unsigned int vol, unsigned int bloc, unsigned char *buffer){
  write_sector(cylinder_of_bloc(vol,bloc),sector_of_bloc(vol,bloc),buffer);
}











