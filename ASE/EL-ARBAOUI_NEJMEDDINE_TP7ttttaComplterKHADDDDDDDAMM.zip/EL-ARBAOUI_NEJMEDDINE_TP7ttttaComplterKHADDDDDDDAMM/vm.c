/* ------------------------------
   $Id: vm-skel.c,v 1.1 2002/10/21 07:16:29 marquet Exp $
   ------------------------------------------------------------

   Volume manager skeleton.
   Philippe Marquet, october 2002

   1- you must complete the NYI (not yet implemented) functions
   2- you may add commands (format, etc.)
   
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "include/hardware.h"
#include "vol.h"
#include "drive.h"



/*la structure de la commande*/
struct _cmd {
    char *name;
    void (*fun) (struct _cmd *c);
    char *comment;
};

/*les fonctions des commandes*/
static void dvol(struct _cmd *c);
static void mkvol(struct _cmd *c);
static void format(struct _cmd *c);
static void del(struct _cmd *c);
static void help(struct _cmd *c) ;
static void save(struct _cmd *c);
static void quit(struct _cmd *c);
static void xit(struct _cmd *c);
static void none(struct _cmd *c) ;
static void read(struct _cmd *c) ;
static void write(struct _cmd *c) ;
static void infoMbr(struct _cmd *c) ;

/*le tableau des comandes*/
static struct _cmd commands [] = {
    {"dvol", dvol, 	"display the partition table"},
	{"infoMbr", infoMbr,  "display the mbr info"},
    {"mkvol",  mkvol,	"create a new partition"},
    {"read", read,	"read un bloc"},
    {"write", write,	"write dans un bloc"},
    {"format", format,	"format a partition"},
    {"del",  del,	"delete a partition"},
    {"save", save,	"save the MBR"},
    {"quit", quit,	"save the MBR and quit"},
    {"exit", xit,	"exit (without saving)"},
    {"help", help,	"display this help"},
    {0, none, 		"unknown command, try help"}
} ;


/* ------------------------------
   dialog and execute 
   ------------------------------------------------------------*/

/*éxecuter la commande a partir d'une chaine de caractère*/
static void execute(const char *name)
{
    struct _cmd *c = commands;
  
    while (c->name && strcmp (name, c->name)){
	c++;
	
    }
	(*c->fun)(c);
}

static void loop(void)
{
    char name[64];
    
    while (printf("> "), scanf("%62s", name) == 1)
	execute(name) ;
}

/* ------------------------------------------------------------
		      command execution 
   ------------------------------------------------------------*/
static void dvol(struct _cmd *c)
{
	int i;
	if(mbr.mbr_n_vol == 0) printf("Le disque est vide. Créer un volume avec 'mkvol' S.V.P\n");
	else{
		for(i = 0; i < mbr.mbr_n_vol; i++){
			info_vol(i);
		}
	}
}

static void mkvol(struct _cmd *c)
{
	unsigned int nbrbloc;
	char input[64];
	enum vol_type_e type;
	printf("> ");
	printf("Donnez le nombre de bloc du volume que vous voulez créer : ");
	if(scanf("%62s", input)){
		type = base;
		nbrbloc = atoi(input);
		init_vol(nbrbloc,type);
	}
	else{
		printf("> ");
		printf("Erreur creation partition\n");
	}
}



static void infoMbr(struct _cmd *c)
{
	mbr_info();
}
static void read(struct _cmd *c)
{       
    	char input[64];
        char inputdeux[64];
        int t=tailleSect();
	unsigned char  buffer[t];
	printf("> ");
	printf("Donner le vol et le bloc a lire : ");
        if(scanf("%62s %62s", input, inputdeux)){
	  unsigned int vol = atoi(input);
	  unsigned int bloc= atoi(inputdeux);
	  read_bloc(vol, bloc, buffer);
	  fprintf(stdout,"%s",buffer);
	
	}
}


static void write(struct _cmd *c)
{
	char input[64];
        char inputdeux[64];
        int t=tailleSect();
	unsigned char  buffer[t];
	printf("> ");
        printf("Donner le vol puis le bloc dans lesquels vous voulez écrire puis ce que vous voulez écrire : ");
        if(scanf("%62s %62s", input, inputdeux)){
	  unsigned int vol = atoi(input);
	  unsigned int bloc= atoi(inputdeux);
	  fgets(buffer,t,stdin);
	  write_bloc(vol, bloc, buffer);
	}
}

static void format(struct _cmd *c)
{
	unsigned int vol;
	char input[64];
	printf("> ");
	printf("Donnez le numéro de volume que vous voulez formater: ");
	if(scanf("%62s", input)){
		vol = atoi(input);
		format_vol(vol);
	}
	else{
		printf("> ");
		printf("Erreur format partition\n");
	}
}

static void del(struct _cmd *c)
{
	/* Déclaration des variables */
	char name[8];
	unsigned int vol;


	/* Saisie de la partition désirée */
	do
	{
		fprintf(stdout, "Partition to delete : \033[32m(integer)\033[00m ");
		fgets(name,8, stdin);
		vol = atoi(name);

		if( vol < 0 || vol > MAX_VOL)
		{
			fprintf(stdout, "\033[31mPartition incorrect!\033[00m\r\n");
		}
	}
	while(vol < 0 || vol > MAX_VOL);

	/* Affichage du warning */
	fprintf(stdout, "\033[31mBE CAREFUL !\033[00m\r\n");
	fprintf(stdout, "\033[31mIf you continue, you will erase all informations on this partition.\033[00m\r\n");
	fprintf(stdout, "\033[31mErase can not be undone !\033[00m\r\n");
	fprintf(stdout, "\r\n");
	fprintf(stdout, "If you want continue, enter 'y' : ");

	/* Demande confirmation */
	if (getchar() == 'y')
	{
		/* Affichage "en cours" */
		fprintf(stdout, "Erasing in progress...\r\n");

		/* Suppression de la partition */
		del_vol(vol);
	}
	else
	{
		/* Affichage "annulé" */
		fprintf(stdout, "Erasing canceled.\r\n");
	}

	/* Retrait du saut à la ligne */
	getchar();


}

static void save(struct _cmd *c)
{
  save_mbr();
  printf("MBR saved successfully!\n");  
}

static void quit(struct _cmd *c)
{
  save(c);
  xit(c);
}

static void do_xit()
{
    exit(EXIT_SUCCESS);
}

static void xit(struct _cmd *dummy)
{
    do_xit(); 
}

static void help(struct _cmd *dummy)
{
    struct _cmd *c = commands;
  
    for (; c->name; c++) 
	printf ("%s\t-- %s\n", c->name, c->comment);
}

static void none(struct _cmd *c)
{
    printf ("%s\n", c->comment) ;
}

static void empty_it(){
    return;
}

static void init(){
	unsigned int i;
    
	/* init hardware */
	if(init_hardware("hardware.ini") == 0) {
	    fprintf(stderr, "Error in hardware initialization\n");
	    exit(EXIT_FAILURE);
	}

	/* Interreupt handlers */
	for(i=0; i<16; i++)
	    IRQVECTOR[i] = empty_it;

	/* Allows all IT */
	_mask(1);

	
}

int main(int argc, char **argv){
  init();
  load_mbr();
  /* dialog with user */ 
   
  loop();
  
  /* abnormal end of dialog (cause EOF for xample) */
  do_xit();
  
  /* make gcc -W happy */
  exit(EXIT_SUCCESS);
}


