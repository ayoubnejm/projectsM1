#include <assert.h>
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "vol.h"

  
void init_vol(unsigned int taille, enum vol_type_e type){
	unsigned int cylinder, sector;
	int i;
         
	if(enoughPlace(taille)){
	  /* premier volume doit commencer au cylibdre 0 mais au secteur 1 */
	  if(mbr.mbr_n_vol == 0){
	    cylinder = 0;
	    sector = 1;
	  }
	  /* nombre maximal de volume */
	  else if(mbr.mbr_n_vol == MAX_VOL) {
	    printf("- Erreur, aucun volume ne peut être créé\n");
	    return;
	  }
	  /* cas normal, créer le volume */
	  else{ /* problème si il y a un volume(pas la dernière) qui est supprimé */
		//le cylindre calculé grace au cylindre du volume précédent et du nombre de secteurs de celui ci
	    cylinder = mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_cylindre
			 + (mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_sector + mbr.mbr_vol[mbr.mbr_n_vol-1].vol_n_bloc) / HDA_MAXSECTOR;
	    //le secteur calculé grace au secteur du volume précédent et du nombre de secteurs de celui ci 
	    sector = (mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_sector + mbr.mbr_vol[mbr.mbr_n_vol-1].vol_n_bloc) % HDA_MAXSECTOR;
	  }
	  mbr.mbr_vol[mbr.mbr_n_vol].vol_first_cylindre = cylinder;
	  mbr.mbr_vol[mbr.mbr_n_vol].vol_first_sector = sector;
	  mbr.mbr_vol[mbr.mbr_n_vol].vol_n_bloc = taille;
	  mbr.mbr_vol[mbr.mbr_n_vol].vol_type = type;
	  printf("- Volume %d est crée sur le disk.\n", mbr.mbr_n_vol);
	  mbr.mbr_n_vol++;
	}else{
	  printf("- Pas assez de place dans le disque.\n", mbr.mbr_n_vol);
	}	
}


/**
 * Retourne 1 s'il ya assez de place pour crééer un volume de taille 'taille'
 * après le dernier volume existant.
 *
 */
int enoughPlace(int taille){
  int cy=infoCyl();
  int sec=infoSect();
  int dernier_sector_vol = (mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_sector + mbr.mbr_vol[mbr.mbr_n_vol-1].vol_n_bloc) % sec;
  int dernier_cylinder_vol = mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_cylindre
			 + (mbr.mbr_vol[mbr.mbr_n_vol-1].vol_first_sector + mbr.mbr_vol[mbr.mbr_n_vol-1].vol_n_bloc) / sec;
  int place_restante = ((cy-dernier_cylinder_vol+1)*sec)-dernier_sector_vol;

  if(place_restante >= taille){
    return 1;
  }else{
    return 0;
  }
}




void info_vol(unsigned int vol){
         int t=tailleSect();
        printf("- Information générale de Volume %u\n", vol);
	printf("	-Ce volume dans le disk, premier cylindre: %u, premier secteur: %u\n", mbr.mbr_vol[vol].vol_first_cylindre, mbr.mbr_vol[vol].vol_first_sector);
	printf("	-Nombre de bloc de ce volume: %u\n", mbr.mbr_vol[vol].vol_n_bloc);	
	printf("	-Taille de ce volume: %u\n", mbr.mbr_vol[vol].vol_n_bloc * t);
	printf("	-Type de ce volume: %s\n",  vol_type_table[mbr.mbr_vol[vol].vol_type]);

}

void del_vol(unsigned int vol){
	int i;
	if(mbr.mbr_n_vol > vol){
	 /* format_sector(mbr.mbr_vol[vol].vol_first_cylindre, mbr.mbr_vol[vol].vol_first_sector, mbr.mbr_vol[vol].vol_n_bloc, 0);*/
	  for(i = vol; i < mbr.mbr_n_vol-1; i++) {
	    mbr.mbr_vol[i] = mbr.mbr_vol[i+1];
	  }
	  mbr.mbr_n_vol--;	
		
	  fprintf(stdout, "\033[32mErasing successfull !\033[00m\r\n");
	  printf("- Volume %d est supprimé du disk.\n", vol);
	
	}
	else{
	  printf("- Erreur, ce volume n'existe pas!\n");
	}
}

void format_vol(unsigned int vol){
	
	int i, nbBloc;
	nbBloc = mbr.mbr_vol[vol].vol_n_bloc;
	if(mbr.mbr_n_vol > vol){
		for(i=0; i < nbBloc; i++) {
			format_sector (cylinder_of_bloc(vol,i), sector_of_bloc(vol,i), 1, 42);
		}
		printf("- Volume %d est formaté.\n", vol);
	}
	else{
		printf("- Erreur, ce volume n'existe pas!\n");
	}
}



void list_vols(){
  unsigned int i;
  if(!mbr.mbr_n_vol){

    printf("Aucun volume n'existe sur le disque\n");

  }else{

    for(i=0; i<mbr.mbr_n_vol;i++){
      info_vol(i);
    }
    
  }
}


