#include <stdio.h>
#include <stdlib.h>

#include "super.h"
#include "vol.h"


#include "hardware.h"



static void empty_it(){
    return;
}

static void init1(){
	unsigned int i;
    
	/* init hardware */
	if(init_hardware("hardware.ini") == 0) {
	    fprintf(stderr, "Error in hardware initialization\n");
	    exit(EXIT_FAILURE);
	}

	/* Interreupt handlers */
	for(i=0; i<16; i++)
	    IRQVECTOR[i] = empty_it;

	/* Allows all IT */
	_mask(1);
}
int main(int argc, char** argv)
{
	init1();
	load_mbr();


    if (argc < 2)
        return 0;
    unsigned int i;
    int block_to_get = atoi(argv[2]);
    
 
    
    if (load_super(0) == 0)
    {
        if (atoi(argv[1]) == 0){
            for (i = 0; i < block_to_get; ++i){
            if(new_bloc())
			printf("got block %u\n", new_bloc());
			}
		}else{
            free_bloc(block_to_get);
			printf("free block %u\n",block_to_get); 
			}
		
    }
        
}
