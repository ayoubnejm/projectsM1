/*----------------------------------------------
Traduction du hardware.ini en "fichier".h
  ------------------------------------------------*/


#define HDA_FILENAME   "vdiskA.bin"   // nom du fichier de stockage du disque simulé
#define HDA_CMDREG       0x3F6        // registre de commande du disque maitre
#define HDA_DATAREGS     0x110        // base des registres de données (r,r+1,r+2,...r+7)
#define HDA_IRQ          14           // Interruption du disque
#define HDA_MAXCYLINDER  16           // Nombre de pistes du disque maître 
#define HDA_MAXSECTOR    16           // Nombre de secteurs du disque maître
#define HDA_SECTORSIZE   150          // Taille (en octet) dun secteur du disque maître
#define HDA_STPS         2            // nombre de SYSTICK pour changer de secteur
#define HDA_STPC         1            // nombre de SYSTICK pour changer de piste 
#define HDA_PON_DELAY    30           // nombre de SYSTICK avant amorce du disque
#define HDA_POFF_DELAY   30           // nombre de SYSTICK avant arret du disque */


void read_sector(unsigned int cylindre, unsigned int sector, unsigned char *buffer);

void write_sector(unsigned int cylindre, unsigned int sector, const unsigned char *buffer);

void format_sector(unsigned int cylindre, unsigned int sector, unsigned int nsector, unsigned int value);

void seek(int numcyl, int numsec);




