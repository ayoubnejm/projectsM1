#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "vol.h"
#include "drive.h"
#include "super.h"
#include "hardware.h"

#define MAX_ARG     3

static void empty_it(){
    return;
}

static void init1(){
	unsigned int i;
    
	/* init hardware */
	if(init_hardware("hardware.ini") == 0) {
	    fprintf(stderr, "Error in hardware initialization\n");
	    exit(EXIT_FAILURE);
	}

	/* Interreupt handlers */
	for(i=0; i<16; i++)
	    IRQVECTOR[i] = empty_it;

	/* Allows all IT */
	_mask(1);
}
	
int main(int argc, char** argv)
{
    char* volume_string;
    const char* nom;
    char resp;

    unsigned int serial;
    unsigned int volume;

    volume_string = getenv("$CURRENT_VOLUME");
    
    if (!volume_string)
    {
        printf("ATTENTION: Aucun volume declare dans $CURRENT_VOLUME ou sa valeur est incorrecte, le volume 0 sera utilise.\n");
        volume = 0;
		current_volume=volume;
    }
    else
        volume = atoi(volume_string);
		current_volume=volume;
    
    if (argc < MAX_ARG)
    {
        printf("Usage: %s Nom Serial\n", argv[0]);
        printf("Cree un nouveau systeme de fichier sur le volume designe par $CURRENT_VOLUME (0 par defaut) avec pour nom Nom et numero de serie Serial.\n");
        exit(EXIT_SUCCESS);
    }
    
    nom = argv[1];
    serial = atoi(argv[2]);
    
    printf("Creation du systeme de fichier de nom %s, de numero de serie %u sur le volume %u.\n", nom, serial, volume);
	
    do
    {
        printf("\n");
        printf("Est-ce correct (o/n) ? ");
		
    }
    while (scanf("%c", &resp) != 1 || (resp != 'o' && resp != 'n'));
    
    if (resp == 'n')
    {
        printf("Abandon de la procedure par l'utilisateur.\n");
        exit(EXIT_SUCCESS);
    }
	init1();
	load_mbr();
	load_super(volume);
    init_super(volume,serial,nom);
	

    
    
    exit(EXIT_SUCCESS);
}

