#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "mbr.h"
#include "super.h"
#define SUPER 0
#define BLOC_SIZE 256
#define BLOC_NULL 0

void init_super(unsigned int vol, unsigned int serial, const char* name)
{
	
	/*on declare le super bloc 	*/
	struct free_block_s fb; 
    unsigned int free_size; 
    unsigned char buf[BLOC_SIZE];
	/*initialisation du magique key*/
    super.super_magic = SUPER_MAGIC;  
    free_size=mbr.mbr_vol[vol].vol_n_bloc-1;// prend l nbr de bloc-1
	printf("%d",free_size);
    super.super_nb_free = free_size;
    /*le premier bloc libre est le bloc 1*/
    super.super_first_free=1;
    super.super_root=2;
    /*super name et serial*/
    memcpy(super.super_name, name, 32);
    super.super_name[31]=0;
    super.super_serial=serial;

    /*on copie super dans le buffer*/
    *((struct super_s *)buf)=super;
    write_bloc(vol, SUPER, buf);
    /*initialisation du mbr*/
    fb.fb_n_blocks=free_size;
    fb.fb_next=0;
    *((struct free_block_s *)buf)=fb; 
    write_bloc(vol, SUPER+1, buf);


}


int load_super(unsigned int vol)
{
	unsigned char buf[BLOC_SIZE];	
	
	read_bloc(vol, SUPER, buf);
	super=*(struct super_s *)buf;
	read_bloc(vol, SUPER, buf);

	   if(super.super_magic==SUPER_MAGIC){
			current_volume=vol;
 			super=*(struct super_s *)buf;
 
	  		return EXIT_SUCCESS;
		}

	   return EXIT_FAILURE;  
}


void save_super()
 {
	
   unsigned char buf[BLOC_SIZE];
  (*(struct super_s *)buf)=super;
  write_bloc(current_volume,SUPER,buf);
}


unsigned int new_bloc()
 {

    struct free_block_s fb;
	unsigned int nbloc;
    unsigned  char buf[BLOC_SIZE];
	
	   if (!super.super_nb_free)
   {
     printf("Impossible d'allouer un nouveau bloc ,volume plein\n");
     return 0 ;
   }

	if(super.super_magic != SUPER_MAGIC){ 
		fprintf(stderr, "Load a super bloc first\n");
		return 0;
	}


	fb=*((struct free_block_s *)buf);
	//lire le premier bloc libre
    read_bloc(current_volume, super.super_first_free, buf);
	super.super_nb_free--;
    nbloc = super.super_first_free;
	if(nbloc == 0) return 0; 
	if(fb.fb_n_blocks == 1){
		super.super_first_free = fb.fb_next;
	}
	else {
		super.super_first_free++;
		fb.fb_n_blocks--;
		*((struct free_block_s *)buf)=fb;
		write_bloc(current_volume, nbloc+1, buf);
	}

	save_super();
	return nbloc;
	
}


void free_bloc(unsigned int bloc)
 {
	
	struct free_block_s fb;
    unsigned char buf[BLOC_SIZE];
	unsigned int nbrBloc=mbr.mbr_vol[current_volume].vol_n_bloc;
	/* PAS le bloc 0 */
    if (!bloc){
        printf("Impossible de libérer le BLOC 0 <Super BLOC>");
		return;
	}
    if (bloc>nbrBloc)
   {
     printf("Impossible de libérer le bloc %u , car il n'existe pas \n", bloc);
     return ;
   }
	   if (super.super_nb_free==nbrBloc-1)
   {
     printf("Impossible de désallouer un bloc, Vous avez déppasez le nbr total : %u \n",nbrBloc);
     return ;
   }
    fb.fb_n_blocks=1;
	fb.fb_next=super.super_first_free;   
	super.super_first_free=bloc;
    super.super_nb_free++;
	 /*write block */
    *((struct free_block_s *)buf)=fb;
    write_bloc(current_volume, bloc, buf);
    save_super();

}

