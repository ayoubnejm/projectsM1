#define SUPER_MAGIC 0x01234567
#define FB_MAGIC 0x76543210
#define MAX_NAMESIZE   32

/*Variables globales*/
struct super_s super;
unsigned int current_volume;
/*************/


struct super_s
{
   unsigned int super_magic;
   unsigned int super_serial;
   unsigned int super_root;
   char super_name [MAX_NAMESIZE];
   unsigned int super_first_free;
   unsigned int super_nb_free;
   
   
};


struct free_block_s
{

   unsigned int fb_n_blocks;
   unsigned int fb_next;
   unsigned int fb_magic;

};




void init_super(unsigned int vol, unsigned int serial, const char* name);
void save_super();
int load_super(unsigned int vol);
unsigned int new_bloc();
void free_bloc(unsigned int bloc);
