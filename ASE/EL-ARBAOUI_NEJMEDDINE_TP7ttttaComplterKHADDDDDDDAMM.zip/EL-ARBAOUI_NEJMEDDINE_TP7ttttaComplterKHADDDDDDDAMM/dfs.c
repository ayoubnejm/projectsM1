#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "vol.h"
#include "drive.h"
#include "super.h"
#include "hardware.h"



static void empty_it(){
    return;
}

static void init1(){
	unsigned int i;
    
	/* init hardware */
	if(init_hardware("hardware.ini") == 0) {
	    fprintf(stderr, "Error in hardware initialization\n");
	    exit(EXIT_FAILURE);
	}

	/* Interreupt handlers */
	for(i=0; i<16; i++)
	    IRQVECTOR[i] = empty_it;

	/* Allows all IT */
	_mask(1);
}

int main(int argc, char** argv)
{
	init1();
	load_mbr();


    unsigned int i;
    unsigned int max_vol = mbr.mbr_n_vol;
	unsigned int nbrBloc=mbr.mbr_vol[current_volume].vol_n_bloc;

	if (argc > 1)
    {
        printf("Usage: ./dfs\n");
        printf("Display file System\n");
        exit(EXIT_SUCCESS);
    }

    for (i = 0; i < max_vol; ++i)
    {
        if (load_super(i) == 0)
        {
            printf("Volume %u : dispose d'un systeme de fichier.\n", i);
            printf("%s : Nb total de blocs => %u , numero de série du volume => %d ,nb bloc libres => %u.\n", super.super_name, nbrBloc, super.super_serial,super.super_nb_free);
        }
        else
        {
            printf("Volume %u : pas de systeme de fichier.\n", i);
        }
    }
    
 
}

