TP3 réalisé par Ayoub NEJMEDDINE  &  Sara EL ARBAOUI

TP3 Statut : TERMINE

La premiere partie du tp fut relativement simple à coder, la fonction yield decoulait directement de l'implementation vue en TD. Les fonctions create_ctx et switch_to_ctx furent plus delicates à implementer, en effet l'anneau de contextes (ctx_ring) etait à prendre en compte lors de la creation du contexte.

La seconde partie consistait principalement à integrer les interruptions dans le programme et à definir les sections critiques.


Nom de l'executable : pingpong
