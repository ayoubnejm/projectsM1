/* Librairies standards */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
/* Entêtes */
#include "ctx.h"
#include "hw.h"

/* Variables globales */
static struct ctx_s *CONTEXTE_COURANT = NULL;
static struct ctx_s* ctx_ring = NULL;

/* Fonction "start_current_context"  qui permet d'executer un context pour la premiere fois */
void start_current_context (){

	CONTEXTE_COURANT -> state= active ;
	CONTEXTE_COURANT -> f ( CONTEXTE_COURANT -> args);
	CONTEXTE_COURANT -> state = terminated ;
	yield();
}

/* Fonction "init_ctx" */
int init_ctx (struct ctx_s * ctx, int stack_size, func_t f, void * args) {
	
	/* Assignation du pointeur de fonction */
	ctx->f = f;
	
	/* Assignation du pointeur des arguments */
	ctx->args= args;

	/* Assignation du status */
	ctx->state = undefined;

	/* Assignation du nombre magique */
	ctx->ctx_magic = CTX_MAGIC;

	/* Allocation de la pile */
	ctx->ctx_stack = (unsigned char*) malloc(stack_size);
	
	/* Assignation du pointeur EBP */
	ctx->ctx_ebp = ctx-> ctx_stack + stack_size - 4;

	/* Assignation du pointeur ESP */
	ctx->ctx_esp = ctx->ctx_ebp;

	return  EXIT_SUCCESS;
 
}
 



/*Initialise et crée la boucle de contexte*/
int create_ctx(int stack_size, func_t f, void * args) {

	struct ctx_s * ctx;
	ctx = (struct ctx_s*) malloc(sizeof (struct ctx_s));
	assert(ctx);

	/*Ajout d'un contexte à la boucle*/
	if(ctx_ring){
		ctx->next = ctx_ring->next ;
		ctx_ring->next = ctx;
	}
	/*Création de la boucle de contexte */ 
	else{
		ctx_ring = ctx;
		ctx_ring->next = ctx;

	}
	return init_ctx(ctx,stack_size,f,args);

}
 


/*Appelle la fonction de changement de contexte ou lance la boucle de contexte*/
void yield(){
	/*Si la boucle de contextes s'éxécute déjà*/
	if(CONTEXTE_COURANT){
		switch_to_ctx(CONTEXTE_COURANT->next);
	}
	/*Premier appel à yield()*/
	else{
		/*La boucle existe-t-elle ?*/
		assert(ctx_ring);
		switch_to_ctx(ctx_ring);
	}
}

/*Change de contexte*/
void switch_to_ctx (struct ctx_s * newctx) {
	struct ctx_s * tmp;

	assert(newctx -> ctx_magic == CTX_MAGIC );
	/* Un contexte est en cours */
	if( CONTEXTE_COURANT != NULL ){  

	/* Désactivation des interruptions*/ 
		irq_disable();
		asm ("mov %%esp, %0 \n\t"
		    "mov %%ebp, %1 "
		    : "=r" (CONTEXTE_COURANT->ctx_esp),
		      "=r" (CONTEXTE_COURANT->ctx_ebp)
		);

	/*  Réactivation des interruptions  */
		irq_enable();
		CONTEXTE_COURANT->state= inactive ;
	}

	/* Changement de contexte */
	CONTEXTE_COURANT = newctx;
	
	/************************************/
 	irq_disable();
	/************************************/
	 asm ("mov %0, %%esp \n\t"
		"mov %1, %%ebp "
		:
		: "r" (CONTEXTE_COURANT-> ctx_esp),
		  "r" (CONTEXTE_COURANT-> ctx_ebp)
	 );
	/************************************/
	irq_enable();
	/************************************/
	/*Si le contexte courant n'a pas encore été lancé*/
	if( CONTEXTE_COURANT -> state == undefined ){
		start_current_context();
	}else{	
		CONTEXTE_COURANT -> state= active ;
		return ;
	}	
		
	 /*sauvegarde du contexte courant*/
	 while(newctx-> state==terminated){
		/************************************/
			irq_disable();
		/************************************/
			CONTEXTE_COURANT->next = newctx->next;
			tmp = newctx;
			newctx= newctx->next;
			free(tmp->ctx_stack);
			free(tmp);
		/************************************/
			irq_enable();
		/************************************/
	}

}
/*installe le gestionnaire d'interruption*/
void start_sched(){

	start_hw(); /* initialiser le materiel */
	setup_irq(TIMER_IRQ, yield);
	while(1){
		pause();
	}

}

