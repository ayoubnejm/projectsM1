#include <stdio.h>
#include <stdlib.h>
#include "ctx.h"



void f_ping();
void f_pong();

int main()
{
    create_ctx(16384, f_ping, NULL);
    create_ctx(16384, f_pong, NULL);
    start_sched();
    exit(EXIT_SUCCESS);
}

void f_ping()
{
    while(1)
    {
        printf("A");
        printf("B");
        printf("C");
    }
}

void f_pong()
{
    while(1)
    {
        printf("1");
        printf("2");
    }
}
