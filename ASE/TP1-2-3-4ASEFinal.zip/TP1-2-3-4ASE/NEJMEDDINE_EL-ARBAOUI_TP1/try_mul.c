#include "try.h"
#include <stdio.h>
#include <stdlib.h>

struct ctx_s* pctx;

static int mul(int depth)
{
    int i;

    switch (scanf("%d", &i))
    {
        case EOF: return 1;
        case 0: return mul(depth+1);
        case 1:
            if (i)
               return i * mul(depth+1);
           else
               throw(pctx, 0);
    }
    return 0;
}

int main()
{
    int product;

    pctx = (struct ctx_s*)malloc(sizeof(struct ctx_s));

    printf("A list a int, please\n");
    product = try(pctx, mul, 0);
    printf("product = %d\n", product);

    return 0;
}
