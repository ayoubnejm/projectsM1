#include "try.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static int val=1;

/* Fonction "try" sauvegarde un contexte */ 
int try(struct ctx_s* pctx, func_t* f, int arg)
{
    int ret;

    if (!pctx)
        exit(EXIT_FAILURE);


    asm("movl %%ebp, %0;"
        "movl %%esp, %1;"
        : "=r" (pctx->ctx_ebp), "=r" (pctx->ctx_esp)); /* sortie */


    ret = f(arg);

    return ret;
}

/* Fonction "throw" restaure un contexte */ 

int throw(struct ctx_s* pctx, int r)
{
	
    if (!pctx)
        exit(EXIT_FAILURE);

     val = r;
   

    asm("movl %0, %%ebp;"
        "movl %1, %%esp;"
        :
        : "r" (pctx->ctx_ebp), "r" (pctx->ctx_esp)); /* entree */
      

    return  val;
}

