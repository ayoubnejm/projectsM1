#ifndef _CTX_H_
#define _CTX_H_

typedef void (func_t)(void*);

void yield();

int create_ctx(int stack_size, func_t f, void * args);

#endif
