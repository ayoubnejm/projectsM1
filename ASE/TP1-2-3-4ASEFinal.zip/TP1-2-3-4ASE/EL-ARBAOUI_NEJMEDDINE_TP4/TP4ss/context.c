#define CTX_MAGIC 0xB16B00B5
#define CTX_ERRONE 0xBABEB00B5
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "hw.h"
#include "ctx.h"


/*Initialisation d'un contexte*/
int init_ctx(struct ctx_s *ctx, int stack_size, func_t f, void* args){
	if(stack_size<1){
		return 0;
	}

	ctx->ctx_size=stack_size;
	ctx->ctx_stack=malloc(stack_size);
	if(!ctx->ctx_stack){
		return 0;
	}
	ctx->ctx_esp=&ctx->ctx_stack[stack_size-4];
	ctx->ctx_ebp=&ctx->ctx_stack[stack_size-4];
	ctx->ctx_magic=CTX_MAGIC;
	ctx->ctx_state=CTX_RDY;

	if(!f){
		return 0;
	}
	ctx->ctx_f=f;
	ctx->ctx_arg=args;	
	return 1;
}


/*Exécute la fonction lié au contexte courant et modifie sa valeur s'il se termine*/
void start_current_ctx(void){
	current_ctx->ctx_state=CTX_EXQ;
	current_ctx->ctx_f(current_ctx->ctx_arg);
	current_ctx->ctx_state=CTX_END;
	current_ctx->ctx_magic=CTX_ERRONE;
	yield();
}

/*Change de contexte*/
/*ctx : contexte à effectuer*/
void switch_to_ctx(struct ctx_s* ctx){
	/*Tant que ctx n'existe pas ou est fini*/
	while((ctx)&&((ctx->ctx_state==CTX_END)||(ctx->ctx_state==CTX_STOP))){
		if(ctx->ctx_state==CTX_END){
			/*S'il ne reste qu'un contexte dans la boucle */ 
			if(current_ctx==ctx){
				/*Désactivation des interruptions*/ 
				irq_disable();
				/*Reprise du main*/
				asm("movl %0, %%esp" "\n\t" "movl %1, %%ebp"
				    : 
				    : "r"(ctx_main.ctx_esp), "r"(ctx_main.ctx_ebp)
				);
				/*Réactivation des interruptions*/
				irq_enable();
				free(ctx);
				ctx=&ctx_main;
			}
			/*Utilisation du chaînon suivant*/
			else{
				current_ctx->next=ctx->next;
				free(ctx);
				ctx=current_ctx->next;
			}
		}
		else if(ctx->ctx_state==CTX_STOP){
			ctx=ctx->next;
		}
	}
	/*Changement de contexte*/
	if((ctx)&&((ctx->ctx_magic==CTX_MAGIC)&&((ctx->ctx_state==CTX_RDY)||(ctx->ctx_state==CTX_EXQ)))){
		/*Le contexte courant existe*/
		if(current_ctx){
			/*Sauvegarde de l'état du contexte courant*/
			irq_disable();
			asm("movl %%esp, %0" "\n\t" "movl %%ebp, %1"
			: "=r"(current_ctx->ctx_esp), "=r"(current_ctx->ctx_ebp) 
			:);
			irq_enable();
		}
		/*Premier Appel de la fonction*/
		else{
			irq_disable();
			/*Sauvegarde du contexte de main*/
			asm("movl %%esp, %0" "\n\t" "movl %%ebp, %1"
			: "=r"(ctx_main.ctx_esp), "=r"(ctx_main.ctx_ebp) 
			:);
			irq_enable();
		}
		/*Remplacement ou initialisation du contexte courant par celui de ctx*/
		current_ctx=ctx;
		irq_disable();
		asm("movl %0, %%esp" "\n\t" "movl %1, %%ebp"
		    : 
		    : "r"(current_ctx->ctx_esp), "r"(current_ctx->ctx_ebp)
		);
		irq_enable();
		/*Si le contexte courant n'a pas encore été lancé*/
		if(current_ctx->ctx_state==CTX_RDY){
			start_current_ctx();
		}
	}
}

/*Appelle la fonction de changement de contexte ou lance la boucle de contexte*/
void yield(){
	/*printf("yield\n");*/
	/*Si la boucle de contextes s'éxécute déjà*/
	if(current_ctx){
		switch_to_ctx(current_ctx->next);
	}
	/*Premier appel à yield()*/
	else{
		/*La boucle existe-t-elle ?*/
		assert(ring_ctx);
		switch_to_ctx(ring_ctx);
	}
}

/*Initialise et crée la boucle de contexte*/
/*stack_size : Taille de la pile */
/*f : fonction exécuté par le contexte*/
/*args : arguments passé à la fonction f*/
int create_ctx(int stack_size, func_t f, void * args){
	struct ctx_s *new = malloc(sizeof(struct ctx_s));
	assert(new);
	/*Création de la boucle de contexte */ 
	if(!ring_ctx) {
		ring_ctx = new;
		ring_ctx->next = new;	
	}
	/*Ajout d'un contexte à la boucle*/
	else {
		new->next=ring_ctx->next;
		ring_ctx->next = new;
	}
	return init_ctx(new, stack_size, f, args);
}

/* Première Fonction exécuté par l'un des contexte */
void f_ping(void *args){
	int i;
	int a=0;
	while(a<100){
		sem_down(&sem);
		for(i=0;i<11000;i++){

		}
		printf("A");
		for(i=0;i<11000;i++){

		}
		printf("B");
		for(i=0;i<11000;i++){

		}
		printf("C");
		a++;
		sem_up(&sem);
	}
	printf("\nFIN de Ping\n");
}

/* Seconde Fonction exécuté par l'un des contexte */
void f_pong(void *args){
	int i;
	int a=0;
	while(a<100){
		sem_down(&sem);
		printf("1");
		for(i=0;i<11000;i++){

		}
		printf("2");
		for(i=0;i<11000;i++){

		}
		a++;
		sem_up(&sem);
	}
	printf("\nFIN de Pong\n");
}

/* Troisième Fonction exécuté par l'un des contexte */
void f_pang(void *args){
	int i;
	int a=0;
	while(a<100){
		sem_down(&sem);
		printf("Z");
		for(i=0;i<11000;i++){

		}
		a++;
		sem_up(&sem);
	}
	printf("\nFIN de Pang\n");
}

void sem_init(struct sem_s *sem, unsigned int val){
	assert(val>0);
	sem->cpt=val;
	sem->sem_first = NULL;
	sem->sem_last = NULL;
}

void sem_up(struct sem_s *sem){
	struct ctx_s *tmp;
	/*printf("sem_up debut ");*/
	irq_disable();
	sem->cpt++;
	if(sem->cpt <= 0){
		sem->sem_last->ctx_state=CTX_EXQ;
		tmp=sem->sem_last;
		if(sem->sem_last->ctx_sem_previous){
			sem->sem_last->ctx_sem_previous->ctx_sem_next=NULL;
			sem->sem_last=sem->sem_last->ctx_sem_previous;
		}
		else{
			sem->sem_last=NULL;			
			sem->sem_first=NULL;
		}
			tmp->ctx_sem_previous=NULL;
		irq_enable();
		/*printf(" sem_up fin ");*/
		switch_to_ctx(tmp);
	}
	irq_enable();
	/*printf("sem_up fin");	*/
}

void sem_down(struct sem_s * sem){
	/*printf(" sem_down debut ");*/
	irq_disable();
	sem->cpt--;
	if(sem->cpt < 0){
		if(!sem->sem_first){
			sem->sem_last=current_ctx;
		}
		else{
			sem->sem_first->ctx_sem_previous=current_ctx;
		}
		current_ctx->ctx_sem_next = sem->sem_first;
		sem->sem_first=current_ctx;
		current_ctx->ctx_state = CTX_STOP;
		irq_enable();
		/*printf(" sem_down fin ");*/
		yield();	
	}
	/*printf(" sem_down fin ");*/
	irq_enable();
}

/* MAIN */
int main(){
	sem_init(&sem,1);
	create_ctx(16384,f_ping,NULL);
	create_ctx(16384,f_pong,NULL);
	create_ctx(16384,f_pang,NULL);
	setup_irq(TIMER_IRQ, yield);
	start_hw();	
	yield();	
	printf("\nFin de Main\n");
	exit(EXIT_SUCCESS);
}

