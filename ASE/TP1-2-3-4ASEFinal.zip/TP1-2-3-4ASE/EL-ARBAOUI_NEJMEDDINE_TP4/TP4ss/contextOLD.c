#define CTX_MAGIC 0xB16B00B5
#define CTX_ERRONE 0xB16B00B5
#include <stdio.h>
#include <stdlib.h>
#include "ctx.h"
#include <assert.h>
#include "hw.h"


enum state_e { CTX_RDY, CTX_EXQ, CTX_END};

struct ctx_s {
	void * ctx_esp;
	void * ctx_ebp;
	unsigned ctx_magic;
	enum state_e ctx_state;
	unsigned ctx_size;
	char * ctx_stack;
	func_t* ctx_f;
	void* ctx_arg;
	struct ctx_s *next;
};

struct ctx_s *current_ctx=(struct ctx_s*)0;
struct ctx_s *ring_ctx =(struct ctx_s*)0;
struct ctx_s ctx_main;

int init_ctx(struct ctx_s *ctx, int stack_size, func_t f, void* args){
	if(stack_size<1){
		return 0;
	}

	ctx->ctx_size=stack_size;
	ctx->ctx_stack=malloc(stack_size);
	if(!ctx->ctx_stack){
		return 0;
	}
	ctx->ctx_esp=&ctx->ctx_stack[stack_size-4];
	ctx->ctx_ebp=&ctx->ctx_stack[stack_size-4];
	ctx->ctx_magic=CTX_MAGIC;
	ctx->ctx_state=CTX_RDY;

	if(!f){
		return 0;
	}
	ctx->ctx_f=f;
	ctx->ctx_arg=args;	
	return 1;
}



void start_current_ctx(void){
	current_ctx->ctx_state=CTX_EXQ;
	current_ctx->ctx_f(current_ctx->ctx_arg);
	current_ctx->ctx_state=CTX_END;
	current_ctx->ctx_magic=CTX_ERRONE;
	yield();
}

void switch_to_ctx(struct ctx_s* ctx){
	while((ctx)&&(ctx->ctx_state==CTX_END)){
		if(current_ctx==ctx){
			asm("movl %0, %%esp" "\n\t" "movl %1, %%ebp"
			    : 
			    : "r"(ctx_main.ctx_esp), "r"(ctx_main.ctx_ebp)
			);
			free(ctx);
			ctx=&ctx_main;
		}
		else{
			current_ctx->next=ctx->next;
			free(ctx);
			ctx=current_ctx->next;
		}
	}
	if((ctx)&&((ctx->ctx_magic==CTX_MAGIC)&&((ctx->ctx_state==CTX_RDY)||(ctx->ctx_state==CTX_EXQ)))){
		if(current_ctx){
			asm("movl %%esp, %0" "\n\t" "movl %%ebp, %1"
			: "=r"(current_ctx->ctx_esp), "=r"(current_ctx->ctx_ebp) 
			:);
		}
		else{
			asm("movl %%esp, %0" "\n\t" "movl %%ebp, %1"
			: "=r"(ctx_main.ctx_esp), "=r"(ctx_main.ctx_ebp) 
			:);
		}
		current_ctx=ctx;
		asm("movl %0, %%esp" "\n\t" "movl %1, %%ebp"
		    : 
		    : "r"(current_ctx->ctx_esp), "r"(current_ctx->ctx_ebp)
		);
		if(current_ctx->ctx_state==CTX_RDY){
			start_current_ctx();
		}
	}
}

void yield(){
	if(current_ctx){
		switch_to_ctx(current_ctx->next);
	}
	else{
		assert(ring_ctx);
		switch_to_ctx(ring_ctx);
	}
}

int create_ctx(int stack_size, func_t f, void * args){
	struct ctx_s *new = malloc(sizeof(struct ctx_s));
	assert(new);
	if(!ring_ctx) {
		ring_ctx = new;
		ring_ctx->next = new;		
	} else {
		new->next=ring_ctx->next;
		ring_ctx->next = new;
	}
	return init_ctx(new, stack_size, f, args);
}

void f_ping(void *args){
	int c=200;
	while(c){
		printf("A");
		yield();
		printf("B");
		yield();
		printf("C");
		yield();
		c--;
	}
	printf("\nFIN de Ping\n");
}

void f_pong(void *args){
	int d=100;
	while(d){
		printf("1");
		yield();
		printf("2");
		yield();
		d--;
	}
	printf("\nFIN de Pong\n");
}

void f_pang(void *args){
	int e=50;
	while(e){
		printf("Z");
		yield();
		e--;
	}
	printf("\nFIN de Pang\n");
}

int main(){
	create_ctx(16384,f_ping,NULL);
	create_ctx(16384,f_pong,NULL);
	create_ctx(16384,f_pang,NULL);
	yield();
	printf("\nFin de Main\n");
	exit(EXIT_SUCCESS);
}

