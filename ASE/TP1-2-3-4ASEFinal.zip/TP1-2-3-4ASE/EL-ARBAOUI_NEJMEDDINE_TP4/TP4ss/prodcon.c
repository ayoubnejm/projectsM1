#define CTX_MAGIC 0xB16B00B5
#define CTX_ERRONE 0xBABEB00B
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "hw.h"
#include "ctx.h"
#define N 100 

/*Enuméré d'état du contexte*/
enum state_e {CTX_RDY, CTX_EXQ, CTX_END, CTX_STOP};

/*Structure de contexte*/ 
struct ctx_s {
	int ctx_id;
	void *ctx_esp;
	void *ctx_ebp;
	unsigned ctx_magic;
	enum state_e ctx_state;
	unsigned ctx_size;
	char *ctx_stack;
	func_t* ctx_f;
	void* ctx_arg;
	struct ctx_s *next;
	struct ctx_s *ctx_sem_next;
	struct ctx_s *ctx_sem_previous;
};

struct sem_s {
	int cpt;
	struct ctx_s *sem_first;
	struct ctx_s *sem_last;
};

/*Contexte Courant*/
struct ctx_s *current_ctx=(struct ctx_s*)0;
/*Boucle de contexte*/
struct ctx_s *ring_ctx =(struct ctx_s*)0;
/*Contexte pour sauvegarder celui de main*/
struct ctx_s ctx_main;
struct sem_s mutex,vide,plein;
int entrepot[N]={0};

void sem_down(struct sem_s * sem);

void sem_up(struct sem_s *sem);

/*Initialisation d'un contexte*/
int init_ctx(struct ctx_s *ctx, int stack_size, func_t f, void* args){
	static int id=0;
	if(stack_size<1){
		return 0;
	}

	ctx->ctx_size=stack_size;
	ctx->ctx_stack=malloc(stack_size);
	if(!ctx->ctx_stack){
		return 0;
	}
	ctx->ctx_esp=&ctx->ctx_stack[stack_size-4];
	ctx->ctx_ebp=&ctx->ctx_stack[stack_size-4];
	ctx->ctx_magic=CTX_MAGIC;
	ctx->ctx_state=CTX_RDY;

	if(!f){
		return 0;
	}
	ctx->ctx_f=f;
	ctx->ctx_arg=args;
	ctx->ctx_id=id;
	id++;
	return 1;
}


/*Exécute la fonction lié au contexte courant et modifie sa valeur s'il se termine*/
void start_current_ctx(void){
	current_ctx->ctx_state=CTX_EXQ;
	current_ctx->ctx_f(current_ctx->ctx_arg);
	current_ctx->ctx_state=CTX_END;
	current_ctx->ctx_magic=CTX_ERRONE;
	yield();
}

/*Change de contexte*/
/*ctx : contexte à effectuer*/
void switch_to_ctx(struct ctx_s* ctx){
	/*Tant que ctx n'existe pas ou est fini*/
	while((ctx)&&((ctx->ctx_state==CTX_END)||(ctx->ctx_state==CTX_STOP))){
		if(ctx->ctx_state==CTX_END){
			/*S'il ne reste qu'un contexte dans la boucle */ 
			if(current_ctx==ctx){
				/*Désactivation des interruptions*/ 
				irq_disable();
				/*Reprise du main*/
				asm("movl %0, %%esp" "\n\t" "movl %1, %%ebp"
				    : 
				    : "r"(ctx_main.ctx_esp), "r"(ctx_main.ctx_ebp)
				);
				/*Réactivation des interruptions*/
				irq_enable();
				free(ctx);
				ctx=&ctx_main;
			}
			/*Utilisation du chaînon suivant*/
			else{
				current_ctx->next=ctx->next;
				free(ctx);
				ctx=current_ctx->next;
			}
		}
		else if(ctx->ctx_state==CTX_STOP){
			ctx=ctx->next;
		}
	}
	/*Changement de contexte*/
	if((ctx)&&((ctx->ctx_magic==CTX_MAGIC)&&((ctx->ctx_state==CTX_RDY)||(ctx->ctx_state==CTX_EXQ)))){
		/*Le contexte courant existe*/
		if(current_ctx){
			/*Sauvegarde de l'état du contexte courant*/
			irq_disable();
			asm("movl %%esp, %0" "\n\t" "movl %%ebp, %1"
			: "=r"(current_ctx->ctx_esp), "=r"(current_ctx->ctx_ebp) 
			:);
			irq_enable();
		}
		/*Premier Appel de la fonction*/
		else{
			irq_disable();
			/*Sauvegarde du contexte de main*/
			asm("movl %%esp, %0" "\n\t" "movl %%ebp, %1"
			: "=r"(ctx_main.ctx_esp), "=r"(ctx_main.ctx_ebp) 
			:);
			irq_enable();
		}
		/*Remplacement ou initialisation du contexte courant par celui de ctx*/
		current_ctx=ctx;
		irq_disable();
		asm("movl %0, %%esp" "\n\t" "movl %1, %%ebp"
		    : 
		    : "r"(current_ctx->ctx_esp), "r"(current_ctx->ctx_ebp)
		);
		irq_enable();
		/*Si le contexte courant n'a pas encore été lancé*/
		if(current_ctx->ctx_state==CTX_RDY){
			start_current_ctx();
		}
	}
}

/*Appelle la fonction de changement de contexte ou lance la boucle de contexte*/
void yield(){
	/*printf("yield\n");*/
	/*Si la boucle de contextes s'éxécute déjà*/
	if(current_ctx){
		switch_to_ctx(current_ctx->next);
	}
	/*Premier appel à yield()*/
	else{
		/*La boucle existe-t-elle ?*/
		assert(ring_ctx);
		switch_to_ctx(ring_ctx);
	}
}

/*Initialise et crée la boucle de contexte*/
/*stack_size : Taille de la pile */
/*f : fonction exécuté par le contexte*/
/*args : arguments passé à la fonction f*/
int create_ctx(int stack_size, func_t f, void * args){
	struct ctx_s *new = malloc(sizeof(struct ctx_s));
	assert(new);
	/*Création de la boucle de contexte */ 
	if(!ring_ctx) {
		ring_ctx = new;
		ring_ctx->next = new;	
	}
	/*Ajout d'un contexte à la boucle*/
	else {
		new->next=ring_ctx->next;
		ring_ctx->next = new;
	}
	return init_ctx(new, stack_size, f, args);
}

void produire_objet(int* objet){
	static int i=1;
	*objet=i;
	i++;
	printf("Le producteur %d cree l'objet %d.\n",current_ctx->ctx_id,i);
}

void mettre_objet(int objet){
	int i;
	int boolean=0;
	for(i=0;i<N;i++){
		if(!entrepot[i]){
			boolean=1;
			entrepot[i]=objet;
			printf("Le producteur %d met l'objet %d dans le hangar %d.\n",current_ctx->ctx_id,objet,i);
			break;
		}
	}
	if(!boolean){
		printf("Le producteur %d n'a pas trouver de place pour déposer l'objet %d.\n",current_ctx->ctx_id,objet);
	}	
}

void producteur(void *args){
	int i;
	int objet;

	while(1){
		produire_objet(&objet);
		sem_down(&vide);
		sem_down(&mutex);
		mettre_objet(objet);
		sem_up(&mutex);
		sem_up(&plein);
		for(i=0;i<11000;i++){

		}
	}
}

void retirer_objet(int* objet){
	int i;
	int boolean=0;
	for(i=0;i<N;i++){
		if(entrepot[i]){
			boolean=1;
			*objet=entrepot[i];
			entrepot[i]=0;
			printf("Le consommateur %d récupère l'objet i %d dans le hangar %d.\n",current_ctx->ctx_id,*objet,i);
			break;
		}
	}
	if(!boolean){
		printf("Le consommateur %d n'a pas trouvé d'objet.\n",current_ctx->ctx_id);
	}
}

void utiliser_objet(int objet){
	printf("Le consommateur %d utilise l'objet %d.\n",current_ctx->ctx_id,objet);
}

void consommateur(void *args){

	int objet;

	while(1){
		sem_down(&plein);
		sem_down(&mutex);
		retirer_objet(&objet);
		sem_up(&mutex);
		sem_up(&vide);
		utiliser_objet(objet);
	}
}


void sem_init(struct sem_s *sem, unsigned int val){
	assert(val>=0);
	sem->cpt=val;
	sem->sem_first = NULL;
	sem->sem_last = NULL;
}

void sem_up(struct sem_s *sem){
	struct ctx_s *tmp;
	/*printf("sem_up debut ");*/
	irq_disable();
	sem->cpt++;
	if(sem->cpt <= 0){
		sem->sem_last->ctx_state=CTX_EXQ;
		tmp=sem->sem_last;
		if(sem->sem_last->ctx_sem_previous){
			sem->sem_last->ctx_sem_previous->ctx_sem_next=NULL;
			sem->sem_last=sem->sem_last->ctx_sem_previous;
		}
		else{
			sem->sem_last=NULL;			
			sem->sem_first=NULL;
		}
			tmp->ctx_sem_previous=NULL;
		irq_enable();
		/*printf(" sem_up fin ");*/
		switch_to_ctx(tmp);
	}
	irq_enable();
	/*printf("sem_up fin");	*/
}

void sem_down(struct sem_s * sem){
	/*printf(" sem_down debut ");*/
	irq_disable();
	sem->cpt--;
	if(sem->cpt < 0){
		if(!sem->sem_first){
			sem->sem_last=current_ctx;
		}
		else{
			sem->sem_first->ctx_sem_previous=current_ctx;
		}
		current_ctx->ctx_sem_next = sem->sem_first;
		sem->sem_first=current_ctx;
		current_ctx->ctx_state = CTX_STOP;
		irq_enable();
		/*printf(" sem_down fin ");*/
		yield();	
	}
	/*printf(" sem_down fin ");*/
	irq_enable();
}

/* MAIN */
int main(){
	sem_init(&mutex,1);
	sem_init(&vide,N);
	sem_init(&plein,0);
	create_ctx(16384,consommateur,NULL);
	create_ctx(16384,producteur,NULL);
	create_ctx(16384,consommateur,NULL);
	create_ctx(16384,consommateur,NULL);
	create_ctx(16384,producteur,NULL);
	setup_irq(TIMER_IRQ, yield);
	start_hw();	
	yield();	
	printf("\nFin de Main\n");
	exit(EXIT_SUCCESS);
}

