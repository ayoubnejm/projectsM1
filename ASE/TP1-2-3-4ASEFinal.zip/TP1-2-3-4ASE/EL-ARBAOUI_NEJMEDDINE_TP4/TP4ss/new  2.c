/*
Changement de contexte sur IT
Biblioth�que semaphore
test de la bibliotheque semaphore
*/

struct sem_s {
	int cpt;
	struct ctx_s *sem_first;
	struct ctx_s *sem_last;
}

struct ctx_s {
	void *ctx_esp;
	void *ctx_ebp;
	unsigned ctx_magic;
	enum state_e ctx_state;
	unsigned ctx_size;
	char *ctx_stack;
	func_t* ctx_f;
	void* ctx_arg;
	struct ctx_s *next;
	struct ctx_s *ctx_sem_next;
	struct ctx_s *ctx_sem_previous;
}

enum state_e {CTX_RDY, CTX_EXQ, CTX_END, CTX_STOP}


void sem_init(struct sem_s *sem, unsigned int val){
	assert(val>0);
	sem->cpt=val;
	sem->sem_first = NULL;
	sem->sem_last = NULL;
}


void sem_up(struct sem_s *sem){
	struct ctx_s *tmp;
	irq_disable();
	sem->cpt++;
	if(sem->cpt <= 0){
		sem->sem_last->ctx_state=CTX_EXQ;
		sem->sem_last->ctx_sem_previous->ctx_sem_next=NULL;
		tmp=sem->sem_last;
		sem->sem_last=sem->sem_last->ctx_sem_previous;
		tmp->ctx_sem_previous=NULL;
		irq_enable();
		switch_to(tmp);
	}
	irq_enable();	
}

void sem_down(struct sem_s * sem){
	irq_disable();
	sem->cpt--;
	if(sem->cpt < 0){
		if(!sem->sem_first){
			sem->sem_last=current_ctx;
		}
		else{
			sem->sem_first->ctx_sem_previous=current_ctx;
		}
		current_ctx->ctx_sem_next = sem->sem_first;
		sem->sem_fisrt=current_ctx;
		current_ctx->ctx_state = CTX_STOP;
		irq_enable();
		yield();	
	}
	irq_enable();
}

/*
-supprimer &ctx_stop de l'anneau)
- modifier switch_to() ne pas donner la main � CTX_STOP
	while(new->ctx_state==CTX_STOP){
		new= new->ctx_next;
	}
- Tous CTX_STOP -> message utilisateur
*/
