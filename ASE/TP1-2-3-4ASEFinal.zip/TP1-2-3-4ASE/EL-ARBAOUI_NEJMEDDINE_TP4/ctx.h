#define CTX_MAGIC 0xDEADBEEF

typedef void (func_t) (void *);


enum state_e {ACTIF, INACTIF, UNDEFINED, TERMINATED , BLOCKED}  ;

struct ctx_s {
	void * ctx_esp, *ctx_ebp;
	unsigned int ctx_magic;	
	enum state_e state;
	void* args;
	func_t * f;
	unsigned  char * ctx_stack;	
	struct ctx_s * next;
	struct ctx_s *ctx_sem_list;
};

int init_ctx (struct ctx_s * ctx, int stack_size, func_t f, void * args);

void start_current_context ();

int create_ctx(int stack_size,func_t f, void * args);

 void yield();

void switch_to_ctx (struct ctx_s * newctx);

void start_sched();

struct ctx_s* getCurrentContext();

