struct sem_s {

	int sem_cpt;
	struct ctx_s *sem_list;

};

void sem_init( struct sem_s* sem, unsigned int val);

void sem_up(struct sem_s *sem);

void sem_down(struct sem_s *sem);
