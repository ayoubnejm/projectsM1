/* Librairies standards */
#include "ctx.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <unistd.h>
#include "hw.h"

/* Variables globales */
static struct ctx_s * ctx_current = NULL;
static struct ctx_s * ctx_ring = NULL;


/*Initialise et crée la boucle de contexte*/
int create_ctx (int stack_size, func_t f, void * args) {
	struct ctx_s * ctx;
	irq_disable();
	ctx = (struct ctx_s * ) malloc (sizeof(struct ctx_s));
	assert(ctx);

	if (init_ctx(ctx, stack_size, f, args)) return 1;

	/*Ajout d'un contexte à la boucle*/
	if (ctx_ring != NULL) {
			
			ctx -> next = ctx_ring -> next;
			ctx_ring -> next = ctx;
		
	}	
	/*Création de la boucle de contexte */ 
	else {
		ctx_ring = ctx;
		ctx_ring -> next = ctx;
		
	}
	irq_enable();
	return 0;
}

struct ctx_s* getCurrentContext() 
{
    return ctx_current;
}

/* Fonction "init_ctx" */
int init_ctx (struct ctx_s * ctx, int stack_size, func_t f, void * args) {

	/* Assignation du pointeur des arguments */
	ctx -> args = args;
		
	/* Assignation du pointeur de fonction */
	ctx -> f = f;

	/* Assignation du status */
	ctx -> state = UNDEFINED;

	/* Assignation du nombre magique */
	ctx -> ctx_magic = CTX_MAGIC;

	/* Allocation de la pile */
	ctx -> ctx_stack = (unsigned char *) malloc (stack_size);
	if(ctx-> ctx_stack == NULL) return 1;
	
	/* Assignation du pointeur EBP */
	ctx -> ctx_ebp = (unsigned char *) (ctx -> ctx_stack + (stack_size - 4));

	/* Assignation du pointeur ESP */
	ctx -> ctx_esp = ctx -> ctx_ebp;
		
return 0;
}

/* Fonction "start_current_context"  qui permet d'executer un context pour la premiere fois */
void start_current_context () {
	ctx_current -> state = ACTIF;
	ctx_current -> f(ctx_current -> args);
	ctx_current -> state = TERMINATED;
	yield();
}


/*Change de contexte*/
void switch_to_ctx (struct ctx_s * newctx) {
	struct ctx_s * tmp;
	/************************************/
 	 	irq_disable();
	/************************************/
	
	/* Un contexte est en cours */
	if (ctx_current != NULL) {
		
		asm("mov %%ebp, %0 \n\t"
			 "mov %%esp, %1"
		:"=r" (ctx_current-> ctx_ebp),
		"=r" (ctx_current -> ctx_esp)
		);
	}
	
	ctx_current = newctx;
	assert(newctx -> ctx_magic == CTX_MAGIC);
	
	
	asm("mov %0, %%ebp \n\t"
		"mov %1, %%esp"
		:
		:"r" (ctx_current -> ctx_ebp),
		"r" (ctx_current -> ctx_esp)
	);
	
		
	while (ctx_current-> state == TERMINATED) {
		irq_disable();		
		if (ctx_current == newctx){
			free(newctx->ctx_stack);
			free(newctx);
			  exit(EXIT_SUCCESS);
		}else{
			
			ctx_current = newctx -> next;
			tmp = newctx;
			newctx = newctx -> next;
			free(tmp->ctx_stack);
			free(tmp);
			
		}
		irq_enable();
		
	}



	
	if (ctx_current->state == UNDEFINED) {
		start_current_context();
	}
	else {
		ctx_current -> state = ACTIF;
		return;
	}
}


/*Appelle la fonction de changement de contexte ou lance la boucle de contexte*/
 void yield () {
	/*Si la boucle de contextes s'éxécute déjà*/
	if (ctx_current) {
		switch_to_ctx(ctx_current->next);
	}

	/*Premier appel à yield()*/
	else switch_to_ctx(ctx_ring);
}

void start_sched () {
	
	start_hw();
	setup_irq(TIMER_IRQ, yield);
	while (1) {

		pause();
	}

}
