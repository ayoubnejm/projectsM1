#define WORD_SIZE sizeof(int);

#define N 100                         /* nombre de places dans le tampon */

struct sem_s mutex, vide, plein;

typedef void(func_t)(void*);


enum ctx_state_e{CTX_INIT, CTX_EXQ, CTX_END, CTX_BLK};

struct ctx_s{
  unsigned char* ctx_stack;
  void* ctx_esp;
  void* ctx_ebp;
  enum ctx_state_e ctx_state;
  func_t* ctx_f;
  void* ctx_arg;
  struct ctx_s * ctx_next;
#define CTX_MAGIC 0xCAFEBABE
  unsigned ctx_magic;
  struct ctx_s* ctx_sem_list_next;
};

struct sem_s{
  int sem_cpt;
  struct ctx_s* sem_ctx_list;
};

int init_ctx(struct ctx_s* ctx, 
	     int stack_size, func_t f, void*args);

void switch_to_ctx(struct ctx_s* ctx);

void start_current_ctx();

void yield(void);

int create_ctx(int stack_size, func_t f, void *args);

void sem_init(struct sem_s *sem,unsigned int val);

void sem_up(struct sem_s * sem);

void sem_down(struct sem_s *sem);

