#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "hw.c"
#include "library.h"


static struct ctx_s * current_ctx = (struct ctx_s*)0;
static struct ctx_s * ring_ctx = (struct ctx_s*)0;


void start_current_ctx (){

  current_ctx ->ctx_state = CTX_EXQ;
  current_ctx ->ctx_f(current_ctx->ctx_arg);
  current_ctx ->ctx_state = CTX_END;
  yield();
  assert(0);
}

int create_ctx(int stack_size, func_t f, void *args){
  
  struct ctx_s * new_ctx;
  new_ctx = malloc(sizeof(struct ctx_s));
  init_ctx(new_ctx, stack_size, f, args);
  irq_disable();
  if(ring_ctx){
    new_ctx -> ctx_next = ring_ctx -> ctx_next;
    ring_ctx -> ctx_next = new_ctx;
  }
  else{
    ring_ctx = new_ctx -> ctx_next = new_ctx;
  }
  irq_enable();
}


void yield(void){
  if(!ring_ctx) return;
  if(current_ctx)
    switch_to_ctx(current_ctx->ctx_next);
  else
    switch_to_ctx(ring_ctx);
}


void start_sched (){
  setup_irq(TIMER_IRQ, yield);
  start_hw();
  yield();
  
}

int init_ctx(struct ctx_s* ctx,
	     int stack_size, func_t f, void*args){

  ctx-> ctx_stack = malloc(stack_size);
  assert (ctx->ctx_stack);
  ctx->ctx_esp = ctx->ctx_ebp = ctx->ctx_stack 
    + stack_size - WORD_SIZE;
  ctx->ctx_f = f;
  ctx->ctx_arg = args;
  ctx->ctx_magic = CTX_MAGIC;
  
}

void switch_to_ctx(struct ctx_s * newctx){

  assert(newctx->ctx_magic == CTX_MAGIC);
  
  if(newctx -> ctx_state == CTX_END){
    irq_disable();
    if(newctx != current_ctx)
      free(newctx -> ctx_stack);
    current_ctx -> ctx_next = newctx -> ctx_next;
    free(newctx);
    irq_enable();
	
  }
  if(current_ctx){
    
    asm("movl %%esp,%0" "\n\t" 
	"movl %%ebp,%1"
	:"=r"(current_ctx->ctx_esp) , 
	 "=r"(current_ctx->ctx_ebp)
	);
	
	
  }

  current_ctx = newctx;

  asm("movl %0,%%esp" "\n\t" 
      "movl %1,%%ebp"
      :
      :"r"(current_ctx->ctx_esp) , 
       "r"(current_ctx->ctx_ebp)
      );
  if (current_ctx->ctx_state == CTX_INIT)
    start_current_ctx();
	
	/*while(newctx->ctx_state == CTX_BLQ)
		newctx = newctx->ctx_next;*/
}

void sem_init(struct sem_s * sem,unsigned val){
  sem -> sem_cpt = val;
  sem -> sem_ctx_list=NULL;
}

void sem_down(struct sem_s *sem){
	irq_disable();
	sem->sem_cpt--;
	if(sem-> sem_cpt <0){
		current_ctx -> ctx_state = CTX_BLK;
		current_ctx -> ctx_sem_list_next = sem-> sem_ctx_list;
		sem->sem_ctx_list = current_ctx;
		irq_enable();
		yield();
	}
}

void sem_up(struct sem_s * sem){
	irq_disable();
	sem->sem_cpt++;
	if(sem->sem_cpt <= 0){
	  sem->sem_ctx_list->ctx_state = CTX_EXQ;
	  sem->sem_ctx_list = sem->sem_ctx_list -> ctx_sem_list_next;	
	}
	irq_enable();

}
