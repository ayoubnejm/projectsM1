#include <stdio.h>
#include <stdlib.h>
#include "library.h"

/******************************************************************************
*  Variables globales
******************************************************************************/


int entree = 0;
int sortie = 0;
int compteur = 0;
int buffer[N]; 


void producteur(void *arg);
void consommateur(void *arg);


/* produire l'objet suivant */
int produire_objet() {
	printf("Compteur = %d\n", 	compteur);
	printf("[+] Je produit un objet\n");
	return 5;
}


// Consommateur
int utiliser_objet(int n) {
	printf("compteur = %d\n", compteur);
	printf("[-] Consommateur\n", n);
	return 0;
}


mettre_objet(int item) {
    buffer[entree] = item;
    entree = (entree + 1) % N;
    compteur++;
}


retirer_objet(int item) {
      item = buffer[sortie];
      sortie = (sortie + 1) % N;
      compteur--;
}


void producteur (void *args){
  int objet ;

  while (1) {
    produire_objet(objet);           /* produire l'objet suivant */
    sem_down(&vide);                  /* dec. nb places libres */
    sem_down(&mutex);                 /* entree en section critique */
    mettre_objet(objet);              /* mettre l'objet dans le tampon */
    sem_up(&mutex);                   /* sortie de section critique */
    sem_up(&plein);                   /* inc. nb place occupees */
  }
}

void consommateur (void *args){
  int objet ;

  while (1) {
    sem_down(&plein);                 /* dec. nb emplacements occupes */
    sem_down(&mutex);                 /* entree section critique */
    retirer_objet (objet);           /* retire un objet du tampon */
    sem_up(&mutex);                   /* sortie de la section critique */
    sem_up(&vide);                    /* inc. nb emplacements libres */
    utiliser_objet(objet);            /* utiliser l'objet */
  }
}


int main(int argc, char *argv[]){
sem_init(&mutex, 1);                /* controle d'acces au tampon */
sem_init(&vide, N);                 /* nb de places libres */
sem_init(&plein, 0);                /* nb de places occupees */


  create_ctx(16384, producteur, NULL);
  create_ctx(16384, consommateur, NULL);
  //switch_to_ctx(&ctx_ping);
  start_sched();
  exit(EXIT_SUCCESS);
}
