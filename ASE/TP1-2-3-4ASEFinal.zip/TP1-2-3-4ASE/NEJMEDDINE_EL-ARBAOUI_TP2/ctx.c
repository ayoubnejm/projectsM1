/* Librairies standards */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

/* Entêtes */
#include "ctx.h"



/* Variables globales */
static struct ctx_s *CONTEXTE_COURANT = NULL;


/* Fonction "start_current_context"  qui permet d'executer un context pour la premiere fois */
void start_current_context (){

	CONTEXTE_COURANT -> state= active ;
	CONTEXTE_COURANT -> f ( CONTEXTE_COURANT -> args);
	CONTEXTE_COURANT -> state = terminated ;

}


/* Fonction "init_ctx" */
int init_ctx (struct ctx_s * ctx, int stack_size, func_t f, void * args) {
	
	/* Assignation du pointeur de fonction */
	ctx->f = f;
	
	/* Assignation du pointeur des arguments */
	ctx->args= args;

	/* Assignation du status */
	ctx->state = undefined;

	/* Assignation du nombre magique */
	ctx->ctx_magic = CTX_MAGIC;

	/* Allocation de la pile */
	ctx->ctx_stack = (unsigned char*) malloc(stack_size);
	
	/* Assignation du pointeur EBP */
	ctx->ctx_ebp = ctx-> ctx_stack + stack_size - 4;

	/* Assignation du pointeur ESP */
	ctx->ctx_esp = ctx->ctx_ebp;

	return  EXIT_SUCCESS;
 
}

void switch_to_ctx (struct ctx_s * newctx) {

	/* Un contexte est en cours */
	if( CONTEXTE_COURANT != NULL ){  

		asm ("mov %%esp, %0 \n\t"
		    "mov %%ebp, %1 "
		    : "=r" (CONTEXTE_COURANT->ctx_esp),
		      "=r" (CONTEXTE_COURANT->ctx_ebp)
		);

		CONTEXTE_COURANT->state= inactive ;
	}

	/* Changement de contexte */
	CONTEXTE_COURANT = newctx;
	
	assert(newctx -> ctx_magic == CTX_MAGIC );
 
	   asm ("mov %0, %%esp \n\t"
		"mov %1, %%ebp "
		:
		: "r" (CONTEXTE_COURANT-> ctx_esp),
		  "r" (CONTEXTE_COURANT-> ctx_ebp)
	 );


	/* Exécution du contexte */
	if( CONTEXTE_COURANT -> state == undefined ){

		start_current_context();

	}else{
	
		CONTEXTE_COURANT -> state= active ;
		return ;
	}	
	 

}




