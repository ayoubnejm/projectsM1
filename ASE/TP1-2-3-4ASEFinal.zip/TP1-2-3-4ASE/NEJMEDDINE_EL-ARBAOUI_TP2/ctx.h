#define CTX_MAGIC 0x123456

typedef void (func_t)(void*);

enum state_e{
	 active, inactive, undefined , terminated
};

struct ctx_s {
	void *args;
	func_t *f;
	unsigned char *ctx_stack;
	enum state_e state;
	void *ctx_esp, *ctx_ebp;
	unsigned int ctx_magic;
};


int init_ctx (struct ctx_s * ctx, int stack_size, func_t f, void * args);

void switch_to_ctx (struct ctx_s * newctx);

void start_current_context();


