#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "drive.h"
#include "hardware.h"


/* dump buffer to stdout,
   and octal dump if octal_dump; an ascii dump if ascii_dump! */
void dump(unsigned char *buffer, unsigned int buffer_size, int ascii_dump, int octal_dump) {
    int i,j;
    
    for (i=0; i<buffer_size; i+=16) {
	/* offset */
	printf("%.8o",i);

	/* octal dump */
	if (octal_dump) {
	    for(j=0; j<8; j++)
		printf(" %.2x", buffer[i+j]);
	    printf(" - ");
	    
	    for( ; j<16; j++)
		printf(" %.2x", buffer[i+j]);
	    
	    printf("\n");
	}
	/* ascii dump */
	if (ascii_dump) {
	    printf("%8c", ' ');
	    
	    for(j=0; j<8; j++)
		printf(" %1c ", isprint(buffer[i+j])?buffer[i+j]:' ');
	    printf(" - ");
	    
	    for( ; j<16; j++)
		printf(" %1c ", isprint(buffer[i+j])?buffer[i+j]:' ');
	    
	    printf("\n");
	}
	
    }
}



void dmps(int cylinder, int sector){

	_out(HDA_DATAREGS,(cylinder>>8) & 0xFF);
	_out(HDA_DATAREGS+1,cylinder & 0xFF);

	_out(HDA_DATAREGS+2,(sector>>8) & 0xFF);
	_out(HDA_DATAREGS+3,sector & 0xFF);

	_out(HDA_CMDREG,CMD_SEEK);

	_sleep(HDA_IRQ);
	_out(HDA_DATAREGS,0x00);
	_out(HDA_DATAREGS+1,0x01);
	_out(HDA_CMDREG,CMD_READ);
	_sleep(HDA_IRQ);
	  dump(MASTERBUFFER,HDA_SECTORSIZE,0,1);
}
static void empty_it(){
    return;
}


int main(int argc, char **argv){

  int i;

  if(init_hardware("hardware.ini") == 0){
      fprintf(stderr, " Erreur d'initialisation du hardware\n");
      exit(EXIT_FAILURE);
  }

  for(i=0; i<16; i++)
    IRQVECTOR[i] = empty_it;
  _mask(1);
  if(argc == 3){
    dmps(atoi(argv[1]),atoi(argv[2]));
    exit(0);
  }
  else{
    printf("-------------------ERREUR DE COMMANDE----------------\nUtilisation:\n./dmps cylindre secteur\n");
    exit(1);
  }
    
}
