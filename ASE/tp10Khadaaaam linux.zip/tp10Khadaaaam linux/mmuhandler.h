


struct tlb_entry_s {
	unsigned tlb_dummy : 8; // un champ de 8 bit
	unsigned tlb_vpage : 12;
	unsigned tlb_ppage : 8;
	unsigned tlb_xwr : 3;
	unsigned tlb_valid : 1;
};

struct pm_mapp_s {
	unsigned pm_vpage : 12;
	unsigned pm_mapped : 1;
};

struct vm_mapp_s {
	unsigned vm_ppage : 8;
	unsigned vm_mapped : 1;
};
void mmuhandler();
void mmuhandlerSimple();

void print_default_page();
void reset_default_page();
unsigned vpage_of_vaddr(unsigned vaddr);

static int ppage_of_vaddr(int process, unsigned vaddr);
