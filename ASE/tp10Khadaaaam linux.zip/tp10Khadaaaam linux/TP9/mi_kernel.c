#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mi_syscall.h"
#include "mi_kernel.h"
#include "mi_user.h"

#include "include/hardware.h"


unsigned vpage_of_vaddr(unsigned vaddr){

	return (vaddr >> 12) & 0xFFF;

}

static int ppage_of_vaddr(int process, unsigned vaddr){

	unsigned int vpage ;
	
	vpage =  vpage_of_vaddr(vaddr);
	return vpage < N/2 ? (process*(N/2)+vpage) : -1 ;
	
}

static void mmuhandler(void){

	int ppage;
	struct tlb_entry_s tlb ;
	int virtualPage;

	virtualPage = (unsigned) _in(MMU_FAULT_ADDR);

	ppage = ppage_of_vaddr(current_process , virtualPage);

	if(ppage == -1){
		printf("MMUHANDLER : Segmentatioon fault\n");
		return ;
	}

	tlb.unused = 0 ;
	tlb.virt_page = vpage_of_vaddr(virtualPage );
	tlb.phys_page = ppage ;
	tlb.access_type = 7;
	tlb.is_active =1;

	_out(TLB_ADD_ENTRY, *((int*) &tlb));
}


		
static void switch_to_process0(void) {
	current_process = 0;
	_out(MMU_CMD, MMU_RESET);
}

static void switch_to_process1(void) {
	current_process = 1;
	_out(MMU_CMD, MMU_RESET);
}



int main( int argc , char **argv){
	
	if(init_hardware("etc/hardware.ini") == 0) {
		fprintf(stderr, "Error in hardware initialization\n");
		exit(EXIT_FAILURE);
	}

	
	IRQVECTOR[MMU_IRQ] = mmuhandler;

	IRQVECTOR[SYSCALL_SWTCH_0] = switch_to_process0; 
	IRQVECTOR[SYSCALL_SWTCH_1] = switch_to_process1; 
	

	_mask(0x1001);

	init();
	return EXIT_SUCCESS;
}
