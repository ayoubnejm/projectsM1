#include "include/hardware.h"

struct tlb_entry_s{

	unsigned unused:8;
	unsigned virt_page:12;
	unsigned phys_page:8;
	unsigned access_type:3;
	unsigned is_active:1;
 };

unsigned int current_process;


static void mmuhandler(void);
static int ppage_of_vaddr(int process, unsigned vaddr);
unsigned vpage_of_vaddr(unsigned vaddr);
static void switch_to_process0(void);
static void switch_to_process1(void);






