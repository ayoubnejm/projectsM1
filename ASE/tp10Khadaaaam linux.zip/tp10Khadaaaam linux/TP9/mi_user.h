
#include "include/hardware.h"

 int sum(void *ptr);
 void init();

