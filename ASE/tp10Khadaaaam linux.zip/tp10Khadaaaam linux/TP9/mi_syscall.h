#define PAGE_SIZE 4
#define PM_PAGES 256 // 1<<8
#define PM_SIZE PAGE_SIZE*PM_PAGES
#define BEGIN_PMEM *(int*)&physical_memory
#define END_PMEM  *(int*)&physical_memory + PM_SIZE - 1

#define VM_PAGES 4096 // 1<<12
#define VM_SIZE PAGE_SIZE*VM_PAGES
#define BEGIN_VMEM *(int*)&virtual_memory
#define END_VMEM  *(int*)&virtual_memory + VM_SIZE - 1

#define TLB_SIZE 32
#define TLB_ENTRIES 0x800	

#define N 20





#define SYSCALL_SWTCH_0 16 
#define SYSCALL_SWTCH_1 17
