#define CTX_MAGIC 0xDEADBEEF

typedef void (func_t) (void *);



enum state_e {activ, inactive,undefined, terminated}  ;

struct ctx_s {
	void * ctx_esp, *ctx_ebp;
	unsigned int ctx_magic;	
	enum state_e state;
	void* args;
	func_t * f;
	unsigned  char * ctx_stack;	
	struct ctx_s * next;
};

int init_ctx (struct ctx_s * ctx, int stack_size, func_t f, void * args);

void start_current_context ();

int create_ctx(int stack_size,func_t f, void * args);

static void yield ();

void switch_to_ctx (struct ctx_s * newctx);

void start_sched();



