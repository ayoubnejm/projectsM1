#include <stdio.h>
#include <stdlib.h>
#include "ctx.h"
#include "hw.h"


void f_ping(void *arg);
void f_pong(void *arg);

int main(int argc, char *argv[]) {


  create_ctx(16384, f_ping, NULL);
  create_ctx(16384, f_pong, NULL);
start_sched();
  exit(EXIT_SUCCESS);
}

void f_ping(void *args) {
	int i;
	for (i = 0; i < 1000; i++){
    printf("A") ;
    printf("C") ;  
	 printf("C") ;
  }
}

void f_pong(void *args) {
	int i;
  for (i = 0; i < 1500; i++){
    printf("4") ;
    printf("3") ;
  }
}


