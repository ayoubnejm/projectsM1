#include "ctx.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "hw.h"

struct ctx_s * ctx_current = NULL;
static struct ctx_s * ctx_ring = NULL;

int create_ctx (int stack_size, func_t f, void * args) {
	irq_disable();
	struct ctx_s * ctx;
	ctx = (struct ctx_s * ) malloc (sizeof(struct ctx_s));
	assert(ctx);

	if (init_ctx(ctx, stack_size, f, args)) return 1;

	if (ctx_ring != NULL) {
			
			ctx -> next = ctx_ring -> next;
			ctx_ring -> next = ctx;
		
	}
	
	else {
	
		ctx_ring = ctx;
		ctx_ring -> next = ctx;
		
	}
	irq_enable();
	return 0;
}

int init_ctx (struct ctx_s * ctx, int stack_size, func_t f, void * args) {
	ctx -> args = args;
	ctx -> f = f;
	ctx -> state = undefined;
	ctx -> ctx_magic = CTX_MAGIC;
	ctx -> ctx_stack = (unsigned char *) malloc (stack_size);
	if(ctx-> ctx_stack == NULL) return 1;
	ctx -> ctx_ebp = (unsigned char *) (ctx -> ctx_stack + (stack_size - 4));
	ctx -> ctx_esp = ctx -> ctx_ebp;
		
return 0;
}

void start_current_context () {
	ctx_current -> state = activ;
	ctx_current -> f(ctx_current -> args);
	ctx_current -> state = terminated;
	yield();
}

void switch_to_ctx (struct ctx_s * newctx) {
  	irq_disable();
	struct ctx_s * tmp;

	if (ctx_current != NULL) {
		
		asm("mov %%ebp, %0 \n\t"
			 "mov %%esp, %1"
		:"=r" (ctx_current-> ctx_ebp),
		"=r" (ctx_current -> ctx_esp)
		);
	}
	
	ctx_current = newctx;
	assert(newctx -> ctx_magic == CTX_MAGIC);
	
	
	asm("mov %0, %%ebp \n\t"
		"mov %1, %%esp"
		:
		:"r" (ctx_current -> ctx_ebp),
		"r" (ctx_current -> ctx_esp)
	);
	
		
	
	while (ctx_current-> state == terminated) {
		if (ctx_current == newctx){
			free(newctx->ctx_stack);
			free(newctx);
			  exit(EXIT_SUCCESS);
		}else{
			
			ctx_current = newctx -> next;
			tmp = newctx;
			newctx = newctx -> next;
			free(tmp->ctx_stack);
			free(tmp);
			
		}
		
	}
irq_enable();
	if (ctx_current->state == undefined) {
		start_current_context();
	}
	else {
		ctx_current -> state = activ;
		return;
	}
}

static void yield () {
	if (ctx_current) {
		switch_to_ctx(ctx_current->next);
	}
	else switch_to_ctx(ctx_ring);
}

void start_sched () {
	
	start_hw();
	
	setup_irq(TIMER_IRQ, yield);
	
	while (1) {

		pause();
	}

}
