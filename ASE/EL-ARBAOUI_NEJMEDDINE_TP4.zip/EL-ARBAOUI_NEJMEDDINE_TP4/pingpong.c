#include <stdio.h>
#include <stdlib.h>
#include "ctx.h"

void f_ping(void *arg);
void f_pong(void *arg);

int main(int argc, char *argv[]) {


  create_ctx(16384, f_ping, NULL);
  create_ctx(16384, f_pong, NULL);
  start_sched();
  exit(EXIT_SUCCESS);
}

void f_ping(void *args) {
	int i;
	for (i = 0; i < 300; i++){
    printf("A") ;
    printf("B") ;  
	 printf("C") ;
  }
}

void f_pong(void *args) {
	int i;
  for (i = 0; i < 500; i++){
    printf("1") ;
    printf("2") ;
  }
}


