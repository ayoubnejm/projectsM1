
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "hw.h"
#include "ctx.h"
#include "sem.h"

void sem_init(struct sem_s *sem, unsigned int val ){

	sem->sem_cpt = val ;
	sem->sem_list = NULL;

}

void sem_up(struct sem_s *sem ){

	irq_disable();
	sem->sem_cpt++;
	if( sem->sem_cpt <=0){

		sem->sem_list->state = INACTIF;
		sem->sem_list = sem->sem_list->ctx_sem_list;

	}

	irq_enable();
}


void sem_down( struct sem_s *sem){

	irq_disable();
	sem->sem_cpt--;
	struct ctx_s *ctx =  getCurrentContext();
	if(sem->sem_cpt <=0){

		ctx-> state = BLOCKED;
		ctx->ctx_sem_list = sem->sem_list;
		sem -> sem_list= ctx;
		irq_enable();
		//yield();

	}else
		irq_enable();

}
