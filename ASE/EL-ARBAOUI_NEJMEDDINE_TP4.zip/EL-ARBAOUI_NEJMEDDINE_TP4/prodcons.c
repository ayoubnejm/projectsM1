#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "hw.h"
#include "ctx.h"
#include "sem.h"
#define N 100

struct sem_s mutex, vide, plein;


struct objet_t {
  int valeur;
  struct objet_t * next;
};

struct objet_t * buffer = NULL;

void
utiliser_objet(struct objet_t *obj)
{
  printf("Entier consommé : %d\n", obj->valeur);
  free(obj);
}

void
produire_objet(struct objet_t ** obj)
{
  *obj = malloc(sizeof(struct objet_t)); 
  (*obj)->valeur = rand();
  (*obj)->next = NULL;
}

void
mettre_objet(struct objet_t *obj)
{
  obj->next = buffer;
  buffer = obj;
}

void
retirer_objet(struct objet_t **obj)
{
  *obj = buffer;
  buffer = buffer->next;
}

void producteur (void)
{
  struct objet_t *objet ;

  while (1) {
    produire_objet(&objet);           /* produire l'objet suivant */
    sem_down(&vide);                  /* dec. nb places libres */
    sem_down(&mutex);                 /* entree en section critique */
    mettre_objet(objet);              /* mettre l'objet dans le tampon */
    sem_up(&mutex);                   /* sortie de section critique */
    sem_up(&plein);                   /* inc. nb place occupees */
  }
}

void consommateur (void)
{
  struct objet_t *objet ;

  while (1) {
    sem_down(&plein);                 /* dec. nb emplacements occupes */
    sem_down(&mutex);                 /* entree section critique */
    retirer_objet (&objet);           /* retire un objet du tampon */
    sem_up(&mutex);                   /* sortie de la section critique */
    sem_up(&vide);                    /* inc. nb emplacements libres */
    utiliser_objet(objet);            /* utiliser l'objet */
  }
}

void
main()
{
  sem_init(&mutex, 1);                /* controle d'acces au tampon */
  sem_init(&vide, N);                 /* nb de places libres */
  sem_init(&plein, 0);                /* nb de places occupees */

  create_ctx(16384, producteur, NULL);
  create_ctx(16384, consommateur, NULL);
  create_ctx(16384, consommateur, NULL);
  create_ctx(16384, consommateur, NULL);
  create_ctx(16384, consommateur, NULL);
  create_ctx(16384, consommateur, NULL);
  create_ctx(16384, consommateur, NULL);
  create_ctx(16384, consommateur, NULL);
  create_ctx(16384, consommateur, NULL);
  create_ctx(16384, consommateur, NULL);
  create_ctx(16384, consommateur, NULL);
  start_sched();
  
  exit(EXIT_SUCCESS);
}
