import java.io.FileReader;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import org.xml.sax.InputSource;

public class Distance {

	public static void main(String[] arg) {
		try {
			InputSource entree = new InputSource(new FileReader(arg[0])) ;
			String id1 = arg[1];
			String id2 = arg[2];
			String req = "count(//personne[@id='"+id1+"']/ancestor::*) + count(//personne[@id='" + id2+"']/ancestor::*) - 2*count(//*[descendant-or-self::personne[@id='" + id1 +"'] and descendant-or-self::personne[@id='" + id2 +"'] and not(child::*[descendant-or-self::personne[@id='" + id1 +"'] and descendant-or-self::personne[@id='" + id2 +"']])]/ancestor::*)";
			XPath requeteur = XPathFactory.newInstance().newXPath() ;
			double resultat = (Double) requeteur.evaluate(req , entree , XPathConstants.NUMBER) ;
			System.out.println(resultat);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

