package bda ;

import org.xml.sax.*;
import org.xml.sax.helpers.* ;
 
/**
 * @author Ayoub NEJMEDDINE & Sara EL ARBAOUI
 *
 *  
 */

public class MaisonHandler extends DefaultHandler {
	private float superficie = 0;
	private int profondeur=0;
	private String id;


	public String getid(){
		return id;
	}

	public void setId(String id){
		this.id = id;
	}
	/**
	 * Evenement envoye au demarrage du parse du flux xml.
	 * @throws SAXException en cas de probleme quelquonque ne permettant pas de
	 * se lancer dans l'analyse du document.
	 * @see org.xml.sax.ContentHandler#startDocument()
	 */
	public void startDocument() throws SAXException {
		 
	}
	
	/**
	 * Evenement envoye a la fin de l'analyse du flux xml.
	 * @throws SAXException en cas de probleme quelquonque ne permettant pas de
	 * considerer l'analyse du document comme etant complete.
	 * @see org.xml.sax.ContentHandler#endDocument()
	 */
	public void endDocument() throws SAXException {

	}
	
	/**
	 * Evenement recu a chaque fois que l'analyseur rencontre une balise xml ouvrante.
	 * @param nameSpaceURI l'url de l'espace de nommage.
	 * @param localName le nom local de la balise.
	 * @param rawName nom de la balise en version 1.0 <code>nameSpaceURI + ":" + localName</code>
	 * @throws SAXException si la balise ne correspond pas a ce qui est attendu,
	 * comme par exemple non respect d'une dtd.
	 * @see org.xml.sax.ContentHandler#startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes)
	 */
	public void startElement(String nameSpaceURI, String localName, String rawName, Attributes attributs) throws SAXException {
		profondeur++;
		String s="";

		for (int index = 0; index < attributs.getLength(); index++) { 
			if (attributs.getLocalName(index).equals("id"))
				this.setId(attributs.getValue(index));
				
			if(profondeur > 3 && !localName.equals("alcove"))
				s = attributs.getLocalName(index);
			if(s.equals("surface-m2"))
				superficie = superficie + Float.valueOf(attributs.getValue(index).trim()).floatValue();
		}		

	}
	
	

	/**
	 * Evenement recu a chaque fermeture de balise.
	 * @see org.xml.sax.ContentHandler#endElement(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void endElement(String nameSpaceURI, String localName, String rawName) throws SAXException {
		profondeur--;		

		if(profondeur == 1)
		{
			System.out.println(localName.replaceFirst(".",(localName.charAt(0)+"").toUpperCase())+" "+ this.getid() + " :");
			System.out.println("      superficie totale :"+ superficie +" m²");
			superficie = 0;
		}

	}
	
	 
	/**
	 * Evenement recu a chaque fois que l'analyseur rencontre des caracteres (entre
	 * deux balises).
	 * @param ch les caracteres proprement dits.
	 * @param start le rang du premier caractere a traiter effectivement.
	 * @param length le nombre de caracteres a traiter effectivement
	 * @see org.xml.sax.ContentHandler#characters(char[], int, int)
	 */
	public void characters(char[] ch, int start, int length) throws SAXException {
		
	}
	
	/**
	 * Recu chaque fois que des caracteres d'espacement peuvent etre ignores au sens de
	 * XML. C'est a dire que cet evenement est envoye pour plusieurs espaces se succedant,
	 * les tabulations, et les retours chariot se succedants ainsi que toute combinaison de ces
	 * trois types d'occurrence.
	 * @param ch les caracteres proprement dits.
	 * @param start le rang du premier caractere a traiter effectivement.
	 * @param length le nombre de caracteres a traiter effectivement
	 * @see org.xml.sax.ContentHandler#ignorableWhitespace(char[], int, int)
	 */
	public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
		
	}
	
	/**
	 * Rencontre une instruction de traitement.
	 * @param target la cible de l'instruction de traitement.
	 * @param data les valeurs associees a cette cible. En general, elle se presente sous la forme 
	 * d'une serie de paires nom/valeur.
	 * @see org.xml.sax.ContentHandler#processingInstruction(java.lang.String, java.lang.String)
	 */
	public void processingInstruction(String target, String data) throws SAXException {
	
	}
	
	 
	 public static void main(String[] args) {
	        try {
	        	
	            XMLReader saxReader = XMLReaderFactory.createXMLReader();	            
	            saxReader.setContentHandler(new MaisonHandler());           
	            saxReader.parse(args[0]);
	            
	        } catch (Exception t) {
	            t.printStackTrace();
	        }
	    }
	
	
}