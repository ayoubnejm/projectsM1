package main;

import javax.swing.JFrame;

import view.GrayFixer;
import Loading.SplashScreen;

/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class Main {
	
	//initiation et lancement de l'application

	public static void main(String[] args) {
		  
	//splashScreen qui se lance au debut du demarrage de l'application	
	SplashScreen sp = new SplashScreen();
	
	sp.setLocationRelativeTo(null);
	sp.setVisible(true);
	
	try {
		Thread.sleep(2500);
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	sp.dispose();
  
		
		
	/* Lancement de l'application d'optimation des couleurs*/
	// Instantiation de la fenetre de l'application
    JFrame frame = new GrayFixer("ColorOptimizer");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setSize(950, 450);
	frame.setLocationRelativeTo(null);
	frame.setResizable(false);
	frame.setVisible(true);
		
	}

}
