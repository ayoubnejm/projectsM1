package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JPanel;

import controller.GrayFixerControllerGlobal;

import model.ColorModel;
import model.ShapesModel;

/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class GrayFixerViewShapes extends JPanel implements MouseListener,
		Observer {

	private static final long serialVersionUID = 1L;

	protected ShapesModel model;

	private GrayFixerControllerGlobal controllerGlobal;

	public GrayFixerViewShapes() {
		this.addMouseListener(this);

	}

	/**
	 * 
	 * @param model
	 */
	public void setModel(ShapesModel model) {
		// listen to only one model
		if (this.model != null)
			this.model.deleteObserver(this);

		this.model = model;
		this.model.addObserver(this);
	}

	/**
	 * 
	 * @param controllerGlobal
	 */
	public void setControllerGlobal(GrayFixerControllerGlobal controllerGlobal) {
		this.controllerGlobal = controllerGlobal;
	}

	
	public void mouseClicked(MouseEvent e) {
		this.controllerGlobal.tryToFocusOnModel(e.getX(), e.getY());
	}

	
	public void update(Observable o, Object arg) {
		repaint();
	}

	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		int width = this.getWidth();
		int height = this.getHeight();
		ColorModel colorModel;

		Rectangle[] rects = this.model.getRectangles();

		if (rects.length > 0) {

			int shapeWidth = width / rects.length;

			for (int i = 0; i < rects.length; i++) {
				colorModel = this.model.getModelAssociated(rects[i]);

				g.setColor(colorModel.getColor());

				rects[i].x = i * shapeWidth;
				rects[i].y = 0;
				rects[i].height = height;
				rects[i].width = shapeWidth;

				g.fillRect(rects[i].x, rects[i].y, rects[i].width,
						rects[i].height);

			}

			for (int i = 0; i < rects.length; i++) {
				colorModel = this.model.getModelAssociated(rects[i]);

				if (colorModel.equals(this.model.getFocusedModel())) {
					g.setColor(Color.YELLOW);
					g.drawRect(rects[i].x, rects[i].y, rects[i].width,
							rects[i].height);
					g.drawLine(rects[i].x, rects[i].y, rects[i].x
							+ rects[i].width, rects[i].height);
					g.drawLine(rects[i].x + rects[i].width, rects[i].y,
							rects[i].x, rects[i].height);

				}
			}

		}

	}

	public void mousePressed(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}
}
