package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import model.ColorModel;

/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class GrayFixerViewShapesGray extends GrayFixerViewShapes {

	private static final long serialVersionUID = 1L;

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		int width = this.getWidth();
		int height = this.getHeight();

		ColorModel colorModel;

		Rectangle[] rects = this.model.getRectangles();

		if (rects.length > 0) {

			int shapeWidth = width / rects.length;

			for (int i = 0; i < rects.length; i++) {
				colorModel = this.model.getModelAssociated(rects[i]);
				int gray = colorModel.getGray();
				g.setColor(new Color(gray, gray, gray));

				rects[i].x = i * shapeWidth;
				rects[i].y = 0;
				rects[i].height = height;
				rects[i].width = shapeWidth;

				g.fillRect(rects[i].x, rects[i].y, rects[i].width,
						rects[i].height);

			}

			for (int i = 0; i < rects.length; i++) {
				colorModel = this.model.getModelAssociated(rects[i]);

				if (colorModel.equals(this.model.getFocusedModel())) {
					g.setColor(Color.YELLOW);
					g.drawRect(rects[i].x, rects[i].y, rects[i].width,
							rects[i].height);
					g.drawLine(rects[i].x, rects[i].y, rects[i].x
							+ rects[i].width, rects[i].height);
					g.drawLine(rects[i].x + rects[i].width, rects[i].y,
							rects[i].x, rects[i].height);

				}
			}

		}

	}

}
