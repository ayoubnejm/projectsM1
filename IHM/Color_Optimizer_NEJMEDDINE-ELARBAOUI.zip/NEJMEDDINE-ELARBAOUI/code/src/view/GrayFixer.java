package view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSplitPane;

import controller.GrayFixerControllerGlobal;

import model.ShapesModel;

/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class GrayFixer extends JFrame {

	private static final long serialVersionUID = 1L;

	private GrayFixerViewControlGlobal viewControlGlobal;

	private GrayFixerViewShapes viewShapes;

	private GrayFixerViewShapesGray viewShapesGray;

	private GrayFixerViewFocusedColor viewFocusedColor;

	private ShapesModel shapesModel;

	private GrayFixerControllerGlobal controllerGlobal;
 

	public GrayFixer(String title) throws HeadlessException {
		super(title);
		JMenuBar jmb = new JMenuBar();
		JMenu fileMenu = new JMenu("Fichier");
		JMenuItem exit = new JMenuItem("Quitter");
		
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		

		JMenu helpMenu = new JMenu("Aide");
		JMenuItem about = new JMenuItem("A propos");
		
		about.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ImageIcon img = new ImageIcon("images/lille1.jpg");
				String mess = "Bonjour et bienvenue dans l'interface d'optimisation des choix des couleurs! \n";
				mess += "Cette application vous permet de choisir des couleurs et les personnaliser \nafin d'obtenir des niveaux de gris optimises. ";
				mess += "\n\nPour plus d'informations, veuillez nous contacter par mail : \n Sara EL ARBAOUI : sara.el-arbaoui@etudiant.univ-lille1.fr \n Ayoub NEJMEDDINE : ayoub.nejmeddine@etudiant.univ-lille1.fr";
				JOptionPane.showMessageDialog(null, mess, "A propos", JOptionPane.INFORMATION_MESSAGE, img);
			}
		});
		
		fileMenu.add(exit);
		helpMenu.add(about);
		jmb.add(fileMenu);
		jmb.add(helpMenu);
		this.setJMenuBar(jmb);

		this.shapesModel = new ShapesModel();

		this.controllerGlobal = new GrayFixerControllerGlobal();
		this.controllerGlobal.setShapesModel(shapesModel);

		this.viewControlGlobal = new GrayFixerViewControlGlobal(shapesModel);

		this.viewControlGlobal.setControllerGlobal(controllerGlobal);

		this.viewShapes = new GrayFixerViewShapes();

		this.viewShapesGray = new GrayFixerViewShapesGray();

		this.viewShapes.setModel(shapesModel);
		this.viewShapes.setControllerGlobal(controllerGlobal);

		this.viewShapesGray.setModel(shapesModel);
		this.viewShapesGray.setControllerGlobal(controllerGlobal);		
		this.viewFocusedColor = new GrayFixerViewFocusedColor();
		this.viewFocusedColor.setControllerGlobal(controllerGlobal);
		this.viewFocusedColor.setShapesModel(shapesModel);
		this.add(viewControlGlobal, BorderLayout.NORTH);
		
		
		
		Font f = new Font("Book Antiqua", Font.PLAIN, 11); 
		JLabel l= new JLabel("Selectionner une couleur ci-dessous pour la modifier");
		l.setFont(f);
		
		JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT,l, viewShapes);
		split.setResizeWeight(0.04);
		
		JSplitPane split1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,viewShapesGray,viewFocusedColor.jtfHtml);
		split1.setResizeWeight(0.98);
		
		JSplitPane split2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,split, split1);
		split2.setResizeWeight(0.75);
		  
		 
		this.add(split2, BorderLayout.CENTER);
	 
		this.add(viewFocusedColor, BorderLayout.EAST);
	}

}
