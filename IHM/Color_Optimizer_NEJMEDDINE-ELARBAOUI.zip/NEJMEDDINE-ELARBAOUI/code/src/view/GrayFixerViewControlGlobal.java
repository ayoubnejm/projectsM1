package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import model.ColorsUndoManager;
import model.ShapesModel;
import controller.GrayFixerControllerGlobal;

/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class GrayFixerViewControlGlobal extends JPanel implements KeyListener,
		ActionListener {
	private static final long serialVersionUID = 1L;

	private JComboBox<Integer> jcbNbColors;

	private Action actionFixShapesColors;
	private Action actionUndo;
	private Action actionRedo;

	private JLabel jlGenerateShapes;
	private JButton jbFixShapesColors;
	private JButton jbUndo;
	private JButton jbRedo;
	private ColorsUndoManager undoManager;

	private GrayFixerControllerGlobal controllerGlobal;

	/**
	 * 
	 * @param shapesModel
	 */
	public GrayFixerViewControlGlobal(ShapesModel shapesModel) {

		this.setBackground(Color.LIGHT_GRAY);
		this.jlGenerateShapes = new JLabel("Nombre de couleurs : ");
		this.jcbNbColors = new JComboBox<Integer>();
		jcbNbColors.setPreferredSize(new Dimension(200, 25));

		for (int i = 2; i <= 10; i++) {
			jcbNbColors.addItem(i);
		}
		jcbNbColors.setSelectedItem(6);
		jcbNbColors
				.setToolTipText("Choisissez le nombre de couleurs que vous souhaitez traiter");
		this.jcbNbColors.addActionListener(this);

		this.actionFixShapesColors = new AbstractAction("Ameliorer couleurs") {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				controllerGlobal.fixAllColors();
			}
		};

		this.actionUndo = new AbstractAction("") {
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				controllerGlobal.undo();
			}
		};

		this.actionRedo = new AbstractAction("") {
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				controllerGlobal.redo();
			}
		};

		this.jbFixShapesColors = new JButton(actionFixShapesColors);
		jbFixShapesColors
				.setToolTipText("Permet d'ameliorer les couleurs modifiees pour avoir des niveaux de gris optimisees!");
		this.jbUndo = new JButton(actionUndo);
		jbUndo.setToolTipText("Precedent");
		jbUndo.setIcon(new ImageIcon("images/boutonsIcons/undo.png"));
		this.jbRedo = new JButton(actionRedo);
		jbRedo.setToolTipText("Suivant");
		jbRedo.setIcon(new ImageIcon("images/boutonsIcons/redo.png"));

		this.undoManager = new ColorsUndoManager(jbUndo, jbRedo);
		shapesModel.setUndoManager(undoManager);

		this.undoManager.updateUndoRedoButtons();

		this.setLayout(new FlowLayout());
		this.add(jbUndo);
		this.add(jbRedo);
		this.add(jlGenerateShapes);
		this.add(jcbNbColors);
		this.add(jbFixShapesColors);
	}

	/**
	 * 
	 * @param controllerGlobal
	 */
	public void setControllerGlobal(GrayFixerControllerGlobal controllerGlobal) {
		this.controllerGlobal = controllerGlobal;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();

		if (key == KeyEvent.VK_ENTER && e.getSource() == jcbNbColors) {
			int nbColorsToGenerate = 0;
			try {
				nbColorsToGenerate = Integer.parseInt(""
						+ jcbNbColors.getSelectedItem());
				if (nbColorsToGenerate > 10 || nbColorsToGenerate < 2) {
					JOptionPane
							.showMessageDialog(null,
									"Veuillez saisir un nombre de couleur compris entre 2 et 10.");
					return;
				}
			} catch (Exception ex) {
				JOptionPane
						.showMessageDialog(null,
								"Vous devez saisir un nombre entier compris entre 2 et 10.");
				return;
			}
			try {
				controllerGlobal.generateShapes(Integer.parseInt(""
						+ jcbNbColors.getSelectedItem()));
			} catch (Exception ex) {
			}
		}

		if (key == KeyEvent.VK_LEFT) {
			controllerGlobal.undo();
		} else {
			if (key == KeyEvent.VK_RIGHT) {
				controllerGlobal.redo();
			}
		}

	}

	public void keyReleased(KeyEvent e) {

	}

	public void actionPerformed(ActionEvent arg0) {

		int nbColorsToGenerate = 0;
		try {
			nbColorsToGenerate = Integer.parseInt(""
					+ jcbNbColors.getSelectedItem());
		} catch (Exception e) {
			return;
		}

		try {
			controllerGlobal.generateShapes(nbColorsToGenerate);
		} catch (Exception e) {

		}

	}

}
