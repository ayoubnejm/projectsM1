package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JColorChooser;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import model.ColorModel;
import model.ShapesModel;
import controller.GrayFixerControllerGlobal;


/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class GrayFixerViewFocusedColor extends JPanel implements Observer,
		ChangeListener, ActionListener {

	private static final long serialVersionUID = 1L;

	private ShapesModel shapesModel;
	
	private GrayFixerControllerGlobal controllerGlobal;

	private JColorChooser jccChooser;

	public  JTextField jtfHtml;
	
	public GrayFixerViewFocusedColor()  {

		this.jccChooser = new JColorChooser();
		this.jccChooser.getSelectionModel().addChangeListener(this);
		
		jccChooser.setBackground(Color.lightGray);
		this.setLayout(new BorderLayout());

		this.add(this.jccChooser, BorderLayout.CENTER);
		this.jccChooser.setEnabled(true);
		this.jccChooser.setDragEnabled(true);
		//this.jccChooser.setPreviewPanel(new JPanel());
 
		
		this.jtfHtml = new JTextField();
		jtfHtml.setDragEnabled(true);
		this.jtfHtml.addActionListener(this);
		
	}

	@Override
	public void update(Observable o, Object arg) {
		if (o instanceof ShapesModel) {
			ColorModel focused = this.shapesModel.getFocusedModel();
			if (focused != null) {
				this.jccChooser.setColor(focused.getColor());
				this.jtfHtml.setText(focused.getHex());
			}
		}
	}

	
	public void stateChanged(ChangeEvent e) {
		Color newColor = this.jccChooser.getColor();
		if (newColor != null) {
			this.controllerGlobal.setColor(newColor);
		}
	}
	
	public void setShapesModel(ShapesModel shapesModel) {
		this.shapesModel = shapesModel;
		this.shapesModel.addObserver(this);
	}

	public void setControllerGlobal(GrayFixerControllerGlobal controllerGlobal) {
		this.controllerGlobal = controllerGlobal;
	}

	
	
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == this.jtfHtml) {
			 ColorModel focused = this.shapesModel.getFocusedModel();

			if (focused != null) {
				this.controllerGlobal.setHex(this.jtfHtml.getText());
			}
		}
	}
}
