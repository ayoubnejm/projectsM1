package controller;

import java.awt.Color;

import model.ColorModel;
import model.ShapesModel;


/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class GrayFixerControllerGlobal {

	private ShapesModel shapesModel;

	public void generateShapes(int nbShapes) 
	{
		this.shapesModel.generateColors(nbShapes);
	}

	public void setShapesModel(ShapesModel shapesModel) 
	{
		this.shapesModel = shapesModel;
	}

	public void tryToFocusOnModel(int x, int y) 
	{
		ColorModel colorModel = this.shapesModel.getModelSelected(x, y);
		if (colorModel != null) 
		{
			this.shapesModel.setFocusedModel(colorModel);
		}
	}

	public void setHex(String hexString) {
		this.shapesModel.setFocusedHex(hexString);
	}

	public void setColor(Color color) {
		this.shapesModel.setFocusedColor(color);
	}

	public void fixAllColors() {
		this.shapesModel.fixAllColors();
	}

	public void displayGray() {
		this.shapesModel.switchDrawGray();
	}

	public void undo() {
		this.shapesModel.undo();
	}

	public void redo() {
		this.shapesModel.redo();
	}

}
