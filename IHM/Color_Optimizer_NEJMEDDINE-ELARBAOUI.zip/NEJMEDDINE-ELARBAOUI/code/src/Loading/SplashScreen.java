package Loading;

import java.awt.*;

/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class SplashScreen extends Frame {
	/* Permet de generer un splashScreen */
	private static final long serialVersionUID = 1L;
	Image[] img;

	public SplashScreen() {
		super();
		setSize(600, 400);
		setUndecorated(true);
		setFocusable(false);
		setEnabled(false);
		String fileloc = "images/splashScreen.jpg";
		img = new Image[1];
		img[0] = this.getToolkit().createImage(fileloc);
		try {
			MediaTracker mTrack = new MediaTracker(this); // load les image
															// avant de les
															// afficher
			for (int i = 0; i < img.length; i++)
				mTrack.addImage(img[i], i);
			mTrack.waitForAll();
		} catch (Exception e) {
			System.out.println(" setimages e : " + e);
		}
	}

	public void paint(Graphics g) {
		super.paint(g);
		Dimension d = this.getSize();
		g.drawImage(img[0], 0, 0, d.width, d.height, this);
	}

	static public void main(String args[]) {
		try {
			SplashScreen sp = new SplashScreen();
			sp.setLocationRelativeTo(null);
			sp.setVisible(true);
			Thread.sleep(2000);
			sp.setVisible(false);
		} catch (Exception e) {
			System.out.println("enclosing_package.enclosing_method : " + e);
		}
	}

}