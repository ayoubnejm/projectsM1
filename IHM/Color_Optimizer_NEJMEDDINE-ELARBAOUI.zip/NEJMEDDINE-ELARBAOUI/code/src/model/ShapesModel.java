package model;

import java.awt.Color;
import java.awt.Rectangle;
import java.util.Observable;
import java.util.Random;
import javax.swing.undo.UndoableEdit;

/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class ShapesModel extends Observable {

	private Rectangle[] rectangles;
	private ColorModel[] colorModels;
	private ColorModel focusedModel;
	private boolean drawGray;
	private ColorsUndoManager undoManager;
	private boolean willUndoRedo;
	private static final int nbShapesInitial = 6;

	public ShapesModel() {

		generateColors(nbShapesInitial);
		this.drawGray = false;
		this.willUndoRedo = false;

	}

	public void generateColors(int nbShapes) {

		Random randomGenerator = new Random();
		int token, whichToRandom;
		this.rectangles = new Rectangle[nbShapes];

		this.colorModels = new ColorModel[nbShapes];
		this.focusedModel = null;
		if (this.undoManager != null) {
			this.undoManager.discardAllEdits();
			this.undoManager.updateUndoRedoButtons();
		}

		int intervalGray = 255 / nbShapes;
		int grayGap = intervalGray / 2;
		int lastGray = -1;
		int r = 0, g = 0, b = 0, gray, var1, var2, var3;

		for (int i = 0; i < nbShapes; i++) {
			Rectangle rect = new Rectangle(i, i + 1);

			gray = i * intervalGray + randomGenerator.nextInt(intervalGray);

			if (lastGray != -1) {
				while (gray < 255 && gray < i * intervalGray + intervalGray
						&& gray - lastGray < grayGap)
					gray++;
			}

			lastGray = gray;

			whichToRandom = randomGenerator.nextInt(3);
			var1 = randomGenerator.nextInt(255);
			var2 = randomGenerator.nextInt(255);

			switch (whichToRandom) {
			case 0:
				var3 = ColorModel.calculateRed(gray, var1, var2);
				break;

			case 1:
				var3 = ColorModel.calculateGreen(gray, var1, var2);
				break;

			default:
				var3 = ColorModel.calculateBlue(gray, var1, var2);
				break;
			}

			if (var3 < 0) {
				while (var3 < 0) {
					token = randomGenerator.nextInt(2);

					switch (token) {
					case 0:
						if (var1 > 0) {
							var1--;
							break;
						}
					default:
						if (var2 > 0) {
							var2--;
							break;
						}
					}

					switch (whichToRandom) {
					case 0:
						var3 = ColorModel.calculateRed(gray, var1, var2);
						break;
					case 1:
						var3 = ColorModel.calculateGreen(gray, var1, var2);
						break;
					default:
						var3 = ColorModel.calculateBlue(gray, var1, var2);
						break;
					}
				}
			} else if (var3 > 255) {
				while (var3 > 255) {
					token = randomGenerator.nextInt(2);

					switch (token) {
					case 0:
						if (var1 < 255) {
							var1++;
							break;
						}
					default:
						if (var2 < 255) {
							var2++;
							break;
						}
					}

					switch (whichToRandom) {
					case 0:
						var3 = ColorModel.calculateRed(gray, var1, var2);
						break;
					case 1:
						var3 = ColorModel.calculateGreen(gray, var1, var2);
						break;
					default:
						var3 = ColorModel.calculateBlue(gray, var1, var2);
						break;
					}
				}
			}

			switch (whichToRandom) {
			case 0:
				r = var3;
				g = var1;
				b = var2;
				break;
			case 1:
				r = var1;
				g = var3;
				b = var2;
				break;
			default:
				r = var1;
				g = var2;
				b = var3;
				break;
			}

			ColorModel aModel = new ColorModel(r, g, b);

			this.rectangles[i] = rect;
			this.colorModels[i] = aModel;
		}

		setChanged();
		notifyObservers();
	}

	public int getNbShapes() {
		return this.rectangles.length;
	}

	public ColorModel getFocusedModel() {
		return focusedModel;
	}

	public Rectangle[] getRectangles() {
		return this.rectangles;
	}

	/**
	 * 
	 * @param rectangle
	 * @return
	 */
	public ColorModel getModelAssociated(Rectangle rectangle) {
		for (int i = 0; i < this.rectangles.length; i++) {
			if (this.rectangles[i].equals(rectangle))
				return this.colorModels[i];
		}
		return null;
	}

	/**
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public ColorModel getModelSelected(int x, int y) {
		for (int i = 0; i < this.rectangles.length; i++) {
			if (this.rectangles[i].contains(x, y))
				return this.colorModels[i];

		}
		return null;
	}

	/**
	 * 
	 * @param focusedModel
	 */
	public void setFocusedModel(ColorModel focusedModel) {
		this.focusedModel = focusedModel;

		this.setChanged();
		this.notifyObservers();
	}

	public void setFocusedHex(String hex) {
		if (this.focusedModel != null) {
			this.focusedModel.setHex(hex);
			setChanged();
			notifyObservers();
		}
	}

	/**
	 * 
	 * @param color
	 */
	public void setFocusedColor(Color color) {

		if (this.focusedModel != null) {
			int focusedIndex = -1;
			Color oldColor = this.focusedModel.getColor();
			this.focusedModel.setColor(color);
			Color newColor = this.focusedModel.getColor();

			if (!this.willUndoRedo) {
				for (int i = 0; i < this.colorModels.length; i++) {
					if (this.colorModels[i] == this.focusedModel) {
						focusedIndex = i;
						break;
					}
				}
			}

			if (focusedIndex != -1 && !this.willUndoRedo
					&& !oldColor.equals(newColor)) {
				this.addUndoableEvent(focusedIndex, oldColor, newColor);
			}

			setChanged();
			notifyObservers();
		}
	}

	/**
	 * 
	 * @param modelIndex
	 * @param oldColor
	 * @param newColor
	 */
	private void addUndoableEvent(int modelIndex, Color oldColor, Color newColor) {
		UndoableEdit colorChange = new ChangeUndoableColor(this, modelIndex,
				oldColor, newColor);
		this.undoManager.addEdit(colorChange);
		this.undoManager.updateUndoRedoButtons();
	}

	public void fixAllColors() {

		int nbShapes = this.getNbShapes();

		if (nbShapes == 0)
			return;

		int intervalGray = 255 / nbShapes;
		int grayStart, gray, token;
		int r, g, b;
		int lastGray = -1;
		int grayGap = intervalGray / 2;
		Random randomGenerator = new Random();

		for (int i = 0; i < nbShapes; i++) {
			grayStart = i * intervalGray;
			ColorModel aModel = this.colorModels[i];
			r = aModel.getRed();
			g = aModel.getGreen();
			b = aModel.getBlue();
			Color oldColor = aModel.getColor();

			gray = ColorModel.calculateGray(r, g, b);

			if (gray < grayStart) {
				while (gray < grayStart && (r < 255 || g < 255 || b < 255)) {
					token = randomGenerator.nextInt(3);

					switch (token) {
					case 0:
						if (r < 255) {
							r++;
							break;
						}
					case 1:
						if (g < 255) {
							g++;
							break;
						}
					default:
						if (b < 255) {
							b++;
							break;
						}
					}

					gray = ColorModel.calculateGray(r, g, b);

				}

			} else if (gray > grayStart + intervalGray) {

				while (gray > grayStart + intervalGray
						&& (r > 0 || g > 0 || b > 0)) {
					token = randomGenerator.nextInt(3);

					switch (token) {
					case 0:
						if (r > 0) {
							r--;
							break;
						}
					case 1:
						if (g > 0) {
							g--;
							break;
						}
					default:
						if (b > 0) {
							b--;
							break;
						}
					}

					gray = ColorModel.calculateGray(r, g, b);

				}
			}
			if (lastGray > 0) {
				while (gray < lastGray + grayGap
						&& (r < 255 || g < 255 || b < 255)) {
					token = randomGenerator.nextInt(3);

					switch (token) {
					case 0:
						if (r < 255) {
							r++;
							break;
						}
					case 1:
						if (g < 255) {
							g++;
							break;
						}
					default:
						if (b < 255) {
							b++;
							break;
						}
					}
					gray = ColorModel.calculateGray(r, g, b);
				}
			}

			lastGray = gray;

			Color newColor = new Color(r, g, b);

			if (!oldColor.equals(newColor)) {
				this.colorModels[i].setColor(newColor);
				this.addUndoableEvent(i, oldColor, newColor);
			}

		}
		setChanged();
		notifyObservers();
	}

	public boolean isDrawGray() {
		return drawGray;
	}

	public void switchDrawGray() {
		this.drawGray = !drawGray;

		setChanged();
		notifyObservers();
	}

	/**
	 * 
	 * @param colorModelIndex
	 * @param color
	 */
	public void changeColor(int colorModelIndex, Color color) {
		if (colorModelIndex < 0 || colorModelIndex >= this.colorModels.length)
			return;

		this.colorModels[colorModelIndex].setColor(color);
		setChanged();
		notifyObservers();
	}

	public void setUndoManager(ColorsUndoManager undoManager) {
		this.undoManager = undoManager;
	}

	public void undo() {
		if (this.undoManager.canUndo()) {
			this.willUndoRedo = true;
			this.undoManager.undo();
			this.undoManager.updateUndoRedoButtons();
			this.willUndoRedo = false;
		}
	}

	public void redo() {
		if (this.undoManager.canRedo()) {
			this.willUndoRedo = true;
			this.undoManager.redo();
			this.undoManager.updateUndoRedoButtons();
			this.willUndoRedo = false;
		}
	}
}
