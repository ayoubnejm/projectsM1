package model;
import javax.swing.JButton;
import javax.swing.event.UndoableEditEvent;
import javax.swing.undo.UndoManager;

/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class ColorsUndoManager extends UndoManager {
	private static final long serialVersionUID = 1L;

	private JButton jbUndo;
	private JButton jbRedo;
	/**
	 * 
	 * @param jbUndo
	 * @param jbRedo
	 */
	public ColorsUndoManager(JButton jbUndo, JButton jbRedo) {
		super();
		this.jbUndo = jbUndo;
		this.jbRedo = jbRedo;
	}
 
	public void undoableEditHappened(UndoableEditEvent e) {
		super.undoableEditHappened(e);
		this.updateUndoRedoButtons();
	}
	
	public void updateUndoRedoButtons() {
		if (this.canUndo()) {
			this.jbUndo.setEnabled(true);
			this.jbUndo.setToolTipText(this.getPresentationName());
		} else {
			this.jbUndo.setEnabled(false);
		}

		if (this.canRedo()) {
			this.jbRedo.setEnabled(true);
			this.jbRedo.setToolTipText(this.getPresentationName());
		} else {
			this.jbRedo.setEnabled(false);
		}
	}

}
