package model;

import java.awt.Color;

import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;


/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class ChangeUndoableColor extends AbstractUndoableEdit { 
	private static final long serialVersionUID = 1L;
	
	ShapesModel shapesModel;
	int colorModelIndex;
	Color oldColor;
	Color newColor;
	/**
	 * 
	 * @param shapesModel
	 * @param colorModelIndex
	 * @param oldColor
	 * @param newColor
	 */
	public ChangeUndoableColor(ShapesModel shapesModel, int colorModelIndex,
			Color oldColor, Color newColor) {
		super();
		this.shapesModel = shapesModel;
		this.colorModelIndex = colorModelIndex;
		this.oldColor = oldColor;
		this.newColor = newColor;
	}

	
	public void undo() throws CannotUndoException {
		super.undo();
		this.shapesModel.changeColor(colorModelIndex, oldColor);
	}

	
	public void redo() throws CannotRedoException {
		super.redo();
		this.shapesModel.changeColor(colorModelIndex, newColor);
	}

}
