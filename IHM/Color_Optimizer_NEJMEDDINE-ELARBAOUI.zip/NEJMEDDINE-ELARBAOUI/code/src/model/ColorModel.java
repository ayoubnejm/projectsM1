package model;

import java.awt.Color;
import java.util.Observable;

/**
 * @autors : Sara El Arbaoui 
 * &
 * Ayoub Nejmeddine
 **/
public class ColorModel extends Observable {

	private static final double rFactor = 0.3;
	private static final double gFactor = 0.59;
	private static final double bFactor = 0.11;

	private Color color;

	public ColorModel(int red, int green, int blue) {
		super();
		this.color = new Color(red, green, blue);
	}

	public int getGray() {
		return calculateGray(this.color.getRed(), this.color.getGreen(),
				this.color.getBlue());
	}

	public int getRed() {
		return this.color.getRed();
	}

	public int getGreen() {
		return this.color.getGreen();
	}

	public int getBlue() {
		return this.color.getBlue();
	}

	public Color getColor() {
		return color;
	}

	public int getRGB() {
		return this.color.getRGB();
	}

	public String getHex() {
		String result = "#", tmp;

		tmp = Integer.toHexString(color.getRed() & 0xff);
		if (tmp.length() < 2)
			result += "0";
		result += tmp;

		tmp = Integer.toHexString(color.getGreen() & 0xff);
		if (tmp.length() < 2)
			result += "0";
		result += tmp;

		tmp = Integer.toHexString(color.getBlue() & 0xff);
		if (tmp.length() < 2)
			result += "0";
		result += tmp;
		return result;
	}

	public void setHex(String hex) {
		hex = hex.toLowerCase();
		if (hex.matches("#[a-f0-9]{6}")) {
			this.color = new Color(Integer.valueOf(hex.substring(1, 3), 16),
					Integer.valueOf(hex.substring(3, 5), 16), Integer.valueOf(
							hex.substring(5, 7), 16));
			setChanged();
			notifyObservers();
		}
	}

	public void setRed(int red) {
		this.color = new Color(red, getGreen(), getBlue());
		setChanged();
		notifyObservers();
	}

	public void setGreen(int green) {
		this.color = new Color(getRed(), green, getBlue());
		setChanged();
		notifyObservers();
	}

	public void setBlue(int blue) {
		this.color = new Color(getRed(), getGreen(), blue);
		setChanged();
		notifyObservers();
	}

	public void setColor(Color color2) {
		this.color = new Color(color2.getRGB());
		setChanged();
		notifyObservers();
	}

	public static int calculateGray(int r, int g, int b) {
		return (int) (rFactor * r + gFactor * g + bFactor * b);
	}

	public static int calculateRed(int gray, int g, int b) {
		return (int) ((gray - g * gFactor - b * bFactor) / rFactor);
	}

	public static int calculateGreen(int gray, int r, int b) {
		return (int) ((gray - r * rFactor - b * bFactor) / gFactor);
	}

	public static int calculateBlue(int gray, int r, int g) {
		return (int) ((gray - r * rFactor - g * gFactor) / bFactor);
	}
}
