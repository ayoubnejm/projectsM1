package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.ImageIcon;
import javax.swing.Timer;
import javax.swing.TransferHandler;
import javax.swing.event.UndoableEditEvent;
import model.FilePlayer;
import model.MyManager;
import model.MyPlayer;
import model.TableModelPlayerFile;
import model.TransfertChanson;
import model.TransfertHandlerListe;
import model.UndoableDelete;
import model.JtunesModel;
import view.UiTools;
import view.JtunesVue;

/***
 * Représente le controlleur
 * 
 * @author NEJMEDDINE & EL ARBAOUI
 * 
 */
public class JtunesController {

	/***
	 * Le modèle d
	 */
	private JtunesModel model;
	/***
	 * La vue.
	 */
	private JtunesVue view = null;
	private Timer timer;
	private TransfertChanson transferChanson = new TransfertChanson(this);
	private TransfertHandlerListe transferList = new TransfertHandlerListe(this);
	private MyManager manager = new MyManager(this);

	/***
	 * Constructeur
	 * 
	 * @param m
	 */
	public JtunesController(JtunesModel m) {
		this.model = m;
	}

	/***
	 * Permet d'associer une vue au controlleur.
	 * 
	 * @param view
	 */
	public void addView(JtunesVue view) {
		this.view = view;
	}

	/** Gestion des recherches dynamique : **/

	/***
	 * Classe permet de filtrer la liste des fichiers audio encours suivant un
	 * pattern (mot clé)
	 * 
	 * @author valentin
	 * 
	 */
	private class MyThreadTimer extends Thread {
		public void run() {
			String s;
			boolean isHere;

			// on recupere l'infi de comboBox
			String item = (String) view.getComboBox().getSelectedItem();

			model.getTableData();
			// on supprime la liste de JTable
			TableModelPlayerFile.clear();
			model.getTableData().fireTableDataChanged();
			// view.getFileTable().updateUI();

			ArrayList<FilePlayer> lesFilePlayer = new ArrayList<FilePlayer>();
			lesFilePlayer = UiTools.getFilePlayerOfList(model.getCurentList());
			String textCle = view.getSearchField().getText().toLowerCase();
			String motCle[] = textCle.split(" ");

			for (FilePlayer fp : lesFilePlayer) {
				isHere = true;
				s = fp.getInformation(item);
				s = s.toLowerCase();
				for (String mc : motCle) {
					if (!s.contains(mc)) {
						isHere = false;
					}
				}
				if (isHere)
					model.getTableData().addFile(fp);
			}
		}
	}

	/**
	 * Action listener permet de déclencher le filtrage des fichiers audios
	 * suivant le pattern.
	 */
	ActionListener actionListnerTimer = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			MyThreadTimer t = new MyThreadTimer();
			t.start();
		}
	};

	public void initialiserTimer() {

		timer = new Timer(200, actionListnerTimer);
		timer.setRepeats(false);
	}

	public Timer getTimer() {
		return timer;
	}

	public void setPosition(int pos) {
		int duration = this.model.getDuration();
		int valMaxSlider = this.view.getCurrentTrackSlider().getMaximum();
		int newPos = pos * (duration / valMaxSlider);
		this.model.setPosition(newPos);
	}

	public void setVolume(float volume) {
		this.model.setVolume(volume);
	}

	public void addFileInTableData(FilePlayer fp, String filePath) {
		if (!this.model.getTableData().getFilesList().contains(fp)) {
			model.addFileInTableData(fp);
			xmlFile.XmlFile.addElement(model.getCurentList(), filePath);
		}
	}

	/****
	 * Permet d'activer le mode aléatoire.
	 */
	public void randomPlayOn() {

		this.view.getFileTable().setRowSorter(null);
		this.view
				.getRandomPlayButton()
				.setIcon(
						new ImageIcon(
								ClassLoader
										.getSystemResource("utils/images/Icons/player/Random.png")));
		this.view.getRandomPlayButton().setToolTipText(
				"Désactiver la lecture aléatoire");
		this.model.setRandomPlayMode(true);
		this.model.setCurrentTrack(model.getTableData().getFilesList().get(0));

		Collections.shuffle(this.model.getTableData().getFilesList());
		this.model.getTableData().fireTableDataChanged();
		this.view.getFileTable().setRowSorter(this.view.getSorter());

		this.view.getFileTable().getSelectionModel().setSelectionInterval(0, 0);
	}

	/***
	 * Permet de désactiver le mode aléatoire.
	 */
	public void randomPlayOff() {

		this.view
				.getRandomPlayButton()
				.setIcon(
						new ImageIcon(
								ClassLoader
										.getSystemResource("utils/images/Icons/player/Random_off.png")));
		this.view.getRandomPlayButton().setToolTipText(
				"Activer la lecture aléatoire");
		this.model.setRandomPlayMode(false);
		this.model.getTableData().getFilesList().clear();
		this.model.getTableData().setFilePlayerOfList(
				this.model.getCurentList());

		this.model.getTableData().fireTableDataChanged();

		this.view.getFileTable().getSelectionModel().setSelectionInterval(0, 0);
	}

	/***
	 * Permet de récupèrer le fichier audio sélectionné dans la jTable.
	 * 
	 * @return
	 */
	public FilePlayer getFilePlayerSelected() {
		int selectedRow = this.view.getFileTable().getSelectedRow();
		if (selectedRow == -1) {
			selectedRow = 0;
		}

		this.view.getFileTable().getSelectionModel()
				.setSelectionInterval(selectedRow, selectedRow);
		int rowConverted = this.view.getFileTable().getRowSorter()
				.convertRowIndexToModel(selectedRow);
		FilePlayer filePlayerSelected = this.model.getTableData()
				.getFilePlayer(rowConverted);
		return filePlayerSelected;
	}

	/***
	 * Permet de récupèrer la "playList" sélectionnée
	 * 
	 * @return
	 */
	public File getPlayListSelected() {
		int selectedRow = this.view.getPlayListTable().getSelectedRow();
		if (selectedRow == -1) {
			selectedRow = 0;
		}

		this.view.getPlayListTable().getSelectionModel()
				.setSelectionInterval(selectedRow, selectedRow);
		int rowConverted = this.view.getPlayListTable().getRowSorter()
				.convertRowIndexToModel(selectedRow);
		File playListSelected = this.model.getTablePlayList().getPlayList(
				rowConverted);
		return playListSelected;
	}

	public FilePlayer getNextFilePlayer() {

		int selectedRow = this.view.getFileTable().getSelectedRow() + 1;
		if (this.model.isRepeatMode()) {
			selectedRow -= 1;
		} else if (selectedRow >= this.model.getTableData().getRowCount()) {
			selectedRow -= 1;
		}

		this.view.getFileTable().getSelectionModel()
				.setSelectionInterval(selectedRow, selectedRow);
		int rowConverted = this.view.getFileTable().getRowSorter()
				.convertRowIndexToModel(selectedRow);
		FilePlayer filePlayerSelected = this.model.getTableData()
				.getFilePlayer(rowConverted);

		return filePlayerSelected;
	}

	/***
	 * Permet de récupèrer le fichier audio précedent le fichier audio en cours
	 * de lecture.
	 * 
	 * @return
	 */
	public FilePlayer getPreviousFilePlayer() {

		int selectedRow = this.view.getFileTable().getSelectedRow() - 1;
		if (selectedRow < 0) {
			selectedRow = 0;
		}

		this.view.getFileTable().getSelectionModel()
				.setSelectionInterval(selectedRow, selectedRow);
		int rowConverted = this.view.getFileTable().getRowSorter()
				.convertRowIndexToModel(selectedRow);
		FilePlayer filePlayerSelected = this.model.getTableData()
				.getFilePlayer(rowConverted);

		return filePlayerSelected;
	}

	public void setCurentList(String pathXml) {
		model.setListJTable(pathXml);
	}

	public String getCurentList() {
		return model.getCurentList();
	}

	public void playPauseFile(String path, FilePlayer fp) {

		if (this.model.getPlayer().getState() == 0) {
			this.model.getPlayer().setJtunesModel(this.model);
			
			System.out.println(UiTools.getPathOfFilePlayer(fp, path));

			stopFile();
			this.model.getPlayer().Load(UiTools.getPathOfFilePlayer(fp, path));
			this.model.getPlayer().PlayPause();

			float oldValue = (new Float(this.view.getVolumeSlider().getValue()) / new Float(
					this.view.getVolumeSlider().getMaximum()));
			setVolume(oldValue);

			this.model.setCurrentTrack(fp);
			this.view.getCurrentTrackSlider().setValue(0);
			this.view.getCurrentTrackName().setText(
					model.getCurrentTrack().getTitle() + "   "
							+ model.getCurrentTrack().getArtist() + "  ");
			this.view.getCurrentTrackDuration().setText(
					model.getStringDuration(this.model.getCurrentDuration()));
			this.view.getCurrentTrackTotalDuration().setText(
					model.getStringDuration(this.model.getPlayer()
							.getDuration()));
			// this.view.getCurrentTrackName().start();
			this.view
					.getPlayButton()
					.setIcon(
							new ImageIcon(
									ClassLoader
											.getSystemResource("utils/images/Icons/player/Pause.png")));
		} else if (this.model.getPlayer().getState() == 2) {
			this.model.getPlayer().PlayPause();
			this.view
					.getPlayButton()
					.setIcon(
							new ImageIcon(
									ClassLoader
											.getSystemResource("utils/images/Icons/player/Play.png")));
		} else if (this.model.getPlayer().getState() == 3) {
			this.model.getPlayer().PlayPause();
			this.view
					.getPlayButton()
					.setIcon(
							new ImageIcon(
									ClassLoader
											.getSystemResource("utils/images/Icons/player/Pause.png")));
		}

	}

	public MyPlayer getPlayer() {
		return this.model.getPlayer();
	}

	public FilePlayer getCurrentTrack() {
		return this.model.getCurrentTrack();
	}

	public void stopFile() {
		this.model.getPlayer().Stop();
		this.view.getCurrentTrackSlider().setValue(0);
		this.view.getCurrentTrackName().setText("Aucune lecture en cours");
		this.view.getCurrentTrackTotalDuration().setText("00:00:00");
		this.view
				.getPlayButton()
				.setIcon(
						new ImageIcon(
								ClassLoader
										.getSystemResource("utils/images/Icons/player/Play.png")));
	}

	public void repeatModeOff() {
		this.model.setRepeatMode(false);
		this.view
				.getRepeatButton()
				.setIcon(
						new ImageIcon(
								ClassLoader
										.getSystemResource("utils/images/Icons/player/Repeat_off.png")));
		this.view.getRepeatButton().setToolTipText(
				"Répéter la liste de lecture");
	}

	public void repeatModeOn() {
		this.model.setRepeatMode(true);
		this.view
				.getRepeatButton().setIcon(	new ImageIcon(ClassLoader.getSystemResource("utils/images/Icons/player/Repeat.png")));
		this.view.getRepeatButton().setToolTipText("Désactiver la répétition");
	}

	public MyManager getMyManager() {
		return this.manager;
	}

	public TransferHandler getTransferChanson() {
		return this.transferChanson;
	}

	public void actionSupprimer() {
		int index = view.getJListe().getSelectedIndex();
		if (index != -1)
			manager.undoableEditHappened(new UndoableEditEvent(view
					.getlistModel(), new UndoableDelete(view.getlistModel(),
					(String) view.getlistModel().remove(index), index)));

		updateUndoRedoButtons();
	}

	public void actionAnnuler() {
		if (manager.canUndo()) {
			manager.undo();
			updateUndoRedoButtons();
		}
	}

	public void actionRefaire() {
		if (manager.canRedo()) {
			manager.redo();
			updateUndoRedoButtons();
		}
	}

	public void updateUndoRedoButtons() {
		view.getboutonAnnuler().setEnabled(manager.canUndo());
		view.getboutonRefaire().setEnabled(manager.canRedo());
		if (view.getlistModel().isEmpty()) {
			view.getboutonSupprimer().setEnabled(false);
		} else {
			view.getboutonSupprimer().setEnabled(true);
		}
	}

	public TransferHandler getTransferList() {
		return transferList;
	}

	/**
	 * 
	 */

	public void createNewPlayListFile() {
		int currentsize = model.getTablePlayList().getThePlayList().size();
		File f;

		if (currentsize == 0)
			f = new File(model.getXMLPATH() + "/"
					+ "Derniere Liste ecoutée.xml");
		else {
			int num = currentsize + 1;

			f = new File(model.getXMLPATH() + "/" + "Nouvelle liste " + num
					+ ".xml");

			while (f.exists()) {
				f = new File(model.getXMLPATH() + "/" + "Nouvelle liste "
						+ num++ + ".xml");
			}
		}
		try {
			f.createNewFile();
			Writer output = null;
			output = new BufferedWriter(new FileWriter(f));
			output.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
					+ "<playLists>" + "</playLists>");
			output.close();
			model.getTablePlayList().addPlayList(f);
			model.getTablePlayList().fireTableDataChanged();
		} catch (IOException e) {
		}

	}

	public void deletePlayListFile() {
		int selectedRow = this.view.getPlayListTable().getSelectedRow();
		System.out.println(selectedRow);

		try {
			if (selectedRow != -1) {
				File f = model.getTablePlayList().getPlayList(selectedRow);
				f.delete();
				model.getTablePlayList().removePlayList(selectedRow);
				model.getTableData();
				TableModelPlayerFile.clear();
				model.getTableData().fireTableDataChanged();
				view.getStatus().setText("");
				view.getFileTable().updateUI();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteFilePlayer() {
		int selectedRow = this.view.getFileTable().getSelectedRow();

		try {
			if (selectedRow != -1) {
				FilePlayer fp = model.getTableData().getFilePlayer(selectedRow);
				model.getTableData().removeFile(selectedRow);
				model.getTableData().fireTableDataChanged();

				xmlFile.XmlFile.removeElement(model.getCurentList(),
						UiTools.getPathOfFilePlayer(fp, model.getCurentList()));

			}
		} catch (Exception e) {
		}
	}

	public JtunesModel getModel() {
		return this.model;
	}

	public JtunesVue getView() {
		return this.view;
	}

}