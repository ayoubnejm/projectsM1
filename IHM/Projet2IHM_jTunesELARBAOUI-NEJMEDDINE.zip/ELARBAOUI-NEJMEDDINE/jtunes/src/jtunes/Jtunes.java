package jtunes;

import model.*;
import view.*;
import controller.*;

/***
 * @author NEJMEDDINE & EL ARBAOUI
 * **/
public class Jtunes {
	public Jtunes() {
		/*Initialisation du modèle.*/
		JtunesModel jmod = new JtunesModel();
		/*Associer le controller au modèle.*/
		JtunesController controller = new JtunesController(jmod);
        /*Associer le controller et le modèle à la vue.*/
		JtunesVue jv = new JtunesVue(jmod,controller);
		controller.addView(jv);
	}
	
    public static void main(String args[]) {
    //Schedule a job for the event-dispatching thread:
    //creating and showing this application's GUI.
    javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new Jtunes();
      }
    });
	}
}