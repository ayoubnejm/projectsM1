package xmlFile;

import java.io.*;
import java.util.Iterator;
import java.util.List;
import org.jdom.*;
import org.jdom.input.SAXBuilder;
import org.jdom.output.*;

/**
 * *
 *
 * @author NEJMEDDINE & EL ARBAOUI
 */
public class XmlFile {

    static void enregistre(String fichier, Document d) {
        try {
            // On utilise ici un affichage classique avec getPrettyFormat()
            XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
            // Remarquez qu'il suffit simplement de créer une instance de
            // FileOutputStream
            // avec en argument le nom du fichier pour effectuer la
            // sérialisation.
            sortie.output(d, new FileOutputStream(fichier));
        } catch (java.io.IOException e) {
        }
    }

    public XmlFile(String nomFichier) {
        Element racine = new Element("playLists");

        // On crée un nouveau Document JDOM basé sur la racine que l'on vient
        // de
        // créer
        org.jdom.Document document = new Document(racine);

        enregistre(nomFichier, document);
    }

    public static void addElement(String path, String chanson) {
        org.jdom.Document doc = null;
        Element racine;

        // On crée une instance de SAXBuilder
        SAXBuilder sxb = new SAXBuilder();
        try {
            // On cree un nouveau document JDOM avec en argument le fichier XML
            // Le parsing est terminé ;)
            doc = sxb.build(new File(path));
            racine = doc.getRootElement();
            Element chan = new Element("music");
            chan.setText(chanson);
            racine.addContent(chan);
            enregistre(path, doc);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void removeElement(String pathXml, String path) {
        org.jdom.Document doc = null;
        Element racine;

        // On crée une instance de SAXBuilder
        SAXBuilder sxb = new SAXBuilder();
        try {
            File playlistFile = new File(pathXml);
            doc = sxb.build(playlistFile);
            racine = doc.getRootElement();

            List listChansons = racine.getChildren("music");

            Iterator i = listChansons.iterator();
            for (Object o : listChansons) {
                Element courant = (Element) o;
                if (courant.getText().equals(path)) {
                    courant.getParent().removeContent(courant);
                    enregistre(playlistFile.getAbsolutePath(), doc);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}