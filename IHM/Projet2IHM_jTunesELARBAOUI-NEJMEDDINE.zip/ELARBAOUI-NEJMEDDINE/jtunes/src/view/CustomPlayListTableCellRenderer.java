package view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;

/**
 * *
 *
 * @author NEJMEDDINE & EL ARBAOUI
 */
public class CustomPlayListTableCellRenderer extends DefaultTableCellRenderer {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public Component getTableCellRendererComponent(JTable table, Object obj,
            boolean isSelected, boolean hasFocus, int row, int column) {
        Component cell = super.getTableCellRendererComponent(table, obj,
                isSelected, hasFocus, row, column);

        TableColumnModel cm = table.getColumnModel();
        cm.getColumn(0).setCellEditor(new PlayListCellEditor());

        Font displayFont = new Font("Serif", Font.BOLD, 11);
        cell.setFont(displayFont);
        this.setHorizontalAlignment(JLabel.CENTER);
        table.setCursor(new Cursor(Cursor.HAND_CURSOR));

        table.setRowHeight(32);
        if (isSelected) {
            cell.setBackground(new Color(140, 140, 150));
            Font f = new Font("", Font.BOLD, 13);
            cell.setFont(f);
            cell.setForeground(Color.BLACK);
        } else {
            cell.setForeground(Color.WHITE);
            cell.setBackground(new Color(64, 64, 64));
        }

        return cell;
    }
}