package view;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.*;

/***
 * 
 * @author NEJMEDDINE & EL ARBAOUI
 */

	@SuppressWarnings("serial")
	public class ImageField extends JTextField {
		private  BufferedImage image;
		
		public ImageField(int length, String iconUrl) {
			super(length);
			
	        URL url = ClassLoader.getSystemResource(iconUrl);
			try {
				image = ImageIO.read(url);
			} catch (IOException e) {}
			this.setMargin(new Insets(1, 1 + image.getWidth(), 1, 1));
		}
		
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int y = (getHeight() - image.getHeight())/2;
            g.drawImage(image, 2, y, this);
        }
		


	}