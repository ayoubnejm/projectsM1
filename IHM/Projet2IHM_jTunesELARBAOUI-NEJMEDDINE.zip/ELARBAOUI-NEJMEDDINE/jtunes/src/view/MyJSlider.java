package view;

import java.awt.Cursor;
import java.awt.Dimension;

import javax.swing.JSlider;

/**
 * *
 * Classe représente notre Slider personnalisé.
 *
 * @author NEJMEDDINE & EL ARBAOUI
 *
 */
public class MyJSlider extends JSlider {
 
    private static final long serialVersionUID = 1L;

    /**
     * Constructs a Slider with default parameters
     */
    public MyJSlider() {
        initSlider();
    }

    /**
     * Constructs a Slider with the specified default minimum, maximum and
     * default value values.
     */
    public MyJSlider(int min, int max, int defaultVal) {
        super(HORIZONTAL, min, max, defaultVal);
        this.setPreferredSize(new Dimension(150, 10));
        initSlider();
    }

    /**
     * Initializes the slider by setting default properties.
     */
    private void initSlider() {

        setOpaque(false);
        setFocusable(false);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    /**
     * Overrides the superclass method to install the UI delegate to repaint the
     * thumb and the track component
     */
    public void updateUI() {
        setUI(new MyJSliderUI(this));
        updateLabelUIs();
    }
}