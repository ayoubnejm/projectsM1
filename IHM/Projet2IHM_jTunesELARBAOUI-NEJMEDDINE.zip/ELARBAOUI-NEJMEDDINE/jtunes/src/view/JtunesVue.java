package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.Observable;
import java.util.Observer;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.DropMode;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.TransferHandler;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import model.FiltreFileChooserMp3;
import model.JtunesModel;
import controller.JtunesController;

/**
 * *
 * Classe représente la vue de jTunes
 *
 * @author NEJMEDDINE & EL ARBAOUI
 *
 */
public class JtunesVue implements Observer {

    JFrame myFrame = new JFrame("Jtunes Mp3");
    JPanel myPanel = new JPanel();
    JPanel southToolBarPanel = new JPanel();
    JPanel WestPanel = new JPanel();
    JPanel northPlayerMenu = new JPanel();
    JPanel playingInfo = new JPanel();
    JPanel trackInfo = new JPanel();
    JPanel durationNSlider = new JPanel();
    JPanel audioControl = new JPanel();
    JPanel trackOptions = new JPanel();
    JPanel volumeOptions = new JPanel();
    JPanel searchOptions = new JPanel();
    JPanel playModePanel = new JPanel();
    int i = 0;
    private JButton rewindButton;
    private JButton forwardButton;
    private JButton playButton;
    private JButton stopButton;
    private JButton browseButton;
    private JButton browseDirButton;
    private JButton searchButton;
    private JButton volumeUpButton;
    private JButton randomPlayButton;
    private JButton addPlayListButton;
    private JButton repeatModeButton;
    private JLabel currentTrackName = new JLabel("Aucune lecture en cours");
    private JLabel currentTrackDuration = new JLabel();
    private JLabel totalTrackDuration = new JLabel();
    private JLabel status = new JLabel("");
    private ImageField searchField = new ImageField(12, "utils/images/Icons/player/find.png");
    private MyJSlider volumeSlider = new MyJSlider(40, 100, 87);
    private MyJSlider currentTrackSlider = new MyJSlider(0, 100, 0);
    private MyJTable fileTable;
    private MyJTable playListTable;
    private TableRowSorter<TableModel> sorter;
    private TableRowSorter<TableModel> playListsorter;
    private JComboBox combo = new JComboBox();
    private JtunesModel model;
    private JtunesController controller;
    // ///////////////////////////////////////
    DefaultListModel listModel;
    JListe list;
    JButton boutonAnnuler, boutonRefaire, boutonSupprimer, boutonDemarer;
    JPanel ListChanson = new JPanel();
    JPanel panelActionsTop = new JPanel();
    JPanel panelActionsTopLabels = new JPanel();

    public DefaultListModel getlistModel() {
        return listModel;
    }

    public JListe getJListe() {
        return list;
    }

    public JButton getboutonAnnuler() {
        return boutonAnnuler;
    }

    public JButton getboutonRefaire() {
        return boutonRefaire;
    }

    public JButton getboutonSupprimer() {
        return boutonSupprimer;
    }

    public JtunesVue(JtunesModel model, JtunesController controller) {
        this.model = model;
        this.controller = controller;
        this.controller.initialiserTimer();
        model.addObserver(this);
        this.buildUi();
    }

    public JComboBox getComboBox() {
        return combo;
    }

    public JTable getFileTable() {
        return fileTable;
    }

    public JTable getPlayListTable() {
        return playListTable;
    }

    public JButton getPlayButton() {
        return this.playButton;
    }

    public JButton getStopButton() {
        return this.stopButton;
    }

    public JButton getRewindButton() {
        return this.rewindButton;
    }

    public JButton getForwordButton() {
        return this.forwardButton;
    }

    public JButton getVolumeButton() {
        return this.volumeUpButton;
    }

    public JButton getSearchButton() {
        return this.searchButton;
    }

    public JButton getBrowseButton() {
        return browseButton;
    }

    public JButton getBrowseDirButton() {
        return browseDirButton;
    }

    public JButton getRandomPlayButton() {
        return randomPlayButton;
    }

    public JButton getAddPlayListButton() {
        return addPlayListButton;
    }

    public JButton getRepeatButton() {
        return repeatModeButton;
    }

    public MyJSlider getVolumeSlider() {
        return this.volumeSlider;
    }

    public MyJSlider getCurrentTrackSlider() {
        return this.currentTrackSlider;
    }

    public JTextField getSearchField() {
        return searchField;
    }

    public JLabel getCurrentTrackName() {
        return this.currentTrackName;
    }

    public JLabel getCurrentTrackDuration() {
        return this.currentTrackDuration;
    }

    public JLabel getCurrentTrackTotalDuration() {
        return this.totalTrackDuration;
    }

    public JLabel getStatus() {
        return this.status;
    }

    public TableRowSorter<TableModel> getSorter() {
        return sorter;
    }

    public TableRowSorter<TableModel> getPlayListSorter() {
        return playListsorter;
    }

    /**
     * *********************---------------------- Getters / Setters End
     * ----------------------------***************************
     */
    /**
     * *******--------------------- Creation de composant graphiques
     * --------------------*******************
     */
    public void createFrame() {
        myFrame.setLayout(new BorderLayout());
        myFrame.setIconImage(Toolkit
                .getDefaultToolkit()
                .getImage(ClassLoader.getSystemResource("utils/images/Icons/player/icon_app.png")));
        // myFrame.setPreferredSize(new Dimension(1180, 720));
        myFrame.setMinimumSize(new Dimension(1180, 400));
        myFrame.setResizable(true);
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setVisible(true);
        myFrame.pack();
        myFrame.setLocationRelativeTo(null);
    }

    public void buildUi() {
        createFrame();
        createContentPane();

    }

    public JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        /**
         * Menu Fichier *
         */
        JMenu menu = new JMenu("Fichier");
        menu.setMnemonic(KeyEvent.VK_F);

        ImageIcon quitIcon = new ImageIcon("./src/utils/images/quit.png");

        JMenuItem quitApplication = new JMenuItem("Quitter", quitIcon);
        quitApplication.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));
        quitApplication.addActionListener(quitAppli);

        ImageIcon browseIcon = new ImageIcon("./src/utils/images/file_add_icon.png");
        JMenuItem browseFile = new JMenuItem("Importer un fichier", browseIcon);
        browseFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
        browseFile.addActionListener(browseFileListener);



        ImageIcon browseDirIcon = new ImageIcon("./src/utils/images/dir_add_icon.png");
        JMenuItem browseDir = new JMenuItem("Importer un dossier", browseDirIcon);
        browseDir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, ActionEvent.CTRL_MASK));
        browseDir.addActionListener(browseDirListener);


        ImageIcon playListIcon = new ImageIcon("./src/utils/images/AddPlaylist_icon.png");
        JMenuItem newPlayList = new JMenuItem("Nouvelle liste de lecture", playListIcon);
        newPlayList.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
        newPlayList.addActionListener(newPlayListener);

        menu.add(newPlayList);
        menu.add(browseFile);
        menu.add(browseDir);
        menu.add(quitApplication);

        /**
         * Menu Lecture *
         */
        JMenu menu2 = new JMenu("Lecture");
        menu2.setMnemonic(KeyEvent.VK_L);

        ImageIcon playIcon = new ImageIcon("./src/utils/images/Icons/player/Play_icon.png");
        JMenuItem playItem = new JMenuItem("Lecture/Pause de la piste", playIcon);
        playItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        playItem.addActionListener(playPauseFileListener);

        ImageIcon stopIcon = new ImageIcon("./src/utils/images/Icons/player/Stop_icon.png");
        JMenuItem stopItem = new JMenuItem("Arrêter la lecture", stopIcon);
        stopItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
        stopItem.addActionListener(stopFileListener);

        ImageIcon rewindIcon = new ImageIcon("./src/utils/images/Icons/player/Rewind_icon.png");
        JMenuItem rewindItem = new JMenuItem("Piste précédente", rewindIcon);
        rewindItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, ActionEvent.CTRL_MASK));
        rewindItem.addActionListener(prevFileListener);

        ImageIcon forwardIcon = new ImageIcon("./src/utils/images/Icons/player/Forward_icon.png");
        JMenuItem forwardItem = new JMenuItem("Piste suivante", forwardIcon);
        forwardItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, ActionEvent.CTRL_MASK));
        forwardItem.addActionListener(nextFileListener);

        menu2.add(playItem);
        menu2.add(stopItem);
        menu2.add(rewindItem);
        menu2.add(forwardItem);

        /**
         * Menu Mode *
         */
        JMenu menu3 = new JMenu("Mode");
        menu3.setMnemonic(KeyEvent.VK_M);

        ImageIcon randomIcon = new ImageIcon("./src/utils/images/Icons/player/Random_icon.png");
        JMenuItem randomItem = new JMenuItem("Activer/Désactiver la lecture aléatoire", randomIcon);
        randomItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.CTRL_MASK));
        randomItem.addActionListener(randomPlayListener);

        ImageIcon repeatIcon = new ImageIcon("./src/utils/images/Icons/player/Repeat_icon.png");
        JMenuItem repeatItem = new JMenuItem("Répéter la piste en cours", repeatIcon);
        repeatItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.CTRL_MASK));
        repeatItem.addActionListener(repeatPlayListener);

        ImageIcon searchIcon = new ImageIcon("./src/utils/images/Icons/player/find_icon.png");
        JMenuItem searchItem = new JMenuItem("Recherche", searchIcon);
        searchItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
        searchItem.addActionListener(searchListener);

        menu3.add(randomItem);
        menu3.add(repeatItem);
        menu3.add(searchItem);

        /**
         * Menu Bar *
         */
        menuBar.add(menu);
        menuBar.add(menu2);
        menuBar.add(menu3);

        return menuBar;
    }

    public void createContentPane() {
        myFrame.setJMenuBar(createMenuBar());
        myFrame.getContentPane().add(createNorthPanel(), BorderLayout.NORTH);
        myFrame.getContentPane().add(createCenter(), BorderLayout.CENTER);
        myFrame.getContentPane().add(createWestPanel(), BorderLayout.WEST);
        myFrame.getContentPane().add(createSouthToolBar(), BorderLayout.SOUTH);
    }

    public JPanel createEast() {

        // JPanel
        JPanel fen = new JPanel();
        fen.setLayout(new BorderLayout(10, 10));
        fen.setPreferredSize(new Dimension(250, 700));

        // Liste
        listModel = new DefaultListModel();
        list = new JListe(listModel);
        list.setDropMode(DropMode.INSERT);
        list.setTransferHandler(this.controller.getTransferList());
        list.setDragEnabled(true);

        list.addUndoableEditListener(this.controller.getMyManager());

        JScrollPane listScroller = new JScrollPane(list);
        listScroller.setPreferredSize(new Dimension(250, 500));

        boutonSupprimer = UiTools.createButton("",
                "utils/images/supprimer.png", 26, 26);
        boutonSupprimer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.actionSupprimer();
            }
        });
        boutonDemarer = UiTools.createButton("", "utils/images/annuler.png",
                26, 26);
        boutonDemarer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
//				controller.;
            }
        });
        boutonAnnuler = UiTools.createButton("", "utils/images/annuler.png",
                26, 26);
        boutonAnnuler.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.actionAnnuler();
            }
        });

        boutonRefaire = UiTools.createButton("", "utils/images/refaire.png",
                26, 26);
        boutonRefaire.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.actionRefaire();
            }
        });

        panelActionsTop.setLayout(new BoxLayout(panelActionsTop,
                BoxLayout.X_AXIS));
        panelActionsTop.add(Box.createRigidArea(new Dimension(100, 0)));

        JPanel panelActionsBottom = new JPanel();

        BoxLayout boxLayout = new BoxLayout(panelActionsBottom,
                BoxLayout.PAGE_AXIS);
        panelActionsBottom.setLayout(boxLayout);

        boutonAnnuler.setToolTipText("Annuler");
        boutonAnnuler.setEnabled(false);
        boutonRefaire.setToolTipText("Refaire");
        boutonRefaire.setEnabled(false);
        boutonSupprimer.setToolTipText("Supprimer la chanson");
        boutonSupprimer.setEnabled(false);
        panelActionsTopLabels.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelActionsTop.add(boutonSupprimer);
        panelActionsTop.add(boutonAnnuler);
        panelActionsTop.add(boutonRefaire);
        panelActionsTop.add(panelActionsTopLabels);

        TitledBorder title;
        title = BorderFactory
                .createTitledBorder("Liste des chansons prochaines : ");
        title.setTitleJustification(TitledBorder.CENTER);
        listScroller.setBorder(title);
        Font displayFont = new Font("Sans Serif", Font.BOLD, 12);
        list.setFont(displayFont);

        ListChanson.setPreferredSize(new Dimension(100, 300));
        ListChanson.setVisible(true);

        fen.add(listScroller, BorderLayout.NORTH);
        fen.add(panelActionsTop, BorderLayout.SOUTH);

        return fen;
    }

    public JScrollPane createCenter() {
        fileTable = new MyJTable(model.getTableData());

        fileTable.setDragEnabled(true);
        fileTable.setDropMode(DropMode.INSERT);
        fileTable.setTransferHandler(this.controller.getTransferChanson());

        sorter = new TableRowSorter<TableModel>(fileTable.getModel());
        sorter.setSortsOnUpdates(true);
        fileTable.setRowSorter(sorter);
        fileTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        fileTable.setDefaultRenderer(Object.class,
                new CustomTableCellRenderer());

        fileTable.addMouseListener(TableClickListener);
        fileTable.addKeyListener(deleteFilePlayerListener);
        fileTable.getSelectionModel().setSelectionInterval(0, 0);
        return new JScrollPane(fileTable);
    }
    ActionListener quitAppli = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            System.exit(1);
        }
    };

    public JPanel createPlayModePanel() {
        playModePanel.setLayout(new FlowLayout());

        playModePanel.setAlignmentX(FlowLayout.LEFT);
        playModePanel.setPreferredSize(new Dimension(255, 40));

        browseButton = UiTools.createButton("",
                "utils/images/Icons/player/file_add.png", 32, 32);

        browseDirButton = UiTools.createButton("",
                "utils/images/Icons/player/dir_add.png", 32, 32);

        randomPlayButton = UiTools.createButton("",
                "utils/images/Icons/player/Random_off.png", 32, 32);

        addPlayListButton = UiTools.createButton("",
                "utils/images/Icons/player/AddPlaylist.png", 32, 32);

        repeatModeButton = UiTools.createButton("",
                "utils/images/Icons/player/Repeat_off.png", 32, 32);

        browseButton.addActionListener(browseFileListener);
        browseDirButton.addActionListener(browseDirListener);
        addPlayListButton.addActionListener(newPlayListener);
        randomPlayButton.addActionListener(randomPlayListener);
        repeatModeButton.addActionListener(repeatPlayListener);

        browseButton.setToolTipText("Ajouter un fichier");
        browseDirButton.setToolTipText("Ajouter un dossier");
        randomPlayButton.setToolTipText("Activer la lecture aléatoire");
        addPlayListButton.setToolTipText("Créer une nouvelle liste de lecture");
        repeatModeButton.setToolTipText("Répéter la piste en cours");

        playModePanel.add(browseButton);
        playModePanel.add(browseDirButton);
        playModePanel.add(addPlayListButton);
        playModePanel.add(randomPlayButton);
        playModePanel.add(repeatModeButton);

        return playModePanel;
    }

    public JPanel createSouthToolBar() {
        southToolBarPanel.setLayout(new BorderLayout());

        JPanel tempPanel = new JPanel();
        tempPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        tempPanel.add(status);
        southToolBarPanel.add(createPlayModePanel(), BorderLayout.WEST);
        southToolBarPanel.add(tempPanel, BorderLayout.CENTER);
        return southToolBarPanel;
    }

    public JPanel createNorthPanel() {
        northPlayerMenu.setBackground(new Color(64, 64, 64));
        northPlayerMenu.setLayout(new BorderLayout());
        northPlayerMenu.add(createAudioControl(), BorderLayout.WEST);
        northPlayerMenu.add(createPlayingInfo(), BorderLayout.CENTER);
        northPlayerMenu.add(createTrackOptions(), BorderLayout.EAST);
        return northPlayerMenu;
    }

    public JPanel createPlayingInfo() {

        playingInfo.setBackground(new Color(64, 64, 64));
        playingInfo.add(createTrackInfo());

        return playingInfo;
    }

    public JPanel createTrackInfo() {
        trackInfo.setBackground(new Color(64, 64, 64));
        trackInfo.setLayout(new BoxLayout(trackInfo, BoxLayout.Y_AXIS));
        trackInfo.setAlignmentX(Component.CENTER_ALIGNMENT);

        trackInfo.add(Box.createRigidArea(new Dimension(0, 7)));

        currentTrackName.setAlignmentX(Component.CENTER_ALIGNMENT);
        currentTrackName.setForeground(Color.WHITE);

        trackInfo.add(currentTrackName);
        trackInfo.add(Box.createRigidArea(new Dimension(0, 2)));
        trackInfo.add(createSliderTrack("00:00:00", "00:00:00"));
        return trackInfo;
    }

    public JPanel createTrackOptions() {

        trackOptions.setLayout(new BoxLayout(trackOptions, BoxLayout.Y_AXIS));
        trackOptions.setPreferredSize(new Dimension(310, 80));

        trackOptions.add(createSearchOptions());

        return trackOptions;
    }
    KeyListener actionListnerSearch = new KeyListener() {
        public void keyPressed(KeyEvent e) {
            if (controller.getTimer().isRunning()) {
                controller.getTimer().restart();

            } else {
                controller.getTimer().start();
            }

        }

        public void keyReleased(KeyEvent e) {
        }

        public void keyTyped(KeyEvent e) {
        }
    };

    public JPanel createSearchOptions() {
        searchOptions.setBackground(new Color(64, 64, 64));
        searchOptions.setLayout(new FlowLayout(FlowLayout.RIGHT));
        searchOptions.setPreferredSize(new Dimension(250, 35));
        searchField.addKeyListener(actionListnerSearch);

        combo.setPreferredSize(new Dimension(67, 20));
        combo.addItem("Tous");
        combo.addItem("Nom");
        combo.addItem("Album");
        combo.addItem("Artist");
        combo.addItem("Titre");
        combo.addItem("Annee");

        searchOptions.add(combo);
        searchOptions.add(searchField);

        return searchOptions;
    }

    public JPanel createVolumeOptions() {
        volumeOptions.setBackground(new Color(64, 64, 64));
        volumeOptions.setLayout(new FlowLayout(FlowLayout.LEFT));
        volumeOptions.setPreferredSize(new Dimension(150, 45));

        volumeOptions.add(createVolumeSlider());
        volumeUpButton = UiTools.createButton("",
                "utils/images/Icons/player/volume_high.png", 32, 32);
        volumeOptions.add(volumeUpButton);
        return volumeOptions;
    }

    public JSlider createVolumeSlider() {
        volumeSlider.setMajorTickSpacing(20);
        volumeSlider.setMinorTickSpacing(10);
        volumeSlider.addChangeListener(volumeListener);
        volumeSlider.setPreferredSize(new Dimension(100, 32));
        return volumeSlider;
    }

    public JSlider createCurrentTrackSlider() {
        currentTrackSlider.addChangeListener(currentTrackListener);
        return currentTrackSlider;
    }

    public JPanel createSliderTrack(String currentDuration, String totalDuration) {
        durationNSlider.setLayout(new FlowLayout(FlowLayout.CENTER));
        durationNSlider.setOpaque(false);
        currentTrackDuration.setForeground(Color.WHITE);
        totalTrackDuration.setForeground(Color.WHITE);
        currentTrackDuration.setText(currentDuration);
        totalTrackDuration.setText(totalDuration);

        durationNSlider.add(currentTrackDuration);
        durationNSlider.add(createCurrentTrackSlider());
        durationNSlider.add(totalTrackDuration);
        return durationNSlider;
    }

    public JPanel createAudioControl() {
        audioControl.setOpaque(false);

        rewindButton = UiTools.createButton("",
                "utils/images/Icons/player/Rewind.png", 50, 50);
        playButton = UiTools.createButton("",
                "utils/images/Icons/player/Play.png", 70, 70);
        forwardButton = UiTools.createButton("",
                "utils/images/Icons/player/Forward.png", 50, 50);
        stopButton = UiTools.createButton("",
                "utils/images/Icons/player/Stop.png", 50, 50);

        playButton.addActionListener(playPauseFileListener);
        stopButton.addActionListener(stopFileListener);
        rewindButton.addActionListener(prevFileListener);
        forwardButton.addActionListener(nextFileListener);

        audioControl.add(Box.createRigidArea(new Dimension(30, 80)));
        audioControl.add(rewindButton);
        audioControl.add(playButton);
        audioControl.add(forwardButton);
        audioControl.add(stopButton);
        audioControl.add(createVolumeOptions());

        audioControl.setTransferHandler(controller.getTransferChanson());
        JtunesVue.DragAndDropListener drag = new JtunesVue.DragAndDropListener();
        audioControl.addMouseMotionListener(drag);

        audioControl.addMouseListener(drag);

        return audioControl;
    }
    ActionListener searchListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            try {
                searchField.requestFocus();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
    ActionListener browseDirListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            JFileChooser choix = new JFileChooser();

            choix.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

            int retour = choix.showOpenDialog(new JFrame());
            if (retour == JFileChooser.APPROVE_OPTION) {

                String directoryPath = choix.getSelectedFile().getAbsolutePath();// chemin absolu du dossier choisi
                File directory = new File(directoryPath);

                if (!directory.exists()) {
                    System.out.println("Le fichier/répertoire '" + directoryPath + "' n'existe pas");
                } else if (!directory.isDirectory()) {
                    System.out.println("Le chemin '" + directoryPath + "' correspond à un fichier et non à un répertoire");
                } else {
                    File[] subfiles = directory.listFiles();
                    for (int i = 0; i < subfiles.length; i++) {

                        if (subfiles[i].getName().toLowerCase().endsWith("mp3")) {
                            if (model.getTablePlayList().getThePlayList().isEmpty()) {
                                controller.createNewPlayListFile();
                                model.setListJTable(model.getDefaultPlayList());
                                model.setThePlayList();

                            }

                            controller.addFileInTableData(UiTools
                                    .getFilePlayerOfFile(subfiles[i].getPath()),
                                    subfiles[i].getPath());

                            model.setNbTrackInCurrentPlayList(model.getTableData().getFilesList().size());
                            String stringMorceaux = (model.getNbTrackInCurrentPlayList() > 1) ? " morceaux" : " morceau";
                            getStatus().setText(model.getNbTrackInCurrentPlayList() + stringMorceaux);
                        }

                    }
                }

            }
        }
    };
    ActionListener browseFileListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            JFileChooser fileChooser = new JFileChooser();
            FiltreFileChooserMp3 mp3 = new FiltreFileChooserMp3("Fichiers Mp3", ".mp3");
            fileChooser.addChoosableFileFilter(mp3);
            fileChooser.setMultiSelectionEnabled(true);


            int returnValue = fileChooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File[] selectedFile = fileChooser.getSelectedFiles();

                try {
                    for (i = 0; i < selectedFile.length; i++) {
                        if (selectedFile[i].getName().toLowerCase().endsWith("mp3")) {
                            if (model.getTablePlayList().getThePlayList().isEmpty()) {
                                controller.createNewPlayListFile();
                                model.setListJTable(model.getDefaultPlayList());
                                model.setThePlayList();

                            }

                            controller.addFileInTableData(UiTools
                                    .getFilePlayerOfFile(selectedFile[i].getPath()),
                                    selectedFile[i].getPath());

                            model.setNbTrackInCurrentPlayList(model.getTableData().getFilesList().size());
                            String stringMorceaux = (model.getNbTrackInCurrentPlayList() > 1) ? " morceaux" : " morceau";
                            getStatus().setText(model.getNbTrackInCurrentPlayList() + stringMorceaux);
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    };
    ActionListener playPauseFileListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            try {
                controller.playPauseFile(model.getCurentList(),
                        controller.getFilePlayerSelected());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
    ActionListener nextFileListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            try {
                controller.stopFile();
                controller.playPauseFile(model.getCurentList(),
                        controller.getNextFilePlayer());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
    ActionListener prevFileListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            try {
                controller.stopFile();
                controller.playPauseFile(model.getCurentList(),
                        controller.getPreviousFilePlayer());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
    ActionListener stopFileListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            try {
                controller.stopFile();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
    ActionListener randomPlayListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            try {
                if (model.israndomPlayMode()) {
                    controller.randomPlayOff();
                    System.out.println("random OFF");
                } else {
                    controller.randomPlayOn();
                    System.out.println("random ON");
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
    ActionListener repeatPlayListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            try {
                if (model.isRepeatMode()) {
                    controller.repeatModeOff();
                    System.out.println("repeat OFF");
                } else {
                    controller.repeatModeOn();
                    System.out.println("repeat ON");
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
    ActionListener newPlayListener = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            try {
                controller.createNewPlayListFile();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
    ChangeListener volumeListener = new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
            try {
                float oldValue = (new Float(getVolumeSlider().getValue()) / new Float(
                        getVolumeSlider().getMaximum()));

                if (!getVolumeSlider().getValueIsAdjusting()) {
                    model.setVolume(oldValue);
                }

                if (getVolumeSlider().getValue() == 40) {
                    volumeUpButton
                            .setIcon(new ImageIcon(
                            ClassLoader
                            .getSystemResource("utils/images/Icons/player/volume_muted.png")));
                } else if ((getVolumeSlider().getValue() >= 41 && getVolumeSlider()
                        .getValue() <= 60)) {
                    volumeUpButton
                            .setIcon(new ImageIcon(
                            ClassLoader
                            .getSystemResource("utils/images/Icons/player/volume_low.png")));
                } else if ((getVolumeSlider().getValue() > 60 && getVolumeSlider()
                        .getValue() <= 80)) {
                    volumeUpButton
                            .setIcon(new ImageIcon(
                            ClassLoader
                            .getSystemResource("utils/images/Icons/player/volume_medium.png")));
                } else if (getVolumeSlider().getValue() > 80) {
                    volumeUpButton
                            .setIcon(new ImageIcon(
                            ClassLoader
                            .getSystemResource("utils/images/Icons/player/volume_high.png")));
                }
                volumeUpButton.updateUI();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
    ChangeListener currentTrackListener = new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
            try {
                int oldValue = getCurrentTrackSlider().getValue();
                controller.setPosition(oldValue);
                // System.out.println(model.getPosition());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
    /**
     * *--------------------------- Listeners End -----------------**
     */
    MouseAdapter TableClickListener = new MouseAdapter() {
        public void mouseClicked(MouseEvent e) {
            if (e.getClickCount() == 2) {
                controller.stopFile();
                controller.playPauseFile(model.getCurentList(),
                        controller.getFilePlayerSelected());
            }
        }
    };
    /**
     * *
     * Evenement se produit dés la sélection change dans le playlist.
     */
    MouseAdapter PlayListTableClickListener = new MouseAdapter() {
        public void mouseClicked(MouseEvent e) {

            if (e.getClickCount() == 1) {
                model.setCurentList(controller.getPlayListSelected().getAbsolutePath());
                model.getTableData().getFilesList().clear();
                model.getTableData().setFilePlayerOfList(model.getCurentList());
                model.getTableData().fireTableDataChanged();
            }
            model.setNbTrackInCurrentPlayList(model.getTableData().getFilesList().size());
            String stringMorceaux = (model.getNbTrackInCurrentPlayList() > 1) ? " morceaux" : " morceau";
            getStatus().setText(model.getNbTrackInCurrentPlayList() + stringMorceaux);

        }
    };
    /**
     * *
     * Evenement pour la suppression d'une playList
     */
    KeyAdapter deletePlayListListener = new KeyAdapter() {
        public void keyPressed(KeyEvent e) {

            int key = e.getKeyCode();

            if (e.getSource().equals(playListTable) && key == KeyEvent.VK_DELETE) {
                controller.deletePlayListFile();
            }
        }
    };
    /**
     * *
     * Evenement pour la suppression du morceau .
     */
    KeyAdapter deleteFilePlayerListener = new KeyAdapter() {
        public void keyPressed(KeyEvent e) {

            int key = e.getKeyCode();

            if (e.getSource().equals(fileTable) && key == KeyEvent.VK_DELETE) {
                controller.deleteFilePlayer();
            }
        }
    };

    public JPanel createWestPanel() {

        WestPanel.setLayout(new BoxLayout(WestPanel, BoxLayout.Y_AXIS));
        WestPanel.setPreferredSize(new Dimension(250, 200));
        WestPanel.setBackground(new Color(230, 230, 230));

        playListTable = new MyJTable(model.getTablePlayList());
        playListTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        playListTable.setDefaultRenderer(Object.class,
                new CustomPlayListTableCellRenderer());

        playListTable.addMouseListener(PlayListTableClickListener);
        playListTable.addKeyListener(deletePlayListListener);

        playListsorter = new TableRowSorter<TableModel>(
                playListTable.getModel());
        playListTable.setRowSorter(playListsorter);


        playListTable.setDragEnabled(true);
        playListTable.setDropMode(DropMode.INSERT);
        playListTable.setTransferHandler(this.controller.getTransferList());

        JPanel LibraryPanel = new JPanel();
        LibraryPanel.setMaximumSize(new Dimension(500, 30));

        WestPanel.add(new JScrollPane(playListTable));

        return WestPanel;
    }

    public class DragAndDropListener extends MouseAdapter {

        private MouseEvent firstMoveEvent = null;

        public void mousePressed(MouseEvent e) {
            this.firstMoveEvent = e;
            e.consume();

        }

        public void mouseDragged(MouseEvent e) {
            if (this.firstMoveEvent != null) {
                e.consume();
                JComponent panel = (JComponent) e.getSource();
                panel.getTransferHandler().exportAsDrag(panel,
                        this.firstMoveEvent, TransferHandler.COPY);

                this.firstMoveEvent = null;
            }
        }
    }

    @Override
    public void update(Observable obs, Object o) {
        int duration = this.model.getDuration();
        int valMaxSlider = getCurrentTrackSlider().getMaximum();
        int newPos = this.model.getPosition() / (duration / valMaxSlider);
        this.getCurrentTrackSlider().setValue(newPos);

        this.getCurrentTrackDuration().setText(
                this.model.getStringDuration(this.model.getCurrentDuration()));

        if (this.model.getCurrentDuration() > this.model.getPlayer()
                .getDuration()) {
            controller.stopFile();
            controller.playPauseFile(model.getCurentList(),
                    controller.getNextFilePlayer());
        }

    }
}
