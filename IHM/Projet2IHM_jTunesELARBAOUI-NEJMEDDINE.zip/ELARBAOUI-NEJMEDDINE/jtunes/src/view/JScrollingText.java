package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Timer;
import java.util.TimerTask;

public class JScrollingText extends JLabel {

    /**
     * *
     * @author NEJMEDDINE & EL ARBAOUI
     */
    private static final long serialVersionUID = 1L;
    private String textToDisplay;
    private int speed;
    private int period;
    private int offset;
    private int x;
    private Timer timer;

    public JScrollingText(String text) {
        this(text, 1);
    }

    public JScrollingText(String text, int speed) {
        this(text, speed, 100);
    }

    public JScrollingText(String text, int speed, int period) {
        this(text, speed, period, 0);
    }

    public JScrollingText(String text, int speed, int period, int offset) {
        super(text);
        this.textToDisplay = text;
        this.speed = speed;
        this.period = period;
        this.offset = offset;
    }

    public void setTextToDisplay(String textToDisplay) {
        this.textToDisplay = textToDisplay;
    }

    public String getTextToDisplay() {
        return this.textToDisplay;
    }

    public void paintComponent(Graphics g) {
        if (isOpaque()) {
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
        }
        g.setColor(getForeground());

        FontMetrics fm = g.getFontMetrics();
        Insets insets = getInsets();

        int width = fm.stringWidth(getText()) - (insets.left + insets.right);
        int height = getHeight() - (insets.top + insets.bottom);

        int textWidth = fm.stringWidth(getText());
        if (width < textWidth) {
            width = textWidth + offset;
        }
        x %= width;

        int textX = insets.left + x;
        int textY = insets.top + (height - fm.getHeight()) / 2 + fm.getAscent();

        g.drawString(getText(), textX, textY);
        g.drawString(getText(), textX + (speed > 0 ? -width : width),
                textY);
    }

    public Timer getTimer() {
        return this.timer;
    }

    public void start() {
        timer = new Timer();
        TimerTask task = new TimerTask() {
            public void run() {
                x += speed;
                repaint();
            }
        };
        timer.scheduleAtFixedRate(task, 5000, period);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        JButton quit = new JButton("Quitter");
        quit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        frame.getContentPane().add(quit);
        JScrollingText scrollingText1 = new JScrollingText(
                "Barre des tâches... Pressez le bouton Quitter", -1);
        scrollingText1.setBorder(BorderFactory.createEtchedBorder());
        scrollingText1.start();
        scrollingText1.setTextToDisplay("oki doki");
        frame.getContentPane().add(scrollingText1, BorderLayout.NORTH);
        JScrollingText scrollingText2 = new JScrollingText(
                "Barre des tâches... Pressez le bouton Quitter");
        scrollingText2.setBorder(BorderFactory.createEtchedBorder());
        scrollingText2.start();
        scrollingText2.setBackground(Color.YELLOW);
        scrollingText2.setOpaque(true);
        frame.getContentPane().add(scrollingText2, BorderLayout.SOUTH);
        frame.setVisible(true);
    }
}