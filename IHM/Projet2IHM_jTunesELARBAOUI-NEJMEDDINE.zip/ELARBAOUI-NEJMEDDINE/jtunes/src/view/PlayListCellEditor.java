package view;

import java.awt.Component;
import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;

/***
 * 
 * @author NEJMEDDINE & EL ARBAOUI
 */

public class PlayListCellEditor extends DefaultCellEditor {

    private static final long serialVersionUID = 3906661204577632795L;
    private final static JTextField tf = new JTextField();

    public PlayListCellEditor() {
        super(tf);
        setClickCountToStart(2);
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
            boolean isSelected, int row, int column) {
        tf.setText(value.toString());
        return tf;
    }

    public Object getCellEditorValue() {
        return tf.getText();
    }
}