package view;

import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

/**
 * *
 * Représente une JTable personnalisé qui contient une table d'un modèle.
 *
 * @author NEJMEDDINE & EL ARBAOUI
 *
 */
public class MyJTable extends JTable {

    
    private static final long serialVersionUID = 8250666339982577330L;
    /**
     * 
     * La table du modèle.
     */
    AbstractTableModel tabModel;

    public MyJTable(AbstractTableModel dm) {
        super(dm);
        this.tabModel = dm;

    }

    public AbstractTableModel getTableModel() {
        return this.tabModel;
    }
}