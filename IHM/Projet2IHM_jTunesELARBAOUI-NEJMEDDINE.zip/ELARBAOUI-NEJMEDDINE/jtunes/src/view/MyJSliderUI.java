package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import javax.swing.JComponent;
import javax.swing.JSlider;
import javax.swing.plaf.basic.BasicSliderUI;


/**
 * Classe représente notre JSliderUI personnalisé.
 * @author @author NEJMEDDINE & EL ARBAOUI
 *
 */
public class MyJSliderUI extends BasicSliderUI {

	private Color rangeColor = new Color(200, 185, 225);
	
	public MyJSliderUI(JSlider arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
    /**
	* Paints the slider. The selected thumb is always painted on top of the
	* other thumb.
	*/
	    @Override
	    public void paint(Graphics g, JComponent c) {
	        super.paint(g, c);

	        if(true) {
		        Rectangle knobBounds = thumbRect;
		        int w = knobBounds.width;
		        int h = knobBounds.height;
		        
		        // Create graphics copy.
		        Graphics2D g2d = (Graphics2D) g.create();

		        // Create default thumb shape.
		        Shape thumbShape = createThumbShape(w,h);

		        // Draw thumb.
		        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
		            RenderingHints.VALUE_ANTIALIAS_ON);
		        g2d.translate(knobBounds.x, knobBounds.y);
		        
		        g2d.setColor(Color.WHITE);
		        g2d.fill(thumbShape);

		        g2d.setColor(Color.LIGHT_GRAY);
		        g2d.draw(thumbShape);
		        
		        // Dispose graphics.
		        g2d.dispose();
	        }
	        

	    }
	
	    @Override
	    public void paintThumb(Graphics g) {
	        // Do nothing.
	    }
	    
	    private Shape createThumbShape(int width, int height) {
	        // Use circular shape.
	        Ellipse2D shape = new Ellipse2D.Double(0, height/4, width, height/2);
	        return shape;
	    }
	    
	    /**
	    * Paints the track.
	    */
	        @Override
	        public void paintTrack(Graphics g) {
	            // Draw track.
	            super.paintTrack(g);
	            
	            Rectangle trackBounds = trackRect;
	            
	            if (slider.getOrientation() == JSlider.HORIZONTAL) {
	                // Determine position of selected range by moving from the middle
	                // of one thumb to the other.
	                int lowerX = thumbRect.x + (thumbRect.width / 2);
	                
	                // Determine track position.
	                int cy = (trackBounds.height / 2) - 2;

	                // Save color and shift position.
	                Color oldColor = g.getColor();
	                g.translate(trackBounds.x, trackBounds.y + cy);
	                
	                // Draw selected range.
	                g.setColor(rangeColor);
	                for (int y = 0; y <= 3; y++) {
	                    g.drawLine(0, y, lowerX - trackBounds.x, y);
	                }

	                // Restore position and color.
	                g.translate(-trackBounds.x, -(trackBounds.y + cy));
	                g.setColor(oldColor);
	                
	            } else {
	                // Determine position of selected range by moving from the middle
	                // of one thumb to the other.
	                int lowerY = thumbRect.x + (thumbRect.width / 2);
	                
	                // Determine track position.
	                int cx = (trackBounds.width / 2) - 2;

	                // Save color and shift position.
	                Color oldColor = g.getColor();
	                g.translate(trackBounds.x + cx, trackBounds.y);

	                // Draw selected range.
	                g.setColor(rangeColor);
	                for (int x = 0; x <= 3; x++) {
	                    g.drawLine(0, lowerY - trackBounds.y, x, lowerY - trackBounds.y);
	                }
	                
	                // Restore position and color.
	                g.translate(-(trackBounds.x + cx), -trackBounds.y);
	                g.setColor(oldColor);
	            }
	        }


}