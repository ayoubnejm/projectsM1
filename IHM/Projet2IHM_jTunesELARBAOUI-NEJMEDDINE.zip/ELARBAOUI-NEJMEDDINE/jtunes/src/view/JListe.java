package view;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;

public class JListe extends JList {

    /**
     * *
     * @author NEJMEDDINE & EL ARBAOUI
     */
    private static final long serialVersionUID = -5783335995828666147L;

    JListe(DefaultListModel listModel) {
        super(listModel);
    }

    public void addUndoableEditListener(UndoableEditListener listener) {
        listenerList.add(UndoableEditListener.class, listener);
    }

    public void removeUndoableEditListener(UndoableEditListener listener) {
        listenerList.remove(UndoableEditListener.class, listener);
    }

    public void fireUndoableEditUpdate(UndoableEditEvent e) {
        Object[] listeners = listenerList.getListenerList();
        for (int i = listeners.length - 2; i >= 0; i -= 2) {
            if (listeners[i] == UndoableEditListener.class) {
                ((UndoableEditListener) listeners[i + 1]).undoableEditHappened(e);
            }
        }
        this.repaint();
    }
}