package view;

import java.awt.Cursor;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import org.farng.mp3.MP3File;
import org.farng.mp3.TagException;
import org.farng.mp3.id3.AbstractID3v1;
import org.farng.mp3.id3.AbstractID3v2;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import model.FilePlayer;

/**
 * *
 * Permet de : Récupérer les informations d'un fichier mp3 Charger les playlist
 * depuis des fichiers XML. Créer un bouton avec une image.
 *
 * @author NEJMEDDINE & EL ARBAOUI
 *
 */
public class UiTools {

    /**
     * *
     * Permet de créer un bouton avec un image.
     *
     * @param buttonName
     * @param imgUrl
     * @param w
     * @param h
     * @return
     */
    public static JButton createButton(String buttonName, String imgUrl, int w,
            int h) {
        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource(imgUrl));
        JButton jb = new JButton(buttonName, img);
        jb.setPreferredSize(new Dimension(w, h));
        jb.setOpaque(false);
        jb.setFocusPainted(false);
        jb.setBorderPainted(false);
        jb.setContentAreaFilled(false);
        Cursor c = new Cursor(Cursor.HAND_CURSOR);
        jb.setCursor(c);
        return jb;
    }

    /**
     * *
     * Récupère la liste des fichiers xml des listes de lecture disponible.
     *
     * @param dir
     * @return
     */
    public static List<File> getXmlFilesOfDir(File dir) {
        List<File> xmlList = new ArrayList<File>();
        try {
            File[] list = null;

            if (dir.isDirectory()) {
                list = dir.listFiles();
            }

            for (File f : list) {
                String fileName = f.getName().toLowerCase();
                if (fileName.endsWith(".xml")) {
                    xmlList.add(f);
                }
            }
        } catch (Exception e) {
        }

        return xmlList;
    }

    /**
     * *
     * Récupère l'Artist depuis le fichier mp3
     *
     * @param mp3file
     * @return
     */
    public static String getArtist(MP3File mp3file) {
        String title = "", artist = "", album = "", genre = "", year = "";

        if (mp3file.hasID3v1Tag()) {
            AbstractID3v1 tag = mp3file.getID3v1Tag();
            if (tag != null) {
                try {
                    artist = tag.getLeadArtist();
                } catch (Exception e) {
                }
            }
        } else if (mp3file.hasID3v2Tag()) {
            AbstractID3v2 tag = mp3file.getID3v2Tag();
            if (tag != null) {
                artist = tag.getFrame("TP1").toString();
            }
        }
        return artist;
    }

    /**
     * *
     * Récupère le titre depuis le fichier mp3
     *
     * @param mp3file
     * @return
     */
    public static String getTitle(MP3File mp3file) {
        String title = "";

        if (mp3file.hasID3v1Tag()) {
            AbstractID3v1 tag = mp3file.getID3v1Tag();
            if (tag != null) {
                try {
                    title = tag.getSongTitle();
                } catch (Exception e) {
                }
            }
        } else if (mp3file.hasID3v2Tag()) {
            AbstractID3v2 tag = mp3file.getID3v2Tag();
            if (tag != null) {
                title = tag.getFrame("TT2").toString();
            }
        }
        return title;
    }

    /**
     * **
     * Récupère l'album depuis le fichier mp3
     *
     * @param mp3file
     * @return
     */
    public static String getAlbum(MP3File mp3file) {
        String album = "";

        if (mp3file.hasID3v1Tag()) {
            AbstractID3v1 tag = mp3file.getID3v1Tag();
            if (tag != null) {
                try {
                    album = tag.getAlbumTitle();
                } catch (Exception e) {
                }
            }
        } else if (mp3file.hasID3v2Tag()) {
            AbstractID3v2 tag = mp3file.getID3v2Tag();
            if (tag != null) {
                album = tag.getFrame("TAL").toString();
            }
        }
        return album;
    }

    /**
     * **
     * Récupère le genre depuis le fichier mp3
     *
     * @param mp3file
     * @return
     */
    public static String getGenre(MP3File mp3file) {
        String genre = "";

        if (mp3file.hasID3v1Tag()) {
            AbstractID3v1 tag = mp3file.getID3v1Tag();
            if (tag != null) {
                try {
                   genre = tag.getSongGenre();
                } catch (Exception e) {
                }
            }
        } else if (mp3file.hasID3v2Tag()) {
            AbstractID3v2 tag = mp3file.getID3v2Tag();
            if (tag != null) {
                genre = tag.getFrame("TCO").toString();
            }
        }
        return genre;
    }

    /**
     * **
     * Récupère l'annee depuis le fichier mp3
     *
     * @param mp3file
     * @return
     */
    public static String getYear(MP3File mp3file) {
        String year = "";

        if (mp3file.hasID3v1Tag()) {
            AbstractID3v1 tag = mp3file.getID3v1Tag();
            if (tag != null) {
                try {
                    year = tag.getYearReleased();
                } catch (Exception e) {
                }
            }
        } else if (mp3file.hasID3v2Tag()) {
            AbstractID3v2 tag = mp3file.getID3v2Tag();
            if (tag != null) {
                year = tag.getFrame("TYE").toString();
            }
        }
        return year;
    }

    /**
     * *
     * Récupère le fichier audio depuis son chemin complet
     *
     * @param filename
     * @return
     */
    public static FilePlayer getFilePlayerOfFile(String filename) {
        File sourcefile = new File(filename);
        try {
            MP3File mp3file = new MP3File(sourcefile);
            String name = sourcefile.getName();

            return new FilePlayer(name, getTitle(mp3file), getArtist(mp3file),
                    getAlbum(mp3file), getGenre(mp3file), getYear(mp3file));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TagException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    public static ArrayList<FilePlayer> getFilePlayerOfList(String fileXml) {
        SAXBuilder sxb = new SAXBuilder();
        Document document = null;
        ArrayList<FilePlayer> lesFilePlayer = new ArrayList<FilePlayer>();
        try {
            // On crÃ©e un nouveau document JDOM avec en argument le fichier XML
            // Le parsing est terminÃ© ;)
            document = sxb.build(new File(fileXml));
            // On initialise un nouvel Ã©lÃ©ment racine avec l'Ã©lÃ©ment racine du
            // document.
            Element racine = document.getRootElement();

            // On crÃ©e une List contenant tous les noeuds "etudiant" de l'Element
            // racine
            List listChansons = racine.getChildren("music");

            // On crÃ©e un Iterator sur notre liste
            Iterator i = listChansons.iterator();
            while (i.hasNext()) {
                // On recrÃ©e l'Element courant Ã  chaque tour de boucle afin de
                // pouvoir utiliser les mÃ©thodes propres aux Element comme :
                // selectionner un noeud fils, modifier du texte, etc...
                Element courant = (Element) i.next();
                // On affiche le nom de l'element courant
                // System.out.println(courant.getText());

                File sourcefile = new File(courant.getText());
                FilePlayer fp = getFilePlayerOfFile(sourcefile.getAbsolutePath());
                if (fp != null) {
                    lesFilePlayer.add(fp);
                }


            }
        } catch (Exception e) {
        }

        return lesFilePlayer;

    }

    public static String getPathOfFilePlayer(FilePlayer fp, String pathXml) {
        SAXBuilder sxb = new SAXBuilder();
        Document document = null;
        try {
            // On crÃ©e un nouveau document JDOM avec en argument le fichier XML
            // Le parsing est terminÃ© ;)
            document = sxb.build(new File(pathXml));
        } catch (Exception e) {
        }


        // On initialise un nouvel Ã©lÃ©ment racine avec l'Ã©lÃ©ment racine du
        // document.
        Element racine = document.getRootElement();

        // On crÃ©e une List contenant tous les noeuds "music" de l'Element
        // racine
        List listChansons = racine.getChildren("music");
        ArrayList<FilePlayer> lesFilePlayer = new ArrayList<FilePlayer>();
        // On crÃ©e un Iterator sur notre liste
        Iterator i = listChansons.iterator();
        while (i.hasNext()) {
            // On recrré l'Element courant Ã  chaque tour de boucle afin de
            // pouvoir utiliser les mÃ©thodes propres aux Element comme :
            // selectionner un noeud fils, modifier du texte, etc...
            Element courant = (Element) i.next();
            // On affiche le nom de l'element courant
            // System.out.println(courant.getText());

            File sourcefile = new File(courant.getText());
            String filename = sourcefile.getName();
            try {
                MP3File mp3file = new MP3File(sourcefile);
                if (filename.equals(fp.getName()) & getArtist(mp3file).equals(fp.getArtist())
                        && getAlbum(mp3file).equals(fp.getAlbum())
                        && getTitle(mp3file).equals(fp.getTitle())) {
                    return courant.getText();
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (TagException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return "";
    }
}