package view;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;

public class CustomTableCellRenderer extends DefaultTableCellRenderer {

    /**
     * *
     * @author NEJMEDDINE & EL ARBAOUI
     */
    private static final long serialVersionUID = 1L;

    public Component getTableCellRendererComponent(JTable table, Object obj,
            boolean isSelected, boolean hasFocus, int row, int column) {
        Component cell = super.getTableCellRendererComponent(table, obj,
                isSelected, hasFocus, row, column);
        if (isSelected) {
            cell.setBackground(new Color(142, 185, 225));
        } else {
            if (row % 2 == 0) {
                cell.setBackground(Color.WHITE);
            } else {
                cell.setBackground(new Color(230, 230, 230));
            }
        }

        TableColumn Tcolumn = null;
        for (int i = 0; i < 5; i++) {
            Tcolumn = table.getColumnModel().getColumn(i);
            if (i == 0 || i == 1 || i == 2) {
                Tcolumn.setPreferredWidth(120);
            } else if (i == 3) {
                Tcolumn.setMinWidth(50);
                Tcolumn.setMaxWidth(100);
            } else {
                Tcolumn.setMinWidth(50);
                Tcolumn.setMaxWidth(100);
            }
        }

        return cell;
    }
}