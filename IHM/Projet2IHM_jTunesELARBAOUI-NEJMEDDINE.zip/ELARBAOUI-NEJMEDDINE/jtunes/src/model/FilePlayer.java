package model;

/****
 * Représtente un fichier audio.
 * 
 * @author NEJMEDDINE & EL ARBAOUI
 * 
 */
public class FilePlayer {

	private String name;
	private String title;
	private String artist;
	private String album;
	private String genre;
	private String year;

	/***
	 * 
	 * @param Name
	 * @param title
	 * @param artist
	 * @param album
	 * @param genre
	 * @param year
	 */
	public FilePlayer(String Name, String title, String artist, String album,
			String genre, String year) {
		this.name = Name;
		this.title = title;
		this.artist = artist;
		this.album = album;
		this.genre = genre;
		this.year = year;

	}

	/***
	 * Permet de récupérer le nom.
	 * 
	 * @return
	 */

	public String getName() {
		return name;
	}

	/***
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/***
	 * 
	 * @return
	 */
	public String getArtist() {
		return artist;
	}

	/***
	 * 
	 * @return
	 */
	public String getAlbum() {
		return album;
	}

	/***
	 * 
	 * @return
	 */
	public String getGenre() {
		return genre;
	}

	/***
	 * 
	 * @return
	 */
	public String getYear() {
		return year;
	}

	/***
	 * 
	 * @param type
	 * @return
	 */
	public String getInformation(String type) {
		if (type == "Artiste")
			return artist;
		else if (type == "Titre")
			return title;
		else if (type == "Album")
			return album;
		else if (type == "Annee")
			return year;
		else if (type == "Nom")
			return name;

		if (type == "Genre")
			return genre;

		return title + artist + album + genre + year;
	}

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof FilePlayer))
			return false;
		FilePlayer fp = (FilePlayer) o;

		return (fp.getTitle().equals(this.getTitle()))
				&& (fp.getArtist().equals(this.getArtist()))
				&& (fp.getAlbum().equals(this.getAlbum()))
				&& (fp.getYear().equals(this.getYear())
						&& (fp.getGenre().equals(this.getGenre())) && (fp
							.getName().equals(this.getName())));

	}

}