package model;

import javax.swing.event.UndoableEditEvent;
import javax.swing.undo.UndoManager;

import controller.JtunesController;



/***
 * UnDo Manager pour notre controlleur.
 * @author NEJMEDDINE & EL ARBAOUI
 *
 */
public class MyManager extends UndoManager {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JtunesController controller;
	public MyManager(JtunesController controller){
		super();
		this.controller = controller;
	}

	public void undoableEditHappened(UndoableEditEvent event) {
		super.undoableEditHappened(event);

	}
	
	
}