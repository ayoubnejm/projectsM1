package model;

import javax.swing.DefaultListModel;
import javax.swing.JPanel;
import javax.swing.undo.AbstractUndoableEdit;

/**
 * *
 *
 * @author NEJMEDDINE & EL ARBAOUI
 */
public class UndoableDelete extends AbstractUndoableEdit {

    private int index;
    protected String item;
    private DefaultListModel listModel;
    private JPanel colorPreview;

    public UndoableDelete(DefaultListModel dlm, String s, int i) {
        listModel = dlm;
        item = s;
        index = i;
    }

    public void undo() {
        super.undo();
        listModel.add(index, item);
    }

    public void redo() {
        super.redo();
        listModel.remove(this.index);
    }

    public String getPresentationName() {
        return this.getPresentationName();
    }
}