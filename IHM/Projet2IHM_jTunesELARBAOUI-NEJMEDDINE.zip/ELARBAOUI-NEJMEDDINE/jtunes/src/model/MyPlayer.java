package model;

import javazoom.jl.decoder.Equalizer;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.LillePlayer;

/***
 * Notre lecteur mp3, Utilise LillePlayer fournit dans le TP.
 * 
 * @author NEJMEDDINE & EL ARBAOUI
 * 
 */
public class MyPlayer {
	private LillePlayer player;
	private String currentPath;

	private int state; // 0:stop, 1:load, 2:play 3:pause
	private float volume = (float) 0.87;
	private int position = 0;
	private JtunesModel model;

	public void setJtunesModel(JtunesModel model) {
		this.model = model;
	}

	public MyPlayer() {
		player = null;
		currentPath = "";
		state = 0;
	}

	public int getState() {
		return this.state;
	}

	public void Load(String path) {
		if (state != 0)
			Stop();

		try {
			currentPath = path;
			player = new LillePlayer(currentPath);
			player.setVolume(volume);
			Equalizer eq = new Equalizer();
			eq.getBand(0);
			state = 1;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void PlayPause() {
		if (state == 0) {
			Load(currentPath);
			PlayPause();
		} else if (state == 1) {
			LaunchListenThread llt = new LaunchListenThread(player);
			llt.start();
			state = 2;
		} else if (state == 2) {
			player.pause();
			state = 3;
		} else if (state == 3) {
			player.pause();
			state = 2;
		}
	}

	public void Stop() {
		if (state == 1 || state == 2 || state == 3) {
			player.close();
			state = 0;
		}
	}

	public float getVolume() {
		return volume;
	}

	public void setVolume(float level) {
		volume = level;
		player.setVolume(level);
	}

	public int getDuration() {
		if (player == null)
			return 0;
		return player.getDuration();
	}

	/***
	 * Permet de retourner le lecteur LillePlayer.
	 * 
	 * @return LillePlayer
	 */
	public LillePlayer getMediaPlayer() {
		return player;
	}

	/***
	 * Permet de récuperer le position de lecture en cours.
	 * 
	 * @return
	 */
	public int getPosition() {
		return position;
	}

	public void setPosition(int pos) {
		player.setPosition(pos);
		position = pos;
	}

	class LaunchListenThread extends Thread {
		private LillePlayer playerInterne;

		public LaunchListenThread(LillePlayer p) {
			playerInterne = p;
		}

		public void run() {
			try {
				System.out.println("LaunchEvent");
				PlayThread pt = new PlayThread();
				pt.start();

				while (!playerInterne.isComplete()) {
					position = playerInterne.getPosition();

					if (player == playerInterne) {

						model.setPosition(position);
						model.setCurrentDuration(position);
					}
					try {
						Thread.sleep(200);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

				if (player == playerInterne) {
					System.out.println("EndEvent");
					model.setPosition(position);
					model.setCurrentDuration(position);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		class PlayThread extends Thread {
			public void run() {
				try {
					playerInterne.play();
				} catch (JavaLayerException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void main(String[] args) {
		if (args.length == 0) {
			System.out.println("Usage: MP3Player <filename>");
			System.exit(0);
		}

		MyPlayer myPlayer = new MyPlayer();
		myPlayer.Load(args[0]);
		myPlayer.PlayPause();

	}
}