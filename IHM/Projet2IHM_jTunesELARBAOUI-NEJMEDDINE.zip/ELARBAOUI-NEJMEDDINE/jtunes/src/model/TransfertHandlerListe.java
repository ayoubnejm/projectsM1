package model;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.TransferHandler;
import javax.swing.table.AbstractTableModel;
import controller.JtunesController;
import view.MyJTable;

/**
 * TransfertHandler pour une JListe
 *
 * @author NEJMEDDINE & EL ARBAOUI
 */
public class TransfertHandlerListe extends TransferHandler {

    /**
     * Serial
     */
    private static final long serialVersionUID = 1003585100042286989L;
    /**
     * Index de l element insere
     */
    int insertedindex = 0;
    /**
     * Index de l element selectionne
     */
    int selectedindex = 0;
    /**
     * Source
     */
    private JComponent sourceList;
    private JtunesController controller;

    /**
     * Constructeur
     */
    public TransfertHandlerListe(JtunesController controller) {
        this.controller = controller;
    }

    /**
     * Permet de connaitre la source du drag
     *
     * @param c le JComponent source
     * @return le numero de l action
     */
    public int getSourceActions(JComponent c) {

        return TransferHandler.COPY_OR_MOVE;
    }

    /**
     * Permet de creer un transferable pour le transfert
     *
     * @param c le JComponent
     * @return un Transferable
     */
    public Transferable createTransferable(JComponent c) {
        AbstractTableModel tableModel = (AbstractTableModel) ((JTable) c)
                .getModel();
        selectedindex = ((JTable) c).getSelectedRow();
        return new StringSelection((String) tableModel.getValueAt(
                selectedindex, 0));

    }

    /**
     * Methode de fin d export
     *
     * @param c le JComponent
     * @param t le Transferable
     * @param action l action associe
     */
    public void exportDone(JComponent c, Transferable t, int action) {
        // Nothing
    }

    /**
     * Permet de savoir si on peut effectuer le drag
     *
     * @param info le TransferSupport
     * @param true s il est supporte
     */
    public boolean canImport(TransferHandler.TransferSupport info) {

        // Pour ne gerer que le drop et pas le paste
        if (!info.isDrop()) {
            return false;
        }

        if (!info.isDataFlavorSupported(DataFlavor.stringFlavor)) {
            return false;
        }

        // On recherche l'emplacement du drop
        MyJTable.DropLocation dl = (MyJTable.DropLocation) info
                .getDropLocation();

        // On ne supporte que les emplacements de drop valides
        return dl.getDropPoint() != null;

    }

    /**
     * Permet d effectuer le transfert
     *
     * @param info le TransferSupport
     * @return true s il l import se passe bien
     */
    public boolean importData(TransferHandler.TransferSupport info) {

        if (!info.isDrop()) {
            return false;
        }

        Transferable t = info.getTransferable();



        // Verifie qu'on a une String flavor
        if (!info.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
            return false;
        }

        // On recherche l'emplacement du drop
        MyJTable.DropLocation dl = (MyJTable.DropLocation) info
                .getDropLocation();

        int d = dl.getRow();
        MyJTable jtab = (MyJTable) info.getComponent();
        String s = String.valueOf(jtab.getValueAt(d, 0));
        String str = "";

        try {

            String filename = "";
            List files = (List) (t.getTransferData(DataFlavor.javaFileListFlavor));
            for (int i = 0; i < files.size(); i++) {
                str = (((File) files.get(i))).getAbsolutePath();
                System.out.println(str + " en " + s);
                xmlFile.XmlFile.addElement("Playlists/" + s + ".xml", str);

            }

        } catch (UnsupportedFlavorException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }




        return true;
    }
}