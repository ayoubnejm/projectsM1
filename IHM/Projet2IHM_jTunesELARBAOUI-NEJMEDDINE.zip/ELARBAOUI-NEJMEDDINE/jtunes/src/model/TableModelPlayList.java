package model;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import view.UiTools;
/***
 * 
 * @author NEJMEDDINE & EL ARBAOUI
 */
public class TableModelPlayList extends AbstractTableModel {

    private static final long serialVersionUID = 1L;
    private static List<File> playList = new ArrayList<File>();
    private final String[] entetes = {"PlayList"};

    public TableModelPlayList() {
        super();
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        if (aValue != null && aValue != "") {
            File f = playList.get(rowIndex);
            switch (columnIndex) {
                case 0:
                    File newFile = new File("Playlists/" + (String) aValue + ".xml");
                    if (!newFile.getName().equals(".xml") && !playList.contains(newFile)) {
                        f.renameTo(newFile);
                        playList.set(rowIndex, newFile);
                        fireTableCellUpdated(rowIndex, columnIndex);
                    }
                    break;
            }
        }
    }

    public Class getColumnClass(int columnIndex) {
        switch (columnIndex) {
            default:
                return Object.class;
        }
    }

    public void setPlayListOfDir(File f) {
        for (File pl : UiTools.getXmlFilesOfDir(f)) {
            playList.add(pl);
        }
        fireTableDataChanged();
    }

    public int getRowCount() {
        return playList.size();
    }

    public int getColumnCount() {
        return entetes.length;
    }

    public String getColumnName(int columnIndex) {
        return entetes[columnIndex];
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return playList.get(rowIndex).getName().substring(0, playList.get(rowIndex).getName().length() - 4);
            default:
                return null; //Ne devrait jamais arriver
        }
    }

    public void addPlayList(File f) {
        playList.add(f);
        fireTableRowsInserted(playList.size() - 1, playList.size() - 1);
    }

    public void removePlayList(int rowIndex) {
        playList.remove(rowIndex);
        fireTableRowsDeleted(rowIndex, rowIndex);
    }

    public File getPlayList(int rowIndex) {
        return this.playList.get(rowIndex);
    }

    public static void clear() {
        playList.clear();
    }

    public List<File> getThePlayList() {
        return this.playList;
    }

    public void setThePlayList(List<File> pl) {
        this.playList = pl;
    }
}