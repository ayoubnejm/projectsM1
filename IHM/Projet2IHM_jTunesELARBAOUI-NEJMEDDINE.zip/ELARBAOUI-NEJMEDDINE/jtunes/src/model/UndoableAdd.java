package model;

import javax.swing.DefaultListModel;
import javax.swing.undo.AbstractUndoableEdit;

public class UndoableAdd extends AbstractUndoableEdit {

    /**
     * *
     * @author NEJMEDDINE & EL ARBAOUI
     */
    private static final long serialVersionUID = 1L;
    protected String item;
    private int index;
    private DefaultListModel listModel;

    public UndoableAdd(DefaultListModel dlm, String s, int i) {
        listModel = dlm;
        item = s;
        index = i;
    }

    public void undo() {
        super.undo();
        listModel.remove(this.index);
    }

    public void redo() {
        super.redo();
        listModel.add(index, item);

    }
}