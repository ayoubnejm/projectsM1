package model;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import view.UiTools;


/***
 *  Classe permet de représenter les fichiers audio sous forme d'un tableau.
 * @author NEJMEDDINE & EL ARBAOUI
 *
 */
public class TableModelPlayerFile extends AbstractTableModel {

	private static final long serialVersionUID = 1L;

	/***
	 * Les fichiers disponibles.
	 */
	private final static List<FilePlayer> files = new ArrayList<FilePlayer>();

	/***
	 * Entêtes de la table contenant les fichiers.
	 */
	private final String[] entetes = { "Nom","Titre", "Artiste", "Album", "Genre",
			"Annee" };

	public TableModelPlayerFile() {
		super();
	}

	/***
	 * Chargement des morceaux depuis un fichire xml.
	 * @param pathXml
	 */
	public void setFilePlayerOfList(String pathXml) {
		try {
			for (FilePlayer fp : UiTools.getFilePlayerOfList(pathXml)) {
				files.add(fp);
			}
		} catch (Exception e) {
		}
		fireTableDataChanged();
	}

	/***
	 * Récupère le nombre de fichiers disponibles.
	 */
	public int getRowCount() {
		return files.size();
	}

	/***
	 * Récupère la nombre des colonnes de la Jtable pour la visualisation des fichiers audio.
	 * 
	 */
	public int getColumnCount() {
		return entetes.length;
	}

	/***
	 * Récupère le nom d'une colonnes grâce à son index.
	 */
	public String getColumnName(int columnIndex) {
		return entetes[columnIndex];
	}

	/***
	 * Permet de récupèrer la valeur d'un case dans le JTable (nom, titre, artiste, album, genre)
	 */
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0 : return files.get(rowIndex).getName();
		case 1:
			return files.get(rowIndex).getTitle();
		case 2:
			return files.get(rowIndex).getArtist();
		case 3:
			return files.get(rowIndex).getAlbum();
		case 4:
			return files.get(rowIndex).getGenre();
		case 5:
			return files.get(rowIndex).getYear();
		default:
			return null; // Ne devrait jamais arriver
		}
	}

	/***
	 * Permet d'ajouter une ligne à la Jtable.
	 * @param file : la ligne.
	 */
	public void addFile(FilePlayer file) {
		files.add(file);
		fireTableRowsInserted(files.size() - 1, files.size() - 1);
	}

	/***
	 * Permet de retirer une ligne depuis la JTable.
	 * @param rowIndex
	 */
	public void removeFile(int rowIndex) {
		files.remove(rowIndex);
		fireTableRowsDeleted(rowIndex, rowIndex);
	}

	/***
	 * Permet de récupèrer le fichier représenté par la ligne d'index "index".
	 * @param rowIndex
	 * @return
	 */
	public FilePlayer getFilePlayer(int rowIndex) {
		return this.files.get(rowIndex);
	}

	/***
	 * Permet de vider la jTable.
	 */
	public static void clear() {
		files.clear();
	}

	/***
	 * Permet de récupèrer la liste des fichiers disponibles dans la jtable.
	 * @return liste des fichiers audio.
	 */
	public List<FilePlayer> getFilesList() {
		return this.files;
	}

}