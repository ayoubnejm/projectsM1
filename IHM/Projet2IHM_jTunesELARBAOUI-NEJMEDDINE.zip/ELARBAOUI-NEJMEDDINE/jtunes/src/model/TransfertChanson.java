package model;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.TransferHandler;
import controller.JtunesController;
import view.MyJTable;
import view.UiTools;
import java.io.File;
import java.util.List;

/**
 * Permet le transfert les path des chansons
 *
 * @author NEJMEDDINE & EL ARBAOUI
 */
@SuppressWarnings("serial")
public class TransfertChanson extends TransferHandler {

    private JtunesController controller;

    public TransfertChanson(JtunesController controller) {
        this.controller = controller;
    }

    public int getSourceActions(JComponent c) {
        return TransferHandler.COPY_OR_MOVE;
    }

    protected Transferable createTransferable(JComponent c) {

        MyJTable t = (MyJTable) c;
        String path = UiTools.getPathOfFilePlayer(
                controller.getFilePlayerSelected(), controller.getCurentList());
        return new StringSelection(path);
    }

    public boolean canImport(TransferHandler.TransferSupport info) {

        // Pour ne gerer que le drop et pas le paste
        if (!info.isDrop()) {
            return false;
        }

        // On ne supporte que les chaines en entrée
        if (info.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
            return true;
        }
        if (info.isDataFlavorSupported(DataFlavor.stringFlavor)) {
            return true;
        }

        return true;
    }

    public boolean importData(TransferHandler.TransferSupport info) {
        // Si le drop n est pas effectue
        if (!info.isDrop()) {
            return false;
        }

        // Si le transfert est possible
        if (info.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
            try {

                // Transferable
                Transferable t = info.getTransferable();

                // pour le Jtable

                try {
                    String filename = "";
                    List files = (List) (t.getTransferData(DataFlavor.javaFileListFlavor));
                    for (int i = 0; i < files.size(); i++) {
                        filename = (((File) files.get(i))).getAbsolutePath();
                        if (!controller.getModel().getTableData().getFilesList().contains(UiTools.getFilePlayerOfFile(filename))) {
                            if (!filename.endsWith(".mp3")) {
                                return false;
                            }
                            MyJTable jtab = (MyJTable) info.getComponent();
                            FilePlayer f = UiTools.getFilePlayerOfFile(filename);
                            ((TableModelPlayerFile) jtab.getTableModel()).addFile(f);

                            xmlFile.XmlFile.addElement(this.controller.getCurentList(), filename);
                            System.out.println("entré drag table ok" + filename);

                        }
                    }
                    controller.getModel().setNbTrackInCurrentPlayList(
                            controller.getModel().getTableData().getFilesList().size());
                    String stringMorceaux = (controller.getModel()
                            .getNbTrackInCurrentPlayList() > 1) ? " morceaux": " morceau";
                    controller.getView().getStatus().setText(controller.getModel().getNbTrackInCurrentPlayList()+ stringMorceaux);

                } catch (Exception e) {
                    e.printStackTrace();
                }
                // pour le PanelAudio
                try {

                    String filename = "";
                    List files = (List) (t
                            .getTransferData(DataFlavor.javaFileListFlavor));
                    filename = (((File) files.get(0))).getAbsolutePath();
                    JPanel jp = (JPanel) info.getComponent();
                    System.out.println("entré drag lecteur boutton play ok");
                    FilePlayer fp = UiTools.getFilePlayerOfFile(filename);
                    xmlFile.XmlFile.addElement(this.controller.getCurentList(),
                            filename);
                    this.controller.stopFile();
                    this.controller.playPauseFile(
                            this.controller.getCurentList(),
                            UiTools.getFilePlayerOfFile(filename));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }
        return false;
    }
}