package model;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import javax.swing.TransferHandler;
import view.UiTools;

/***
 * Représente le modèle  JTunes
 * @author NEJMEDDINE & EL ARBAOUI
 *
 */
public class JtunesModel extends Observable {

	/***
	 * La table qui contient les fichiers audio
	 */
	private TableModelPlayerFile tableData = new TableModelPlayerFile();
	/***
	 * La table qui contient les playlist.
	 */
	private TableModelPlayList tablePlayList = new TableModelPlayList();
	/**
	 * Liste de lecture courante.
	 */
	private String curentList;
	/***
	 * Le lecteur audio.
	 */
	private MyPlayer player;
	/**
	 * Fichier audio en cours de lecture.
	 */
	private FilePlayer currentTrack;
	
	private TransfertChanson transferChanson;
	/***
	 * 
	 */
	private int currentDuration = 0;
	/***
	 * la lecture du morceau en cours de lecture est finie?
	 */
	private boolean isComplete = false;
	/***
	 * L'état d'activation du mode aléatoire.
	 */
	private boolean randomPlayMode = false;
	/***
	 * Le mode de répétition est activé.
	 */
	private boolean repeatMode = false;
	/***
	 * Listes des lecture disponibles. (fichiers xml)
	 */
	private List<File> xmlFileList = new ArrayList<File>();
	/**
	 * Le répertoire qui contient le liste de lecture 
	 */
	private static final String XML_PATH = "Playlists";
	
	/***
	 * Nombre des fichiers audio de la liste de lecture en cours.
	 */
	private int nbTrackInCurrentPlayList = 0;

	/***
	 * Constructeurs.
	 */
	public JtunesModel() {
		player = new MyPlayer();
		File f = new File(getXmlPath());
		f.mkdirs();
		setXmlFileList();
		printXmlFile();
		setListJTable(getDefaultPlayList());
		setThePlayList();
	}
	
	
	
	
	/***  - ----------- Methodes ---------------------- ****/
	/**
	 * Permet de récupèrer la liste de lecture par défaut.
	 * @return
	 */
	public String getDefaultPlayList() {
		String s = "";
		if (getXmlFileList().isEmpty()) 
		{
			return null;
		} 
		else 
		{
			s = getXmlFileList().get(0).getName();
		}
		System.out.println(s);
		return getXmlPath() + "/" + s;
	}

	/***
	 *  permet de récupèrer la liste de fichiers en cours. disponibles.
	 * @return
	 */
	public int countTableDataFiles() {
		int nb = tableData.getFilesList().size();
		return nb;
	}

	
	/*********************** TransfertChanson *************************/
	public TransferHandler getTransferChanson() {
		return this.transferChanson;
	}
	
	public void setTransferChanson(TransfertChanson tc) {
		this.transferChanson = tc;
	}

	/***
	 * Permet de savoir si  la lecture du fichier audio en cours a terminé.
	 * @return
	 */
	public boolean isComplete() {
		return this.isComplete;
	}

	/***
	 * Permet d'activer ou désactiver le mode aléatoire.
	 * @param randomPlayMode
	 */
	public void setRandomPlayMode(boolean randomPlayMode) {
		this.randomPlayMode = randomPlayMode;
	}

	/***
	 * Permet de savoir si le mode aléatoire est activé/ désactivé.
	 * @return
	 */
	public boolean israndomPlayMode() {
		return this.randomPlayMode;
	}

	public void setComplete(boolean complete) {
		this.isComplete = complete;
		setChanged();
		notifyObservers();
	}

	/***
	 * permet de récupèrer le lecteur audio.
	 * @return
	 */
	public MyPlayer getPlayer() {
		return this.player;
	}

	/***
	 * Permet de récupèrer la position du lecteur dans la lecture du fichier en
	 * @return
	 */
	public int getDuration() {
		return this.player.getDuration();
	}

	public int getCurrentDuration() {
		return this.currentDuration;
	}

	/***
	 * Permet de changer la position de lecture.
	 * @param duration
	 */
	public void setCurrentDuration(int duration) {
		this.currentDuration = duration;
		setChanged();
		notifyObservers();
	}

	/***
	 * Permet récupèrer la position de lecture sous forme une durée hh:mm:ss
	 * @param duration
	 * @return
	 */
	public String getStringDuration(int duration){
		int mseconds = duration;
		int seconds = (mseconds / 1000);
		int minutes = (seconds / 60);
		int heures = (minutes / 60);

		seconds -= (minutes * 60);
		minutes -= (heures * 60);
		
        String h = (String.valueOf(heures).length()==1)?"0"+heures:heures+"";
        String m = (String.valueOf(minutes).length()==1)?"0"+minutes:minutes+"";
        String s = (String.valueOf(seconds).length()==1)?"0"+seconds:seconds+"";
        return h+":"+m+":"+s;
    }
	


	/**
	 * permet de réupérer le volume 
	 * @return
	 */
	public float getVolume() {
		return this.getPlayer().getVolume();
	}

	/**
	 * Permet de récupèrer la liste de lecture en cours.
	 * @return
	 */
	public String getCurentList() {
		return this.curentList;
	}

	/***
	 * permet de changer la liste de lecture en cours.
	 * @param c
	 */
	public void setCurentList(String c) {
		this.curentList = c;
	}

	/***
	 * Permet de charger la table des fichiers audio et changer le playlist en cours de lecture.
	 * @param pathXml
	 */
	public void setListJTable(String pathXml) {
		this.curentList = pathXml;
		tableData.setFilePlayerOfList(this.curentList);
	}
	
	
/***
 * Permet de charger la table des fichiers audio.
 * @param path
 */
	public void setListOnJTable(String path) {
		tableData.setFilePlayerOfList(path);
	}

	/***
	 * permet de changer le volume
	 * @param vol
	 */
	public void setVolume(float vol) {
		this.getPlayer().setVolume(vol);
	}

	public void setPosition(int position) {
		this.getPlayer().setPosition(position);
		setChanged();
		notifyObservers();
	}

	/***
	 * Permet de récupèrer la position du lecteur.
	 * @return
	 */
	public int getPosition() {
		return this.getPlayer().getPosition();
	}

	/***
	 *  Permet de récupèrer la table des fichiers audio.
	 * @return
	 */
	public TableModelPlayerFile getTableData() {
		return tableData;
	}

	/***
	 * Permet de récupèrer la table de la liste de lecture.
	 * @return
	 */
	public TableModelPlayList getTablePlayList() {
		return tablePlayList;
	}

	/***
	 * Permet de changer morceau en cours de lecture.
	 * @param currentTrack
	 */
	public void setCurrentTrack(FilePlayer currentTrack) {
		this.currentTrack = currentTrack;
	}

	/***
	 * Permet de récupèrer le fichier en cours de lecture.
	 * @return
	 */
	public FilePlayer getCurrentTrack() {
		return currentTrack;
	}



	/***
	 * permet d'activer ou désactiver la répitition.
	 * @param repeatMode
	 */
	public void setRepeatMode(boolean repeatMode) {
		this.repeatMode = repeatMode;
	}

	/***
	 * Permet de savoir si le mode de répitition de la piste
	 * @return
	 */
	public boolean isRepeatMode() {
		return repeatMode;
	}

	/***
	 * Permet de récupèrer le réperoire de stockage des listes de lecture.
	 * @return
	 */
	public String getXMLPATH() {
		return JtunesModel.getXmlPath();
		
	}

	public void setXmlFileList() {
		File sourcefile = new File(getXmlPath());

		this.xmlFileList = UiTools.getXmlFilesOfDir(sourcefile.getAbsoluteFile());
	}

	/***
	 * Permet de récupèrer les listes de lecture disponibles.
	 * @return
	 */
	public List<File> getXmlFileList() {
		return xmlFileList;
	}

	
	/***
	 * Permet de d'affichier dans la console les liste des lecture disponible.
	 */
	public void printXmlFile() {

		List<File> listedeLecture =  getXmlFileList();
		if (listedeLecture.size()>0)
		{
			System.out.println("Les listes de lecture disponibles : ");
		for (File f : listedeLecture) {
			System.out.println("+ " + f.getName());
		}
		}
		else 
		{ 
			try {
				
			File f;
			f = new  File(getXMLPATH() + "/" +"Derniere Liste ecoutée.xml");
			
			f.createNewFile();
			Writer output = null;
			output = new BufferedWriter(new FileWriter(f));
			output.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
					+ "<playLists>" + "</playLists>");
			output.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
			System.out.println("Aucune liste de lecture est disponible.");
		}
		
	}

	/***
	 * Permet de charger les listes de lecture disponibles.
	 */
	public void setThePlayList() {
		this.getTablePlayList().getThePlayList().clear();
		File sourcefile = new File(getXmlPath());
		this.getTablePlayList().setPlayListOfDir(sourcefile);
	}

	
	/***
	 * Permet d'ajouter un fichier audio dans la table des fichiers audio.
	 * @param fp
	 */
	public void addFileInTableData(FilePlayer fp) {
		this.getTableData().addFile(fp);
	}

	/***
	 * Permet de mettre à jour le nombre des listes de lecture.
	 * @param nbTrackInCurrentPlayList
	 */
	public void setNbTrackInCurrentPlayList(int nbTrackInCurrentPlayList) {
		this.nbTrackInCurrentPlayList = nbTrackInCurrentPlayList;
	}

	/***
	 * Permet de récupèrer le nombre de 
	 * @return
	 */
	public int getNbTrackInCurrentPlayList() {
		return nbTrackInCurrentPlayList;
	}




	public static String getXmlPath() {
		return XML_PATH;
	}

}