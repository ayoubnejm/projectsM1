l'application doit se s'executer dans ce dossier qui contient les librairies nécessaires pour le lancement de l'application.

