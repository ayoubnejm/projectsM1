var layer;
function toogleLayer(whichLayer) {
    //window.alert('toogle layer :'+whichLayer);
    var elem, vis;
    if( document.getElementById ) // this is the way the standards work
        elem = document.getElementById( whichLayer );
    else if( document.all ) // this is the way old msie versions work
        elem = document.all[whichLayer];
    else if( document.layers ) // this is the way nn4 works
        elem = document.layers[whichLayer];

    vis = elem.style;
    // if the style.display value is blank we try to figure it out here
    if(vis.display==''&&elem.offsetWidth!=undefined&&elem.offsetHeight!=undefined)
        vis.display = (elem.offsetWidth!=0&&elem.offsetHeight!=0)?'block':'none';
    vis.display = (vis.display==''||vis.display=='block')?'none':'block';
//window.alert(vis.display);
}
function closeAll(layer) {
    var elem, vis;
    nbVis=layer.length;
    for (i=0;i<nbVis;i++)
    {
        whichLayer=layer[i];
                               
        if( document.getElementById ) // this is the way the standards work
            elem = document.getElementById( whichLayer );
        else if( document.all ) // this is the way old msie versions work
            elem = document.all[whichLayer];
        else if( document.layers ) // this is the way nn4 works
            elem = document.layers[whichLayer];

        vis = elem.style;
        // if the style.display value is blank we try to figure it out here
        vis.display = 'none';
    }
}

function openAll(layer) {
    var elem, vis;
    for (i=0;i<layer.length;i++)
    {
        whichLayer=layer[i];
        if( document.getElementById ) // this is the way the standards work
            elem = document.getElementById( whichLayer );
        else if( document.all ) // this is the way old msie versions work
            elem = document.all[whichLayer];
        else if( document.layers ) // this is the way nn4 works
            elem = document.layers[whichLayer];

        vis = elem.style;
        // if the style.display value is blank we try to figure it out here
        vis.display = 'block';
    }
}                        

