<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once(ABS_START_PATH."/secure/auth.php");


   $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    //echo $altRefs." ".count($selection);
    $width='95%';
    $alts=doQueryRenduEtape0($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $et_pn=$alt[1]." ".$alt[2]; $et_entrNom=$alt[3]; $et_entrCle=$alt[21];
        $et_tel=$alt[4];$et_m=$alt[5];$et_mlille1=$alt[24];

        $t_pn=$alt[6]." ".$alt[7];
        $t_tel=$alt[8]; $t_m=$alt[9];

        $r_pn=$alt[10]." ".$alt[11];
        $r_fonction=$alt[12];
        $r_tel=$alt[13]; $r_m=$alt[14];
        $r_opca=$alt[15];
        $r_opcaNom=$alt[25];

        $d_sign=$alt[16]=="0000-00-00"?"":$alt[16];
        $d_opca=$alt[17]=="0000-00-00"?"":$alt[17];
        $d_deb=$alt[18]=="0000-00-00"?"":$alt[18];
        $d_fin=$alt[19]=="0000-00-00"?"":$alt[19];

        $r_cle= $alt[26];
        $r2_cle= $alt[27];
        $regie_entrCle=$alt[28];
        $regie_bureauRef=$alt[29];
        $regie_referent=$alt[30];
        $regie_referent2=$alt[31];
        $regie_adresse=$alt[32];
        $entr_adresse=$alt[33];
        $ref_coords=$alt[34];
        $ref2_coords=$alt[35];
        $regieRef_coords=$alt[36];
        $regieRef2_coords=$alt[37];
        $formationRef=$alt[38];
        $estFA=substr($formationRef,strlen($formationRef)-2,2)=="FA";
        
        echo "<div id='cadre_0' class='contenu-item2 on'>";
        echo " <table align='center' style='border-width: 0px;border-style:solid;font-size:11px' width='".$width."'>
                <tr>
                    <td>";

        if (hasRole(PROF_ROLE)==FALSE)
            echo "<a href='".ABS_START_URL."/index.php'>Retour page accueil.</a>";
         else
                if($_SESSION[REF_YEAR]>=getCurrYear()) {
                  echo "<form method='post' action='".ABS_START_URL."/index.php'>".
                        "<input type='hidden' name='page' value='".(isset($isOM)?"actions/genererOrdreDeMission_act":"interface/faireActionsEtudiants_act")."'/>".
                        "<table width='100%'><tr><td align='right'>".
                        "<input type='hidden' name='action' value='majEtape0_act' />".
                        "<input type='hidden' name='selection[]' value='".$selection[$i]."' />".
                        "<input type='submit' style='color:orange' value='".(isset($isOM)?"Générer OM":"Modifier")."'/>".
                      "</td></tr></table></form>";
                }
        
         echo          "</td></tr>
                        <tr class='entete'><td>$et_pn</td></tr>
                        ";
        echo          "
                        <tr><td><b>Tél. perso : </b>",$et_tel,"&nbsp; | <b>e-mail :</b> ",$et_m,(strlen($et_mlille1)>0?(", ".$et_mlille1):""),"</td></tr>
                        <tr><td><b>Entreprise : </b>",$et_entrNom,"&nbsp; | <b>Référent(s) :</b> ",$r_pn,(strlen($r2_cle)>0?", ".extraireNP($r2_cle):""),"</td></tr>
                        <tr><td><b>Tél. référents : </b>$r_tel &nbsp; | <b> e-mail : </b>",$r_m,(strlen($ref2_coords)>0?(", ".substr($ref2_coords,strpos("- ",$ref2_coords)+2)):""),"</td></tr>
                        ",
                        ((strlen($regie_entrCle)>0 && ($regie_entrCle!="__sans entreprise__"))?
                        "<tr><td>
                                <b>Régie : </b> ".strtoupper($regie_entrCle)."<b>Référents : </b>".extraireNP($regie_referent).(strlen($regie_referent2)>0?(", ".extraireNP($regie_referent2)):"")."</td></tr>
                         <tr><td><b>Coordonnées : </b> $regieRef_coords &nbsp;;&nbsp; $regieRef2_coords</td></tr>"
                                :"").
                        "<tr><td><b>Signature Contrat :</b> $d_sign &nbsp; |  <b> Début : </b> $d_deb &nbsp; | <b> Fin : </b> $d_fin </td></tr>",
                        ($estFA=="FA"?"<tr><td><b>OPCA :</b> $r_opcaNom &nbsp; | <b>accord OPCA :</b> $d_opca</td></tr>":""),
                        "<tr><td><b>Tuteur universitaire : </b> $t_pn &nbsp; | <b>Tél. pro. :</b> $t_tel &nbsp; | <b>e-mail :</b> $t_m </td></tr>
           
            </table>
        </div>";
    }
        
?>
