
<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/secure/auth.php");
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");

 $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtape2($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $ref=$alt[15]." ".$alt[16];
        $etud=$alt[2]." ".$alt[1];
        $tuteur=$alt[17]." ".$alt[18];
        $date=$alt[3];
        $date=substr($date,8)."/".substr($date,5,2)."/".substr($date,0,4);

        if (strcmp($date,"00/00/0000")==0) {
          echo "<p>
                <b style='color:red'>
                    Veuillez remplir la date de la visite concernant l'étudiant $etud avant d'envoyer le CR!
                </b>
              <p>";

          continue;
        }

        $adequation=$alt[4];
        $integration=$alt[5];

        $mailRef=$alt[14];
        $mailTut=$alt[13];
        $mailEtud=$alt[12];

        $mailRef2=$alt[19];
        $ref2=$alt[20]." ".$alt[21];

        if (strcmp($ref2,"referent__ __sans")==0)
          $ref2=" ";
          
        if (strlen($ref)==1) {
          $ref=$ref2;
          $ref2=" ";
        }
        
        /*$file=file("msgs/notifierCrEtape2_template.txt");
        $msgMail=str_replace("%REFERENT%",$ref,implode('',$file));
        $msgMail=str_replace("%ADEQUATION%",$adequation,$msgMail);
        $msgMail=str_replace("%INTEGRATION%",$integration,$msgMail);
        $msgMail=str_replace("%TUTEUR%",$tuteur,$msgMail);
        */
  
        $file=file("msgs/notifierCrEtape2_template.txt");
        $msgMail=str_replace("%MAIL_TUTEUR%",$mailTut,implode('',$file));
        $msgMail=str_replace("%DATE%",$date,$msgMail);
        $msgMail=str_replace("%S%",(strlen($ref)>1&&strlen($ref2)>1)?"s":"",$msgMail);
        $msgMail=str_replace("%ETUDIANT%",$etud,$msgMail);
        $msgMail=str_replace("%REFERENT%",(strlen($ref2)>1)?($ref." et ".$ref2):$ref,$msgMail);
        $msgMail=str_replace("%ADEQUATION%",$adequation,$msgMail);
        $msgMail=str_replace("%INTEGRATION%",$integration,$msgMail);
        $msgMail=str_replace("%TUTEUR%",$tuteur,$msgMail);

      $to=$mailEtud.(strlen($mailRef)>0?','.$mailRef:"").(strlen($mailRef)>0?','.$mailRef2:"");
      $cc=$mailTut;
      $subject="[stalt] Compte rendu visite entreprise $etud";
      $body=$msgMail;

        echo "
            <p>".
            "Envoyer mail à : $to et $cc"."<br/>".
            "Sujet : $subject"."<br/>".
            to_html($msgMail)."<br/>".
            "</p>
             <form method='post' action='".ABS_START_URL."/index.php'>
                <input type='hidden' name='page' value='interface/faireActionsEtudiants_act'/>
                <input type='hidden' name='action' value='faireNotifierCrEtape2_act'/>
                <input type='hidden' name='selection[]' value='".$alt[0]."'/>
                <input type='submit' value='Envoyer mail'/>
            </form>
        ";
       
    }

?>