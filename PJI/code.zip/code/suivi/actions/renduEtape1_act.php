<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once(ABS_START_PATH."/secure/auth.php");


    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtape1($conn,$altRefs);
    if ($alts==FALSE) {
      echo "Aucune information!";
      die();
    }
    $alt=mysql_fetch_row($alts);

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $et_pn=$alt[1]." ".$alt[2]; 
        $date=$alt[3]=="0000-00-00"?"":$alt[3];
        $entr=$alt[4];
        $serv=$alt[5];
        $client=$alt[6];

        $missions=to_minimum_lines(to_html($alt[7]),1);
        $env=to_minimum_lines(to_html($alt[8]),1);
        $integration=to_minimum_lines(to_html($alt[9]),1);

        $signEtud=$alt[10]!=0?"OUI":"NON";
        $rmqEtud=to_minimum_lines(to_html($alt[11]),1);
        
        $signTut=$alt[12]!=0?"OUI":"NON";
        $rmqTut=to_minimum_lines(to_html($alt[13]),1);
        
        $width="95%";
        echo "<div id='cadre_0' class='contenu-item2 on' >";
        echo " <table align='center' style='border-width: 0px;border-style:solid;font-size:11px' width='".$width."'>
                <tr>
                    <td>";
        
        if (hasRole(PROF_ROLE)!=TRUE)
            echo "<a href='index.php'>Retour page accueil.</a>";
        else
            if($_SESSION[REF_YEAR]>=getCurrYear())
                  echo "<form method='post' action='".ABS_START_URL."/index.php'>".
                        "<input type='hidden' name='page' value='interface/faireActionsEtudiants_act'/>".
                        "<table width='100%'><tr><td align='right'>".
                        "<input type='hidden' name='action' value='majEtape1_act' />".
                        "<input type='hidden' name='selection[]' value='".$selection[$i]."' />".
                        "<input type='submit' style='color:orange' value='Modifier'/>".
                      "</td></tr></table></form>";

        echo          "</td></tr>
                        <tr class='entete'><td>$et_pn</td></tr>
                        ";
        echo          "
               
                <tr>
                    <td>
                        <b>Date rencontre (aaaa-mm-jj) :</b> ",$date,"<br/>
                        <b>Entreprise chosie :</b> ",$entr,"&nbsp;
                        <b>Service/Projet :</b> ",$serv,"&nbsp;
                        (éventuellement client) :</b> ",$client,"<br/>
                    </td>

                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Quels sont (ou seront) les missions confiées ?</b><br/>
                        <div style='width:".$width."'>
                        <p>".$missions."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Dans quel environnement technique ?</b><br/>
                        <div style='width:".$width."'>
                        <p>".$env."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Comment se passe l'intégration dans l'entreprise ?</b><br/>
                        <div style='width:".$width."'>
                        <p>".$integration."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation de l'étudiant </b> <i>".$signEtud."</i> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p>".$rmqEtud."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation du tuteur </b> <i>".$signTut."</i> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p>".$rmqTut."</p>
                        </div>
                    </div></td>
                </tr>
            </table>
        </div>";

       
    }
?>
