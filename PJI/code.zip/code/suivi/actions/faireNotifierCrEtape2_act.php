<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/secure/auth.php");
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once(ABS_START_PATH."/mail/sendMail.php");
require_once(ABS_START_PATH."/log/log.php");


    action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"faireNotifierCrEtape2",array($selection));

    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtape2($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $ref=$alt[15]." ".$alt[16];
        $etud=$alt[2]." ".$alt[1];
        $tuteur=$alt[17]." ".$alt[18];
        $date=$alt[3];
        $date=substr($date,8)."/".substr($date,5,2)."/".substr($date,0,4);

        if (strcmp($date,"00/00/0000")==0) {
          echo "<p>
                <b style='color:red'>
                    Veuillez remplir la date de la visite concernant l'étudiant $etud avant d'envoyer le CR!
                </b>
              <p>";

          continue;
        }
        $adequation=$alt[4];
        $integration=$alt[5];

        $mailRef=$alt[14];
        $mailTut=$alt[13];
        $mailEtud=$alt[12];

        $mailRef2=$alt[19];
        $ref2=$alt[20]." ".$alt[21];

        if (strcmp(strtolower($ref2),"referent__ __sans")==0)
          $ref2=" ";

        if (strlen($ref)==1) {
          $ref=$ref2;
          $ref2=" ";
        }
        
        $file=file("msgs/notifierCrEtape2_template.txt");
        $msgMail=str_replace("%MAIL_TUTEUR%",$mailTut,implode('',$file));
        $msgMail=str_replace("%DATE%",$date,$msgMail);
        $msgMail=str_replace("%ETUDIANT%",$etud,$msgMail);
        $msgMail=str_replace("%S%",(strlen($ref)>1&&strlen($ref2)>1)?"s":"",$msgMail);
        $msgMail=str_replace("%REFERENT%",(strlen($ref2)>1)?($ref." et ".$ref2):$ref,$msgMail);
        $msgMail=str_replace("%ADEQUATION%",$adequation,$msgMail);
        $msgMail=str_replace("%INTEGRATION%",$integration,$msgMail);
        $msgMail=str_replace("%TUTEUR%",$tuteur,$msgMail);

      $to=$mailEtud.
            (strlen($mailRef)>0?','.$mailRef:"").
            (strlen($mailRef2)>0?','.$mailRef2:"");
      $cc=$mailTut;
      $subject="[stalt] Compte rendu visite entreprise $etud";
      $body=$msgMail;

      error_log("sending mail $to $cc $subject");
      $result=sendAuthenticatedMail($to,$cc,$subject,$msgMail);
      //$result=FALSE;
      error_log($result);

      if ($result===TRUE) {
            echo "<p>E-mail envoyé avec succès à $to et $cc !</p>";
      }
      else
            /* message déja affiché par sendAuthenticatedMail */
            echo "<p>Pb. avec envoi!<br/>$result</p>";

       
    }

?>
</div>
        </div>
