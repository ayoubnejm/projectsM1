<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");

    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    //echo $altRefs;
    
    $alts=doQueryRenduEtape1($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    $nbCols=2;
    $space=50;
    $width="95%";

    if ($alt[3]===null)
    {
        echo "<div id='cadre_0' class='contenu-item2 on'>Votre tuteur n'as pas encore saisi les détails de la rencontre.<br/>";
        echo "<a href='".ABS_START_URL."/index.php'>Revenir à la page d'accueil</a></div>";
        die();
    }
    
    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $et_pn=$alt[1]." ".$alt[2]; 
        $date=$alt[3]=="0000-00-00"?"":$alt[3];
        $entr=$alt[4];
        $serv=$alt[5];
        $client=$alt[6];

        $missions=to_minimum_lines(to_html($alt[7]),0);
        $env=to_minimum_lines(to_html($alt[8]),0);
        $integration=to_minimum_lines(to_html($alt[9]),0);

        $signEtud=$alt[10];
        $rmqEtud=to_minimum_lines(to_text($alt[11]),0);
        
        $signTut=$alt[12]!=0?"OUI":"NON";;
        $rmqTut=to_minimum_lines(to_html($alt[13]),0);
        
        echo "<div id='cadre_0' class='contenu-item2 on' >";
        echo "<form name='form",$i,"' action='".ABS_START_URL."/index.php' method='post'>";
        echo "<input type='hidden' name='page' value='actions/faireMajEtape1Etud_act'/>";
        echo "<input type='hidden' name='altCle' value='",$altCle,"'/>";
        echo "
                <b>L'ETUDIANT : ",$et_pn,"</b><br/>
                <table align='center' style='border-width: 0px;border-style:solid;font-size:11px'>
                <tr>
                    <td style='border-width: 1px;border-style:' width='".$width."'>
                        Date rencontre (aaaa-mm-jj) : ".$date."<br/>
                        Entreprise chosie : ".$entr."<br/>
                        Service/Projet : ".$serv."<br/>
                        (éventuellement client) : ".$client."<br/>
                    </td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Quels sont (ou seront) les missions confiées ?</b><br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>".$missions."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Dans quel environnement technique ?</b><br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>".$env."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Comment se passe l'intégration dans l'entreprise ?</b><br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>".$integration."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation de l'étudiant </b><input type='checkbox' name='signEtud'",($signEtud!=0?"checked='checked' value='1'":""),"/>(remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='rmqEtud' style='width:95%' rows='2'>",$rmqEtud,"</textarea></p>
                        
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation du tuteur </b>".$signTut." (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>&nbsp;&nbsp;&nbsp;",$rmqTut,"</p>
                        </div>
                    </div></td>
                </tr>";
                echo "<tr><td align='center'><input type='button' value='Revenir en arrière' onclick='javascript:history.go(-1);'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                echo "<input type='submit' style='align:right;background-color:orange' value='Valider'/></td>
                </tr>
            </table>";
        echo "</form>";
        echo "</div>";

}
?>