<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">

<?php
require_once(ABS_START_PATH.'/secure/auth.php');
require_once(ABS_START_PATH.'/dbmngt/queries.php');
require_once(ABS_START_PATH.'/html/utils.php');
require_once(ABS_START_PATH.'/dbmngt/connect.php');
require_once(ABS_START_PATH.'/log/log.php');
require_once(ABS_START_PATH.'/calendar/tc_calendar.php');


$conn = doConnection();
$selection=getParam('selection','');
$res = doQueryDonneeOrdreDeMission($conn, $selection[0]);

action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"genererOrdreDeMission",array($selection));

$resTmp = mysql_fetch_row($res);
?>

        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/gestionFormulaireToPDF.js" lang="javascript"></SCRIPT>
        <script language="javascript" src="<?php echo ABS_START_URL; ?>/calendar/calendar.js"></script>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo ABS_START_URL; ?>/js/formToWizard.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $("#SignupForm").formToWizard({ submitButton: 'SaveAccount' })
            });
            gestionMoyenDeTransport('SignupForm');
        </script>

   
        <div id="main">
            <form action="<?php echo ABS_START_URL;?>/exportPDF/pdfV2.php" method="post" name="formulaire" id="SignupForm" onsubmit="return valider()">
                <?php
                if ($resTmp[4] <= 25) {
                    echo"<h1> Mission sans frais pour Lille 1</h1>";
                    echo"<input type=\"hidden\" name=\"frais\" value =\"false\"/>";
                } else {
                    echo"<h1> Mission avec frais pour Lille 1</h1>";
                    echo"<input type=\"hidden\" name=\"frais\" value =\"true\"/>";
                }
                ?>

                <input type="hidden" name="nom" value =" <?php echo $resTmp[0] ?> "/>
                <input type="hidden" name="prenom" value =" <?php echo $resTmp[1] ?>" />
                <input type="hidden" name="objet" value="<?php echo "Visite pédagogique en entreprise<br/> Etudiant : " . $resTmp[5] . " " . $resTmp[6] . "<br/> Formation : " . $resTmp[8] . " <br/> Entreprise : " . $resTmp[7] ?>" />
                <input type="hidden" name="lieu" value =" <?php echo $resTmp[2] ?>"/>
                <input type="hidden" name="adresse" value =" <?php echo $resTmp[3] ?>"/>
                <input type="hidden" name="pays" value="France" />

                <fieldset>
                    <legend>Moyen de transport</legend>
                    

                    <input type="checkbox" name="moyenTransport" id="train" onchange="gestionMoyenDeTransport('SignupForm')" /> <label for="train">Train</label>

                    <div id="divInfoTrain" style="display:none; font-size:9pt">
                        <input type="radio" name="classeTrain" id="premiere"   /> 
                        <label for="premiere">1ère</label>
                        <input type="radio" name="classeTrain" id="seconde" checked  /> 
                        <label for="seconde">2éme</label>
                        <br/>
                        <text id="erreurReductionTrain" style="display:none;font-size:9pt"><font color="#FF0000">Champ Invalide un pourcentage est un nombre entier compris entre 0 et 100</font><br/></text>
                        Je bénéficie d'une réduction de 
                        <input type= "text" name="reductionTrain" size="3" />
                        % au titre de
                        <input type="text" name="moyenReductionTrain" />                
                    </div>            
                    <br/>
                    <input type="checkbox" id="voiture" onchange="gestionMoyenDeTransport('SignupForm')" />
                    <label for="voiture">Voiture</label> 

                    <div id="divInfoVoiture" style="display:none;font-size:9pt">
                        <text id="erreurPuissanceVoiture" style="display:none"><font color="#FF0000">Champ Invalide la puissance fiscale est un nombre entier compris entre 1 et 20</font><br/></text>
                        <text id="erreurPuissanceVoitureObligatoire" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        Puissance fiscale *: 
                        <input type="text" name="cv" size="2"  />                
                        <text id="erreurImmatriculationVoiture" style="display:none"><br/><font color="#FF0000">Champ obligatoire </font><br/></text>
                        Immatriculation *:
                        <input type="text" name="immatriculation"/>                
                    </div>

                    <br/>
                    <input type="checkbox" id="locationVoiture" onchange="gestionMoyenDeTransport('SignupForm')"  />
                    <label for="locationVoiture">Location de voiture par Agence de voyages sur marché</label>
                    <br/>
                    <div id="divInfoVoitureLocation" style="display:none;font-size:9pt">
                        <text id="erreurNbPersonneLocationObligatoire" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        <text id="erreurNbPersonneLocation" style="display:none"><font color="#FF0000">Champ Invalide le nombre de personne est un nombre entier compris entre 1 et 10</font><br/></text>
                        <label for="nbPersVoitureLocation" >Nombre de personnes *:</label> 
                        <input type="text" name="nbPersVoitureLocation" />                
                    </div>
                    <br/>
                    <input type="checkbox" id="avion" onchange="gestionMoyenDeTransport('SignupForm')" />
                    <label for="avion">Avion</label> 
                    <input type="checkbox" id="taxi"  onchange="gestionMoyenDeTransport('SignupForm')"/>
                    <label for="taxi">Taxi</label>
                    <input type="checkbox" id="metro"  onchange="gestionMoyenDeTransport('SignupForm')"/>
                    <label for="metro">Transports en commun</label>
                    <input type="checkbox" id="velo"  onchange="gestionMoyenDeTransport('SignupForm')"/>
                    <label for="velo">Vélo</label>


                    <h2>Détails du voyage </h2>
                    <input type="hidden" name="departAllerParDefaut" value="Villeneuve d'ascq" />
                    <input type="hidden" name="kmaller" value ="<?php echo $resTmp[4] ?>"/>
                    <input type="checkbox" id="DepartDifferentLille1" name="DepartDifferentLille1" onchange="gestionMoyenDeTransport('SignupForm')"  />
                    <label for="DepartDifferentLille1">Départ different de Lille1</label>
                    <br/>
                    <div id="divDepartDifferent" style="display:none;font-size:9pt">
                        <text id="erreurVilleDepartObligatoire" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        <text id="erreurVilleDepart" style="display:none"><font color="#FF0000">Champ Invalide la ville ne peut dépasser 18 caractéres</font><br/></text>
                        <label for="departAller" >Ville de depart (arrivée :<?php echo $resTmp[2] ?>) *:</label>
                        <input type="text" name="departAller" value="Villeneuve d'ascq" />                        
                      <!--  <text id="erreurKmObligatoire" style="display:none"><br/><font color="#FF0000">Champ obligatoire </font><br/></text>
                        <text id="erreurKm" style="display:none"><br/><font color="#FF0000">Champ Invalide le kilometrage est un nombre entier supérieur à 1</font><br/></text>
                        <label for="kmaller" >Km aller *:</label> 
                        <input type="text" name="kmaller" value ="" size="2"/>-->
                    </div>

                </fieldset>





                <fieldset>
                    <legend>Aller</legend>


                    <table style="font-size:9pt"><tr><td colspan="2">
                    <text id="erreurDateAller" style="display:none"><font color="#FF0000">La date doit être complétement renseigniée</font><br/></text>
                    <tr><td>Date (Aller) * :</td><td>
                    <?php
                    $myCalendar = new tc_calendar("dateAller", true);
                    $myCalendar->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    $myCalendar->setDate(date('d'), date('m'), date('Y'));
                    $myCalendar->dateAllow('' . date('d') . '-' . date('m') . '-' . date('Y'), '', false);
                    $myCalendar->setPath(ABS_START_URL."/calendar/");
                    $myCalendar->disabledDay("sun");
                    $myCalendar->setDateFormat('j F Y');
                    $myCalendar->setAlignment('left', 'bottom');
                    $myCalendar->writeScript();
                    ?></td></tr>
                    <tr><td colspan="2">
                    <text id="erreurHeureDepartAllerFormat" style="display:none"><font color="#FF0000">Champ Invalide attention au format</font><br/></text>
                    <text id="erreurHeureDepartAller" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                    <text id="erreurHeureArriverAllerFormat" style="display:none"><font color="#FF0000">Champ Invalide attention au format</font><br/></text>
                    <text id="erreurHeureArriverAller" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                    <input type="hidden" name="arriverAller" value ="<?php echo $resTmp[2] ?>"/>
                    
                    </td></tr>
                    <tr><td>Heure de depart (hh:mm) *</td><td> :<input size="5" type="text" name="horaireDepartAller" value="09:00"/>
                      et d'arrivée (hh:mm) * :<input size="5" type="text" name="horaireArriverAller" value="10:00" />
                    </td></tr>
                    <tr><td colspan="2">
                    <text id="erreurTransportAller" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                    </td></tr>
                    <tr><td>
                    Transport utilisé * :</td><td><select name="transportAller" style="width:100%"><option/> </select>
                    </td></tr>
                    <tr><td colspan="2">
                    <input type="checkbox" id="EscaleAller" name="EscaleAller" onchange="gestionMoyenDeTransport('SignupForm')"  />
                    <label for="EscaleAller">Vous changez de moyen de transport durant le voyage</label>
                    <div id="divEscaleAller" style="display:none">
                        <text id="erreurEscaleAllerObligatoire" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        <text id="erreurVilleEscaleAller" style="display:none"><font color="#FF0000">Champ Invalide la ville ne peut dépasser 18 caractéres</font><br/></text>
                        <label for="villeEscaleAller" >Ville de l'escale *:</label>
                        <input type="text" name="villeEscaleAller"/><br/>

                        <text id="erreurTransportAllerEscaleObligatoire" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        <label for="TransportAllerEscale" >Transport utilisé en deuxiéme *:</label> 
                        <select name="TransportAllerEscale"><option/></select>
                        <br/>
                        <text id="erreurHeureDepartEscaleAllerFormat" style="display:none"><font color="#FF0000">Champ Invalide attention au format</font><br/></text>
                        <text id="erreurHeureDepartEscaleAller" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        Heure du depart en deuxiéme (hh:mm) * :<input size="5" type="text" name="horaireDepartAllerEscale" />
                        <br/>                
                        <text id="erreurHeureArriverEscaleAllerFormat" style="display:none"><font color="#FF0000">Champ Invalide attention au format</font><br/></text>
                        <text id="erreurHeureArriverEscaleAller" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        Heure de l'arrivée en deuxiéme (hh:mm) * :<input size="5" type="text" name="horaireArriverAllerEscale" />
                    </div>
                    <input type="hidden" name="arriverAller" value ="<?php echo $resTmp[2] ?>"/>
                      </td></tr>
                    </table>
                </fieldset>



                <fieldset>
                    <legend>Retour</legend>
                    <table style="font-size:9pt"><tr><td colspan="2">
                    <label for="DateRetourDifferente">Date de retour différente</label><input type="checkbox" name="DateRetourDifferente" id="DateRetourDifferente"  onchange="gestionDate('SignupForm')"/>
                    <text id="erreurDateRetour" style="display:none"><font color="#FF0000"><br/>La date doit être complétement renseigniée</font><br/></text>
                    <text id="erreurDateRetourFormat" style="display:none"><font color="#FF0000"><br/>La date de retour est obligatoirement superieur a la date de l'aller</font><br/></text>
                    </td></tr>
                    <tr><td colspan="2"><td></td><td>
                    <div id="dateRetourDiv" style="display: none"/>
                    <?php
                    $myCalendar2 = new tc_calendar("dateRetour", true);
                    $myCalendar2->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    $myCalendar2->setDate(date('d'), date('m'), date('Y'));
                    $myCalendar2->disabledDay("sun");
                    $myCalendar2->dateAllow('' . date('d') . '-' . date('m') . '-' . date('Y'), '', false);
                    $myCalendar2->setPath(ABS_START_URL."/calendar/");
                    $myCalendar2->setDateFormat('j F Y');
                    $myCalendar2->setAlignment('left', 'bottom');
                    $myCalendar2->writeScript();
                    ?>
                    </div>
                      </td></tr>
                    <tr><td colspan="2">
                    <input type="hidden" name="departRetour" value ="<?php echo $resTmp[2] ?>"/>
                    <text id="erreurHeureDepartRetourFormat" style="display:none"><font color="#FF0000">Champ Invalide attention au format</font><br/></text>
                    <text id="erreurHeureDepartRetour" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                    <input type="hidden" name="arriverRetour" value="Villeneuve d'ascq" />
                    <text id="erreurHeureArriverRetourFormat" style="display:none"><font color="#FF0000">Champ Invalide attention au format</font><br/></text>
                    <text id="erreurHeureArriverRetour" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                    </td></tr>
                    <tr><td>Heure de depart (hh:mm) *</td><td> :<input size="5" type="text" name="horaireDepartRetour" value="11:30" />
                    et d'arrivée (hh:mm) * :<input size="5" type="text" name="horaireArriverRetour" value="12:30"/>
                    </td></tr>
                    <tr><td colspan="2">
                    <text id="erreurTransportRetour" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                    </td></tr>
                    <tr><td>Transport Utilisé * :</td><td><select name="transportRetour" style="width:100%"> </select>
                    </td></tr>
                    <tr><td colspan="2">
                    <input type="checkbox" id="EscaleRetour" name="EscaleRetour" onchange="gestionMoyenDeTransport('SignupForm')"  />
                    <label for="EscaleRetour">Vous changez de moyen de transport durant le voyage</label>
                    <br/>
                    <div id="divEscaleRetour" style="display:none">
                        <text id="erreurEscaleRetourObligatoire" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        <text id="erreurVilleEscaleRetour" style="display:none"><font color="#FF0000">Champ Invalide la ville ne peut dépasser 18 caractéres</font><br/></text>
                        <label for="villeEscaleRetour" >Ville de l'escale *:</label>            
                        <input type="text" name="villeEscaleRetour"/><br/>
                        <text id="erreurTransportRetourEscaleObligatoire" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        <label for="TransportRetourEscale" >Transport utilisé en deuxiéme *:</label> 
                        <select name="TransportRetourEscale"></select>
                        <br/>
                        <text id="erreurHeureDepartEscaleRetourFormat" style="display:none"><font color="#FF0000">Champ Invalide attention au format</font><br/></text>
                        <text id="erreurHeureDepartEscaleRetour" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        Heure du depart en deuxiéme (hh:mm) * :<input size="5" type="text" name="horaireDepartRetourEscale" />
                        <br/>            
                        <text id="erreurHeureArriverEscaleRetourFormat" style="display:none"><font color="#FF0000">Champ Invalide attention au format</font><br/></text>
                        <text id="erreurHeureArriverEscaleRetour" style="display:none"><font color="#FF0000">Champ obligatoire </font><br/></text>
                        Heure de l'arrivée en deuxiéme (hh:mm) * :<input size="5" type="text" name="horaireArriverRetourEscale" />
                    </div>
                    </td></tr>
              </table>

                    <text id="erreurObservation" style="display:none"><font color="#FF0000"><br/>Les observations ne doivent pas dépasser 50 caractéres</font><br/></text>
                    Observations : <input type="text" name="observations" />
                    <br/>
                    <input type="submit" value="Valider" />
                </fieldset>
            </form>         



            * Champs obligatoires
        </div>
        </div>
        </div>


