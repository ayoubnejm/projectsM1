<?php
require_once (ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once (ABS_START_PATH."/html/dbutils.php");
require_once (ABS_START_PATH."/html/escaping.php");
echo '<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">';

    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtapeBilan($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    $conn=doConnection();
    $res=true;
    echo "<b>Mise à jour des informations concernant les missions de soutenance</b>";

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $et_pn=$alt[1]." ".$alt[2];

        $rmqTut=$alt[14]." <br/>Fiche preremplie par responsable<br/>";

        $queryString="set autocommit=0 ";
        $res=$res && !(!mysql_query($queryString,$conn));
        $queryString="begin ";
        $res=$res && !(!mysql_query($queryString,$conn));
        if ($res!=false)
        {
            $queryString="select alternanceRef from fa_etapevp where alternanceRef='".$altCle."'";
            //echo $queryString."<br/>";
            if (mysql_query($queryString,$conn)==false || mysql_num_rows(mysql_query($queryString,$conn))==0)
            {
                $queryString="insert into fa_etapevp (`alternanceRef`) values ('".$altCle."');";
              //  echo $queryString."<br/>";
                $res=$res && !(!mysql_query($queryString,$conn));
            } else {
               echo "<h2>ATTENTION : Fiche déjà crée pour $et_pn - Rétirer après coup l'information en trop. </h2><hr/>";
            }

            $queryString="update fa_etapevp set dateRencontre='".date("Y-n-d")."',  remarquesTuteur='".$rmqTut."' ".
                         "where alternanceRef='".$altCle."'";
            //echo $queryString;
            if (!mysql_query($queryString,$conn))
            {
                
                echo "pb updating information for $et_pn : ".mysql_errno($conn)." - ".mysql_error($conn)."<hr/>";
                mysql_query("rollback",$conn);
            } else {
              $queryString="commit ";
              $res=$res && !(!mysql_query($queryString,$conn));

              echo "Informations mise à jour pour $et_pn !<hr/>";
            }

        }
    
}
    ?>
</div>
        </div>