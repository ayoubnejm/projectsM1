<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">

        <?php
        /*
         * To change this template, choose Tools | Templates
         * and open the template in the editor.
         */
        require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
        require_once (ABS_START_PATH."/dbmngt/connect.php");
        require_once (ABS_START_PATH."/html/escaping.php");
        require_once (ABS_START_PATH."/html/dbutils.php");
        require_once (ABS_START_PATH."/config/auth.ini.php");
        require_once (ABS_START_PATH."/log/log.php");

        $altCle=doDBEscape(getParam("altCle",null));
        if ($altCle==null) die("Demande de maj invalide!");

        action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"faireMajEtape0",array($altCle));
        
        $et_pn=doDBEscape(getParam("et_pn",null));
        $et_cle=doDBEscape(getParam("et_cle",null));
        //$et_entr=doDBEscape(getParam("et_entr",null);
        $et_entrCle=doDBEscape(getParam("fa_entreprise_cle",null));
        $et_tel=doDBEscape(getParam("et_tel",null));
        $et_m = doDBEscape(getParam("et_m",null));

        $t_ref=doDBEscape(getParam("t_ref",null));
        //$t_tel=doDBEscape(getParam("t_tel",null);
        //$t_m=doDBEscape(getParam("t_m",null);

        //Modification JTA 
        $r_cle=doDBEscape(getParam("fa_referent_cle", null));
        $r_bureau_cle=doDBEscape(getParam("fa_bureau_cle",null));
        $r2_cle=doDBEscape(getParam("fa_referent2_cle", null));

        $regie_r_cle=doDBEscape(getParam("fa_regie_referent_cle", null));
        $regie_bureau_cle=doDBEscape(getParam("fa_regie_bureau_cle",null));
        $regie_r2_cle=doDBEscape(getParam("fa_regie_referent2_cle", null));
        
        //Fin modif
        $r_p=doDBEscape(getParam("r_p",null));
        $r_n=doDBEscape(getParam("r_n",null));
        $r_fonct=doDBEscape(getParam("r_fonction",null));
        $r_tel=doDBEscape(getParam("r_tel",null));
        $r_m=doDBEscape(getParam("r_m",null));
        $r_opca=doDBEscape(getParam("r_opca",null));
        

        $d_sign=doDBEscape(getParam("d_sign","0000-00-00"));
        if ($d_sign=='') $d_sign="0000-00-00";
        $d_opca=doDBEscape(getParam("d_opca","0000-00-00"));
        if ($d_opca=='') $d_opca="0000-00-00";
        $d_deb=doDBEscape(getParam("d_deb","0000-00-00"));
        if ($d_deb=='') $d_deb="0000-00-00";
        $d_fin=doDBEscape(getParam("d_fin","0000-00-00"));
        if ($d_fin=='') $d_fin="0000-00-00";
        ?>
        <h2>Mise à jour des informations concernant l'alternance de <?php echo $et_pn ?></h2>
        <?php
            $conn=doConnection();
            $res=true;
            $queryString="set autocommit=0 ";
            $res=$res && !(!mysql_query($queryString,$conn));
            $queryString="begin ";
            $res=$res && !(!mysql_query($queryString,$conn));
            $queryString="update contrat set ";
            if ($res) {
                if ($t_ref!=="NULL")
                    $queryString.="tuteurRef='".$t_ref."', ";
                else
                    $queryString.="tuteurRef=NULL, ";

                if ($r_opca) {
                    $queryString.="opcaRef='".$r_opca."',";
                }
                //Ajout JTA 
                if($r_bureau_cle){
                    $queryString.="bureauRef='".$r_bureau_cle."',";
                }
                if($r_cle){
                    $queryString.="referentRef='".$r_cle."',";
                }
                if($r2_cle){
                    $queryString.="referentRef2='".$r2_cle."',";
                }
                if($regie_bureau_cle){
                    $queryString.="regieBureauRef='".$regie_bureau_cle."',";
                }
                if($regie_r_cle){
                    $queryString.="regieReferentRef='".$regie_r_cle."',";
                }
                if($regie_r2_cle){
                    $queryString.="regieReferentRef2='".$regie_r2_cle."',";
                }
                // Fin ajout 
                $queryString.="debutContrat='".$d_deb."', finContrat='".$d_fin."', accordOPCA='".$d_opca."', signatureContrat='".$d_sign."'  where alternanceCle='".$altCle."'";
                $res=$res && !(!mysql_query($queryString,$conn));
            }

            error_log($queryString);
            if ($res) {
                $queryString="update etudiant set mail='".$et_m."', tel='".$et_tel."' where etudCle='".$et_cle."'";
                $res=$res && !(!mysql_query($queryString,$conn));
            }            
            if (!$res)
            {
                mysql_query("rollback",$conn);
                die("pb updating information");
            }
            $queryString="commit ";
            $res=$res && !(!mysql_query($queryString,$conn));

            echo "Informations mise à jour!<hr/>";
            $selection=array();
            $selection[]=$altCle;
            require_once(ABS_START_PATH."/actions/renduEtape0_act.php");
            
            return true;
        ?>

   </div>
        </div>

