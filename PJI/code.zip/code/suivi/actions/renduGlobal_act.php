<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once("config/main.ini.php");
require_once(ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once(ABS_START_PATH."/secure/auth.php");

?>
<script src="<?php echo ABS_START_URL;?>/js/common.js" type="text/javascript"></script>
<script src="<?php echo ABS_START_URL;?>/js/toogleDivs.js" type="text/javascript"></script>

<?php
$conn=doConnection();

$altRefs="'".$selection[0]."'";
for ($i=1;$i<count($selection);$i++)
    $altRefs.=", "."'".$selection[$i]."'";

echo $altRefs." ".count($selection);

$etapes=array("renduEtape0_act","renduEtape1_act","renduEtape2_act","renduEtapeMissionSoutenance_act","renduEtapeBilan_act");
$descr=array("Informations générales","Rencontre tuteur","1ère visite pédagogique","Mission soutenance","2ème visite pédagogique");


echo "<table border='0' width='100%'>";
for ($etapeNo=0;$etapeNo<count($etapes);$etapeNo++) {
  echo "<tr class='entete'><td width='60%' valign='center'>";
  echo "<a onClick=\"javascript:toogleLayer('div_".$etapes[$etapeNo]."');\" class='div' name='a_".$etapes[$etapeNo]."'>";
  echo "<font size='4' style='font-weight:bold'>".$descr[$etapeNo]."</font></a></td>";
  echo "<td align='right'><a href='#a_".$etapes[$etapeNo]."' onClick=\"javascript:toogleLayer('div_".$etapes[$etapeNo]."');\" class='div'><i>+/-</i></a>&nbsp;|
                                <a class='div' onClick='javascript:openAll(layer);'><i>+tout</i></a>&nbsp;|&nbsp;
                                <a class='div' onClick='javascript:closeAll(layer);'><i>-tout</i></a></td>";
  echo "</td></tr><tr><td colspan='2'>";
  echo "<div style='display:block' id='div_".$etapes[$etapeNo]."'>";
  require_once(ABS_START_PATH."/actions/".$etapes[$etapeNo].".php");
  echo "</div>";
  echo "</td></tr>";

}


echo "</table>";
//error_log ("BAUUUUUUUUUUU");

echo "<script type='text/javascript'>
        var layer=new Array();";
for ($i=0;$i<count($etapes);$i++) {
    echo "layer[".$i."]='div_".$etapes[$i]."';";
}

echo "  closeAll(layer);
      </script>";

?>


