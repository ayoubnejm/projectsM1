<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">

<?php

require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/html/dbutils.php");


    $conn=doConnection();

    echo "<form action='".ABS_START_URL."/index.php' method='post' id='actionForm'>
          <input type='hidden' name='page' value='interface/gestionTuteursInactifs_act'/>";
    echo "<br/><ul>\n"; 
    echo "</ul>";

    $tuteurRef = ''; 
    $tuteurRef = $selection[0]; 
    
    echo "<br/>Le tuteur suivant sera activé de l'application ".$tuteurRef.":<br/>\n";
  
    echo "<br/><br/>";

    echo "<input type='hidden' value=1 name='activer'/>";
    echo "<input type='hidden' value='".$tuteurRef."' name='tuteurRef'/>";
    echo "<input type='button' value='Annuler' onclick='javascript:history.go(-1);'/>";
    echo "<input type='submit' style='color:orange' value='Activer'/>";
    echo "</form>";


?>
</div>
</div>
