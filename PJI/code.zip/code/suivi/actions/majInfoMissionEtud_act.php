<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");


    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    //echo $altRefs;
    
    $alts=doQueryRenduEtape1($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    $nbCols=2;
    $space=50;
    $width=((1000-$space*$nbCols)/$nbCols)<500?500:((1000-$space*$nbCols)/$nbCols);
    $divs=array("<div style='display:block; position:relative; float:left;width:".($width).";border: 1px dashed #000000; padding:1em '>",
                "<div style='display:block; position:relative; float:left;width:".($width)."; border: 1px dashed #000000; padding:1em '>",
                "<div style='display:block; position:relative; float:left;width:".($width)."; border: 1px dashed #000000; padding:1em '>",
                "<div style='display:block; position:relative; float:left;width:".($width)."; border: 1px dashed #000000; padding:1em '>"
                );

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $et_pn=$alt[1]." ".$alt[2]; 
        $date=$alt[3]=="0000-00-00"?"":$alt[3];
        $entr=$alt[4];
        $serv=$alt[5];
        $client=$alt[6];

        $missions=to_minimum_lines(to_text($alt[7]),0);
        $env=to_minimum_lines(to_text($alt[8]),0);
        $integration=to_minimum_lines(to_text($alt[9]),0);

        $signEtud=$alt[10]!=0?"OUI":"NON";
        $rmqEtud=to_minimum_lines(to_html($alt[11]),0);
        
        $signTut=$alt[12];
        $rmqTut=to_minimum_lines(to_text($alt[13]),0);

        $mots=$alt[14];
        
        echo $divs[$i%$nbCols];
        echo "<form name='form",$i,"' action='".ABS_START_URL."/index.php' method='post'>";
        echo "<input type='hidden' name='page' value='actions/faireMajInfoMissionEtud_act'/>";
        echo "<input type='hidden' name='altCle' value='",$altCle,"'/>";
        echo "
                <h2><b>Mission(s) <input type='hidden' value='",$et_pn,"' name='et_pn'/></b><br/>
                </h2><table align='center'>
                <tr>
                    <td style='border-width: 1px;border-style:' width='".$width."'>
                        <input type='hidden' value='",$date,"' name='date'/>
                        <input type='hidden' value='",$entr,"' name='entr'/>
                        Service/Projet : <input type='text' value='",$serv,"' name='serv'/><br/>
                        (éventuellement client) : <input type='text' value='",$client,"' name='client'/><br/>
                    </td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Quels sont (ou seront) les missions confiées ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='missions' style='width:95%' rows='6'>",$missions,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Dans quel environnement technique ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='env' style='width:95%' rows='6'>",$env,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Mots clés ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='motscles' style='width:95%' rows='1'>",$mots,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                ";
                echo "<tr><td align='center'><input type='button' value='Revenir en arrière' onclick='javascript:location=\"index.php\";'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                echo "<input type='submit' style='align:right;background-color:orange' value='Valider'/></td>
                </tr>
            </table>";
        echo "</form>";
        echo "<hr/><b>Note:</b> Si vous avez déjà rencontré votre tuteur et qu'il a rempli le CR de votre rencontre, les modifications saisies ici ne seront pas reportées sur votre livret!";
        echo "</div>";

    
}
?>