<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/secure/auth.php");
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");


    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtapeMissionSoutenance($conn,$altRefs);

    if (hasRole(PROF_ROLE)!=TRUE)
            echo "<a href='../interface/accueilEtudiant.php'>Retour page accueil.</a>";
        else
          if($_SESSION[REF_YEAR]>=getCurrYear())
           echo "<table width='100%'><tr><td width='75%'></td><td align='center'>".
                        "<form method='post' action='".ABS_START_URL."/index.php'>".
                          "<input type='hidden' name='page' value='interface/faireActionsEtudiants_act'/>".
                                "<input type='hidden' name='action' value='majEtapeMissionSoutenance_act' />".
                            "<input type='hidden' name='selection[]' value='".$selection[0]."' />".
                            "<input type='submit' style='color:orange' value='Modifier'/>".
                        "</form>\n".
                        "</td><td>".
                        ($alts?("<form method='post' action='".ABS_START_URL."/index.php'>".
                          "<input type='hidden' name='page' value='interface/faireActionsEtudiants_act'/>".
                                "<input type='hidden' name='action' value='notifierCrEtapeMissionSoutenance_act' />".
                            "<input type='hidden' name='selection[]' value='".$selection[0]."' />".
                            "<input type='submit' style='color:orange' value='Notifier Ref-Etud' alt='Notifier par mail référent et étudiant'/>".
                        "</form>"):"").
                        "</td></tr></table>"
                      ;

    if ($alts==FALSE) {
      echo "<table align='center' style='border-width: 0px;border-style:solid;font-size:11px' width='".$width."'>
                <tr>
                    <td>Aucune information!</td></tr></table>";
    } else {
    $alt=mysql_fetch_row($alts);

    $nbCols=2;
    $space=50;
    $width="95%";

    //echo "<H3 style='color:red'>Evitez les accents, apostrophes, guillIemets...</H3>";
    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $et_pn=$alt[1]." ".$alt[2]; 
        
        $dateR=$alt[3]=="0000-00-00"?"":$alt[3];
        $typeR=$alt[4];

        $dateV=$alt[5]=="0000-00-00"?"":$alt[5];

        $missions=to_minimum_lines(to_html($alt[6]),1);
        $envtTechnique=to_minimum_lines(to_html($alt[7]),1);
        $enjeux=to_minimum_lines(to_html($alt[8]),1);
        
        $signEtud=$alt[9]!=0?"OUI":"NON";
        $rmqEtud=to_minimum_lines(to_html($alt[10]),1);

        $signRef=$alt[11]!=0?"OUI":"NON";
        $rmqRef=to_minimum_lines(to_html($alt[12]),1);

        $signTut=$alt[13]!=0?"OUI":"NON";
        $rmqTut=to_minimum_lines(to_html($alt[14]),1);
        
        echo "<div id='cadre_0' class='contenu-item2 on'>";
        echo " <table align='center' style='border-width: 0px;border-style:solid;font-size:11px' width='".$width."'>
                        <tr class='entete'><td>$et_pn</td></tr>
                        
                <tr>
                    <td>
                       <b>Date rencontre : </b> $dateR &nbsp; |
                            <b> Type rencontre : </b> $typeR &nbsp; |
                            <b> Date validation : </b> $dateV <td>
                </tr>
                        
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Quelle est la mission (ou partie de mission) choisie ?</b><br/>
                        <div style='width:".$width."'>
                        <p>",$missions,"</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Dans quel environnement technique ?</b><br/>
                        <div style='width:".$width."'>
                        <p>",$envtTechnique,"</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Avec quels enjeux pour l'entreprise et/ou le client ?</b><br/>
                        <div style='width:".$width."'>
                        <p>",$enjeux,"</p>
                        </div>
                    </div></td>
                </tr>
                   <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation de l'étudiant </b><i>".$signEtud."</i> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p>".$rmqEtud."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation du référent </b><i>".$signRef."</i> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p>".$rmqRef."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation du tuteur </b><i>".$signTut."</i> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p>".$rmqTut."</p>
                        </div>
                    </div></td>
                </tr>
            </table>
        </div>";

    }
    }
?>