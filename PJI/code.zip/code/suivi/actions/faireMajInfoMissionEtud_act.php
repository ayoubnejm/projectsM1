<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        <?php
        /*
         * To change this template, choose Tools | Templates
         * and open the template in the editor.
         */
        
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/html/dbutils.php");
        require_once(ABS_START_PATH."/html/escaping.php");

        require_once (ABS_START_PATH."/config/auth.ini.php");
        require_once (ABS_START_PATH."/log/log.php");

        $altCle=getParam("altCle",null);
        if ($altCle==null) die("Demande de maj invalide!");

        action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"faireMajInfoMissionEtud_act",$altCle);

        $et_pn=getParam("et_pn",null);
        $et_cle=substr($altCle,0,-1);
        //$et_entr=getParam("et_entr",null);
        $date=getParam("date","0000-00-00");
        $entr=doDBEscape(getParam("entr",null));
        $serv=doDBEscape(getParam("serv",null));
        $client=doDBEscape(getParam("client",null));

        $missions=doDBEscape(getParam("missions",null));
        $env=doDBEscape(getParam("env",null));
        $integration=doDBEscape(getParam("integration",null));
        $motsCles=doDBEscape(getParam("motscles",null));

//        $signEtud=(getParam("signEtud",null)==null?0:1);
//        $rmqEtud=getParam("rmqEtud",null);

        $signTut=(getParam("signTut",null)==null?0:1);
        $rmqTut=doDBEscape(getParam("rmqTut",null));

        action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"faireMajInfoMissionEtud",array($altCle));

        
        ?>
        <h2>Mise à jour des informations votre (<?php echo $et_pn ?>) mission </h2>
        <?php
            $conn=doConnection();
            $res=true;
            $queryString="set autocommit=0 ";
            $res=$res && !(!mysql_query($queryString,$conn));
            $queryString="begin ";
            $res=$res && !(!mysql_query($queryString,$conn));
            if ($res)
            {
                $queryString="select alternanceRef from infoetud where alternanceRef='".$altCle."'";
                error_log( $queryString);
                if (mysql_query($queryString,$conn)===false || mysql_num_rows(mysql_query($queryString,$conn))===0)
                {
                    $queryString="insert into infoetud (`alternanceRef`) values ('".$altCle."');";
                    //echo $queryString."<br/>";
                    $res=$res && !(!mysql_query($queryString,$conn));
                }
            
                $queryString="update infoetud set dateSaisie='".$date."', service='".$serv."', client='".$client.
                             "', missions='".$missions."', environnementTechnique='".$env."', motscles='".$motsCles."' where alternanceRef='".$altCle."'";
            }
            $res=$res &&!(!mysql_query($queryString,$conn));
            error_log($queryString." - ".mysql_error());
            if ($res)
            {           
              $queryString="commit ";
              $res=$res && !(!mysql_query($queryString,$conn));
              error_log($queryString." - ".mysql_error());
            }
            if ($res==false) {
                mysql_query("rollback",$conn);
                die("pb updating information");
            }
            echo "Informations mise à jour!<hr/>";

            $selection=array();
            $selection[]=$altCle;
            require_once(ABS_START_PATH."/actions/majInfoMissionEtud_act.php");
            
            return true;
        ?>

</div>
        </div>