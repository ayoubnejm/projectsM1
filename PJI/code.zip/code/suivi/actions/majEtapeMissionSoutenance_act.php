<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once (ABS_START_PATH."/calendar/tc_calendar.php");


   echo "<SCRIPT src='".ABS_START_URL."/calendar/calendar.js' lang='javascript'></SCRIPT>";
   echo "<SCRIPT src='http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js' lang='javascript' ></SCRIPT>";

    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtapeMissionSoutenance($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    $nbCols=2;
    $space=50;
    $width="95%";
    
    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $et_pn=$alt[1]." ".$alt[2]; 
        
        $dateR=$alt[3]=="0000-00-00"?"":$alt[3];
        $typeR=$alt[4];

        $dateV=$alt[5]=="0000-00-00"?"":$alt[5];

        $missions=to_minimum_lines(to_text($alt[6]),0);
        $envtTechnique=to_minimum_lines(to_text($alt[7]),0);
        $enjeux=to_minimum_lines(to_text($alt[8]),0);
        
        $signEtud=$alt[9];
        $rmqEtud=to_minimum_lines(to_text($alt[10]),0);

        $signRef=$alt[11];
        $rmqRef=to_minimum_lines(to_text($alt[12]),0);

        $signTut=$alt[13];
        $rmqTut=to_minimum_lines(to_text($alt[14]),0);
        
        echo "<div id='cadre_",$i,"' class='contenu-item2 on'>";
        
        echo "<form id='form'",$i,"' name='form", $i, "' action='".ABS_START_URL."/index.php' method='post'>";
        echo "<input type='hidden' name='page' value='actions/faireMajEtapeMissionSoutenance_act'/>";
        echo "<input type='hidden' name='altCle' value='",$altCle,"'/>";
        echo "
                <b>L'ETUDIANT : ",$et_pn,"<input type='hidden' value='",$et_pn,"' name='et_pn'/></b><br/>
                <table align='center'>
                <tr>
                    <td style='border-width: 1px;border-style:' width='".$width."'>
                        <table>
                        <tr>
                            <td>Date rencontre (aaaa-mm-jj) : </td><td>";
                    $myCalendarRecontre = new tc_calendar("dateR", true);
                    $myCalendarRecontre->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    //$myCalendarSIGN->setDate(date('d'), date('m'), date('Y'));
                    //$myCalendarSIGN->setDate(intval(substr($d_sign,8,2)),intval(substr($d_sign,5,2)),intval(substr($d_sign,0,4)));
                    $myCalendarRecontre->setDateYMD($dateR);
                    $myCalendarRecontre->disabledDay("sun");
                    //error_log("from time : ".strtotime((intval(date('Y'))-3).'-1-1'));
                    //error_log("to time : ".strtotime((intval(date('Y'))+3).'-1-1'));
                    //$myCalendarSIGN->dateAllow((intval(date('Y'))-3).'-1-1', (intval(date('Y'))+3).'-1-1', true);
                    $myCalendarRecontre->setPath(ABS_START_URL."/calendar/");
                    $myCalendarRecontre->setDateFormat('Y-F-j');
                    $myCalendarRecontre->setAlignment('left', 'bottom');
                    //error_log("d_sign : ".substr($d_sign,8,2)." - ".substr($d_sign,5,2)." - ".substr($d_sign,0,4));
                    $myCalendarRecontre->writeScript();
      echo "</td>
                        </tr>
                        <tr>
                            <td>Type rencontre : </td><td>";
        echo createSelect('typeR',array("mail","tel.","visite"),array("mail","tel.","visite"),0);
        echo               "</td>
                        </tr>
                        <tr>
                            <td>Date validation (aaaa-mm-jj) : </td><td>";
                    $myCalendarValidation = new tc_calendar("dateV", true);
                    $myCalendarValidation->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    //$myCalendarSIGN->setDate(date('d'), date('m'), date('Y'));
                    //$myCalendarSIGN->setDate(intval(substr($d_sign,8,2)),intval(substr($d_sign,5,2)),intval(substr($d_sign,0,4)));
                    $myCalendarValidation->setDateYMD($dateV);
                    $myCalendarValidation->disabledDay("sun");
                    //error_log("from time : ".strtotime((intval(date('Y'))-3).'-1-1'));
                    //error_log("to time : ".strtotime((intval(date('Y'))+3).'-1-1'));
                    //$myCalendarSIGN->dateAllow((intval(date('Y'))-3).'-1-1', (intval(date('Y'))+3).'-1-1', true);
                    $myCalendarValidation->setPath(ABS_START_URL."/calendar/");
                    $myCalendarValidation->setDateFormat('Y-F-j');
                    $myCalendarValidation->setAlignment('left', 'bottom');
                    //error_log("d_sign : ".substr($d_sign,8,2)." - ".substr($d_sign,5,2)." - ".substr($d_sign,0,4));
                    $myCalendarValidation->writeScript();
  echo "</td>
                        </tr>
                        </table>
                                               
                    </td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Quelle est la mission (ou partie de mission) choisie ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='missions' style='width:95%' rows='6'>",$missions,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Dans quel environnement technique ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='envtTechnique' style='width:95%' rows='6'>",$envtTechnique,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Avec quels enjeux pour l'entreprise et/ou le client ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='enjeux' style='width:95%' rows='6'>",$enjeux,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation de l'étudiant ",($signEtud!=0?"OUI":"NON")," (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>".$rmqEtud."</p>
                        
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation du référent <input type='checkbox' name='signRef'",($signRef!=0?"checked='checked' value='1'":""),"/>(remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='rmqRef' style='width:95%' rows='2'>",$rmqRef,"</textarea></p>

                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation du tuteur <input type='checkbox' name='signTut'",($signTut!=0?"checked='checked' value='1'":""),"/> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'>&nbsp;&nbsp;&nbsp;<textarea name='rmqTut' style='width:95%' rows='2'>",$rmqTut,"</textarea></p>
                        </div>
                    </div></td>
                </tr>";
          echo "<tr><td align='center'>
        <!--input type='button' value='Annuler' onclick='javascript:window.location='/';'/-->
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            echo "<input type='submit' style='align:right;background-color:orange' value='Valider'/></td>
            </tr>
            </table>";
        echo "</form>";
        echo "</div>";
    
}
?>