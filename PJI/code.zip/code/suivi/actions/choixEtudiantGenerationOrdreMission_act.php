<?php
require_once(ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once(ABS_START_PATH."/secure/auth.php");
// Auteurs JTA / VIJ

   $isOM=1;
   require_once(ABS_START_PATH."/actions/renduEtape0_act.php");
?>
