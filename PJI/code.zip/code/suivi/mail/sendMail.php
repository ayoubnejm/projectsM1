<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function sendAuthenticatedMail($to,$cc,$subject,$body) {
        require_once "Mail.php";

        $from = "marius.bilasco@univ-lille1.fr";

        $host = "smtps.univ-lille1.fr";
        $port = "587";
        $username = "stages";
        $password = "7oPDnTXR";

        $bcc="marius.bilasco@univ-lille1.fr";

        $headers = array ('From' => $from,
          'To' => $to,
          'Cc' => $cc,
          'Bcc' => $bcc,
          'Content-type' => "text/plain; charset=UTF-8",
          'Subject' => $subject);
        $smtp = Mail::factory('smtp',
          array ('host' => $host,
            'port' => $port,
            'auth' => true,
            'username' => $username,
            'password' => $password));

        $mail = $smtp->send(explode(',',$to.",".$cc.",".$bcc), $headers, $body);

        if (PEAR::isError($mail)) {
          return $mail->getMessage();
         } else {
           return TRUE;
         }

}

?>
