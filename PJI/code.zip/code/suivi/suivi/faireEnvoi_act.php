<?php
require_once(ABS_START_PATH."/secure/auth.php");

if (!hasRole(RESP_ROLE))
    redirectAuth(null);
?>
<div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 1 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Confirmer envois</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>

        <h1>Mails à envoyer</h1>
<?php
    require_once(ABS_START_PATH."/mail/sendMail.php");
    
    $msgs=str_replace("\'","'",$_REQUEST["msgs"]);
    $tos=$_REQUEST["tos"];
    $ccs=$_REQUEST["ccs"];
    $subjects=$_REQUEST["subjects"];

    for ($i=0;$i<count($msgs);$i++)
    {

      $result=sendAuthenticatedMail($tos[$i],$ccs[$i],$subjects[$i],$msgs[$i]);
      //$result=FALSE;
      error_log($result);

      if ($result===TRUE) {
            echo "<p>E-mail envoyé avec succès à ",$tos[$i], " !</p>";
      }
      else
            /* message déja affiché par sendAuthenticatedMail */
            echo "<p>Pb. avec envoi!<br/>$result</p>";

    }

?>
</body>
</html>