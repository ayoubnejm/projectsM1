<?php
require_once(ABS_START_PATH."/secure/auth.php");

if (!hasRole(RESP_ROLE))
    redirectAuth(null);
?>

<div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 1 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Confirmer envois</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>

        <h1>Mails à envoyer</h1>
        <form action="<?php echo ABS_START_URL;?>/index.php" method="post">
          <input type="hidden" name="page" value="suivi/faireEnvoi_act"/>
        <?php
           
            $selection=$_REQUEST["selection"];
            $listeEtuds=$_REQUEST["etudiants"];
            $tuteurs=$_REQUEST["tuteurs"];
            $mailTuteurs=$_REQUEST["mailsTuteurs"];
            $etapeSuivi=$_REQUEST["etapeSuivi"];

            for ($i=0;$i<count($selection);$i++)
            {
            $tuteur=$tuteurs[$selection[$i]];
            $mailTuteur=$mailTuteurs[$selection[$i]];

            $file=file(ABS_START_PATH."/msgs/rappelEtape_".$etapeSuivi."_template.txt");

            $msgMail=str_replace("%TUTEUR%",$tuteurs[$selection[$i]],implode('',$file));
            $msgMail=str_replace("%LISTE%",$listeEtuds[$selection[$i]],$msgMail);

            $headersMail  = 'MIME-Version: 1.0' . "\r\n";
            $headersMail .= 'Content-type: text/plain; charset=utf-8' . "\n";
            $headersMail .= "From: Marius Bilasco <Marius.Bilasco@univ-lille1.fr> \n".

                        "Subject: [stalt] Informations manquantes concernant le suivi d'alternants - ".$etapeSuivi." \n".
                        "To: ".$tuteur."<".$mailTuteur."> \n".
                        //"To: Marius Bilasco <Marius.Bilasco@univ-lille1.fr> \n".
                        "Cc: Marius Bilasco <Marius.Bilasco@univ-lille1.fr> \n";
                        //"\"".$tuteur."\" <".$mailTut."> \r\n";
            $subject="[stalt] Informations manquantes concernant le suivi d'alternants - ".$etapeSuivi;
            $to=$mailTuteur;
            $cc="Marius Bilasco <Marius.Bilasco@univ-lille1.fr>";

            echo "
                <p>".
                to_html($headersMail)."<br/>".
                to_html($msgMail)."<br/>".
                "</p><hr/>";;

            echo "<input type='hidden' name='tos[]' value=\"".$to."\"/>";
            echo "<input type='hidden' name='ccs[]' value=\"".$cc."\"/>";
            echo "<input type='hidden' name='subjects[]' value=\"".$subject."\"/>";
            echo "<input type='hidden' name='msgs[]' value=\"".$msgMail."\"/>";
           }
            
        ?>
        <input type="submit" value="Envoyer"/>
    </form>
    </div>
</div>