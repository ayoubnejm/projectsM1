<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once ("../secure/auth.php");
    require_once("../mail/sendMail.php");
    
if (!hasRole(ALL_RESP_ROLE))
      
      redirectAuth(null);
 ?>
<html>
   <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Confirmer envoi</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
    </head>
    <body>

        <h1>Mails à envoyer</h1>
<?php>
    $msgs=str_replace("\'","'",$_REQUEST["msgs"]);
    $tos=$_REQUEST["tos"];
    $ccs=$_REQUEST["ccs"];
    $subjects=$_REQUEST["subjects"];

    for ($i=0;$i<count($msgs);$i++)
    {

      $result=sendAuthenticatedMail($tos[$i],$ccs[$i],$subjects[$i],$msgs[$i]);
      //$result=FALSE;
      error_log($result);

      if ($result===TRUE) {
            echo "<p>E-mail envoyé avec succès à ",$tos[$i], " !</p>";
      }
      else
            /* message déja affiché par sendAuthenticatedMail */
            echo "<p>Pb. avec envoi!<br/>$result</p>";

    }

?>
</body>
</html>