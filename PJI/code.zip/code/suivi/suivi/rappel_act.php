<div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 1 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Situation du suivi</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>
        
        <SCRIPT src="<?php echo ABS_START_URL;?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL;?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL;?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL;?>/js/form.js" lang="javascript"></SCRIPT>

        <?php
            require_once(ABS_START_PATH."/dbmngt/connect.php");
            require_once(ABS_START_PATH."/dbmngt/queriesSuivi.php");
            require_once(ABS_START_PATH."/html/utils.php");

            $conn=doConnection();
            
            $etapeSuivi=$_REQUEST["etapeSuivi"];

            $formations=$_REQUEST["formation"];
            $formation="";

            for ($i=0;$i<count($formations);$i++)
              $formation.=",".$formations[$i];
            $formation=substr($formation,1);

            //echo $formation;
            $formationsArr=array("M1MIAGEFA","M2MIAGEFA","M1INFOFA","M2ESERVFA",
            "M2IAGLFA","M2MOCADFA","M2IVIFA","M2TIIRFA");

            $etapeSuiviArr=array("rencontreEtudiant","1ereVisite","missionSoutenance","2emeVisite");
            echo "<h1>Choisissez etape suivi et formation</h1>";

            echo "<form action='".ABS_START_URL."/index.php' method='post'>";
            echo "<input type='hidden' name='page' value='suivi/rappel_act'/>";
            echo "<font size='+1' style='bold'>Etape suivi :</font> <select name='etapeSuivi' onChange='javascript:submit()'>";
            for ($i=0;$i<count($etapeSuiviArr);$i++) {
              echo "<option value='".$etapeSuiviArr[$i]."'".
                  (strcmp($etapeSuivi,$etapeSuiviArr[$i])==0?"selected='selected'":"")
                .">".$etapeSuiviArr[$i]."</option>";
            }
            echo "</select><br/>";
            echo "<font size='+1' style='bold'>Formations</font><br/><table>";
            for ($i=0;$i<count($formationsArr);$i++) {
              if ($i%4==0) echo "<tr>";
              echo "<td><input type='checkbox' name='formation[]' value='".$formationsArr[$i].
                  "' ".(strpos($formation,$formationsArr[$i])>-1?"checked='checked'":"").
                  " onClick='javascript:submit()'/>".
                  $formationsArr[$i]."</td>";
              if ($i%4==3) echo "</tr>";
            }
            echo "</table><br/><input type='submit' value='MAJ'/>";
            echo "</form>";
            
            if ($etapeSuivi=="1ereVisite")
              $result=doQueryListe1eresVisitesPasSaisies($conn,$formation);
            else if ($etapeSuivi=="2emeVisite")
              $result=doQueryListe2emesVisitesPasSaisies($conn,$formation);
            else if ($etapeSuivi=="missionSoutenance")
              $result=doQueryListeMissionsSoutPasSaisies($conn,$formation);
            else if ($etapeSuivi=="rencontreEtudiant")
              $result=doQueryListeRencontresEtudiantPasSaisies($conn,$formation);
            else die("indiquer etapeSuivi");
            //$data=array("tuteur"=>array("formation"=>array("nom"=>array(),"mail"=>array())));

            echo "<h1>Liste tuteurs n'ayant pas rempli l'étape $etapeSuivi : </h1>";
            $tuteurs=array();
            $formations=array();
            $mails=array();

            $allMails="";

            $row=mysql_fetch_row($result);
            while ($row)
            {
              //echo "dealing with ".$row[1]." ".count($tuteurs)."<br/>";
              $tutNom=$row[1]; 
              $formation=$row[5];
              if (!array_key_exists($tutNom,$tuteurs)) {
                //echo "nv tut ".$tutNom."<br/>";
                $mails[$tutNom]=$row[2]; $allMails.=", ".$row[2];
                $tuteurs[$tutNom]=array($formation=>array(0=>array("nom"=>$row[3],"email"=>$row[4])));
              } else if (!array_key_exists($formation,$tuteurs[$tutNom]))
                {
                  //echo "nv formation ".$formation."<br/>";
                  $tuteurs[$tutNom][$formation]=array(0=>array("nom"=>$row[3],"email"=>$row[4]));
                }
              else {
               //echo "ajout étud ".$row[3]."<br/>";
               array_push($tuteurs[$tutNom][$formation],array("nom"=>$row[3],"email"=>$row[4]));
              }
              $row=mysql_fetch_row($result);
            }

            echo "<a onClick=\"javascript:checkAll('actionForm','selection[]',true);\"><font style='color:blue; text-decoration:underline;'>Tous</font></a> - ";
            echo "<a onClick=\"javascript:checkAll('actionForm','selection[]',false);\"><font style='color:blue; text-decoration:underline;'>Aucun</font></a>";

            $tutIT=array_keys($tuteurs);
            echo "<form action='".ABS_START_URL."/index.php' method='post' id='actionForm' >";
            echo "<input type='hidden' name='page' value='suivi/confirmerEnvoi_act'/>";
            echo "<input type='hidden' name='etapeSuivi' value='".$etapeSuivi."'/>";
            echo "<table border='1'>";
            for ($i=0;$i<count($tutIT);$i++)
            {
              $etuds="";
              echo "<tr><td><input type='checkbox' id='chkbox_$i' name='selection[]' value='".$i."'/>";
              echo "<input type='hidden' name='mailsTuteurs[]' value='".$mails[$tutIT[$i]]."'/>";
              echo "<input type='hidden' name='tuteurs[]' value='".$tutIT[$i]."'/>".$tutIT[$i]."</td><td><table>";

              //echo count($tuteurs[$tutIT[$i]])."<br/>";
              $formIT=array_keys($tuteurs[$tutIT[$i]]);
              for ($j=0;$j<count($formIT);$j++){
                $etuds.="\n--".$formIT[$j]."--";
                echo "<tr><td>".$formIT[$j]."</td><td><table>";
                for ($k=0;$k<count($tuteurs[$tutIT[$i]][$formIT[$j]]);$k++) {
                  echo "<tr><td>".$tuteurs[$tutIT[$i]][$formIT[$j]][$k]["nom"]."</td>";
                  //echo "<td>".$tuteurs[$tutIT[$i]][$formIT[$j]][$k]["email"]."</td>";
                  echo "</tr>";
                  $etuds.="\n - ".$tuteurs[$tutIT[$i]][$formIT[$j]][$k]["nom"];
                }
                $etuds.="\n";
                echo "</table></td></tr>";
              }
              echo "</tr></td></table></td></tr>";
              echo "<input type='hidden' name='etudiants[]' value='".$etuds."'/>";
            }
            echo "</table>";
            echo "<a onClick=\"javascript:checkAll('actionForm','selection[]',true);\"><font style='color:blue; text-decoration:underline;'>Tous</font></a> - ";
            echo "<a onClick=\"javascript:checkAll('actionForm','selection[]',false);\"><font style='color:blue; text-decoration:underline;'>Aucun</font></a>";
            echo "<br/><input type='submit' value='Notifier tuteurs'/>";
            echo "</form>";
            echo "<br/><h3>Mails tuteurs : </h3>".substr($allMails,1)."<br/>";
        ?>
    </body>
