<?php
require_once "../config/main.ini.php";
require_once ABS_START_PATH.'/html/utils.php';
require_once(ABS_START_PATH."/distance/calculDistance.php");

$nom = getParam('nom', '');
$prenom = getParam('prenom', '');
$civ = "Mr. / Mme / Mlle :";
$objet = getParam('objet', '');
$adresse = getParam('adresse', '');
$pays = getParam('pays', '');
$lieu = getParam('lieu', '');

$CV = getParam('cv', '');
$kmAller = getParam('kmaller', '');
$immatriculation = getParam('immatriculation', '');

$transportAller = getParam('transportAller', '');
$transportRetour = getParam('transportRetour', '');
$transportAllerEscale = getParam('TransportAllerEscale', '');
$transportRetourEscale = getParam('TransportRetourEscale', '');


$transportTrain = false;
$transportVoiture = false;
$transportAvion = false;
$transportTaxi = false;
$transportVoitureLocation = false;
switch ($transportAller) {
    case('Train'):$transportTrain = true;
        break;
    case('Voiture'):$transportVoiture = true;
        break;
    case('Avion'):$transportAvion = true;
        break;
    case('Taxi'):$transportTaxi = true;
        break;
    case('Voiture de location'):$transportVoitureLocation = true;
        break;
}

switch ($transportRetour) {
    case('Train'):$transportTrain = true;
        break;
    case('Voiture'):$transportVoiture = true;
        break;
    case('Avion'):$transportAvion = true;
        break;
    case('Taxi'):$transportTaxi = true;
        break;
    case('Voiture de location'):$transportVoitureLocation = true;
        break;
}
$escaleAller = getParam('EscaleAller', '');
$escaleAller = trim($escaleAller);

$escaleRetour = getParam('EscaleRetour', '');
$escaleRetour = trim($escaleRetour);

if ($escaleAller == 'on') {
    switch ($transportAllerEscale) {
        case('Train'):$transportTrain = true;
            break;
        case('Voiture'):$transportVoiture = true;
            break;
        case('Avion'):$transportAvion = true;
            break;
        case('Taxi'):$transportTaxi = true;
            break;
        case('Voiture de location'):$transportVoitureLocation = true;
            break;
    }
}
if ($escaleRetour == 'on') {
    switch ($transportRetourEscale) {
        case('Train'):$transportTrain = true;
            break;
        case('Voiture'):$transportVoiture = true;
            break;
        case('Avion'):$transportAvion = true;
            break;
        case('Taxi'):$transportTaxi = true;
            break;
        case('Voiture de location'):$transportVoitureLocation = true;
            break;
    }
}


$dateAller = getParam('dateAller', '');
$dateRetour = getParam('dateRetour', '');
$dateRetourDifferente = getParam('DateRetourDifferente', '');
$dateRetourDifferente = trim($dateRetourDifferente);



//Inversion date pour date française !!! 
$jour = $dateAller[8] . $dateAller[9];
$annee = $dateAller[0] . $dateAller[1] . $dateAller[2] . $dateAller[3];

$nb_jours = 0;
if ($dateRetourDifferente != 'on') {
    $dateRetour = $jour . "/" . $dateAller[5] . $dateAller[6] . "/" . $annee;
} else {
    //calcule de la duree du sejour 
    $d1 = new DateTime($dateAller);
    $d2 = new DateTime($dateRetour);
    $interval = $d1->diff($d2);
    $nb_jours = $interval->format('%a');

    //Inversion de la date retour en date française        
    $jourRetour = $dateRetour[8] . $dateRetour[9];
    $anneeRetour = $dateRetour[0] . $dateRetour[1] . $dateRetour[2] . $dateRetour[3];
    $dateRetour = $jourRetour . "/" . $dateRetour[5] . $dateRetour[6] . "/" . $anneeRetour;
}
$dateAller = $jour . "/" . $dateAller[5] . $dateAller[6] . "/" . $annee;

$arriverAller = getParam('arriverAller', '');
$arriverAller = str_replace('.', '', $arriverAller);
$arriverAller = trim($arriverAller);

$departDifferent = getParam('DepartDifferentLille1', '');
$departDifferent = trim($departDifferent);
if ($departDifferent == 'on') {
    $departAller = getParam('departAller', '');
    if ($transportVoiture) {
        //Calcule de la distance 
        $Distance = new calculDistance();
        $kmAller = $Distance->getDistance2($departAller, $arriverAller);
    }
} else {
    $departAller = getParam('departAllerParDefaut', '');
}

$departAller = trim($departAller);

$departRetour = getParam('departRetour', '');
$departRetour = str_replace('.', '', $departRetour);
$departRetour = trim($departRetour);

$frais = getParam('frais', '');
$frais = trim($frais);
$table1 = "
<table border=1 align=center>  
<tr > 
    <td border=0> <img src='logo.jpg' width=150 height=75 /></td>
    <td colspan=4 align=center >
    <H3> DEMANDE D'AUTORISATION DE  MISSION</H3>    
         ECRIRE LISIBLEMENT EN CARACTERE D'IMPRIMERIE
         <br/>
         <b> Attention :</b> Les demandes incompletes seront refus&eacute;es ;
           </td>
   
     <td colspan=2 align=center>N&deg; d'ordre de mission :<br/><br/>";

if (getParam('frais', '') == "true") {
    $table1.="<img src='case-a-cocher-selectionnee.gif'/> Avec frais pour LILLE1</td>";
} else {
    $table1.="<img src='case-a-cocher-selectionnee.gif'/> Sans frais pour LILLE1</td>";
}
$table1 .="</tr>";

//
/////////////////////////////////  Objet de la mission /////////////////////////////////////////////    
$table1 .="
<tr> 
    <td rowspan=5 align=center  bgcolor=#DAF2EF border=1 size=15><br/><b>OBJET <br/><br/>DE LA <br/><br/> MISSION</b></td>
    <td colspan=6 size=10>" . $civ . " NOM : <b>" . $nom . "</b> Pr&eacute;nom : <b>" . $prenom . "</b></td>
</tr>
 
  <tr>
  <td  colspan=6 size=10 >Objet : <b>" . $objet . "</b></td>
  </tr>

<tr> 
    
    <td colspan=4  size=10>LIEU(X) effectif(s) de la mission :<b>" . $lieu . "</b> <br/>
                                Adresse compl&egrave;te de la mission :<br/> <b>" . $adresse . "</b></td>
   <td colspan=2 size=10> Pays : <br/><b>" . $pays . "</b> </td>
  </tr>
  

  <tr>
  <td colspan=3 size=10>FRAIS D'INSCRIPTION :<br/> MONTANT : ..........</td>
    <td colspan=3 size=10> <img src='case-a-cocher.gif'/> avanc&eacute;s par le demandeur <br/> <img src='case-a-cocher.gif'/> par bon de commande <br/>(uniquement pour les organismes français)   </td>
  </tr>

<tr>
  <td colspan=6 bgcolor=#636767 size=10>Participation &agrave; une manifestation scientifique : <br/>joindre le programme complet et le bulletin d'inscription
compl&eacute;t&eacute; par le demandeur </td>
  </tr>
";

////////////////////////////////////Deroulement de la mission ////////////////////////////////////////////////////



$table1 .="
<tr>
<td rowspan=5 align=center  bgcolor=#DAF2EF border=1 size=15><b>D&Eacute;ROULEMENT<br/><br/>DE LA <br/><br/> MISSION</b>
<br/>&Agrave; remplir de
<br/>mani&egrave;re d&eacute;tail&eacute;e
<br/>pour toutes les
<br/>&eacute;tapes de votre
<br/>voyage
</td>
</tr>
<tr>
<td size=10 colspan=6 >
";
if ($transportTrain) {
    $table1 .="<img src='case-a-cocher-selectionnee.gif'/> Train ";
    if (getParam('premiere', '')) {
        $table1.="<img src='case-a-cocher-selectionnee.gif'/> 1&eacute;re <img src='case-a-cocher.gif'/> 2&egrave;me Je b&eacute;n&eacute;ficie d'une r&eacute;duction de <b>" . getParam('reductionTrain', '') . "</b> % au titre de <b>" . getParam('moyenReductionTrain', '')."</b>";
    } else {
        $table1.="<img src='case-a-cocher.gif'/> 1&eacute;re <img src='case-a-cocher-selectionnee.gif'/> 2&egrave;me Je b&eacute;n&eacute;ficie d'une r&eacute;duction de <b>" . getParam('reductionTrain', '') . "</b> % au titre de <b>" . getParam('moyenReductionTrain', '')."</b>";
    }
} else {
    $table1 .="<img src='case-a-cocher.gif'/> Train <img src='case-a-cocher.gif'/> 1&eacute;re <img src='case-a-cocher.gif'/> 2&egrave;me Je b&eacute;n&eacute;ficie d'une r&eacute;duction de.......... % au titre de .........";
}
if ($transportAvion) {
    $table1 .="<br/><img src='case-a-cocher-selectionnee.gif'/> Avion";
} else {
    $table1 .="<br/><img src='case-a-cocher.gif'/> Avion";
}
if ($transportVoiture) {
    $table1 .="<br/><img src='case-a-cocher-selectionnee.gif'/> V&eacute;hicule personnel Puissance fiscale <b>" . $CV . "</b> CV <br/>     Joindre copies carte grise + attestation assurance pour
1&eacute;re mission annuelle
<br/>Km Aller : <b>" . $kmAller . "</b> Immatriculation :<b>" . $immatriculation."</b>";
} else {
    $table1 .="<br/><img src='case-a-cocher.gif'/> V&eacute;hicule personnel Puissance fiscale ...... CV <br/> Joindre copies carte grise + attestation assurance pour
1&eacute;re mission annuelle
<br/>Km Aller : ...... Immatriculation : ......";
}
$table1 .="<br/> <small>(Je certifie que ma police d'assurances satisfait aux exigences l'article 34 du d&egrave;cret n&deg; 90.437)</small>";
if ($transportTaxi) {
    $table1 .="<br/><img src='case-a-cocher-selectionnee.gif'/> Taxi ";
} else {
    $table1 .="<br/><img src='case-a-cocher.gif'/> Taxi ";
}
if ($transportVoitureLocation) {
    $table1 .="<img src='case-a-cocher-selectionnee.gif'/> Location de voiture par Agence de voyages sur march&egrave;(Nbre de pers.:<b>" . getParam('nbPersVoitureLocation', '') . "</b>)";
} else {
    $table1 .="<img src='case-a-cocher.gif'/> Location de voiture par Agence de voyages sur march&egrave;(Nbre de pers.:.....)";
}
$table1 .="
</td>
</tr>
<tr>
<td align=center size=10>DATES <br/>(Aller-Retour)</td>
<td align=center size=10>DEPART DE</td>
<td align=center size=10>HORAIRE</td>
<td align=center size=10>ARRIVEE A</td>
<td align=center size=10>HORAIRE</td>
<td align=center size=10>TRANSPORT<br/>UTILISE</td>
</tr>
<tr >
<b>
<td height=130 size = 10>" . $dateAller . "<br/>";
if ($escaleAller != 'on' && $escaleRetour != 'on') {
    $table1 .="".$dateRetour . "</td>
<td height=130>" . $departAller . "<br/>" . $departRetour . "</td>
<td height=130>" . getParam('horaireDepartAller', '') . "<br/>" . getParam('horaireDepartRetour', '') . "</td>
<td height=130>" . $arriverAller . "<br/>" . $departAller . "</td>
<td height=130>" . getParam('horaireArriverAller', '') . "<br/>" . getParam('horaireArriverRetour', '') . "</td>
<td height=130>" . $transportAller . "<br/>" . $transportRetour . "</td>
</b></tr>";
} else if ($escaleAller == 'on' && $escaleRetour != 'on') {
    $table1 .= $dateAller . "<br/>" . $dateRetour . "</td>
<td   height=130>" . $departAller . "<br/>" . getParam('villeEscaleAller', '') . "<br/>" . $departRetour . "</td>
<td   height=130>" . getParam('horaireDepartAller', '') . "<br/>" . getParam('horaireDepartAllerEscale', '') . "<br/>" . getParam('horaireDepartRetour', '') . "</td>
<td   height=130>" . getParam('villeEscaleAller', '') . "<br/>" . $arriverAller . "<br/>" . $departAller . "</td>
<td   height=130>" . getParam('horaireArriverAller', '') . "<br/>" . getParam('horaireArriverAllerEscale', '') . "<br/>" . getParam('horaireArriverRetour', '') . "</td>
<td   height=130>" . $transportAller . "<br/>" . getParam('TransportAllerEscale', '') . "<br/>" . $transportRetour . "</td>
</b></tr>";
} else if ($escaleAller != 'on' && $escaleRetour == 'on') {
    $table1 .= $dateRetour . "<br/>" . $dateRetour . "</td>
<td   height=130>" . $departAller . "<br/>" . $departRetour . "<br/>" . getParam('villeEscaleRetour', '') . "</td>
<td   height=130>" . getParam('horaireDepartAller', '') . "<br/>" . getParam('horaireDepartRetour', '') . "<br/>" . getParam('horaireDepartRetourEscale', '') . "</td>
<td   height=130>" . $arriverAller . "<br/>" . getParam('villeEscaleRetour', '') . "<br/>" . $departAller . "</td>
<td   height=130>" . getParam('horaireArriverAller', '') . "<br/>" . getParam('horaireArriverRetour', '') . "<br/>" . getParam('horaireArriverRetourEscale', '') . "</td>
<td   height=130>" . $transportAller . "<br/>" . $transportRetour . "<br/>" . getParam('TransportRetourEscale', '') . "</td>
</b></tr>";
} else {
    $table1 .= $dateAller . "<br/>" . $dateRetour . "<br/>" . $dateRetour . "</td>
<td   height=130>" . $departAller . "<br/>" . getParam('villeEscaleAller', '') . "<br/>" . $departRetour . "<br/>" . getParam('villeEscaleRetour', '') . "</td>
<td   height=130>" . getParam('horaireDepartAller', '') . "<br/>" . getParam('horaireDepartAllerEscale', '') . "<br/>" . getParam('horaireDepartRetour', '') . "<br/>" . getParam('horaireDepartRetourEscale', '') . "</td>
<td   height=130>" . getParam('villeEscaleRetour', '') . "<br/>" . $arriverAller . "<br/>" . getParam('villeEscaleRetour', '') . "<br/>" . $departAller . "</td>
<td   height=130>" . getParam('horaireArriverAller', '') . "<br/>" . getParam('horaireArriverAllerEscale', '') . "<br/>" . getParam('horaireArriverRetour', '') . "<br/>" . getParam('horaireArriverRetourEscale', '') . "</td>
<td   height=130>" . $transportAller . "<br/>" . getParam('TransportAllerEscale', '') . "<br/>" . $transportRetour . "<br/>" . getParam('TransportRetourEscale', '') . "</td>
</b></tr>";
}

$table1 .="<tr>
<td colspan=6 size=10>OBSERVATIONS : <b>" . getParam('observations', '') . "</b> </td>
</tr>
";

////////////////////////////////////Prise en Charge de la mission ////////////////////////////////////////////////////



$table1 .="
<tr>
<td rowspan=3 align=center  bgcolor=#DAF2EF border=1 size=15><b><br/><br/>PRISE EN <br/>CHARGE DE<br/>LA MISSION</b></td>
</tr>
<tr>
<td border=1 colspan=2 size=10>DEMANDE D'AVANCE :   <br/>
                                TRANSPORT :          <br/>
                                S&Eacute;JOUR : <br/>
                                COLLOQUE :           <br/>
                                VISA :               </td>
<td colspan=1 border=1 size=10 >
<img src='case-a-cocher.gif'/> LILLE1<br/>
<img src='case-a-cocher-selectionnee.gif'/> LILLE1<br/>
<img src='case-a-cocher.gif'/> LILLE1<br/>
<img src='case-a-cocher.gif'/> LILLE1<br/>
<img src='case-a-cocher.gif'/> LILLE1
</td>

<td colspan=3 border=1 size=10> .................................<br/>
                               <img src='case-a-cocher.gif'/> Autre organisme (pr&eacute;sicer) :       .................<br/>
                               <img src='case-a-cocher.gif'/> Autre organisme (pr&eacute;sicer) :       .................<br/>
                               <img src='case-a-cocher.gif'/> Autre organisme (pr&eacute;sicer) :       .................<br/>
                               <img src='case-a-cocher.gif'/> Autre organisme (pr&eacute;sicer) :       .................</td>

</tr>

<tr>
<td colspan=6 size=10>nombre de repas compris dans l'inscription ou gratuis : 0 <br/>
    nombre de nuit comprises dans l'inscription ou gratuites : 0 <br/>
    nombre de repas dans un restaurant administrtatif ou assimil&eacute; : ..... <br/>
    nombre de nuits : <b>" . $nb_jours . "</b>  nombre de repas dans d'autre condition : .......
</td>
</tr>
";


////////////////////////////////////Imputation  ////////////////////////////////////////////////////



$table1 .="

<tr>
<td align=center  bgcolor=#DAF2EF border=1 size=15><b>IMPUTATION</b></td>
<td colspan=6 size=10> Centre financier : <img src='case-a-cocher.gif'/> 9476351  <img src='case-a-cocher.gif'/> 94763511  <img src='case-a-cocher.gif'/> 4554903  Domaine fonctionnel : .............. <br/>
                        Rubrique : ...................... Convention ou Action Sp&eacute;cifique : ........................</td>
</tr>


<tr>
<td colspan=2 size=7 >Le demandeur<br/>
Date : <b>" . date('d') . '/' . date('m') . '/' . date('Y') . "</b><br/>
Signature :
</td>
<td  colspan=5 size=10> Le responsable de la ligne de cr&eacute;dit<br/>
Date :<br/>
Signature :
</td>
</tr>
";


////////////////////////////////////Enregistrement////////////////////////////////////////////////////



$table1 .="
<tr>
<td rowspan=5 align=center  bgcolor=#DAF2EF border=1><b>Enregistrement</b></td>
</tr>

<tr>
<td colspan=1 height=30  >  </td>
<td colspan=2 height=30 align=center > TRANSPORT  </td>
<td colspan=2 height=30 align=center> INSCRIPTION </td>
<td colspan=1 height=30 align=center>  SEJOUR </td>
</tr>

<tr>
<td colspan=1 height=30> Commande  </td>
<td colspan=2 height=30>  </td>
<td colspan=2 height=30>  </td>
<td colspan=1 height=30>  </td>
</tr>

<tr>
<td colspan=1 height=30 > Avance </td>
<td colspan=2 height=30>  </td>
<td colspan=2 height=30>  </td>
<td colspan=1 height=30>  </td>
</tr>

<tr>
<td colspan=1 height=30>Montant total</td>
<td colspan=2 height=30>  </td>
<td colspan=2 height=30>  </td>
<td colspan=1 height=30>  </td>
</tr>
</table>
";

require_once(ABS_START_PATH.'/exportPDF/lib/html2pdf.class.php');
$html2pdf = new HTML2PDF('P', 'A4', 'fr');
$html2pdf->WriteHTML($table1);
$html2pdf->Output('OrdreDeMission.pdf');
?>