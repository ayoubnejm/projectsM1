<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once "../dbmngt/connect.php";

require_once "../secure/auth.php";

if (!hasRole(RESP_ROLE))
  die("Only for responsable persons here!");

$conn=doConnection();

$oldUID=$_POST["oldUID"];
$uid=$_POST["newUID"];
$mail=$_POST["mailLille1"];
if (strlen($oldUID) && strlen($uid) && strlen($mail)) {
  echo "Updating uid for : ".$oldUID." to new uid : ".$uid;

  $updateQuery="update fa_etudiant set etudCle='$uid', mailLille1='$mail' where etudCle='$oldUID';";
  error_log($updateQuery);
  mysql_query($updateQuery,$conn);
  $updateQuery="update contrat set etudRef='$uid' where etudRef='$oldUID';";
  error_log($updateQuery);
  mysql_query($updateQuery,$conn);
  echo " with address $mail done <br/>";
} else
 echo "How did you get here? Invalid params!"

?>
