<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once ("../secure/auth.php");
if (!hasRole(RESP_ROLE))
  die("Only for responsable persons here!");


require_once (ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/ldap/ldap.php");
require_once (ABS_START_PATH."/dbmngt/queriesLDAP.php");

$oldUID=$_REQUEST["oldUID"];
$newUID=$_REQUEST["newUID"];
$mail=$_REQUEST["mail"];

if (!(strlen($oldUID)>0 && strlen($newUID)>0 && strlen($mail)>0)) {
	die("Tu dois à tout prix indiquer l'ancien UID, le nouveau UID et l'email ...");
}

$conn=doConnection();
echo "Changement de $oldUID en $uid avec mail : $mail ....";
if (doQueryUpdateUID($oldUID,$newUID,$mail,$conn))
    echo "<font color='green'> OK <br/></font>";
else 
    echo "<font color='red'> Echec <br/></font>";
?>
