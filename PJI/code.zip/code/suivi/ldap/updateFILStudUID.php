<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once ("../dbmngt/connect.php");
require_once ("../dbmngt/queriesLDAP.php");
require_once ("../secure/auth.php");
require_once ("../ldap/ldap.php");


if (!hasRole(RESP_ROLE))
  die("Only for responsable persons here!");

$conn=doConnection("fil_dept");

$oldUID=$_POST["oldUID"];
$uid=$_POST["newUID"];
$mail=$_POST["mailLille1"];

error_log("changing $oldUID to $uid with $mail ! ");
if (strlen($oldUID) && strlen($uid) ) {
  echo "Updating uid for : ".$oldUID." to new uid : ".$uid." with address $mail -> ";

  if (doQueryUpdateUID($oldUID,$uid,$mail,$conn))
    echo "<font color='green'>  done <br/></font>";
  else echo "<font color='red'> Echec <br/></font>";

} else
 echo "How did you get here? Invalid params!"

?>
