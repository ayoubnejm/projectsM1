<?php

function checkEtudMail($email)
{
  $server = "ldaphost.fil.univ-lille1.fr";

  $ds=ldap_connect($server);

  if ($ds==0)
  {
    echo "<font color='red'>Impossible de se connecter au ldap et vérifier l'@ email.</font>";
    return false;
  }
  $racine = "dc=fil.univ-lille1,dc=fr";
  $filter = "mailRoutingAddress=".$email;
  $restriction = array("mail");
  $sr=ldap_search($ds,$racine,$filter,$restriction);
  $info=ldap_get_entries($ds,$sr);
  $cnt=$info["count"];
  ldap_close($ds);
  
  //echo $cnt;

  return ($cnt>0);

}

function checkULilleProfMail($email)
{
  $server = "ldap.univ-lille1.fr";

  $ds=ldap_connect($server);

  if ($ds==0)
  {
    echo "<font color='red'>Impossible de se connecter au ldap et vérifier l'@ email.</font>";
    return false;
  }
  $racine = "ou=people,dc=univ-lille1,dc=fr";
  $filter = "mail=".$email;
  $restriction = array("mail");
  $sr=ldap_search($ds,$racine,$filter,$restriction);
  $info=ldap_get_entries($ds,$sr);
  echo $cnt;
  $cnt=$info["count"];
  ldap_close($ds);

  //echo $cnt;

  return ($cnt>0);

}

function checkLIFLProfMail($email)
{
  $server = "ldap.lifl.fr";

  $ds=ldap_connect($server);

  if ($ds==0)
  {
    echo "<font color='red'>Impossible de se connecter au ldap et vérifier l'@ email.</font>";
    return false;
  }
  $racine = "ou=people,dc=lifl,dc=fr";
  $filter = "mailLocalAddress=".$email;
  $restriction = array("mail");
  $sr=ldap_search($ds,$racine,$filter,$restriction);
  $info=ldap_get_entries($ds,$sr);
  echo $cnt;
  $cnt=$info["count"];
  ldap_close($ds);

  //echo $cnt;

  return ($cnt>0);

}

function getEtudMail($uid)
{
  $server = "ldap.univ-lille1.fr";

  $ds=ldap_connect($server);

  if ($ds==0)
  {
    echo "<font color='red'>Impossible de se connecter au ldap et vérifier l'@ email.</font>";
    return false;
  }
  $racine = "ou=people,dc=univ-lille1,dc=fr";
  $filter = "uid=".$uid;
  $restriction = array("mail");
  $sr=ldap_search($ds,$racine,$filter,$restriction);
  $info=ldap_get_entries($ds,$sr);
  if (isset($info[0]['mail'])) $mail=$info[0]['mail'][0]; else $mail=false;

  ldap_close($ds);

  return $mail;

}

function getEtudMailAndUIDByName($nom,$prenom)
{
  $server = "ldap.univ-lille1.fr";

  $ds=ldap_connect($server);

  if ($ds==0)
  {
    echo "<font color='red'>Impossible de se connecter au ldap et vérifier l'@ email.</font>";
    return false;
  }
  $racine = "ou=people,dc=univ-lille1,dc=fr";
  $filter = "(&(sn=".$nom.")(givenName=".$prenom."))";
  $restriction = array("uid","mail","supannAffectation","ustlFC");
  $sr=ldap_search($ds,$racine,$filter,$restriction);
  $info=ldap_get_entries($ds,$sr);
  $res=$info;

  ldap_close($ds);

  return $res;
}

function getEtudMailAndUIDByNameWithApprox($nom,$prenom)
{
    $res=getEtudMailAndUIDByName(

      strtolower($nom),
      str_replace(
          array('é','è','ë','ï','î','û','ü','à','ä'),
          array('e','e','e','i','i','u','u','a','a'),
          $prenom
      )
    );

    $cnt=$res["count"];
    if ($cnt==0) {
      echo ". <font color='red'>Student not found... Possible cause accents or compound names.</font><br/>  ";
      if (strcmp($prenom,'*')!=0) {
        echo "- Trying only with lastname<br/>";
        return getEtudMailAndUIDByNameWithApprox($nom,'*');
      } else {
        echo " ... still no answer found!<br/>";
        return array();
      }
      
    } else if (($cnt>1) || ($prenom=='*')) {
        // "<br/> Multiple candidates ($cnt) <br/><ul>";

        $arr=array();
        for ($i=0;$i<$cnt;$i++) {
            $arr[]=array("mail"=>$res[$i]['mail'][0],
                        "uid"=>($res[$i]['uid'][0]),
                        "details"=>$res[$i]['supannaffectation'][0]);
        }
      } else {

          $mail=$res[0]['mail'][0];
          $uid=$res[0]['uid'][0];
          
          $arr=array();
          $arr[]=array("mail"=>$mail,"uid"=>$uid,"details"=>"OK");
          
      }
      return $arr;
}
?>
