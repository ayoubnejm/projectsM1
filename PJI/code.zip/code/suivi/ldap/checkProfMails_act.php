<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once (ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/ldap/ldap.php");


echo "<div id='cadre_0' class='contenu-item2 on'>Mails having some problems : ";

$query="(select mail from membre)";
$conn=doConnection();
$result=mysql_query($query,$conn);
error_log($query." - ".mysql_error());

$row=mysql_fetch_row($result);

while ($row)
{ 
  //if (!checkProfMail($row[0]))
  if ((strstr($row[0],"lifl.fr") && !checkLIFLProfMail($row[0]))
      || (strstr($row[0],"univ-lille1.fr") && !checkULilleProfMail($row[0]))
      )
    echo $row[0]." Wrong address <br/>";

  $row=mysql_fetch_row($result);
    
}
echo "</div>";

?>
