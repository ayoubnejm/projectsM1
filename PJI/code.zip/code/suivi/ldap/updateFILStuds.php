<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once ABS_START_PATH."/secure/auth.php";

if (!hasRole(RESP_ROLE))
  die("Only for responsable persons here!");


require_once (ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/ldap/ldap.php");
require_once (ABS_START_PATH."/dbmngt/queriesLDAP.php");


function updateAllUIDs() {
  $query="(select distinct etudCle,nom,prenom from etudiant
            where
                etudCle like 'l3%fa%' or 
                    etudCle like 'miage%' or
                    etudCle like 'm2%' or
                    etudCle like 'm1%' or
                    etudCle like 'l3%fi%'
          )";
  
  $conn=doConnection("fil_dept");
  $result=mysql_query($query,$conn);

  echo "<h1>Looking for students not having Lille 1 UID's in FA application</h1>";
  $row=mysql_fetch_row($result);

  while ($row)
  {
    updateUID($row[0],$row[1],$row[2],$conn);

    $row=mysql_fetch_row($result);

  }

  mysql_close($conn);
}

function updateUID($oldUID,$nom,$prenom,$conn)
{

    echo "Updating uid for : ".$nom." ".$prenom;
    $res=getEtudMailAndUIDByName(

      strtolower($nom),
      str_replace(
          array('é','è','ë','ï','î'),
          array('e','e','e','i','i'),
          $prenom
      )
    );
    $cnt=$res["count"];
    if ($cnt==0) {
      echo ". <font color='red'>Student not found... Possible cause accents or compound names.</font><br/>  ";
      if (strcmp($prenom,'*')!=0) {
        echo "- Trying only with lastname<br/>";
        updateUID($oldUID,$nom,'*',$conn);
      } else {
        echo " ... still no answer found!<br/>";
      }
      return;
    } else if (($cnt>1) || ($prenom=='*')) {
        echo "<br/> Multiple candidates ($cnt) <br/><ul>";
        /*for ($i=0;$i<$res[0]["count"];$i++) echo $res[0][$i]." - ";
        echo "<br/>";*/
        for ($i=0;$i<$cnt;$i++) {
          echo "<li><form target='_blank' action='".ABS_START_URL."/ldap/updateFILStudUID.php' method='post'>";
            if (isset($res[$i][4])) echo $res[$i][4]; else echo "___";
            echo " - ";
            echo $res[$i]['uid'][0]." - ".(isset($res[$i]['mail'])?$res[$i]['mail'][0]:"_no mail_")." - ".
              (isset($res[$i]['supannaffectation'])?$res[$i]['supannaffectation'][0]:"_sans affectation_")." - ".
              (isset($res[$i]['ustlfc'])?($res[$i]['ustlfc'][0]):" FI ou FA");
            echo "<input type='hidden' name='oldUID' value='$oldUID'/>";
            echo "<input type='hidden' name='newUID' value='".$res[$i]["uid"][0]."'/>";
            echo "<input type='hidden' name='mailLille1' value='".isset($res[$i]['mail'])?$res[$i]['mail'][0]:""."'/>";
            echo "<input type='submit' value='This is the one!'/>";
          echo "</form></li>";
        }
        echo "</ul>";
      } else {

          $mail=$res[0]['mail'][0];
          $uid=$res[0]['uid'][0];
          echo "Updating uid for : ".$oldUID." to new uid : ".$uid." with address $mail -> ";

          if (doQueryUpdateUID($oldUID,$uid,$mail,$conn))
            echo "<font color='green'>  done <br/></font>";
          else echo "<font color='red'> Echec <br/></font>";
      }

}
?>
