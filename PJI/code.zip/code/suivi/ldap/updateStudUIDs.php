<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once ABS_START_PATH."/secure/auth.php";

if (!hasRole(RESP_ROLE))
  die("Only for responsable persons here!");


require_once (ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/ldap/ldap.php");

function updateAllUIDs($yearRef=null) {
  if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];
  $query="(select etudCle, nom, prenom from
              etudiant inner join etudiant_groupe on
                etudCle=etudRef and annee=$yearRef
            where
                etudCle like concat(lower(groupeRef),'%')
          )";
  $conn=doConnection();
  $result=mysql_query($query,$conn);
  error_log($query." - ".mysql_error());
  echo "<div id='cadre_0' class='contenu-item2 on'><h1>Looking for students not having Lille 1 UID's</h1>";
  $row=mysql_fetch_row($result);

  while ($row)
  {
    updateUID($row[0],$row[1],$row[2],$conn);

    $row=mysql_fetch_row($result);


  }
  echo "</div>";
  mysql_close($conn);
}

function updateUID($oldUID,$nom,$prenom,$conn)
{
    
    echo "Updating uid for : ".$nom." ".$prenom;
    $res=getEtudMailAndUIDByName(
      
      strtolower($nom),
      str_replace(
          array('é','è','ë','ï','î'),
          array('e','e','e','i','i'),
          $prenom
      )
    );
    $cnt=$res["count"];
    if ($cnt==0) {
      echo ". <font color='red'>Student not found... Possible cause accents or compound names.</font><br/>  ";
      if (strcmp($prenom,'*')!=0) {
        echo "- Trying only with lastname<br/>";
        updateUID($oldUID,$nom,'*',$conn);
      } else {
        echo " ... still no answer found!<br/>";
      }
      return;
    } else if (($cnt>1) || ($prenom=='*')) {
        echo "<br/> Multiple candidates ($cnt) <br/><ul>";
        /*for ($i=0;$i<$res[0]["count"];$i++) echo $res[0][$i]." - ";
        echo "<br/>";*/
        for ($i=0;$i<$cnt;$i++) {
          echo "<li><form target='_blank' action='".ABS_START_URL."/ldap/updateUID.php' method='post'>";
            echo $res[$i][4];
            echo " - ";
            echo $res[$i]['uid'][0]." - ".$res[$i]['mail'][0]." - ".
              $res[$i]['supannaffectation'][0]." - ".
              $res[$i]['ustlfc'][0];
            echo "<input type='hidden' name='oldUID' value='$oldUID'/>";
            echo "<input type='hidden' name='newUID' value='".$res[$i]["uid"][0]."'/>";
            echo "<input type='hidden' name='mailLille1' value='".$res[$i]["mail"][0]."'/>";
            echo "<input type='submit' value='This is the one!'/>";
          echo "</form></li>";
        }
        echo "</ul>";
      } else {

          $mail=$res[0]['mail'][0];
          $uid=$res[0]['uid'][0];
          
          $updateQuery="update etudiant set etudCle='$uid', mailLille1='$mail' where etudCle='$oldUID';";
          mysql_query($updateQuery,$conn);
          error_log($updateQuery." - ".mysql_error());
          $updateQuery="update etudiant_groupe set etudRef='$uid' where etudRef='$oldUID';";
          mysql_query($updateQuery,$conn);
          error_log($updateQuery." - ".mysql_error());
          $updateQuery="update contrat set etudRef='$uid' where etudRef='$oldUID';";
          mysql_query($updateQuery,$conn);
          error_log($updateQuery." - ".mysql_error());
          echo "<font color='green'> with address $mail done <br/></font>";
      }

}
?>
