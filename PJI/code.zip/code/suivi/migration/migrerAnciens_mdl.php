<?php
require_once (ABS_START_PATH."/dbmngt/queriesMigration.php");
//Auteur JTA
header("Content-Type: text/xml");
require_once '../dbmngt/connect.php';

echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
echo "<list>";

$groupeRef = (isset($_POST["groupeRef"])) ? htmlentities($_POST["groupeRef"]) : NULL;
$yearRef = (isset($_POST["yearRef"])) ? htmlentities($_POST["yearRef"]) : NULL;

if ($groupeRef) {
    $conn = doConnection();
    $result = doQueryListEtudiantsAMigrerParGroupe($conn,$groupeRef,$yearRef);

    $row = mysql_fetch_row($result);

    while ($row)
    {
        echo "<item id=\"etudNomCle\" etudNom=\"" . $row[0]." ".$row[1]. " (".$row[2].")\" etudRef=\"".$row[2]."\" />";
        $row = mysql_fetch_row($result);
    }
}

echo "</list>";
?>
