<?php
    require '../secure/auth.php';

    function generateFormSelectionEtudiantAnnee($nom,$action,$annee) {
      echo "
        <form id='".$nom."' name='".$nom."' >
        Formation (Groupe) $annee/".($annee+1)."
         ";
          $keysValues = constructGrantedGroupesKeys(true);
          $keys = $keysValues["keys"];
          $values = $keysValues["values"];
          createSelectWithOnChange("groupeRef", $keys, $values, 0, "javascript:reloadStudentListByGroupYear('".$nom."');");
        ?>
        <br/>
        <select name="etudList" multiple="true" style="width:95%" size="10">
          <option/>
        </select>
        <input type="hidden" value="<?php echo $annee; ?>" name="yearRef"/>
        
        <center><input type="button" name="action"
                 value="<?php echo $action;?>" onclick="javascript:doAction()"/>
        </center>
      </form>
<?php
    }
    
    if (!hasRole(RESP_ROLE))
        redirectAuth();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Migration</title>
        <!--link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" /-->
        <link rel="stylesheet" type="text/css" href="../style/style.css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
        <SCRIPT src="./migrerAnciens_ctrl.js" lang="javascript"></SCRIPT>
    </head>
  <body><div id="acces">
  <div>
	<div id="englobe_acces">

		</div>
	</div>
</div>
<div class="contenu">
    <?php require_once(ABS_START_PATH."/charteFIL/mainTop.php"); ?>
	<div id="main">
		<div id="left"></div>
		<div id="center">
    <h2>Migration étudiants </h2>
    <table width="80%" align="center">
        <tr>
          <td>
            <div>
              <?php generateFormSelectionEtudiantAnnee("anneeCourante","migrer",$_SESSION[REF_YEAR]); ?>
            </div>
          </td>
          <td>
            <div>
              <?php generateFormSelectionEtudiantAnnee("anneeSuivante","effacer",$_SESSION[REF_YEAR]+1); ?>
            </div>
          </td>
        </tr>
      </table>
    </div>
  </div>
</div>
  </body>
</html>
