-- MySQL dump 10.13  Distrib 5.1.49, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: fa_tutorat11
-- ------------------------------------------------------
-- Server version	5.1.49-3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contrat`
--

DROP TABLE IF EXISTS `contrat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contrat` (
  `etudRef` varchar(50) COLLATE utf8_bin NOT NULL,
  `tuteurRef` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `referentRef` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `opcaRef` varchar(20) COLLATE utf8_bin DEFAULT 'inconnue',
  `typeContrat` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `debutContrat` date DEFAULT NULL,
  `finContrat` date DEFAULT NULL,
  `accordOPCA` date DEFAULT NULL,
  `signatureContrat` date DEFAULT NULL,
  `alternanceCle` varchar(20) COLLATE utf8_bin NOT NULL,
  `sudesRef` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `notifAttribTuteur` int(11) DEFAULT NULL,
  PRIMARY KEY (`alternanceCle`),
  UNIQUE KEY `alternanceCle` (`alternanceCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contrat`
--

LOCK TABLES `contrat` WRITE;
/*!40000 ALTER TABLE `contrat` DISABLE KEYS */;
INSERT INTO `contrat` VALUES ('benjamin.bertein',NULL,'m1infofa1BB0R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m1infofa1BB0A',NULL,NULL),('maxime.colmant','lepallec','m1infofa1CM2R','fafiec',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1infofa1CM2A',NULL,1),('nicolas1.cousin','kuttler','m1infofa1CN3R','fafiec',NULL,'2011-09-01','2013-09-13','0000-00-00','2011-07-19','m1infofa1CN3A',NULL,1),('amaury.david','marquet','m1infofa1DA4R','fafiec',NULL,'0000-00-00','0000-00-00','0000-00-00','2011-09-01','m1infofa1DA4A',NULL,1),('kevin.defives','tison','m1infofa1DK5R','__sans opca__',NULL,'2011-09-09','2013-07-08','0000-00-00','2011-09-08','m1infofa1DK5A',NULL,1),('guillaume.gallant','jourdan','m1infofa1GG6R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m1infofa1GG6A',NULL,1),('kevin1.guilbert','lepallec','m1infofa1GK7R','agefos_pme',NULL,'2011-09-08','2013-08-30','2011-09-09','2011-09-05','m1infofa1GK7A',NULL,1),('geoffrey.hecht','salson','m1infofa1HG8R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1infofa1HG8A',NULL,1),('joffray.hochart',NULL,'m1infofa1HJ0R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m1infofa1HJ0A',NULL,NULL),('vincent.herbulot','rouvoy','m1infofa1HV9R','fafiec',NULL,'2011-09-05','0000-00-00','0000-00-00','2011-09-05','m1infofa1HV9A',NULL,1),('florian.ledoux','tison','m1infofa1LF3R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1infofa1LF3A',NULL,1),('kevin.labat','pupin','m1infofa1LK1R','fafiec',NULL,'2011-09-05','2013-09-05','2011-08-13','2011-09-05','m1infofa1LK1A',NULL,1),('valentin.lecerf','boulet','m1infofa1LV2R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1infofa1LV2A',NULL,1),('benoit1.petit','jourdan','m1infofa1PB6R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1infofa1PB6A',NULL,1),('m1infofa1RH29','marquet','m1infofa1RH29R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1infofa1RH29A',NULL,1),('m1infofa1RH30','','m1infofa1RH30R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m1infofa1RH30A',NULL,NULL),('m1infofa11','marquet','m1infofa1RH7R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1infofa1RH7A',NULL,1),('matthieu.ardon','pupin','m1miagefa1AM0R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1miagefa1AM0A',NULL,1),('justine.becuwe','lebbe','m1miagefa1BJ1R','forco',NULL,'2011-09-12','2013-08-31','0000-00-00','2011-09-08','m1miagefa1BJ1A',NULL,1),('antoine.craske','yroos','m1miagefa1CA4R','forco',NULL,'2011-09-01','2013-07-01','2011-08-29','2011-08-11','m1miagefa1CA4A',NULL,1),('florian1.carpentier','lebbe','m1miagefa1CF2R','__sans opca__',NULL,'2011-09-01','2013-08-31','0000-00-00','0000-00-00','m1miagefa1CF2A',NULL,1),('gael.ceriez','bilasco','m1miagefa1CG3R','fafiec',NULL,'2011-09-01','2013-07-01','2011-09-01','2011-09-02','m1miagefa1CG3A',NULL,1),('amelie.devincke','roos','m1miagefa1DA8R','fafiec',NULL,'2011-09-12','2013-07-02','0000-00-00','2011-09-08','m1miagefa1DA8A',NULL,1),('guillaume.despois','yroos','m1miagefa1DG6R','fafiec',NULL,'2011-08-01','0000-00-00','2011-07-29','2011-08-01','m1miagefa1DG6A',NULL,1),('maxime.demeestere','lebbe','m1miagefa1DM5R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1miagefa1DM5A',NULL,1),('marine.desprez','roos','m1miagefa1DM7R','syntec',NULL,'2011-09-12','2013-07-02','0000-00-00','2011-07-21','m1miagefa1DM7A',NULL,1),('tarik.djebien','routier','m1miagefa1DT9R','fafiec',NULL,'2011-09-12','2013-07-31','2011-09-29','2011-09-07','m1miagefa1DT9A',NULL,1),('diane.gombert','jourdan','m1miagefa1GD0R','fafiec',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1miagefa1GD0A',NULL,1),('louis.masson','bilasco','m1miagefa1ML3R','fafiec',NULL,'2011-09-06','2013-09-05','2011-00-00','2011-08-20','m1miagefa1ML3A',NULL,1),('melody.mascot','roos','m1miagefa1MM1R','forco',NULL,'2011-09-05','2013-09-13','2011-09-29','2011-09-02','m1miagefa1MM1A',NULL,1),('michael.mascret','caronc','m1miagefa1MM2R','fafiec',NULL,'2011-09-12','2013-07-31','2011-07-19','2011-06-27','m1miagefa1MM2A',NULL,1),('noe.pamula','lebbe','m1miagefa1PN4R','__sans opca__',NULL,'2011-09-05','2013-07-05','0000-00-00','2011-07-20','m1miagefa1PN4A',NULL,1),('se.rakotobe','marvie','m1miagefa1RS5R','__sans opca__',NULL,'2011-09-01','2013-08-31','0000-00-00','2011-09-01','m1miagefa1RS5A',NULL,1),('kevin.sansen','plenacos','m1miagefa1SK6R','syntec',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m1miagefa1SK6A',NULL,1),('gauthier.bialais','marquet','m2eservfa1BG1R','fafiec',NULL,'2011-09-05','2011-09-04','0000-00-00','0000-00-00','m2eservfa1BG1A',NULL,1),('khaled.boukercha','lhoussai','m2eservfa1BK2R','fafiec',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2eservfa1BK2A',NULL,1),('marine.becker','plenacos','m2eservfa1BM0R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2eservfa1BM0A',NULL,1),('charles.de-potter','plenacos','m2eservfa1DC4R','__sans opca__',NULL,'2010-09-01','2012-09-01','0000-00-00','0000-00-00','m2eservfa1DC4A',NULL,1),('guillaume.dufosset','jourdan','m2eservfa1DG5R','fafiec',NULL,'2011-09-05','2012-09-07','0000-00-00','2011-09-01','m2eservfa1DG5A',NULL,1),('yves.dekerle','lhoussai','m2eservfa1DY3R','fafiec',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2eservfa1DY3A',NULL,1),('francois.gruchala','seinturi','m2eservfa1GF6R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2eservfa1GF6A',NULL,1),('cecile.herbelin','seinturi','m2eservfa1HC7R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2eservfa1HC7A',NULL,1),('ludwig.hottois','jourdan','m2eservfa1HL8R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2eservfa1HL8A',NULL,1),('jessy.lavorel','kuttler','m2eservfa1LJ21R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2eservfa1LJ21A',NULL,1),('clement.nicolet','seinturi','m2eservfa1NC9R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2eservfa1NC9A',NULL,1),('sylvain.thery','duchien','m2eservfa1TS0R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2eservfa1TS0A',NULL,2),('romain.vandecaveye','noe','m2eservfa1VR1R','__sans opca__',NULL,'2010-09-01','2012-08-03','0000-00-00','2010-07-01','m2eservfa1VR1A',NULL,1),('pierre.watine','kuttler','m2eservfa1WP2R','opca_banques',NULL,'2010-09-15','2012-07-30','0000-00-00','0000-00-00','m2eservfa1WP2A',NULL,1),('boubacar-mainassara1','marvie','m2iaglfa1BA1R','__sans opca__',NULL,'2011-09-19','2012-09-07','0000-00-00','2011-09-15','m2iaglfa1BA1A',NULL,1),('mathieu.bon',NULL,'m2iaglfa1BM2R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2iaglfa1BM2A',NULL,NULL),('quentin.bezsilko','jourdan','m2iaglfa1BQ0R','__sans opca__',NULL,'2011-09-05','2012-09-14','0000-00-00','2011-08-04','m2iaglfa1BQ0A',NULL,1),('benoit.cornu','routier','m2iaglfa1CB2R','fafiec',NULL,'2010-09-01','2012-08-31','2010-09-01','2010-09-01','m2iaglfa1CB2A',NULL,1),('antoine.donnez','bilasco','m2iaglfa1DA4R','__sans opca__',NULL,'2011-10-03','2011-09-30','0000-00-00','2011-09-30','m2iaglfa1DA4A',NULL,1),('david.desquiens','bilasco','m2iaglfa1DD3R','afdas',NULL,'2005-09-11','2014-09-12','0000-00-00','2002-09-11','m2iaglfa1DD3A',NULL,1),('arnaud.foraison','kuttler','m2iaglfa1FA6R','fafiec',NULL,'2011-09-01','0000-00-00','0000-00-00','2011-07-22','m2iaglfa1FA6A',NULL,1),('julien.facon','lepallec','m2iaglfa1FJ5R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2iaglfa1FJ5A',NULL,1),('ladislas.gabriel','marvie','m2iaglfa1GL7R','forco_cogeform',NULL,'2011-09-01','2012-09-14','2011-09-01','2011-09-01','m2iaglfa1GL7A',NULL,1),('thibault.havez','lepallec','m2iaglfa1HT8R','__sans opca__',NULL,'2010-09-09','2011-06-12','2011-09-08','2010-09-06','m2iaglfa1HT8A',NULL,1),('kevin.lorthiois','marquet','m2iaglfa1LK9R','__sans opca__',NULL,'2010-09-01','2012-08-31','2010-09-01','2010-09-01','m2iaglfa1LK9A',NULL,1),('alexis.puskarczyk','lepallec','m2iaglfa1PA0R','__sans opca__',NULL,'2011-09-01','2012-09-14','2011-08-12','2011-07-21','m2iaglfa1PA0A',NULL,1),('kevin.senechal','rouvoy','m2iaglfa1SK1R','fafiec',NULL,'2011-08-08','2012-09-14','2011-07-16','2011-06-18','m2iaglfa1SK1A',NULL,1),('romain.torond','duchien','m2iaglfa1TR3R','__sans opca__',NULL,'2011-09-22','2012-08-31','0000-00-00','2011-09-12','m2iaglfa1TR3A',NULL,1),('francois.boissier','lebbe','m2miagefa1BF0R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2miagefa1BF0A',NULL,1),('anthony.copin','pupin','m2miagefa1CA3R','__sans opca__',NULL,'2010-09-01','2011-08-31','0000-00-00','0000-00-00','m2miagefa1CA3A',NULL,1),('charles.christiaens','pupin','m2miagefa1CC2R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2miagefa1CC2A',NULL,1),('joseph.cardon','jourdan','m2miagefa1CJ1R','fafiec',NULL,'2011-08-29','2012-07-03','0000-00-00','2011-08-04','m2miagefa1CJ1A',NULL,1),('amand.dupretz','roos','m2miagefa1DA9R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2miagefa1DA9A',NULL,1),('cindy.decoster','kuttler','m2miagefa1DC6R','fafiec',NULL,'2010-09-01','0000-00-00','0000-00-00','0000-00-00','m2miagefa1DC6A',NULL,1),('jonathan.deleberghe','lebbe','m2miagefa1DJ7R','forco',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2miagefa1DJ7A',NULL,1),('nicolas.deblock','yroos','m2miagefa1DN5R','fafiec',NULL,'2011-09-01','2012-08-31','0000-00-00','2011-08-02','m2miagefa1DN5A',NULL,1),('simon.dib','rouvoy','m2miagefa1DS8R','fafiec',NULL,'2010-09-06','2012-07-03','0000-00-00','2010-09-06','m2miagefa1DS8A',NULL,1),('thomas.daghelet','marvie','m2miagefa1DT4R','fafiec',NULL,'2010-09-01','2012-08-31','0000-00-00','0000-00-00','m2miagefa1DT4A',NULL,1),('celine.gombaud','yroos','m2miagefa1GC1R','fafiec',NULL,'2011-09-12','2012-07-31','2011-07-11','2011-06-23','m2miagefa1GC1A',NULL,1),('manuel.giles','bossut','m2miagefa1GM0R','fafiec',NULL,'2011-09-12','2012-09-07','0000-00-00','2011-09-05','m2miagefa1GM0A',NULL,1),('rudi.leroy','roos','m2miagefa1LR2R','opcalia',NULL,'2011-09-08','2012-09-07','0000-00-00','0000-00-00','m2miagefa1LR2A',NULL,1),('lyes.medjoudj','lebbe','m2miagefa1ML3R','__sans opca__',NULL,'2011-09-12','2012-07-03','0000-00-00','2011-09-06','m2miagefa1ML3A',NULL,1),('elise.picavet','jourdan','m2miagefa1PE4R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2miagefa1PE4A',NULL,1),('kevin.portaux','bossut','m2miagefa1PK5R','__sans opca__',NULL,'2011-09-01','2012-07-31','0000-00-00','2011-07-03','m2miagefa1PK5A',NULL,1),('remi.pourchelle','bilasco','m2miagefa1PR6R','agefos_pme',NULL,'2010-09-10','2012-09-07','2010-09-27','2010-09-03','m2miagefa1PR6A',NULL,1),('cyril.templeux','bilasco','m2miagefa1TC7R','fafiec',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2miagefa1TC7A',NULL,1),('julien.thilliez','lebbe','m2miagefa1TJ8R','agefos_pme',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2miagefa1TJ8A',NULL,1),('sebastien.velay','plenacos','m2miagefa1VS9R','forco',NULL,'2010-09-01','2012-07-15','0000-00-00','0000-00-00','m2miagefa1VS9A',NULL,1),('cyril.wirth','caronc','m2miagefa1WC0R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2miagefa1WC0A',NULL,1),('g.wojtaszewski','bilasco','m2miagefa1WG1R','agecif_ieg',NULL,'2011-09-12','2012-09-11','0000-00-00','0000-00-00','m2miagefa1WG1A',NULL,1),('geoffrey.becuwe','pupin','m2mocadfa1BG38R','syntec',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2mocadfa1BG38A',NULL,1),('maxime.carpentier','derbel','m2mocadfa1CM33R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2mocadfa1CM33A',NULL,2),('eric.regnier','varre','m2mocadfa1RE22R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2mocadfa1RE22A',NULL,1),('mael.baekelandt','marquet','m2tiirfa1BM29R','fafiec',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','m2tiirfa1BM29A',NULL,1),('olivier.szika','grimaud','m2tiirfa1SO23R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2tiirfa1SO23A',NULL,1);
/*!40000 ALTER TABLE `contrat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `fa_entreprise`
--

DROP TABLE IF EXISTS `fa_entreprise`;
/*!50001 DROP VIEW IF EXISTS `fa_entreprise`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_entreprise` (
  `nom` varchar(50),
  `adresse` text,
  `tel` varchar(20),
  `ville` text,
  `codePostal` varchar(5),
  `opcaRef` varchar(100),
  `entrepriseCle` varchar(100)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `fa_entreprise_old`
--

DROP TABLE IF EXISTS `fa_entreprise_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_entreprise_old` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `adresse` text COLLATE utf8_bin NOT NULL,
  `tel` varchar(10) COLLATE utf8_bin NOT NULL,
  `ville` text COLLATE utf8_bin NOT NULL,
  `codePostal` varchar(5) COLLATE utf8_bin NOT NULL,
  `opcaRef` varchar(100) COLLATE utf8_bin NOT NULL,
  `entrepriseCle` varchar(100) COLLATE utf8_bin NOT NULL,
  UNIQUE KEY `entrepriseCle` (`entrepriseCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_entreprise_old`
--

LOCK TABLES `fa_entreprise_old` WRITE;
/*!40000 ALTER TABLE `fa_entreprise_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_entreprise_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_entreprise_old2`
--

DROP TABLE IF EXISTS `fa_entreprise_old2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_entreprise_old2` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `adresse` text COLLATE utf8_bin,
  `tel` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `ville` text COLLATE utf8_bin NOT NULL,
  `codePostal` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `opcaRef` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `entrepriseCle` varchar(100) COLLATE utf8_bin NOT NULL,
  UNIQUE KEY `entrepriseCle` (`entrepriseCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_entreprise_old2`
--

LOCK TABLES `fa_entreprise_old2` WRITE;
/*!40000 ALTER TABLE `fa_entreprise_old2` DISABLE KEYS */;
INSERT INTO `fa_entreprise_old2` VALUES ('__SANS ENTREPRISE__',NULL,NULL,'',NULL,NULL,'__sans entreprise__'),('ACCESS IT','','','VILLENEUVE D\'ASCQ','','agefos_pme','access_it'),('ACSSI',NULL,NULL,'',NULL,NULL,'acssi'),('ALICANTE',NULL,NULL,'',NULL,NULL,'alicante'),('ALLIANCES AIFC','','','MARCQ EN BAROEUL','','__sans opca__','alliances_aifc'),('AUDACE','','','LENS','','__sans opca__','audace'),('AUDAXIS','','','LILLE','','agefos_pme','audaxis'),('BONPRIX',NULL,NULL,'',NULL,NULL,'bonprix'),('CAP GEMINI','','','CROIX','','__sans opca__','cap_gemini'),('COMARCH','','','LEZENNES','','__sans opca__','comarch'),('COMMERCEBTOC(3SUISSES)',NULL,NULL,'',NULL,NULL,'commercebtoc(3suisses)'),('CRISTAL_ID',NULL,NULL,'',NULL,NULL,'cristal_id'),('CROQUEGEL','','','VILLENEUVE D\'ASCQ','','forco','croquegel'),('CYLANDE','','','ROUBAIX','','agefos_pme','cylande'),('DECANORD',NULL,NULL,'Lambersart',NULL,NULL,'decanord'),('DELSSI','','','VILLENEUVE D\'ASCQ','','agefos_pme','delssi'),('DOOAPP','','','VILLENEUVE D\'ASCQ','','agefos_pme','dooapp'),('EADS',NULL,NULL,'',NULL,NULL,'eads'),('EDF',NULL,NULL,'',NULL,NULL,'edf'),('Edu-Studio',NULL,NULL,'',NULL,NULL,'edu-studio'),('EMPEIRIA',NULL,NULL,'',NULL,NULL,'empeiria'),('ERDF','','','LILLE','','agecif_ieg','erdf'),('ERDF-GRDF',NULL,NULL,'',NULL,NULL,'erdf-grdf'),('Green Hosting Services',NULL,NULL,'',NULL,NULL,'green hosting services'),('Groupe AFG LILLE',NULL,NULL,'Marcq en Baroeul',NULL,NULL,'groupe afg lille'),('HARDIS',NULL,NULL,'',NULL,NULL,'hardis'),('HPC-ADLIS','','','TEMPLEMARS','','agefos_pme','hpc-adlis'),('INFITEX','','','VILLENEUVE D ASCQ','','agefos_pme','infitex'),('ISTYATECH','','','VILLENEUVE D\'ASCQ','','__sans opca__','istyatech'),('KIABI',NULL,NULL,'LYS LEZ LANNOY',NULL,NULL,'kiabi'),('LA REDOUTE',NULL,NULL,'',NULL,NULL,'la_redoute'),('LOGICA',NULL,NULL,'',NULL,NULL,'logica'),('MABEOINDUSTRIES',NULL,NULL,'',NULL,NULL,'mabeoindustries'),('MONABANQ',NULL,NULL,'',NULL,NULL,'monabanq'),('NETASCQ',NULL,NULL,'villeneuve d\'ascq',NULL,NULL,'netascq'),('NORDCOMPO',NULL,NULL,'',NULL,NULL,'nordcompo'),('NORSYS',NULL,NULL,'Ennevelin',NULL,NULL,'norsys'),('Odysys',NULL,NULL,'Villeneuve d Ascq',NULL,NULL,'odysys'),('OPEN Groupe',NULL,NULL,'Lambersart',NULL,NULL,'open_groupe'),('OXEMIS','','','WAMBRECHIES','','__sans opca__','oxemis'),('OXYLANE','','','VILLENEUVE D\'ASCQ','','__sans opca__','oxylane'),('PROXIAD NORD','','','LILLE','','agefos_pme','proxiad_nord'),('QUADRA ',NULL,NULL,'',NULL,NULL,'quadra '),('QUADRA (A confirmer)',NULL,NULL,'',NULL,NULL,'quadra (a confirmer)'),('SATHYS','','','LILLE','','syntec','sathys'),('SopraGroup',NULL,NULL,'Tourcoing',NULL,NULL,'sopragroup'),('STRATON IT',NULL,NULL,'Lomme',NULL,NULL,'straton_it'),('TASKER','','','LILLE','','__sans opca__','tasker'),('Tymate',NULL,NULL,'',NULL,NULL,'tymate'),('UBIK INGENIERIE','','','ROUBAIX','','agefos_pme','ubik_ingenierie'),('UNIS',NULL,NULL,'',NULL,NULL,'unis'),('VALIPOST','','','VILLENEUVE D\'ASCQ','','__sans opca__','valipost'),('VEKIA',NULL,NULL,'',NULL,NULL,'vekia'),('VILOGIA',NULL,NULL,'',NULL,NULL,'vilogia'),('WIDOP','','','LILLE','','__sans opca__','widop');
/*!40000 ALTER TABLE `fa_entreprise_old2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `infoetud`
--

DROP TABLE IF EXISTS `infoetud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `infoetud` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `dateSaisie` date DEFAULT NULL,
  `service` text COLLATE utf8_bin NOT NULL,
  `client` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `missions` text COLLATE utf8_bin NOT NULL,
  `environnementTechnique` text COLLATE utf8_bin NOT NULL,
  `motscles` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`alternanceRef`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `infoetud`
--

LOCK TABLES `infoetud` WRITE;
/*!40000 ALTER TABLE `infoetud` DISABLE KEYS */;
INSERT INTO `infoetud` VALUES ('m1infofa1CM2A','0000-00-00','Centre de service','','Realisation de projets diverses en fonction de la demande.\r\nProjet principal : realisation d une application de gestion de projets permettant de gerer les equipes, les documents, la matrice de competences, la base de connaissances etc.','Tout type d environnement en fonction des contraintes et du besoin.',''),('m1infofa1CN3A','2011-09-01','Applications Dashboards, Editeur d\'états','','le développement d’un éditeur d’états (tableaux de bord, business plan, aide à la décision, …) de type wysiwyg (what you see what you get)\n- le développement de sites Internet pour les cabinets d’expertise comptable :\no Site vitrine\no Site collaboratif\no E-learning\n- le développement d’un portail de solutions pour les experts comptables (cloud computing)\n- la mise en oeuvre de l’accessibilité de ces projets quel que soit le type\nde terminal utilisé (client lourd ou léger – smartphone, tablette, …).','Génie Logiciel\n- Méthode AGILE\n- Modélisation de base de données\n- Développement J2EE\n- Développement mobile\n- Technologies Web\n- IHM\n- Talend, GWT,MYSQL, Access','Développeur Applications Experts Comptables'),('m1infofa1DK5A','2011-09-01','Support de l\'application PACE','','Ma principale mission consiste à faire du support pour l\'application PACE. (corrections de bugs, amélioration des outils, etc...).','Je travaille en open space avec toute l\'équipe CAD PLM à Décathlon CAMPUS.','développement, support, analyse'),('m1infofa1GK7A',NULL,'Dev','','conception fonctionnel, technique, realisation','ruby, rails 3, html 5.0, CSS 3.0, jQuery, BackBone.js, Linux, rSpec','cloud, rails, BackBone, Agile'),('m1infofa1HG8A','0000-00-00','Agence Accueil Acheminement Valenciennes','','Creation d un portail intranet gerant les Aleas (remontees d anomalies), les Debriefings (Effectue par un responsable d equipe avec un agent) et les Accompagnements (Formation d un agent).\r\nMaintenance et mise a jour d outils deja existant (essentiellement des portails intranets mais aussi des macros excel). Gestion des bases de donnees et des serveurs .\r\nSelon l avancement du premier projet, un second pourra m etre affecte.','Deux serveurs Apache et MySQL sous Windows.\r\n Les postes de travail des agents sont sous Windows Vista. Developpement dans le langage de mon choix : Pour le portail PHP, avec l aide du framework CakePHP.\r\n Je suis le seul informaticien dans le bureau, par consequent les solutions techniques sous le plus souvent prises par moi-meme.',''),('m1infofa1HV9A','2011-09-01','Développement des infrastructures informatiques de Tasker','','Mise en place d\'infrastructure informatique dans le cloud pour les clients de Tasker, mise en place de logiciels permettant la maintenance de ces infrastructures','Cloud computing via la console d\'Amazon utilisation de windows, linux, et mises en place de plateformes diverses','Cloud computing virtualisation systèmes réseaux'),('m1infofa1LK1A','2011-09-01','Pôle développement et pôle support / exploitation','Vlan - Voix du Nord','- Développement d\'applications client-serveur pour le groupe Voix du Nord / clients externes\n- TMA au sein du pôle support / exploitation, sur la base installée\n- Relation client\n- Rédaction d\'un Wiki interne / Documentations techniques sur les réalisations effectuées','- Panel hétérogène de frameworks de développement (C# en .Net, ASP3, PHP, J2EE)\n- Bases de données : MySql, SQLSERVER\n- Logiciels utilisés : Visual Studio, Eclipse','Développement - TMA - Relation client - documentation'),('m1infofa1PB6A','2011-09-01','','','','',''),('m1miagefa1AM0A','2011-09-01','Centre de Services','','Participation aux activités du Centre de Services:\n- Conception ,Rédactionnel associé , Réalisation ,Test unitaires, Tests d’intégration, Recette client, Mise en production ,Post production, Intervention dans le cadre d’une TMA... et Gestion (devis), Outils, Méthodologie projet','','Suivi projet,'),('m1miagefa1BJ1A','2011-09-01','','','Prendre part au projet OPTEAM : nouvel outil de gestion des contrats de travail et plannings.\ntest/ taches de développement / traitement d\'incidents, correctifs ...','Java J2EE.\nframeworks struts et spring/GWT.','Java/ J2EE'),('m1miagefa1CA4A','2011-10-06','DSI Redcats Europe (Groupe PPR)','','- Chef projet MOE Construction datawarehouse sur outils de publication, mise en place univers/reporting\r\n- Chef projet IT Mise en place calcul triggers marketing client pour automatisation envois mails ciblés\r\n- A definir : contrôle gestion sur le budget et coût IT inter / Mise en place intégration continue IT\r\n\r\n+ nouveau sujet à définir en janvier','Décisionnel : Sunopsis, BO XI Infoview & Designer, systèmes Unix, Perl, DB Sybase AS IQ.\r\nNT (pas de développement) : Java, J2EE, Junit, Maven, Hudson, Selenium\r\nBackoffice : AS400','gestion projet, conception, décisionnel, international'),('m1miagefa1CF2A','2011-09-01','','VNF','TMA pour VNF qui regroupe une vingtaine d\'applications à maintenir et à mettre à jour.','Java/J2EE, oracle, tomcat','TMA Java/J2EE'),('m1miagefa1CG3A','2011-09-01','','Interne à l\'entreprise','Portage d\'une interface caractère d\'un ERP AS/400 en interface graphique avec la technologie Adobe Flex. \n\nDéveloppements en parallèle sur Android.','Utilisation d\'Adobe Flex avec Flash Builder\nAppel de programmes AS/400 contenant les règles métiers \nUtilisation de l\'application sur serveur Linux','Portage ERP en interface graphique'),('m1miagefa1DA8A','0000-00-00','Développement  de programmes Winform et de sites Web','','Intégrée à l’équipe de développement logiciel, vous intervenez dans les phases d’analyse et de développement de solutions logicielles spécifiques pour nos clients utilisateurs, dans des domaines d’activités tels que la grande distribution ou l’industrie.\r\nLes solutions logicielles prennent la forme de programmes Winform (destinés à fonctionner sur les plateformes windows) ou de sites Web.','Plate- forme de développement Microsoft DotNEt, . net, C#\r\nBase de données :  Microsoft SQL Server ,Oracle','Winform, Web, Microsoft'),('m1miagefa1DG6A','0000-00-00','','','aucun','aucun','emailing web php mysql développement logiciels'),('m1miagefa1DM5A','2011-09-01','','','','',''),('m1miagefa1DM7A','2011-09-01','DSI-NTIC du groupe Vauban Humanis\nprojets concernant les NTIC','Groupe Vauban Humanis','Maintien des composants logiciels existants, réalisation des entrevues auprès des utilisateurs afin d\'établir les spécifications fonctionnelles générales, analyse et conception de nouveaux composants pour le fonctionnement courant, réalisation de la conception technique et rédactions des spécifications détaillées par rapport au système de la DSI, documentation, recette','environnement J2EE MVC2 et javascript : Spring, Spring MVC, JPA/Hibernate, Struts, ExtJS, Jquery','analyse, conception, développement, recettage, Java/J2EE'),('m1miagefa1DT9A','2011-09-01','Regie','En regie','Réalisation d\'Evolutions de l\'application de gestion interne en mode AGILE:\nSpécifications\nDéveloppements\nTests et intégration\nRéalisation de Mini POC \nDéveloppement de l\'IHM d\'un outil de montée en charge interne\nRéalisations autour d’applications sur Iphone, Android','Environnement technique\nJava/J2EE FLEX','Java JEE Flex'),('m1miagefa1GD0A','2011-09-01','Webizi','decathlon','','','Drupal'),('m1miagefa1ML3A','2011-09-01','Progiciel - CRM','','Vous serez chargé de la réalisation de développements Java / Flex  conformes à l\'attendu du Client et dans les normes de développement ainsi que le niveau de qualité en vigueur chez Cylande.','Il vous faudra appréhender les technologies ainsi que l\'architecture de la solution UnitedRetail pour laquelle vous assurerez ces développements. Ainsi, au-delà des langages, ce sont les architectures N-Tiers, SOA et les infrastructures J2EE qu\'il vous faudra apprendre à maitriser. \nOutils utilisés : Framework ADF(JDeveloper), Flex (Adobe Flex Builder), Maven, Ant, SGBDR Oracle.','J2EE Oracle ADF Flex'),('m1miagefa1MM1A',NULL,'Service décisionnel','','Assister un chef de projet sur la prise en charge de projets répondant aux besoins des utilisateurs :\n-	Analyse de leurs besoins et contraintes\n-	Etude et conception de modèles de données (Base de données Oracle)\n-	Réalisation de traitements (PL/SQL) et développements BO (univers, rapports) \n-	Qualification, mise en production et maintenance des applications\n-	Activités de coordination, d\'organisation et de communication dans le cadre des projets','','oracle, décisionnel, bdd, business object'),('m1miagefa1MM2A','2011-09-01','1ère année travail au sein de l\'entreprise sur des projets interne.\n2ème année travail en régis pour les clients de l\'entreprise.','','Dans un premier temps, il m\'a été demandé de finaliser 2 sites web et une application interne qui est spécifique aux sites web.\nUne fois terminé je rejoindrais les équipes J2EE sur le développement d\'un projet interne.','OS : Windows XP et Seven\nIDE : Eclipse\nTechnologies : J2EE, php, html/css, ajax, GIT (svn)','Ingénieur J2EE'),('m1miagefa1PN4A','0000-00-00','Centre de service mutualisé','Oxylane, ...','TMA, evolution, ...','Waveset, Xpress, Java, JEE,...',''),('m1miagefa1RS5A','2011-09-01','Pole Expertise Regional de EDF\nRéalisation du portail intranet SAPAM (outils de gestion des demandes internes)','','Réalisation du portail de intranet SAPAM en respectant les étapes suivantes : \n-Architecture et veille technologique\n-développements\n-test\n-déploiements\n-maintenances\n-présentation des évolutions auprès des membres du pôle expertise\n\nParticipation à la réalisation d\'automates basés sur les systèmes d\'information internes d\'EDF (aS400 et SAP)','-Java/J2ee\n-.NET\n-python','j2ee,spring,hibernate,.net,python'),('m1miagefa1SK6A','0000-00-00','DSI','Supermarche Match','Reprendre le projet de l administration des flux afin de voir les differentes technologies et logiciel de l entreprise','Langage : Flex ActionScript J2EE ...\r\nLogiciel : Lotus MyEclipse FlashBuilder\r\nFrameWork : PureMVC',''),('m2eservfa1WP2A','2011-10-20','pole multimedia','','Refactoring d une partie de l application ESPACE CLIENT, avec le but d augmenter la qualite, structure, lisibilite et efficacite du site. Occasionnellement, de la maintenance et de l evulution du site.','Java J2EE, Spring, Struts. Cobol.',''),('m2iaglfa1BA1A','2011-09-01','','Noccopines','Réalisation d\'un site de location de sacs de luxe.','Framework Symfony','Symfony ,  php'),('m2iaglfa1BQ0A','2011-09-01','BtoC','3 Suisses','Participation au projet Endeca\nProgiciel BDD et application web en Java.','Eclipse, Maven, Struts, Weblogic, SVN...','Développement logiciel'),('m2iaglfa1CB2A','2011-09-01','Site e-commerce decathlon','Oxylane','Créer de nouvelles fonctionnalités et mettre à jour les fonctionnalités existantes du site decathlon.\nCréer et mettre à jour les interfaces de ces fonctionnalités.','poste de travail personnel\ndeveloppement sous eclipse sur serveur d\'intégration distant','J2EE JAVA E-COMMERCE'),('m2iaglfa1DA4A','2011-09-01','Developpement de module complémentaires pour l\'ERP Comarch Altum','VITSE','Développement en C# de modules complémentaires (fonctions non gérées de base par l\'ERP). Analyse, conception, dev, tests unitaires...','Dev C#, framework de l\'erp basé sur .Net, Visual Studio, microsoft sql server,','ERP C# .Net'),('m2iaglfa1DD3A','2011-09-01','Projet Florence : Serious game dans le milieu infirmier sur la transfusion sanguine','','Finir le mode tutoriel, faire les modes débutant, confirmé, et experts en ajoutant de l\'IA\n2 autres serious game dans le milieu infirmier dont le thème reste à définir','Utilisation d\'Unity3D pour la modélisation 3D, de l\'IHM...\nCode en C-sharp','Serious game'),('m2iaglfa1FA6A','2011-09-01','','','','',''),('m2iaglfa1FJ5A','2011-09-01','','RFF','Equipe TMA sur l\'ERP JDEdwards produit par Oracle.\nMaintenir l\'application en :\nEffectuant des correctifs.\nEffectuant des évolutions.','L\'environnement est l\'ERP JDEdwards. Pratique du SQL via l\'outil TOAD pour contrôler les données.','JDE ERP SQL'),('m2iaglfa1GL7A','2011-09-01','ICMS (Innovation, Collaborative & Mobile Solutions)','','Développement d\'applications, pas encore vraiment défini','','developpement'),('m2iaglfa1HT8A',NULL,'Projet eSIS - SAV AUCHAN','SAV Auchan','Intégration d\'un support N3 (au sens ITIL) pour l\'application de gestion du SAV Auchan. \n\nDeux grands axes de missions : Gestion des incidents et évolution/correction de l\'application.','Java 1.4 / Javascript / hibernate / Struts pour l\'environnement technique (sous eclipse, avec un serveur tomcat)','Intégration du support N3 Auchan'),('m2iaglfa1LK9A','2011-09-01','Valiclean\nValicheck','La Poste','Mise en production du Valicheck (machine de comptage industrielle pour courrier). Ce projet à été présenté dans le cadre de ma 1ère année.\nDéveloppement de Valiclean, logiciel de transformation de données (txt, bdd, ...) + correction d\'adresses postales.','Windows (XP, Server, ...)\nVisual Studio, MySQL, SQL Server, Access.\nCommunication automate.\nLangages : VB.net, VB6, C/C++, SQL.','Courrier Industriel Correction Algorithmique'),('m2iaglfa1PA0A',NULL,'web e-commerce','Oxylane','dévemoppement d\'application web principlement sur métier e-commerce','web2.0 (HTML, CSS, JS), J2EE (Spring, Hibernate), PHP (Drupal)','développement web'),('m2iaglfa1SK1A','0000-00-00','Infiltrea, notre solution tout-en-un pour les mesureurs de l’étanchéité à l’air. Infiltrea est un logiciel ergonomique, intuitif et fiable permettant de réaliser des tests d’étanchéité et de générer rapports conformes à la norme EN 13-829 et au GA P50-784 en un clic.','','Participer aux spécifications techniques\r\nDévelopper les nouvelles fonctionnalités\r\nContribuer aux process de qualité en mettant en place des tests unitaires\r\nAssurer une veille technologique sur les innovations intégrables dans nos solutions','Organisation Agile (Stand-up meeting, planning poker, sprints)\r\nUtilisation de Java, JavaFX, JUnit, Giuce, Jenkins, Jira, Hibernates.\r\nDeveloppement sous Eclipse. Integration continue via depot git.','JavaFX, Ecoconstruction, Tests, Agile'),('m2iaglfa1TR3A',NULL,'Développement d\'une application mobile pour le reporting.','','Continuer le développement d\'une application sur le reporting mobile, afin de promouvoir ce genre de produit pour les clients d\'IstyaTech.','Utilisation du framework J2EE, ainsi que de la technologie WEB Sencha (Ext JS).','Application mobile, J2EE, reporting mobile, décisionel.'),('m2miagefa1CA3A','2011-09-01','Pôle Pilotage','','Maintenir, documenter et faire évoluer l’outil de prise de rendez- vous client développé durant le Master 1.\nDéveloppement d\'un outil d\'aide à la décision\nGestion de projets de développements d\'applications internes\nINFO: Travaille sur deux sites différents Roubaix (GRDF) et Douai (ERDF)','Serveur local & national Apache\nDéveloppement d\'applications intranet','Développement Gestion Projet Web Intranet'),('m2miagefa1CJ1A','2011-09-01','Nouvelles technologies, Vente à distance','3 SUISSES','Conception, développement et test au sein de l’équipe projet','Technologies à mettre en œuvre :\nJ2EE : Spring, hibernate, jsp, servlet, JSF2, jax-ws (webservices), Tomcat, OpenESB, Eclipse, Maven 2, checkstyle, Junit, HP Quality Center, CAST, Fop, Streamserve, log4j, Oracle 10g\nEnvironnement technique :\nEclipse, Maven 2, Terracotta, MySQL, linux','Web, J2EE, Weblogic'),('m2miagefa1DC6A','2011-09-01','Refonte du site internet Galeries Lafayette','Galeries Lafayette','Evolutions sur le site internet des Galeries Lafayettes notamment refonte de la page panier, de l\'index des marques, ajout d\'un menu de gestion des cartes bleues.','Développement web (HTML,CSS,Javascript), PHP5, OSCommerce, Base de données MySql, Putty','PHP5, E-commerce, OScommerce, Javascript, Web'),('m2miagefa1DJ7A','2011-09-01','Refonte du site internet e-commerce','','Refonte du site actuel e-commerce de Croque Gel, afin de le rendre plus modulable et de faciliter l\'administration grâce à l\'utilisation d\'un CMS(JOOMLA!).','PHP, CSS, Javascript, Web service(Java)',''),('m2miagefa1DN5A','2011-09-01','Pôle GIUnis (application de gestion de l\'entreprise)','','La mission consiste à maintenir et faire évoluer l\'application de gestion de l\'entreprise.\n\nLa mission se déroule en 2 phases :\n\nModule 1 : gestion de l’activité de la société de la gestion du temps à la facturation\ndes prestations.\n\nModule 2 : dans le cadre d’une activité de revente de licences, gestion de l’activité\ndepuis l’achat des licences jusqu’à la facturation des prestations liées à celles-ci.','J2EE, Spring, Spring MVC, JPA, Hibernate, Maven2,\nSelenium, Cruise Control, Tomcat, Linux Debian, BIRT, UML','JEE Hibernate Maven Spring Tomcat'),('m2miagefa1DS8A','2011-09-01','Pôle développement','Potentiellement APLON (Arras) et AlTecom','75% du temps : participation au développement de projets.\n25% du temps : participation à la mise en place d\'architectures pour les applications développées. Encadré par un architecte confirmé.','Ensemble de la plateforme Microsoft et du Framework .NET.\n(SQL Server 2008 R2, Visual Studio 2010, SharePoint 2010...)','Microsoft .NET développement C#'),('m2miagefa1DT4A','2011-09-01','Dév d\'applis web pour ADEO','ADEO','Analyse conception développement d\'applis web.\n\nEn M1, mon tuteur était Raphaël Marvie, et nous étions d\'accord pour qu\'il me suive également en M2.','java spring hibernate struts php sql','J2EE WEB'),('m2miagefa1GC1A','2011-10-04','.NET,','','Mise en place d’un portail SharePoint. (projet interne)\r\nIntervention sur des réalisations de projets au forfait à destination de clients..\r\n\r\nPrésentation à réaliser de SharePoint en interne. ','Sharepoint, ASP .NET, Silverlight','.NET, SharePoint, C#, Silverlight, MVC.NET'),('m2miagefa1GM0A','2011-09-01','E-Commerce','','Intégration d’une équipe projet travaillant sur des solutions e-commerce','Windows XP, KonaKart, J2E, MySQL, Tomcat, Struts','E-commerce J2E KonaKart'),('m2miagefa1LR2A','2011-09-01','DSI Pôle projets','Interne','Création d\'applications de gestion\nMaintenance du site web www.vilogia.fr','Java, JEE, Hibernate, Eclipse, PHP','java hibernate php'),('m2miagefa1ML3A','2011-09-01','je serai intégré au sein d’un des centres de compétences NTIC','','J2EE : Spring, hibernate, FLEX, GWT, jsp, servlet, JSF2, jax-ws (webservices), Tomcat, OpenESB, Eclipse, Maven 2, checkstyle, Junit, HP Quality Center, CAST, Fop, Streamserve, log4j, Oracle 10g','Eclipse, Maven 2, Terracotta, MySQL, linux.\nClarity, HP Quality center, Sourceforge.','Java J2E, hibernate, Spring, j4log, CMMI'),('m2miagefa1PK5A','2011-09-01','Pôle J2EE','','Développement de modules pour l\'application de gestion interne à UNIS, Paie, note de frais, rapport d\'activité...','Environnement Eclipse, Maven, Spring, J2EE, Hibernate, Mantis Bug Tracker pour le suivi des tâches.','J2EE, Hibernate, Spring, Maven'),('m2miagefa1PR6A','2011-09-01','Service informatique','','Mission principale, développé un outil d\'aide à la gestion pour l\'entreprise.\n\nMission secondaire, participer aux projets de cross-canal pour les clients.','Langage : Java,JEE,JSP, .NET\nIDE : Eclipse, Visual web studio\nBDD : MySql, SQL Express\nEnvironnement : Windows / Linux (Ubuntu)','ERP WEB J2EE'),('m2miagefa1TC7A','0000-00-00','POC leroymerlin.fr','Adeo','Monter un POC leroymerlin.fr sous Konakart en vue de décrocher le contrat de refonte du site marchand.','Konakart (J2EE Struts), Liferay, MySQL, Talend',''),('m2miagefa1TJ8A','2011-09-01','le 12/09, 80% equipe PROJET, 20% Bureau Etude.\ninversion a terme;','','Pour le bureau d\'étude (mission principale) : création d\'un outil de configuration des moteurs du Bureau d\'étude en GWT.\nPour l\'equipe projet : migration de l\'un des outils (PROVISIA) d\'un client a une version plus recente.','Bureau d\'etude : GWT, JAVA et SQL.\nProjet : PLSQL, Talend, systèmes unix','GWT, PLSQL, TALEND'),('m2miagefa1VS9A','2011-09-01','Service informatique','','Création d\'application métier (GRC, Back-Office ... ) en version web.\nEn parrallèle gestion d\'un projet (à définir) pour la soutenance du M2','Système i (IBM) communiquant en HTTP avec les nouvelles applications que je dévellope en HTML/Javascript/Ajax.\nBase de données DB2','Refonte d\'application version webisé'),('m2miagefa1WC0A','2011-09-01','EN COURS DE DEFINITION','EN COURS DE DEFINITION','Etant en train de passer des entretiens avec les clients de Unis, mon projet n\'est actuellement pas définit pour cette deuxieme année.','','J2EE SPRING HIBERNATE JPA MAVEN'),('m2miagefa1WG1A',NULL,'Pôle expertise','','Les projets confiés :\n\nAppui au pilotage d’un outil de communication directe sur les micros des salariés : établissement du\nREX de l’expé et préparation de l’extension aux 4300 salariés d’ERDF MMN (projet MERCURE)\nConstruction de tableaux de bord d’aide à la décision\nContribution à l’administration de l’outil de facturation (représentant 90 % du chiffre d’affaires d’ERDF)\ndes fournisseurs d’électricité ( utilisation ORACLE pour entrepôt de données)\nEvolution du site intranet PANDORA ( recevant envrion 1500 demandes / an ) Utilisation apache My\nSQL\nRequêtage sur les SI d’ERDF','Oracle\napache\nMySQL','Décisionnel, mysql, projet, web'),('m2mocadfa1BG38A',NULL,'','Dalkia','ECO : TMA sur un outils de gestions de factures et contrat\nOGE outils interne de suivi d\'activité\n\nA venir : Decisionnel','ECO : Oracle, VB6\nOGE : PHP, wamp, PL/SQL\n\nDecisionnel ...','TMA'),('m2mocadfa1CM33A','2011-09-01','','','','',''),('m2mocadfa1RE22A','2011-09-01','GFS : Global Financial Service','Capgemini','Réaliser une Proof of concept du framework Apex : Oracle Application Express pour estimer l\'intéret du groupe à migrer son système d\'information vers APEX.\nDéveloppements Pl/Sql pour maintenir et faire évoluer la BDD Oracle du système GFS\nRéalisations de Web Services en Java et WSDL pour remplacer le SAAS actuel\nRécuperation des informations de facturation dans gfs par ITESOFT','Pl/Sql WSDL Java XSLT\nWindows XP, SQLPlus, Oracle 11g','développement Pl/Sql');
/*!40000 ALTER TABLE `infoetud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_etapeet`
--

DROP TABLE IF EXISTS `fa_etapeet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_etapeet` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `dateRencontre` date DEFAULT NULL,
  `service` text COLLATE utf8_bin NOT NULL,
  `client` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `missions` text COLLATE utf8_bin NOT NULL,
  `environnementTechnique` text COLLATE utf8_bin NOT NULL,
  `integrationEntreprise` text COLLATE utf8_bin,
  `signatureEtud` tinyint(1) DEFAULT NULL,
  `signatureTuteur` tinyint(1) DEFAULT NULL,
  `remarquesEtud` text COLLATE utf8_bin,
  `remarquesTuteur` text COLLATE utf8_bin,
  `motscles` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`alternanceRef`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_etapeet`
--

LOCK TABLES `fa_etapeet` WRITE;
/*!40000 ALTER TABLE `fa_etapeet` DISABLE KEYS */;
INSERT INTO `fa_etapeet` VALUES ('m1infofa1CN3A','2011-10-12','Applications Dashboards, Editeur d','','migration d une BDD de access97 vers mysql.\r\n\r\nle developpement d un editeur d etats (tableaux de bord, business plan, aide a la decision, …) de type wysiwyg.\r\n\r\nle developpement de sites Internet pour les cabinets d expertise comptable :\r\n1) Site vitrine\r\n2) Site collaboratif\r\n3) E-learning\r\n\r\nle developpement d un portail de solutions pour les experts comptables (cloud computing).\r\n\r\nla mise en oeuvre de l accessibilite de ces projets, quel que soit le type\r\nde terminal utilise : client lourd ou leger, smartphone, tablette.\r\n','Genie Logiciel: Methode AGILE, modelisation de BDD, developpement J2EE/mobile,\r\ntechnologies Web, IHM, Talend, GWT,MYSQL, Access','L etudiant travaille dans une equipe avec  un autre etudiant en Master en temps partiel, et une permanente (chef de projet).',1,1,'','',''),('m1infofa1DA4A','2011-10-07','','','Développement pour plateformes mobiles. Portage.  ','Androïd iPhone','Bien. Cette alternance fait suite au stage de L3 dans la m^me entreprise.\r\n',NULL,1,NULL,'',''),('m1infofa1DK5A','0000-00-00','Support de l','','Ma principale mission consiste à faire du support pour l\'application PACE. (corrections de bugs, amélioration des outils, etc...).','Je travaille en open space avec toute l\'équipe CAD PLM à Décathlon CAMPUS.','',NULL,1,NULL,'Remarque: travail en binôme avec un \"permanent\"\r\npremière visite programmée fin octobre',''),('m1infofa1HV9A','2011-10-24','Développement des infrastructures informatiques de Tasker','','- Mise en place d\'infrastructure informatique dans le cloud pour les clients de Tasker, mise en place de logiciels permettant la maintenance de ces infrastructures,\r\n- Mise en place d\'une solution de monitoring sur la solution d\'agilité de Tasker,\r\n- Mise en place d\'un système de puppet pour le déploiement de configurations à la volée,\r\n- Couche d\'abstraction de gestion de l\'agilité des Cloud providers.','- Console d\'Amazon WS,\r\n- Windows, linux et mises en place de plateformes diverses,\r\n- Puppet (http://puppetlabs.com),\r\n- Développements Java (Glassfish).','- Précédent stage dans l\'équipe de développement (8 personnes: 2 devs + 1 arch. + 1 tech.)',NULL,1,NULL,'{as de remarque particulière',''),('m1infofa1PB6A','2011-10-17','Multidomus','','Développement c# sur le projet Multidomus','C#, ASP Net','Bonne intégration, bénéficie de formation (2 jours)',NULL,1,NULL,'',''),('m1miagefa1CA4A','2011-10-06','DSI Redcats Europe (Groupe PPR)','','- Chef projet MOE Construction datawarehouse sur outils de publication, mise en place univers/reporting\r\n- Chef projet IT Mise en place calcul triggers marketing client pour automatisation envois mails ciblés\r\n- A definir : contrôle gestion sur le budget et coût IT inter / Mise en place intégration continue IT\r\n\r\n+ nouveau sujet à définir en janvier','Décisionnel : Sunopsis, BO XI Infoview & Designer, systèmes Unix, Perl, DB Sybase AS IQ.\r\nNT (pas de développement) : Java, J2EE, Junit, Maven, Hudson, Selenium\r\nBackoffice : AS400','Aucun problème : Déjà dans l\'entreprise l\'an dernier. Appui technique assuré par le tuteur entreprise',1,1,'','',''),('m1miagefa1CG3A','2011-10-06','','Interne à l\'entreprise','Portage d\'une interface texte d\'un ERP AS/400 en interface graphique avec la technologie Adobe Flex. Les objets FLEX gèrent également la communication au dessus de HTTP avec les serveurs AS/400.\r\n\r\nPour des besoins spécifiques il est envisagé de réaliser des développements FLEX sur support mobile.','Utilisation d\'Adobe Flex avec l\'IDE Flash Builder.\r\nAppel de programmes AS/400 contenant les règles métiers. \r\nDéploiement de l\'application sur serveur Linux.','Très bien. Gaël a déjà effectué son stage L3 MIAGE dans l\'entreprise.\r\nInteractions fréquentes avec le référent d\'alternance car il développe les fonctionnalités back-office de l\'application.\r\nCommunication facile avec les autres employés de l\'entreprise.',1,1,'','Belles perspectives d\'alternance',''),('m1miagefa1DG6A','2011-10-06','OXIMAILING','','Maintenance serveurs oximailing, Maintenance sur application oxiforms\r\n(Retour clients).  \r\nChangement de version oximailing ->\r\n -  analyse automatique de retour de mail.\r\n -  migration base de données.\r\n - refonte du site web\r\n\r\n A partir de novembre :\r\n    Portage sur smartphone Android de la partie client d\'oximailing\r\n\r\n',' php/mysql unix ajax \r\n\r\nplate-forme android (java)','Très bonne : Déjà en alternance dans cette entreprise en 2010-2011',NULL,1,NULL,'',''),('m1miagefa1DT9A','2011-10-13','Regie','En regie','Réalisation d\'Evolutions de l\'application de gestion interne en mode AGILE =reprise de UBIK-CRA : prise en main, évolutions et correctifs de bugs\r\n-> Spécifications\r\n-> Développements\r\n-> Tests et intégration\r\n\r\n\r\nSuites envisagées/possibles :\r\n* Réalisation de Mini POC \r\n* Développement de l\'IHM d\'un outil de montée en charge interne\r\n* Réalisations autour d’applications sur Iphone, Android','Environnement technique :\r\nJava/J2EE (JSP, JDBC, ...)\r\nSpring\r\nJquery, \r\nFLEX','* actuellement prise en main des outils\r\n* autoformation (J2EE, JSp, JDBC, Spring, Jquery, ...)\r\n* réalisation de petits correctifs pour se familiariser avec environnement de travail\r\n* synchronisation avec autres étudiants en alternance (2ème année) pour reprise du travail',1,1,'','',''),('m1miagefa1GD0A','2011-10-14','Webizi','decathlon','Jusque Fin Novembre, misson de responsable WEBIZI pour Oxylane en vue de remplacer e-tools pour générer les sites web de la marque (inesis, bitwin, etc). ','drupal 7, Ktest','Très bien, Diane Gombart a déjà fait son stage précédent chez Capgemini. L\'intégration s\'est bien passée, l\'ambiance générale est bonne. ',NULL,1,NULL,'',''),('m1miagefa1ML3A','2011-10-14','Progiciel - CRM','','Réalisation de développements J2EE dans le cadre du pôle CRM qui concerne les modules clients de progiciel UnitedRetail.\r\n\r\nAfin de se familiariser avec les technologies et la manière de développer chez Cylande, une première mission de maintenance concernant l\'ajoute des règles de gestion pour les organismes (Business Units) lui a été confiée. \r\n\r\nLouis a également suivi des formations spécifiques J2EE, Maven et ADF.\r\n\r\nAu cours de l\'année, il est également prévu de s\'impliquer dans la partie front-end en utilisant la technologie FLEX.','Framework ADF(JDeveloper), Flex (Adobe Flex Builder), Maven, Ant, SGBDR Oracle.\r\n\r\nADF framework  Oracle, couvrant les mêmes fonctionnalités que Spring+Hibernate confondues.\r\n','Bien. \r\n\r\nLouis n\'hésite pas aller vers vos collègues en cas de problème. Il n\'est pas perçu comme un stagiaire, mais comme un employé à part entière.',NULL,1,NULL,'',''),('m1miagefa1MM2A','2011-10-26','1ère année travail au sein de l','','Dans un premier temps, il m\'a ete demande de finaliser 2 sites web et une application interne qui est specifique aux sites web.\r\nUne fois termine je rejoindrais les equipes J2EE sur le developpement d\'un projet interne.','OS : Windows XP et Seven\r\nIDE : Eclipse\r\nTechnologies : J2EE, php, html/css, ajax, GIT (svn)','tres bien car Michael sort d\'un stage de licence chez Unis.',NULL,1,NULL,'discussions informelles avec Michael que je vois en cours. J\'ai donc mis la date de la visite comme date de rencontre tuteur-étudiant.',''),('m2eservfa1BG1A','2011-10-18','','','Dev. applications iPhone','Obj. C, iOS','Bonne',NULL,1,NULL,'Je connais l\'entreprise (suivi de stg).\r\nÊtre attentif à la \"carrure\" de la mission.  ',''),('m2eservfa1BK2A','2011-10-11','Projet mutualisé','plein','Actuellement: support client (gestion des erreurs des projets développés par Cagemini).\r\n\r\nEnsuite: Développement J2EE, Jahia, Drupal, JWT.\r\nÉvolution de projet existant + nouveau projet: interface pour les clients pour récupérer des fichiers excel (à conirmer).','Travail en Open Space. ','Bonne intégration, accompagnement aide actuellement par d\'autres personnes pour le support client.',NULL,0,NULL,'',''),('m2eservfa1BM0A','2011-10-18','Dot.net','','Capitalisation de code (site intranet et internet à destination de l\'AMF autorité des marchés financiers, généralisation de module pour le transférer vers d\'autres projets\r\nRecette d\'application','Dot.net .... Site en en asp mvc ......','équipe de 4 + 1 chef de projet\r\nréunion mensuelle\r\npas de difficulté d\'intégration\r\n\r\n\r\n',NULL,1,NULL,' A rediscuter .... ',''),('m2eservfa1DC4A','2011-10-18','PER_NordOuest','','\r\nMaintenir l\'intranet épice qui est au centre de pôle commerce\r\nFaire évoluer l\'intranet épice par exemple importer les données journalières au lieu qu\'elles soit hebdomadaire pour piloter l\'activité journalière du centre de relation clients\r\n','Php Myql, framework interne\r\njql ..........','deuxième de FA, très bonne intégration',NULL,1,NULL,'nous devons rediscuter des missions par rapport au projet M2',''),('m2eservfa1DG5A','2011-10-18','ITC (4eme)','GEFCO','Consultant programmeur sur le framework obisoft (contenant 3 applications) gestion des entrées/sorties commandes. Guillaume travaillera sur Nostra ou Ines.','Java/J2EE','Très bien encadré, bénéficie d\'une formation technique au framework (8 jours de formation)',NULL,1,NULL,'',''),('m2eservfa1DY3A','2011-10-11','projet 3 suisses','Les 3 Suisses et Commerce btoc','Actuellement: debuggage et petites évolutions du site de commerce en ligne.\r\n\r\nFutur (quand + de 2 jours/semaine): développement J2EE','Travail en Open Space.\r\n\r\nJ2EE, eclipse, svn, ...\r\n\r\nJBoss (serveur d\'applications), mysql','Bonne intégration. Toujours quelqu\'un pour aider. Entreaide avec un autre alternant MIAGE.  ',1,0,'','',''),('m2eservfa1LJ21A','2011-10-12','','','Maintenance et extension de d une application mobile (Android)  pour l apprentissage de vocabulaire de langues etrangeres sous forme d un jeux. Connection entre l application et les web services, a realiser avant la commercialisation du produit en fevrier 2012. ','Eclipse, SDK Android, ... (pas encore tout fixe, vu que l etudiant n a que passe deux jours dans l entreprise jusqu a present). Java.\r\n','Tout va bien. Les collaborateurs direct sont plus commerciaux que techniques. Jessy est en discussion par mail avec des equipes freelance, pour les aspects techniques. Pour les aspects graphiques de l application, il travaille avec un infographiste qui est dans l entreprise a temps plein.',1,1,'','',''),('m2eservfa1VR1A','2011-10-26','Service Etudes','','En tache de fond les dev OSB / ODI + un projet sur le long terme visant à industrialiser les flux OSB et à en donner une représentation graphique.','J2EE / Windows','Bien (depuis 2 ans)',NULL,1,NULL,'',''),('m2eservfa1WP2A','2011-10-20','pole multimedia','','Refactoring d une partie de l application ESPACE CLIENT, avec le but d augmenter la qualite, structure, lisibilite et efficacite du site. Occasionnellement, de la maintenance et de l evulution du site.','Java J2EE, Spring, Struts. Cobol.','tout va bien. deuxieme annee d alternance dans le meme entreprise.',1,1,'','',''),('m2iaglfa1BQ0A','2011-10-24','BtoC','3 Suisses','Participation au projet Endeca\r\nProgiciel BDD et application web en Java.','Eclipse, Maven, Struts, Weblogic, SVN, J2EE, ...','Très bonne intégration, bon encadrement (disponibilité, aide, etc.).',NULL,1,NULL,'',''),('m2iaglfa1CB2A','2011-10-25','Site e-commerce decathlon','Oxylane','Créer de nouvelles fonctionnalités et mettre à jour les fonctionnalités existantes du site decathlon.\r\nCréer et mettre à jour les interfaces de ces fonctionnalités.\r\n+ prise en compte de la nouvelle base de données.\r\n* réalisation du header du site dont le mini-panier.\r\n* évolution de l\'interface web','Poste de travail personnel.\r\nDéveloppement sous eclipse sur serveur d\'intégration distant.\r\n\r\nJ2EE côté serveur\r\nhtml/css/javascript pour interface site web\r\n','Il s\'agit d\'une seconde année d\'alternance.\r\nDébut de la mission pour Décathlon début juillet.',1,1,'','',''),('m2iaglfa1DA4A','2011-10-19','Developpement de module complémentaires pour l','VITSE','Développement en C# de modules complémentaires (fonctions non gérées de base par l\'ERP développé par COMARCH).\r\nLe développement se fait sur une architecture 3tiers en utilisant des Bussiness Objects (Microsoft) et une couche DAL pour l\'accès aux données.\r\n \r\nA travers les missions qu\'on confiera à Antoine cette année, l\'entreprise souhaite le voir monter en compétence dans l\'analyse et la conception des solutions développées.','Dev C#\r\nFramework de l\'ERP basé sur .Net\r\nVisual Studio\r\nMicrosoft SQL Server','Antoine travaille directement avec son référent, collaboration qui donne lieu à des nombreux échanges.\r\n\r\nEchanges nombreux également avec les autres équipes COMARCH à l\'étranger (principalement Pologne).',1,1,'','',''),('m2iaglfa1LK9A','2011-10-25','Valiclean Valicheck','La Poste','Mise en production du Valicheck (machine de comptage industrielle pour courrier). Ce projet à été présenté dans le cadre de ma 1re année.\r\nDéveloppement de Valiclean, logiciel de transformation de données (txt, bdd...) + correction d\'adresses postales.','Windows (XP, Server, ...)\r\nVisual Studio, MySQL, SQL Server, Access.\r\nCommunication automate.\r\nLangages : VB.net, VB6, C/C++, SQL.','Bonne ! Kevin est présent chez Valipost depuis deux ans. ',NULL,1,NULL,'',''),('m2iaglfa1SK1A','2011-10-12','Infiltrea','','- Porter l\'application \"Infiltréa\" de JavaFX 1.3 vers JavaFX 2.0\r\n- Développer de nouvelles fonctionnalités (e.g., migration des données vers le cloud)\r\n- Participer aux spécifications techniques\r\n- Assurer une veille technologique sur les innovations intégrables dans Infiltrea','- Organisation Agile (Stand-up meeting, planning poker, sprints)\r\n- Utilisation de technologies Java: JavaFX 1.3/2.0, JUnit, Guice, Hibernate\r\n- Développement sous Eclipse\r\n- Suivi de projet sous Jira\r\n- Integration continue via un dépôt Git + Maven + Jenkins','- Bonne intégration dans une (petite) équipe composée de 7 membres (2 gérants + 1 développeur + 1 alternant + 2 stagiaires +1 responsable communication).\r\n-Participation active aux décisions et aux évolutions du logiciel.',1,1,'Pas de remarque particulière.','Pas de remarque particulière.',''),('m2miagefa1CJ1A','2011-10-17','Nouvelles technologies, Vente à distance','3 SUISSES','Conception, développement et test au sein de l’équipe projet','Technologies à mettre en œuvre :\r\nJ2EE : Spring, hibernate, jsp, servlet, JSF2, jax-ws (webservices), Tomcat, OpenESB, Eclipse, Maven 2, checkstyle, Junit, HP Quality Center, CAST, Fop, Streamserve, log4j, Oracle 10g\r\nEnvironnement technique :\r\nEclipse, Maven 2, Terracotta, MySQL, linux','Bien passé',NULL,1,NULL,'',''),('m2miagefa1DN5A','2011-10-04','Pôle GIUnis (application de gestion de l','','1ère mission :\r\n\r\nLa mission consiste à maintenir et faire évoluer l\'application de gestion de l\'entreprise.\r\n\r\nLa mission se déroule en 2 phases :\r\n\r\nModule 1 : gestion de l’activité de la société de la gestion du temps à la facturation\r\ndes prestations.\r\n\r\nModule 2 : dans le cadre d’une activité de revente de licences, gestion de l’activité\r\ndepuis l’achat des licences jusqu’à la facturation des prestations liées à celles-ci.\r\n\r\n2ème mission : à définir ultérieurement','J2EE, Spring, Spring MVC, JPA, Hibernate, Maven2,\r\nSelenium, Cruise Control, Tomcat, Linux Debian, BIRT, UML','Très bonne. De nombreux collègues miagistes. Soutien au sein de l\'entreprise pour la mise en route.',1,1,'','Visite en entreprise à définir entre le 27 octobre et le 4 novembre',''),('m2miagefa1GC1A','2011-10-04','.NET,','','Mise en place d’un portail SharePoint. (projet interne)\r\nIntervention sur des réalisations de projets au forfait à destination de clients..\r\n\r\nPrésentation à réaliser de SharePoint en interne. ','Sharepoint, ASP .NET, Silverlight','Très bonne. De nombreux collègues miagistes. Aide en interne sur .NET',NULL,1,NULL,'Visite en entreprise à définir entre le 27 octobre et le 4 novembre',''),('m2miagefa1PR6A','2011-10-17','Service informatique','','Mission principale, poursuivre le développement d\'un outil d\'aide à la gestion pour l\'entreprise. Mise en production du module planification pour la fin du mois octobre. Des évolutions du module commande sont éventuellement envisageables. \r\n\r\nMission secondaire, participer aux projets de cross-canal pour les clients en ajoutant notamment un module d\'authentification.\r\n\r\nPar ailleurs, Rémi a développé de bout en bout une application de gestion de courrier NPAI (juillet-septembre). Mise en production fin septembre.','Langage : Java,JEE,JSP, .NET\r\nIDE : Eclipse, Visual web studio\r\nBDD : MySql, SQL Express\r\nEnvironnement : Windows / Linux (Ubuntu)','Bien. Il continue de prendre de l\'assurance. Evolution positive.\r\n',NULL,1,NULL,'Lors de la visite en entreprise il faudra définir les grandes lignes des missions de cette année.',''),('m2miagefa1VS9A','2011-10-18','Service informatique','','Création d\'application métier (GRC, Back-Office ... ) en version web.\r\nEn parrallèle gestion d\'un projet (à définir) pour la soutenance du M2\r\n','Système i (IBM) communiquant en HTTP avec les nouvelles applications que je dévellope en HTML/Javascript/Ajax.\r\nBase de données DB2','Toujours en bonne situation ....',NULL,0,NULL,'discusion autour du projet, en attente de la validation du tuteur entreprise ..... de mon coté je valide la proposition de sebastien ....',''),('m2miagefa1WC0A','2011-10-26','EN COURS DE DEFINITION','EN COURS DE DEFINITION','Etant en train de passer des entretiens avec les clients de Unis, mon projet n\'est actuellement pas défini pour cette deuxieme année.','java J2EE','deja dans l\'entreprise depuis 1 an en alternance',NULL,0,NULL,'',''),('m2miagefa1WG1A','2011-10-18','Pôle expertise','','Pilotage d’un outil de communication directe sur les micros des salariés : établissement du\r\nREX de l’expé et préparation de l’extension aux 4300 salariés d’ERDF MMN (projet MERCURE)\r\n\r\nConstruction de tableaux de bord d’aide à la décision\r\n\r\nContribution à l’administration de l’outil de facturation (représentant 90 % du chiffre d’affaires d’ERDF) des fournisseurs d’électricité ( utilisation ORACLE pour entrepôt de données)\r\n\r\nEvolution du site intranet PANDORA ( recevant environ 1500 demandes / an ) \r\n\r\nRequêtage sur les SI d’ERDF','Oracle\r\nApache\r\nMySQL','Bien.\r\nGuillaume travaille à proximité des ses référents entreprise.\r\n',NULL,1,NULL,'Des problèmes liés au retard dans la signature du contrat ont été mentionnés.',''),('m2tiirfa1BM29A','2011-10-17','','','','','Rupture de CDD en vue. \r\nD\'un commun accord entre les parties',NULL,1,NULL,'','');
/*!40000 ALTER TABLE `fa_etapeet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapevisite1`
--

DROP TABLE IF EXISTS `etapevisite1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapevisite1` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `dateRencontre` date DEFAULT NULL,
  `adequationMission` text COLLATE utf8_bin,
  `integrationEtudiant` text COLLATE utf8_bin,
  `signatureEtud` tinyint(1) DEFAULT NULL,
  `remarquesEtud` text COLLATE utf8_bin,
  `signatureReferent` tinyint(1) DEFAULT NULL,
  `remarquesReferent` text COLLATE utf8_bin,
  `signatureTuteur` tinyint(1) DEFAULT NULL,
  `remarquesTuteur` text COLLATE utf8_bin,
  `typeRencontre` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapevisite1`
--

LOCK TABLES `etapevisite1` WRITE;
/*!40000 ALTER TABLE `etapevisite1` DISABLE KEYS */;
INSERT INTO `etapevisite1` VALUES ('m1miagefa1CG3A','2011-10-17','Oui.\r\nOn demande à Gael de tester plus le code qu\'il produit.','Bien. \r\nA terme on attend de Gael d\'être plus pro-actif en terme de proposition de développement.\r\nIl est envisagé de faire participer Gael aux visites chez les clients de l\'entreprise, ce qui lui permettra d\'acquérir plus de connaissances métier.\r\n',0,'',0,'',1,'Alternace qui commence sur des très bons auspices',NULL),('m1miagefa1DG6A','2011-10-18','Le travail correspond bien à la description qui en était faite lors de la réunion du 6 octobre 2011 :\r\n\r\n- développement du site web et test de la mise en production de la version 6 de l\'application principale de la société : oximailing  -> jusque fin novembre\r\n\r\n- développement d\'applications mobiles (android) d\'accompagnement de l\'application oximaling :\r\n    * recensement des besoins client -> jusque fin décembre\r\n    * développement\r\n\r\n- en parallèle : développement d\'évolutions techniques, en fonction des retours client, de la solution oxiforms de création de formulaires web\r\n(2 semaines de dev.)\r\n\r\n- un point doit être fait fin décembre en fonction des retours client sur la version 6 d\'oximailing\r\n\r\n- plus prospectif et non positionné dans le temps : mise à plat d\'oximailing pour migrer l\'application (actuellement en VB 6) vers .NET et/ou applications WEB.','Très bonne intégration : c\'est la 2ème année d\'alternance de Guillaume dans l\'entreprise. Les points de progrès signalés à la fin de l\'année universitaire dernière ont bien été pris en compte.\r\n\r\nEquipe de développement de 3 personnes.',0,'',1,'',1,'',NULL),('m1miagefa1MM2A','2011-10-26','Pour l\'instant, developpement web en PHP avec Joomla, bientot Workpress.\r\nProjet web avec un client à Dunkerque. Decouverte du recueil des besoins, deplacement a Dunkerque.\r\nDans un proche avenir, Michael va integrer le pole J2EE.','tres bien. Michael avait deja fait son stage de licence chez UNIS.',0,'',0,'',0,'',NULL),('m2miagefa1WC0A','2011-10-26','Pour l\'instant, Cyril est encore sur l\'appli interne sur laquelle il a travaille l\'an dernier. D\'ici une semaine, il sera chez un client (Oxylane, Promod, ...)\r\nCyril est et restera sur des missions J2EE.','pour l\'instant, toujours chez Unis. Integration a venir chez le client. Remarque : Cyril a effectue une presentation pour le client Oxylane. Satisfaction a la fois du cote de Cyril et du cote d\'Oxylane.',0,'',0,'',0,'',NULL);
/*!40000 ALTER TABLE `etapevisite1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapeechanges`
--

DROP TABLE IF EXISTS `etapeechanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapeechanges` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `participants` text COLLATE utf8_bin NOT NULL,
  `typeRencontre` int(11) NOT NULL,
  `dateRencontre` date NOT NULL,
  `resume` text COLLATE utf8_bin NOT NULL,
  `sujet` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapeechanges`
--

LOCK TABLES `etapeechanges` WRITE;
/*!40000 ALTER TABLE `etapeechanges` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapeechanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapeSout`
--

DROP TABLE IF EXISTS `etapeSout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapeSout` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `titreStage` tinytext COLLATE utf8_bin NOT NULL,
  `comprehension` tinyint(4) NOT NULL,
  `efficaciteAnalyse` tinyint(4) NOT NULL,
  `rigueur` tinyint(4) NOT NULL,
  `interet` tinyint(4) NOT NULL,
  `communication` tinyint(4) NOT NULL,
  `autonomie` tinyint(4) NOT NULL,
  `receptivite` tinyint(4) NOT NULL,
  `serieux` tinyint(4) NOT NULL,
  `pourcentageObjectifs` float NOT NULL,
  `difficulteMission` text COLLATE utf8_bin NOT NULL,
  `visaReferent` text COLLATE utf8_bin NOT NULL,
  `dateVisaReferent` date NOT NULL,
  `dateSoutenance` date NOT NULL,
  `noteTravail` float NOT NULL,
  `noteRapport` float NOT NULL,
  `noteSoutenance` float NOT NULL,
  `avisJury` text COLLATE utf8_bin NOT NULL,
  `salle` text COLLATE utf8_bin NOT NULL,
  `heure` varchar(10) COLLATE utf8_bin NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapeSout`
--

LOCK TABLES `etapeSout` WRITE;
/*!40000 ALTER TABLE `etapeSout` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapeSout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapemissionsout`
--

DROP TABLE IF EXISTS `etapemissionsout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapemissionsout` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `dateRencontre` date NOT NULL,
  `typeRencontre` text COLLATE utf8_bin NOT NULL,
  `dateValidation` date NOT NULL,
  `missions` text COLLATE utf8_bin NOT NULL,
  `environnementTechnique` text COLLATE utf8_bin NOT NULL,
  `enjeux` text COLLATE utf8_bin NOT NULL,
  `signatureEtud` tinyint(1) NOT NULL,
  `signatureTuteur` tinyint(1) NOT NULL,
  `signatureReferent` tinyint(1) NOT NULL,
  `remarquesEtud` text COLLATE utf8_bin NOT NULL,
  `remarquesTuteur` text COLLATE utf8_bin NOT NULL,
  `remarquesReferent` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapemissionsout`
--

LOCK TABLES `etapemissionsout` WRITE;
/*!40000 ALTER TABLE `etapemissionsout` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapemissionsout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapevisite2`
--

DROP TABLE IF EXISTS `etapevisite2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapevisite2` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `dateRencontre` date NOT NULL,
  `pointsPositifs` text COLLATE utf8_bin NOT NULL,
  `pointsProgres` text COLLATE utf8_bin NOT NULL,
  `avancementProjet` text COLLATE utf8_bin NOT NULL,
  `dateProbableSoutenance` text COLLATE utf8_bin NOT NULL,
  `signatureEtud` tinyint(1) NOT NULL,
  `signatureTuteur` tinyint(1) NOT NULL,
  `signatureReferent` tinyint(1) NOT NULL,
  `remarquesEtud` text COLLATE utf8_bin NOT NULL,
  `remarquesTuteur` text COLLATE utf8_bin NOT NULL,
  `remarquesReferent` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`alternanceRef`),
  KEY `alternanceRef` (`alternanceRef`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapevisite2`
--

LOCK TABLES `etapevisite2` WRITE;
/*!40000 ALTER TABLE `etapevisite2` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapevisite2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_etudiant`
--

DROP TABLE IF EXISTS `fa_etudiant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_etudiant` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(30) COLLATE utf8_bin NOT NULL,
  `tel` char(20) COLLATE utf8_bin NOT NULL,
  `mail` varchar(100) COLLATE utf8_bin NOT NULL,
  `etudCle` varchar(50) COLLATE utf8_bin NOT NULL,
  `groupeRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `mailLille1` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`etudCle`),
  UNIQUE KEY `etudCle` (`etudCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_etudiant`
--

LOCK TABLES `fa_etudiant` WRITE;
/*!40000 ALTER TABLE `fa_etudiant` DISABLE KEYS */;
INSERT INTO `fa_etudiant` VALUES ('PUSKARCZYK','Alexis','0670902925','a.puska@ile-noire.com','alexis.puskarczyk','M2IAGLFA1','alexis.puskarczyk@etudiant.univ-lille1.fr'),('DUPRETZ','Amand','','amand.dupretz@gmail.com','amand.dupretz','M2MIAGEFA1','amand.dupretz@etudiant.univ-lille1.fr'),('DAVID','Amaury','0631157513','amaury.david@etudiant.univ-lille1.fr','amaury.david','M1INFOFA1','amaury.david@etudiant.univ-lille1.fr'),('DEVINCKE','Amélie','0621953725','amelie.devincke@laposte.net','amelie.devincke','M1MIAGEFA1','amelie.devincke@etudiant.univ-lille1.fr'),('COPIN','Antony','0666666422','antony.copin@gmail.com','anthony.copin','M2MIAGEFA1','anthony.copin@etudiant.univ-lille1.fr'),('CRASKE','Antoine','0679227042','antoine_craske@hotmail.com','antoine.craske','M1MIAGEFA1','antoine.craske@etudiant.univ-lille1.fr'),('DONNEZ','Antoine','0643352463','antoine.donnez@gmail.com','antoine.donnez','M2IAGLFA1','antoine.donnez@etudiant.univ-lille1.fr'),('FORAISON','Arnaud','+33628660528','arnaud.foraison@free.fr','arnaud.foraison','M2IAGLFA1','arnaud.foraison@etudiant.univ-lille1.fr'),('BERTEIN','Benjamin','','','benjamin.bertein','M1INFOFA1','benjamin.bertein@etudiant.univ-lille1.fr'),('CORNU','Benoit','0670505724','benoit.cornu.ustl@gmail.com','benoit.cornu','M2IAGLFA1','benoit.cornu@etudiant.univ-lille1.fr'),('PETIT','Benoit','0637808199','benoit1.petit@gmail.com','benoit1.petit','M1INFOFA1','benoit1.petit@etudiant.univ-lille1.fr'),('BOUBACAR MAINASSARA','Abdoul razak','0607148952','arbmainassara@gmail.com','boubacar-mainassara1','M2IAGLFA1','boubacar-mainassara1@etudiant.univ-lille1.fr'),('HERBELIN','Cécile','','cecile.herbelin@etudiant.univ-lille1.fr','cecile.herbelin','M2ESERVFA1','cecile.herbelin@etudiant.univ-lille1.fr'),('GOMBAUD','Céline','0670448524','celine.gombaud@etudiant.univ-lille1.fr','celine.gombaud','M2MIAGEFA1','celine.gombaud@etudiant.univ-lille1.fr'),('CHRISTIAENS','Charles','','christiaens.charles@gmail.com','charles.christiaens','M2MIAGEFA1','charles.christiaens@etudiant.univ-lille1.fr'),('DE POTTER','Charles','06 25 25 49 31','depotter.charles@gmail.com','charles.de-potter','M2ESERVFA1','charles.de-potter@etudiant.univ-lille1.fr'),('DECOSTER','Cindy','0674055960','cindy.decoster59@gmail.com','cindy.decoster','M2MIAGEFA1','cindy.decoster@etudiant.univ-lille1.fr'),('NICOLET','Clement','','cnicolet@hotmail.fr','clement.nicolet','M2ESERVFA1','clement.nicolet@etudiant.univ-lille1.fr'),('TEMPLEUX','Cyril','06 21 48 68 42','cyril.templeux@gmail.com','cyril.templeux','M2MIAGEFA1','cyril.templeux@etudiant.univ-lille1.fr'),('WIRTH','Cyril','0675970288','cyril.wirth@etudiant.univ-lille1.fr','cyril.wirth','M2MIAGEFA1','cyril.wirth@etudiant.univ-lille1.fr'),('DARRAS','David','','','david.darras','M2MIAGEFA1','david.darras@etudiant.univ-lille1.fr'),('DESQUIENS','David','0679494001','david.desquiens1@gmail.com','david.desquiens','M2IAGLFA1','david.desquiens@etudiant.univ-lille1.fr'),('GOMBART','Diane','0610909338','diane.gombart@gmail.com','diane.gombert','M1MIAGEFA1','diane.gombert@etudiant.univ-lille1.fr'),('PICAVET','Elise','','elise@picavet.info','elise.picavet','M2MIAGEFA1','elise.picavet@etudiant.univ-lille1.fr'),('REGNIER','Eric','0618672705','eric.regnier.mail@gmail.com','eric.regnier','M2MOCADFA1','eric.regnier@etudiant.univ-lille1.fr'),('LEDOUX','Florian','','florian.ledoux@etudiant.univ-lille1.fr','florian.ledoux','M1INFOFA1','florian.ledoux@etudiant.univ-lille1.fr'),('CARPENTIER','Florian','0648563437','florian1.carpentier@gmail.com','florian1.carpentier','M1MIAGEFA1','florian1.carpentier@etudiant.univ-lille1.fr'),('BOISSIER','François','','francois.boissier@gmail.com','francois.boissier','M2MIAGEFA1','francois.boissier@etudiant.univ-lille1.fr'),('GRUCHALA','Francois','','francois.gruchala@etudiant.univ-lille1.fr','francois.gruchala','M2ESERVFA1','francois.gruchala@etudiant.univ-lille1.fr'),('WOJTASZEWSKI','Guillaume','0689580214','g.wojtas@orange.fr','g.wojtaszewski','M2MIAGEFA1','g.wojtaszewski@etudiant.univ-lille1.fr'),('CERIEZ','Gael','0658158388','gaelceriez@free.fr','gael.ceriez','M1MIAGEFA1','gael.ceriez@etudiant.univ-lille1.fr'),('BIALAIS','Gauthier','06 31 03 17 75','gauthier.bialais@gmail.com','gauthier.bialais','M2ESERVFA1','gauthier.bialais@etudiant.univ-lille1.fr'),('BECUWE','Geoffrey','0685397051','becuweg@gmail.Com','geoffrey.becuwe','M2MOCADFA1','geoffrey.becuwe@etudiant.univ-lille1.fr'),('HECHT','Geoffrey','06 69 76 75 60','geoffrey.hecht@gmail.com','geoffrey.hecht','M1INFOFA1','geoffrey.hecht@etudiant.univ-lille1.fr'),('DESPOIS','Guillaume','','guillaumedespois@yahoo.fr','guillaume.despois','M1MIAGEFA1','guillaume.despois@etudiant.univ-lille1.fr'),('DUFOSSET','Guillaume','','guillaume.dufosset@gmail.com','guillaume.dufosset','M2ESERVFA1','guillaume.dufosset@etudiant.univ-lille1.fr'),('GALLANT','Guillaume','','guillaume.gallant@etudiant.univ-lille1.fr','guillaume.gallant','M1INFOFA1','guillaume.gallant@etudiant.univ-lille1.fr'),('LAVOREL','Jessy','0625768860','jessy.lavorel@etudiant.univ-lille1.fr','jessy.lavorel','M2ESERVFA1','jessy.lavorel@etudiant.univ-lille1.fr'),('HOCHART','Joffroy','','','joffray.hochart','M1INFOFA1','joffray.hochart@etudiant.univ-lille1.fr'),('DELEBERGHE','Jonathan','0622827149','jonathan.deleberghe@free.fr','jonathan.deleberghe','M2MIAGEFA1','jonathan.deleberghe@etudiant.univ-lille1.fr'),('CARDON','Joseph','0688553574','cardon.joseph@gmail.com','joseph.cardon','M2MIAGEFA1','joseph.cardon@etudiant.univ-lille1.fr'),('FACON','Julien','0672741919','julien.facon@gmail.com','julien.facon','M2IAGLFA1','julien.facon@etudiant.univ-lille1.fr'),('THILLIEZ','Julien','0659319754','thilliez.julien@gmail.com','julien.thilliez','M2MIAGEFA1','julien.thilliez@etudiant.univ-lille1.fr'),('BECUWE','Justine','0688950037','justine.becuwe@nordnet.fr','justine.becuwe','M1MIAGEFA1','justine.becuwe@etudiant.univ-lille1.fr'),('DEFIVES','Kévin','0603503899','kevin.defives@gmail.com','kevin.defives','M1INFOFA1','kevin.defives@etudiant.univ-lille1.fr'),('LABAT','Kévin','0664756828','labat.kevin@gmail.com','kevin.labat','M1INFOFA1','kevin.labat@etudiant.univ-lille1.fr'),('LORTHIOIS','Kevin','0626855054','klorthiois@valipost.com','kevin.lorthiois','M2IAGLFA1','kevin.lorthiois@etudiant.univ-lille1.fr'),('PORTAUX','Kévin','0626820142','kevin.portaux@etudiant.univ-lille1.fr','kevin.portaux','M2MIAGEFA1','kevin.portaux@etudiant.univ-lille1.fr'),('SANSEN','Kévin','0608153735','sansen.kevin@gmail.com','kevin.sansen','M1MIAGEFA1','kevin.sansen@etudiant.univ-lille1.fr'),('SENECHAL','Kevin','0648117060','kevin.senechal@me.com','kevin.senechal','M2IAGLFA1','kevin.senechal@etudiant.univ-lille1.fr'),('GUILBERT','Kevin','0662523343','kevin.guilbert62@gmail.com','kevin1.guilbert','M1INFOFA1','kevin1.guilbert@etudiant.univ-lille1.fr'),('BOUKERCHA','Khaled','0668431334','khaled.boukercha@gmail.com','khaled.boukercha','M2ESERVFA1','khaled.boukercha@etudiant.univ-lille1.fr'),('GABRIEL','Ladislas','0623464801','gabriel.ladislas@gmail.com','ladislas.gabriel','M2IAGLFA1','ladislas.gabriel@etudiant.univ-lille1.fr'),('MASSON','Louis','0632620289','louis.masson59@gmail.com','louis.masson','M1MIAGEFA1','louis.masson@etudiant.univ-lille1.fr'),('HOTTOIS','Ludwig','','natlantisprog@gmail.com','ludwig.hottois','M2ESERVFA1','ludwig.hottois@etudiant.univ-lille1.fr'),('MEDJOUDJ','Lyes','0658034237','lyesmedjoudj@hotmail.com','lyes.medjoudj','M2MIAGEFA1','lyes.medjoudj@etudiant.univ-lille1.fr'),('ROUSSEZ','Henri','0','henri.roussez@gmail.com','m1infofa1RH29','M1INFOFA1',NULL),('BAEKELANDT','Mael','06 76 20 82 97','mael.baekelandt@free.fr','mael.baekelandt','M2TIIRFA1','mael.baekelandt@etudiant.univ-lille1.fr'),('GILES','Manuel','0633720594','giles.manu@live.fr','manuel.giles','M2MIAGEFA1','manuel.giles@etudiant.univ-lille1.fr'),('BECKER','Marine','','marine.becker@gmail.com','marine.becker','M2ESERVFA1','marine.becker@etudiant.univ-lille1.fr'),('DESPREZ','Marine','0665122993','desprez.marine@gmail.com','marine.desprez','M1MIAGEFA1','marine.desprez@etudiant.univ-lille1.fr'),('BON','Mathieu','','mathieubon27@hotmail.com','mathieu.bon','M2IAGLFA1','mathieu.bon@etudiant.univ-lille1.fr'),('ARDON','Matthieu','0650210347','matthieu.ardon@gmail.com','matthieu.ardon','M1MIAGEFA1','matthieu.ardon@etudiant.univ-lille1.fr'),('CARPENTIER','Maxime','06 73 10 63 57','carpentier.maxime@hotmail.fr','maxime.carpentier','M2MOCADFA1','maxime.carpentier@etudiant.univ-lille1.fr'),('COLMANT','Maxime','06 24 00 12 35','maxime.colmant@gmail.com','maxime.colmant','M1INFOFA1','maxime.colmant@etudiant.univ-lille1.fr'),('DEMEESTERE','Maxime','','maxdem59@hotmail.com','maxime.demeestere','M1MIAGEFA1','maxime.demeestere@etudiant.univ-lille1.fr'),('MASCOT','Melody','0630682104','melody.mascot@orange.fr','melody.mascot','M1MIAGEFA1','melody.mascot@etudiant.univ-lille1.fr'),('MASCRET','Michaël','0698033402','mascretm@gmail.com','michael.mascret','M1MIAGEFA1','michael.mascret@etudiant.univ-lille1.fr'),('DEBLOCK','Nicolas','0610947622','nico.deblock@gmail.com','nicolas.deblock','M2MIAGEFA1','nicolas.deblock@etudiant.univ-lille1.fr'),('COUSIN','Nicolas','0675563423','nicolascousinlille@gmail.com','nicolas1.cousin','M1INFOFA1','nicolas1.cousin@etudiant.univ-lille1.fr'),('PAMULA','Noé','0609951419','noe.pamula@etudiant.univ-lille1.fr','noe.pamula','M1MIAGEFA1','noe.pamula@etudiant.univ-lille1.fr'),('SZIKA','Olivier','','szika.olivier@gmail.com','olivier.szika','M2TIIRFA1','olivier.szika@etudiant.univ-lille1.fr'),('WATINE','Pierre','0698753450','pierrewatine@gmail.com','pierre.watine','M2ESERVFA1','pierre.watine@etudiant.univ-lille1.fr'),('BEZSILKO','Quentin','06 22 66 59 41','quentin.bezsilko@gmail.com','quentin.bezsilko','M2IAGLFA1','quentin.bezsilko@etudiant.univ-lille1.fr'),('POURCHELLE','Rémi','06.37.54.04.90','remi_akheris@hotmail.com','remi.pourchelle','M2MIAGEFA1','remi.pourchelle@etudiant.univ-lille1.fr'),('TOROND','Romain','0649289801','romain.torond@gmail.com','romain.torond','M2IAGLFA1',''),('VANDECAVEYE','Romain','03 20 20 38 52','romain.vandecaveye@free.fr','romain.vandecaveye','M2ESERVFA1','romain.vandecaveye@etudiant.univ-lille1.fr'),('LEROY','Rudi','0320470404','rudileroy@nordnet.fr','rudi.leroy','M2MIAGEFA1','rudi.leroy@etudiant.univ-lille1.fr'),('STIENNE','Rudy','','','rudy.stienne','M1MIAGEFA1','rudy.stienne@etudiant.univ-lille1.fr'),('RAKOTOBE','Sitraka Eric','0320645716','se.rakotobe@etudiant.univ-lille1.fr','se.rakotobe','M1MIAGEFA1','se.rakotobe@etudiant.univ-lille1.fr'),('VELAY','Sébastien','0633153155','sebastien.velay@gmail.com','sebastien.velay','M2MIAGEFA1','sebastien.velay@etudiant.univ-lille1.fr'),('DIB','Simon','06 79 46 67 79','dib.simon@gmail.com','simon.dib','M2MIAGEFA1','simon.dib@etudiant.univ-lille1.fr'),('THERY','Sylvain','','sylvain.thery@gmail.com','sylvain.thery','M2ESERVFA1','sylvain.thery@etudiant.univ-lille1.fr'),('DJEBIEN','Tarik','0602084986','tarik.djebien@etudiant.univ-lille1.fr','tarik.djebien','M1MIAGEFA1','tarik.djebien@etudiant.univ-lille1.fr'),('HAVEZ','Thibault','0607690169','tibavez@gmail.com','thibault.havez','M2IAGLFA1','thibault.havez@etudiant.univ-lille1.fr'),('DAGHELET','Thomas','0649399524','thomas.daghelet@etudiant.univ-lille1.fr','thomas.daghelet','M2MIAGEFA1','thomas.daghelet@etudiant.univ-lille1.fr'),('LECERF','Valentin','','','valentin.lecerf','M1INFOFA1','valentin.lecerf@etudiant.univ-lille1.fr'),('HERBULOT','Vincent','0646772939','vincent.herbulot@gmail.com','vincent.herbulot','M1INFOFA1','vincent.herbulot@etudiant.univ-lille1.fr'),('DEKERLE','Yves','0666477092','yves.dekerle@gmail.com','yves.dekerle','M2ESERVFA1','yves.dekerle@etudiant.univ-lille1.fr');
/*!40000 ALTER TABLE `fa_etudiant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_formation`
--

DROP TABLE IF EXISTS `fa_formation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_formation` (
  `formationCle` varchar(10) COLLATE utf8_bin NOT NULL,
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `responsableRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `responsableRef2` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`formationCle`),
  UNIQUE KEY `formationCle` (`formationCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_formation`
--

LOCK TABLES `fa_formation` WRITE;
/*!40000 ALTER TABLE `fa_formation` DISABLE KEYS */;
INSERT INTO `fa_formation` VALUES ('M1INFOFA','M1 INFO FA','marquet',''),('M1MIAGEFA','Master 1 MIAGE FA','roos',''),('M2ESERVFA','Master 2 E Service FA','seinturi',''),('M2IAGLFA','Master Pro IAGL FA','lepallec',''),('M2IVIFA','Master 2 IVI FA','casiez',''),('M2MIAGEFA','Master 2 MIAGE FA','rouillar',''),('M2MOCADFA','Master 2 MOCAD FA','varre','derbel'),('M2TIIRFA','Master 2 TIIR FA','grimaud','');
/*!40000 ALTER TABLE `fa_formation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_groupe`
--

DROP TABLE IF EXISTS `fa_groupe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_groupe` (
  `groupeCle` varchar(20) COLLATE utf8_bin NOT NULL,
  `formationRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `responsableRef` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`groupeCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_groupe`
--

LOCK TABLES `fa_groupe` WRITE;
/*!40000 ALTER TABLE `fa_groupe` DISABLE KEYS */;
INSERT INTO `fa_groupe` VALUES ('M1INFOFA1','M1INFOFA','marquet'),('M1MIAGEFA1','M1MIAGEFA','yroos'),('M2ESERVFA1','M2ESERVFA','seinturi'),('M2IAGLFA1','M2IAGLFA','lepallec'),('M2IVIFA1','M2IVIFA','casiez'),('M2MIAGEFA1','M2MIAGEFA','yroos'),('M2MOCADFA1','M2MOCADFA','varre'),('M2TIIRFA1','M2TIIRFA','grimaud'),('TEST1','TEST','bilasco');
/*!40000 ALTER TABLE `fa_groupe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_groupe_old`
--

DROP TABLE IF EXISTS `fa_groupe_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_groupe_old` (
  `groupeCle` varchar(20) COLLATE utf8_bin NOT NULL,
  `formationRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `responsableRef` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_groupe_old`
--

LOCK TABLES `fa_groupe_old` WRITE;
/*!40000 ALTER TABLE `fa_groupe_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_groupe_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `fa_opca`
--

DROP TABLE IF EXISTS `fa_opca`;
/*!50001 DROP VIEW IF EXISTS `fa_opca`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_opca` (
  `nom` varchar(50),
  `commentaires` text,
  `anneesFinancees` int(11),
  `representant` varchar(50),
  `tel` varchar(10),
  `mail` varchar(50),
  `opcaCle` varchar(50),
  `url` varchar(200)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `fa_opca_old`
--

DROP TABLE IF EXISTS `fa_opca_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_opca_old` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `commentaires` text COLLATE utf8_bin NOT NULL,
  `anneesFinancees` int(11) NOT NULL DEFAULT '1',
  `representant` varchar(50) COLLATE utf8_bin NOT NULL,
  `tel` varchar(10) COLLATE utf8_bin NOT NULL,
  `mail` varchar(50) COLLATE utf8_bin NOT NULL,
  `opcaCle` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`opcaCle`),
  UNIQUE KEY `opcaCle` (`opcaCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_opca_old`
--

LOCK TABLES `fa_opca_old` WRITE;
/*!40000 ALTER TABLE `fa_opca_old` DISABLE KEYS */;
INSERT INTO `fa_opca_old` VALUES ('INCONNUE','',1,'','','','__sans opca__'),('ADFIM','',1,'','','','adfim'),('AFDAS','',1,'','','','afdas'),('AGECIF IEG','',1,'','','','agecif_ieg'),('AGEFOS','',1,'','','','agefos'),('AGEFOS PME','',1,'','','','agefos_pme'),('FAFIEC','',1,'','','','fafiec'),('FORCO','',1,'','','','forco'),('FORCO COGEFORM','',1,'','','','forco_cogeform'),('OPCA BANQUES','',1,'','','','opca_banques'),('OPCALIA','',1,'','','','opcalia');
/*!40000 ALTER TABLE `fa_opca_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_prof`
--

DROP TABLE IF EXISTS `fa_prof`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_prof` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(30) COLLATE utf8_bin NOT NULL,
  `tel` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `mail` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `bureau` text COLLATE utf8_bin,
  `profCle` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`profCle`),
  UNIQUE KEY `tuteurCle` (`profCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_prof`
--

LOCK TABLES `fa_prof` WRITE;
/*!40000 ALTER TABLE `fa_prof` DISABLE KEYS */;
INSERT INTO `fa_prof` VALUES ('Bilasco','Marius','','marius.bilasco@lifl.fr','','bilasco'),('Bossut','Francis',' ','francis.bossut@univ-lille1.fr',' ','bossut'),('Boulet','Pierre',NULL,'Pierre.Boulet@univ-lille1.fr',NULL,'boulet'),('Caron','Anne-Cécile',' ','anne-cecile.caron@univ-lille1.fr',' ','caronc'),('Casiez','Géry','','Gery.Casiez@lifl.fr','','casiez'),('Clerbout','Mireille',NULL,'Mireille.Clerbout@univ-lille1.fr',NULL,'clerbout'),('de Comité','Francesco',NULL,'Francesco.De-Comite@univ-lille1.fr',NULL,'decomite'),('Derbel','Bilel',NULL,'Bilel.Derbel@univ-lille1.fr',NULL,'derbel'),('Derycke','Alain','','Alain.Derycke@lifl.fr','','derycke'),('Duchien','Laurence','','laurence.duchien@univ-lille1.fr','','duchien'),('Haessle','Thomas',NULL,NULL,NULL,'ext_haessle'),('Lavigne','Serge',NULL,NULL,NULL,'ext_lavigne'),('Nogues','Loïc',NULL,NULL,NULL,'ext_nogues'),('Renaux','Emmanuel',NULL,NULL,NULL,'ext_renaux'),('Stalin','Gaëtan',NULL,NULL,NULL,'ext_stalin'),('Grimaud','Gilles','','Gilles.Grimaud@lifl.fr','','grimaud'),('Hym','Samuel',' ','samuel.hym@univ-lille1.fr',' ','hym'),('Tarby','Jean-Claude',NULL,'jean-claude.tarby@lifl.fr',NULL,'jctarby'),('Delahaye','Jean-Paul','','Jean-Paul.Delahaye@lifl.fr','','jdelahay'),('Jourdan','Laetitia',NULL,'laetitia.jourdan@lifl.fr',NULL,'jourdan'),('Komorowski','Nathalie',' ','nathalie.komorowski@univ-lille1.fr',' ','komorows'),('Kuttler','Céline','','Celine.Kuttler@lifl.fr','','kuttler'),('Noé','Laurent',' ','laurent.noe@univ-lille1.Fr',' ','laurentnoe'),('Lebbe','Jean Marie','','jean-marie.lebbe@lifl.fr','','lebbe'),('Lemaire','François',NULL,'Francois.Lemaire@univ-lille1.fr',NULL,'lemaire'),('Le Pallec','Xavier','','xavier.le-pallec@univ-lille1.fr','','lepallec'),('Lhoussaine','Cédric',NULL,'Cedric.Lhoussaine@lifl.fr',NULL,'lhoussai'),('Liefooghe','Arnaud',NULL,'Arnaud.Liefooghe@univ-lille1.fr',NULL,'liefooga'),('Mailliet','Didier',NULL,'Didier.Mailliet@univ-lille1.fr',NULL,'mailliet'),('Marquet','Philippe','','Philippe.Marquet@lifl.fr  ','','marquet'),('Marvie','Raphaël','','raphael.marvie@lifl.Fr','','marvie'),('Melab','Nouredine ','','nouredine.melab@univ-lille1.fr','','melab'),('Nebut','Mirabelle',NULL,'Mirabelle.Nebut@univ-lille1.fr',NULL,'nebut'),('Noe','Laurent',NULL,'Laurent.Noe@univ-lille1.fr',NULL,'noe'),('Plenacoste','Patricia',NULL,'Patricia.Plenacoste@lifl.fr',NULL,'plenacos'),('Pupin','Maude',' ','maude.pupin@univ-lille1.fr',' ','pupin'),('Roos','Jean-François',' ','jean-francois.roos@univ-lille1.fr',' ','roos'),('Rouillard','José',NULL,'Jose.Rouillard@univ-lille1.fr',NULL,'rouillar'),('Routier','Jean-christophe',NULL,'jean-christophe.routier@lifl.fr',NULL,'routier'),('Rouvoy','Romain',' ','romain.rouvoy@univ-lille1.fr',' ','rouvoy'),('Salson','Mikaël',NULL,'Mikael.Salson@univ-lille1.fr',NULL,'salson'),('Seinturier','Lionel','','Lionel.Seinturier@lifl.fr','','seinturi'),('Tison','Sophie',NULL,'Sophie.Tison@univ-lille1.fr',NULL,'tison'),('Vantroys','Thomas',NULL,'Thomas.Vantroys@univ-lille1.fr',NULL,'vantroys'),('Varre','Jean-Stephane','','jean-stephane.varre@lifl.fr','','varre'),('Wegrzynowski','Eric',NULL,'Eric.Wegrzynowski@univ-lille1.fr',NULL,'wegrzyno'),('Roos','Yves','','yves.roos@lifl.fr','','yroos');
/*!40000 ALTER TABLE `fa_prof` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_referent`
--

DROP TABLE IF EXISTS `fa_referent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_referent` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tel` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `mail` varchar(50) COLLATE utf8_bin NOT NULL,
  `referentCle` varchar(20) COLLATE utf8_bin NOT NULL,
  `entrepriseRef` varchar(100) COLLATE utf8_bin NOT NULL,
  `ville` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fonction` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`referentCle`),
  UNIQUE KEY `referentCle` (`referentCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_referent`
--

LOCK TABLES `fa_referent` WRITE;
/*!40000 ALTER TABLE `fa_referent` DISABLE KEYS */;
INSERT INTO `fa_referent` VALUES ('',NULL,NULL,'','m1infofa1BB0R','__sans entreprise__','',NULL),('Azzi','Ralida','0320304545','ralida.azzi@open-groupe.com','m1infofa1CM2R','open_groupe','Lambersart','Réalisateur'),('BILASCO','Céline','0673487753','cbilasco@aig.fr','m1infofa1CN3R','alliances_aifc','MARCQ EN BAROEUL',''),('DECOOL','Laurent','0320414024','ldecool@odysys.fr','m1infofa1DA4R','odysys','Villeneuve d Ascq',''),('LAUTIER','Hervé','0320198196','herve.lautier@oxylane.com','m1infofa1DK5R','oxylane','VILLENEUVE D\'ASCQ',NULL),('',NULL,NULL,'','m1infofa1GG6R','__sans entreprise__','',NULL),('MARZACK','Yann','0320221628','ymarzack@tymate.com','m1infofa1GK7R','tymate','LILLE',''),('Decrucq','Jean-Jacques','06 03 02 01 04','jean-jacques.decrucq@erdf-grdf.fr','m1infofa1HG8R','erdf','Valenciennes','Chef Agence Acheminement'),('',NULL,NULL,'','m1infofa1HJ0R','__sans entreprise__','',NULL),('Sabine','Desrumaux','0972221481','sabine.desrumaux@tasker.fr','m1infofa1HV9R','tasker','LILLE',''),('','','','','m1infofa1LF3R','eads','',''),('CORDONNIER','Vincent','0320638888','vco@audaxis.com','m1infofa1LK1R','audaxis','LILLE',NULL),('','','','','m1infofa1LV2R','groupe afg lille','Marcq en Baroeul',''),('','null','','','m1infofa1PB6R','quadra ','',''),('','','','','m1infofa1RH29R','green hosting services','',''),('',NULL,NULL,'','m1infofa1RH30R','__sans entreprise__','',NULL),('','','','','m1infofa1RH7R','__sans entreprise__','',''),('LONGHITANO','Francis','','','m1miagefa1AM0R','hardis','LA DÉFENE',''),('SPIESSER','Sophie','0362148881','sophie.spiesser@oxylane.com','m1miagefa1BJ1R','oxylane','HELLEMMES','responsable équipe informatique'),('DUMONT','Benoît','0320697104','bdumont@redoute.fr','m1miagefa1CA4R','la_redoute','ROUBAIX','DSI Redcats Europe'),('BALLOIS','Jeremy','','jeremy.ballois@logica.com','m1miagefa1CF2R','logica','LILLE',''),('PAQUES et Eric LELEU','Alain','','apaques@infitex.fr, eleleu@infitex.fr','m1miagefa1CG3R','infitex','VILLENEUVE D ASCQ',''),('DELCAMBRE','Maxime','0320799410','m.delcambre@delssi.com','m1miagefa1DA8R','delssi','VILLENEUVE D','gerant'),('DEPOORTER','Laurent','0361761095','laurent@oxemis.com','m1miagefa1DG6R','oxemis','WAMBRECHIES','Directeur associé'),('','null','','','m1miagefa1DM5R','__sans entreprise__','',NULL),('BOUQUET','Bruno','0689772396','bruno.bouquet@sathys.com','m1miagefa1DM7R','sathys','LA MADELEINE','directeur technique'),('MOUAWAD','Philippe','0320914981','p.mouawad@ubik-ingenierie.com','m1miagefa1DT9R','ubik_ingenierie','ROUBAIX','Expert technique'),('Bruandet','Romain','','romain.bruandet@capgemini.com','m1miagefa1GD0R','cap_gemini','LILLE','Chef de projet'),('DESWARTE','Antoine','0359000688','adeswarte@cylande.com','m1miagefa1ML3R','cylande','ROUBAIX',''),('GRAU','Francois regis','0359314566','Fr.grau@kiabi.com','m1miagefa1MM1R','kiabi','LYS LEZ LANNOY','responsable service décisionnel'),('MACQUART','Michaël','0320055613','mmacquart@unis.fr','m1miagefa1MM2R','unis','VILLENEUVE D',''),('Empis','Jean Loup','03 28 76 56 00','jlempis@norsys.fr','m1miagefa1PN4R','norsys','Ennevelin','Directeur des opérations'),('CASTEX','Nathalie','0668796526','maxime.souilliart@edf.fr','m1miagefa1RS5R','edf','VILLENEUVE D\'ASCQ',NULL),('BOUQUET','Bruno','0689772396','','m1miagefa1SK6R','sathys','LA MADELEINE',NULL),('DECOOL','Laurent','','Ldecool@odysys.fr','m2eservfa1BG1R','odysys','V. Ascq','resp. / chef de projet'),('Anquez','Claire','','claire.anquez@capgemini.com','m2eservfa1BK2R','cap_gemini','Lille','Responsable de projet'),('',NULL,NULL,'','m2eservfa1BM0R','logica','',NULL),('Dupuis','Christophe','0615319046','christophe-d.dupuy@edf.fr','m2eservfa1DC4R','edf','Lille, rue du luxembourg','PER expert'),('Deschutter','Thomas','','thomas.deschutter@capgemini.com','m2eservfa1DG5R','cap_gemini','Lomme/Euratechno',''),('','','','','m2eservfa1DY3R','cap_gemini','Lille',''),('',NULL,NULL,'','m2eservfa1GF6R','cristal_id','',NULL),('','','','','m2eservfa1HC7R','sopragroup','Tourcoing',''),('',NULL,NULL,'','m2eservfa1HL8R','cap_gemini','',NULL),('Travert','Cyril','0954328888','ctravert@edu-studio.com','m2eservfa1LJ21R','edu-studio','Lille (Euratechnologies)','Directeur'),('',NULL,NULL,'','m2eservfa1NC9R','mabeoindustries','',NULL),('','Ludovic','','','m2eservfa1TS0R','open_groupe','Lambersart',''),('Tourment','Christophe','03 20 20 38 52','ctourment@commerce-btoc.com','m2eservfa1VR1R','commerce_btoc','Croix','Chef de Projet'),('Demolin','Laurent','0320283419','ldemolin@monabanq.com','m2eservfa1WP2R','monabanq','Villeneuve d Ascq','Responsable du pole multimedia'),('Jonghmans','Luc','03 20 09 90 60','l.jonghmans@decanord.fr','m2iaglfa1BA1R','decanord','Lambersart',''),('',NULL,NULL,'','m2iaglfa1BM2R','__sans entreprise__','',NULL),('GROST','Anthony','0631215977','anthony.grost@capgemini.com','m2iaglfa1BQ0R','cap_gemini','CROIX',''),('LASSALLE','Alexandre','0320914981','a.lassalle@ubik-ingenierie.com','m2iaglfa1CB2R','ubik_ingenierie','ROUBAIX',''),('DHENIN','Rodolphe','','rodolphe.dhenin@comarch.fr','m2iaglfa1DA4R','comarch','LEZENNES',''),('CAILLE','François','','francois.caille@audace.fr','m2iaglfa1DD3R','audace','LENS','Développeur Programmeur'),('PERIGAULT','Pascal','','p.perigault@proxiad.com','m2iaglfa1FA6R','proxiad_nord','LILLE',NULL),('','null','','','m2iaglfa1FJ5R','cap_gemini','LILLE',NULL),('PHILIPE','Gardiner','0605181180','philippe.gardiner@oxylane.com','m2iaglfa1GL7R','oxylane','4 BOULEVARD DE MONS, VILLENEUVE D\'ASQ',NULL),('LIAGRE','Alexandre','0320653532','alexandre.liagre@capgemini.com','m2iaglfa1HT8R','cap_gemini','LOMME',NULL),('THIBAUT','Thierry','0328767000','tthibaut@valipost.com','m2iaglfa1LK9R','valipost','VILLENEUVE D\'ASCQ',NULL),('GROST','Anthony','0631215977','anthony.grost@capgemini.com','m2iaglfa1PA0R','cap_gemini','LILLE',NULL),('DUFOUR','Christophe','0952015843','christophe@dooapp.com','m2iaglfa1SK1R','dooapp','VILLENEUVE D',''),('DELOS','Stéphane','0637863356','stephane.delos@istyatech.com','m2iaglfa1TR3R','istyatech','VILLENEUVE D\'ASCQ',NULL),('',NULL,NULL,'','m2miagefa1BF0R','cap_gemini','paris',NULL),('PIESSET / TONNEAU','Arnaud / alexandre','','','m2miagefa1CA3R','erdf-grdf','DOUAI / ROUBAIX',NULL),('',NULL,NULL,'','m2miagefa1CC2R','alicante','',NULL),('Delanoy','Fabrice','','fabrice.delanoy@capgemini.com','m2miagefa1CJ1R','cap_gemini','LILLE','Directeur de Projet'),('',NULL,NULL,'','m2miagefa1DA9R','acssi','',NULL),('','null','','','m2miagefa1DC6R','logica','LILLE',NULL),('DELVOYE','Mickael','0800507503','mdelvoye@croquegel.com','m2miagefa1DJ7R','croque_gel','VILLENEUVE D\'ASCQ',NULL),('MAQUART','Michael','0320055613','mmaquart@unis.fr','m2miagefa1DN5R','unis','VILLENEUVE D',''),('RICCELLI','François','0698499220','friccelli@access-it.fr','m2miagefa1DS8R','access_it','VILLENEUVE D\'ASCQ',NULL),('DESMAREST','Xavier','','xavier.desmarest@empeiria.fr','m2miagefa1DT4R','empeiria','VA',NULL),('MACQUART','Michael','0320055613','mmacquart@unis.fr','m2miagefa1GC1R','unis','VILLENEU',''),('BARAS','François','0688328896','francois.baras@logica.com','m2miagefa1GM0R','logica','LILLE',NULL),('SAVAGE','Laurent','','laurent.savage@vilogia.fr','m2miagefa1LR2R','vilogia','VILLENEUVE D\'ASCQ',NULL),('','null','','','m2miagefa1ML3R','cap_gemini','LOMME',NULL),('',NULL,NULL,'','m2miagefa1PE4R','cap_gemini','',NULL),('MACQUART','Michael','0320055613','mmacquart@unis.fr','m2miagefa1PK5R','unis','VILLENEUVE D\'ASCQ',NULL),('PEGASE','Arnaud','0359312501','apegase@hpc-adlis.fr','m2miagefa1PR6R','hpc-adlis','TEMPLEMARS',NULL),('BARAS','François','06 88 32 88 96','francois.baras@logica.com','m2miagefa1TC7R','logica','Lille','Consultant senior'),('LE GOFF','Grégory','','glegoff@vekia.fr','m2miagefa1TJ8R','vekia','LILLE',NULL),('VANPOUILLE','Gaelle','0359578453','gaelle.vanpouille@bpx-france.net','m2miagefa1VS9R','bonprix','MARCQ EN BAROUEIL',''),('MACQUART','Michael','03-20-05-56-13','mmacquart@unis.fr','m2miagefa1WC0R','unis','VILLENEUVE D',''),('OLEON','Maryse','0328387980','maryse.oleon@erdf-grdf.fr','m2miagefa1WG1R','erdf','LILLE',NULL),('GABORY','Sébastien','','gabory.sebastien@capgemini.com','m2mocadfa1BG38R','cap_gemini','LILLE','RRH'),('DAVIOT','Michel','0362599364','michel.daviot@logica.com','m2mocadfa1CM33R','logica','LILLE',NULL),('RICHARD','Stéphane','0320653474','stephane.richard@capgemini.com','m2mocadfa1RE22R','cap_gemini','LILLE',NULL),('Hay','Frédéric','03 20 29 89 72','fhay@straton-it.fr','m2tiirfa1BM29R','straton_it','Lomme',''),('',NULL,NULL,'','m2tiirfa1SO23R','netasq','villeneuve d\'ascq',NULL);
/*!40000 ALTER TABLE `fa_referent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_sec_roles`
--

DROP TABLE IF EXISTS `fa_sec_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_sec_roles` (
  `roleDesc` text COLLATE utf8_bin NOT NULL,
  `roleCle` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`roleCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_sec_roles`
--

LOCK TABLES `fa_sec_roles` WRITE;
/*!40000 ALTER TABLE `fa_sec_roles` DISABLE KEYS */;
INSERT INTO `fa_sec_roles` VALUES ('ALL_RESP','ALL_RESP'),('','M1INFOFA_RESP'),('Resp MIAGE M1','M1MIAGEFA_RESP'),('','M2ESERVFA_RESP'),('','M2IAGLFA_RESP'),('Resp Info M2','M2INFOFA_RESP'),('M2 IVI FA resp','M2IVIFA_RESP'),('Resp Miage M2','M2MIAGEFA_RESP'),('','M2MOCADFA_RESP'),('','M2TIIRFA_RESP'),('Resp M Info','MINFOFA_RESP'),('Resp M Miage','MMIAGEFA_RESP'),('TEST_RESP','TEST_RESP');
/*!40000 ALTER TABLE `fa_sec_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_sec_user_roles`
--

DROP TABLE IF EXISTS `fa_sec_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_sec_user_roles` (
  `userRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `roleRef` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`userRef`,`roleRef`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_sec_user_roles`
--

LOCK TABLES `fa_sec_user_roles` WRITE;
/*!40000 ALTER TABLE `fa_sec_user_roles` DISABLE KEYS */;
INSERT INTO `fa_sec_user_roles` VALUES ('ALL_RESP','MINFOFA_RESP'),('ALL_RESP','MMIAGEFA_RESP'),('M2INFOFA_RESP','M2ESERVFA_RESP'),('M2INFOFA_RESP','M2IAGLFA_RESP'),('M2INFOFA_RESP','M2IVIFA_RESP'),('M2INFOFA_RESP','M2MOCADFA_RESP'),('M2INFOFA_RESP','M2TIIRFA_RESP'),('MINFOFA_RESP','M1INFOFA_RESP'),('MINFOFA_RESP','M2INFOFA_RESP'),('MMIAGEFA_RESP','M1MIAGEFA_RESP'),('MMIAGEFA_RESP','M2MIAGEFA_RESP'),('bilasco','ALL_RESP'),('casiez','M2IVIFA_RESP'),('derbel','M2MOCADFA_RESP'),('grimaud','M2TIIRFA_RESP'),('jourdan','MINFOFA_RESP'),('jourdan','MMIAGEFA_RESP'),('lebbe','MMIAGEFA_RESP'),('lepallec','M2IAGLFA_RESP'),('lepallec','MINFOFA_RESP'),('marquet','MINFOFA_RESP'),('marvie','M2IAGLFA_RESP'),('nebut','MINFOFA_RESP'),('roos','M1MIAGEFA_RESP'),('rouillar','M2MIAGEFA_RESP'),('routier','MINFOFA_RESP'),('routier','MMIAGEFA_RESP'),('seinturi','M2ESERVFA_RESP'),('varre','M2MOCADFA_RESP'),('yroos','MMIAGEFA_RESP');
/*!40000 ALTER TABLE `fa_sec_user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_soutenance`
--

DROP TABLE IF EXISTS `fa_soutenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_soutenance` (
  `formationRef` varchar(10) CHARACTER SET latin1 NOT NULL,
  `dateRemise` text CHARACTER SET latin1 NOT NULL,
  `datesSoutenances` text CHARACTER SET latin1 NOT NULL,
  `longueurRapport` text CHARACTER SET latin1 NOT NULL,
  `duréeSoutenance` text CHARACTER SET latin1 NOT NULL,
  `observationsTous` text CHARACTER SET latin1,
  `observationsTuteurs` text CHARACTER SET latin1,
  `lienExterne` text CHARACTER SET latin1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_soutenance`
--

LOCK TABLES `fa_soutenance` WRITE;
/*!40000 ALTER TABLE `fa_soutenance` DISABLE KEYS */;
INSERT INTO `fa_soutenance` VALUES ('M2MIAGEFA','30 juin 2011 à 20h','4 et 5 juillet 2011','20 à 30 pages','25 à 30 minutes d\'exposé\r\npuis 10 minutes de questions','Remettez 1 version imprimée du rapport le jour de la soutenance. \r\nEnvoyer 1 version pdf au tuteur le 30/06/2011.\r\n\r\n<a href=\'http://www.lifl.fr/~bilasco/RAPPORT_Mission_MIAGE.pdf\'>Consignes détaillées</a>','suivant les cas vous pouvez donner plus de temps aux étudiants pour vous remettre la version pdf.\r\n\r\nexceptionnellement nous pouvons faire soutenir les étudiants aussi le 6, mais cela doit rester vraiement une exception. ','http://www.lifl.fr/~bilasco/RAPPORT_Mission_MIAGE.pdf'),('L3MIAGEFA','30 juin 2011 à 20h','6 juillet 2011','20 à 30 pages','25 à 30 minutes d\'exposé\r\npuis 10 minutes de question','Remettez 1 version imprimée du rapport le jour de la soutenance. \r\nEnvoyer 1 version pdf au tuteur le 30/06/2011.\r\n\r\n<a href=\'http://www.lifl.fr/~bilasco/RAPPORT_Mission_MIAGE.pdf\'> Consignes détaillées </a>','suivant les cas de figures spécifiques vous pouvez donner plus de temps aux étudiants pour vous remettre la version pdf.','http://www.lifl.fr/~bilasco/RAPPORT_Mission_MIAGE.pdf'),('M2ESERVFA','lundi 29 aout 2011','6-7-8 septembre 2011','50 pages maximum','30 minutes exposé\r\n10 minutes questions','Remettez 1 version imprimée du rapport à votre tuteur et 1 version à Pr. Lionel Seinturier. ','',''),('M2IVIFA','fin juin pour les soutenances début juillet\r\nfin août pour les soutenances début septembre','début juillet ou début septembre','30 pages hors annexes','20 minutes exposé\r\n10 minutes questions','Remettez un rapport électronique et deux 2 exemplaires rapport papier','',''),('M2IAGLFA','','','Une page A3\r\n','20 minutes exposé\r\n10 minutes présentation','Les étudiants ont une page A3 pour faire une synthèse de leur mission (Problème, contexte, réalisation, difficulté, bilan)\r\n\r\nLe document doit être clair et visuel\r\n\r\nDans le cas d\'une période avec plusieurs missions, l\'étudiant en choisi une qu\'il présente de cette manière.\r\n\r\n<a href=\'http://www.coe.montana.edu/ie/faculty/sobek/a3/index.htm\' style=\'color:red\'>Plus d\'informations sur le rapport</a>',NULL,NULL),('M1INFOFA','30 mai 2010','du 7 au 9 juin 2010','Une page A3','20 minutes exposé\r\n10 minutes présentation','Les étudiants ont une page A3 pour faire une synthèse de leur mission (Problème, contexte, réalisation, difficulté, bilan)\r\n\r\nLe document doit être clair et visuel\r\n\r\nDans le cas d\'une période avec plusieurs missions, l\'étudiant en choisi une qu\'il présente de cette manière.\r\n\r\n<a href=\'http://www.coe.montana.edu/ie/faculty/sobek/a3/index.htm\' style=\'color:red\'>Plus d\'informations sur le rapport</a>\r\n\r\nUne séance de présentation de cette méthode est prévue le 21 mars.\r\n\r\nLes étudiants doivent rendre une version PDF et une version imprimée.','Le suivi d\'un stage, inclus aussi un suivi de la rédaction du mémoire et un suivi de la préparation de la soutenance. Merci aux tuteurs universitaires de prendre le temps de relire le mémoire avant le dépôt et de faire un retour sur les slides à l\'étudiant avant la soutenance.','http://www.coe.montana.edu/ie/faculty/sobek/a3/index.htm'),('M2TIIRFA','29 août 2011','(prévisionnelles) 7 et 8 septembre 2011','approx 30 pages +/- 20%','20 minutes éxposé\r\n10 minutes questions','Remettre une version électronique du votre rapport au responsable du Master uniquement après lecture et feu-vert donné par de votre tuteur universitaire.','Le suivi d\'un stage, inclus aussi un suivi de la rédaction du mémoire et un suivi de la préparation de la soutenance. Merci aux tuteurs universitaires de prendre le temps de relire le mémoire avant le dépôt et de faire un retour sur les slides à l\'étudiant avant la soutenance.',NULL);
/*!40000 ALTER TABLE `fa_soutenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_sudes`
--

DROP TABLE IF EXISTS `fa_sudes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_sudes` (
  `sudesCle` int(11) NOT NULL AUTO_INCREMENT,
  `nomSudes` varchar(100) COLLATE utf8_bin NOT NULL,
  `tel` varchar(40) COLLATE utf8_bin NOT NULL,
  `mail` varchar(200) COLLATE utf8_bin NOT NULL,
  `nomPrenomContact` int(100) NOT NULL,
  PRIMARY KEY (`sudesCle`),
  UNIQUE KEY `sudesRef` (`sudesCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_sudes`
--

LOCK TABLES `fa_sudes` WRITE;
/*!40000 ALTER TABLE `fa_sudes` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_sudes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_temp_tuteurs`
--

DROP TABLE IF EXISTS `fa_temp_tuteurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_temp_tuteurs` (
  `etat` int(11) NOT NULL,
  `tuteurRef` varchar(50) COLLATE utf8_bin NOT NULL,
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `nom_tuteur` varchar(50) COLLATE utf8_bin NOT NULL,
  `prenom_tuteur` varchar(50) COLLATE utf8_bin NOT NULL,
  `mail_tuteur` varchar(50) COLLATE utf8_bin NOT NULL,
  `formationRef` varchar(20) COLLATE utf8_bin NOT NULL,
  KEY `tuteurRef` (`tuteurRef`,`formationRef`),
  KEY `alternanceRef` (`alternanceRef`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='table temporaire \r\nutilis dans l''attribution des tuteurs';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_temp_tuteurs`
--

LOCK TABLES `fa_temp_tuteurs` WRITE;
/*!40000 ALTER TABLE `fa_temp_tuteurs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_temp_tuteurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temp`
--

DROP TABLE IF EXISTS `temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temp` (
  `entrepriseCle` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp`
--

LOCK TABLES `temp` WRITE;
/*!40000 ALTER TABLE `temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `fa_entreprise`
--

/*!50001 DROP TABLE IF EXISTS `fa_entreprise`*/;
/*!50001 DROP VIEW IF EXISTS `fa_entreprise`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_entreprise` AS (select `fil_entr`.`entreprise`.`nom` AS `nom`,`fil_entr`.`entreprise`.`adresse` AS `adresse`,`fil_entr`.`entreprise`.`tel` AS `tel`,`fil_entr`.`entreprise`.`ville` AS `ville`,`fil_entr`.`entreprise`.`codePostal` AS `codePostal`,`fil_entr`.`entreprise`.`opcaRef` AS `opcaRef`,`fil_entr`.`entreprise`.`entrepriseCle` AS `entrepriseCle` from `fil_entr`.`entreprise`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fa_opca`
--

/*!50001 DROP TABLE IF EXISTS `fa_opca`*/;
/*!50001 DROP VIEW IF EXISTS `fa_opca`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_opca` AS (select `fil_entr`.`opca`.`nom` AS `nom`,`fil_entr`.`opca`.`commentaires` AS `commentaires`,`fil_entr`.`opca`.`anneesFinancees` AS `anneesFinancees`,`fil_entr`.`opca`.`representant` AS `representant`,`fil_entr`.`opca`.`tel` AS `tel`,`fil_entr`.`opca`.`mail` AS `mail`,`fil_entr`.`opca`.`opcaCle` AS `opcaCle`,`fil_entr`.`opca`.`url` AS `url` from `fil_entr`.`opca`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-10-28 23:17:01
