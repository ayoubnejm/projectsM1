-- MySQL dump 10.13  Distrib 5.1.49, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: fi_stages
-- ------------------------------------------------------
-- Server version	5.1.49-3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contrat`
--

DROP TABLE IF EXISTS `contrat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contrat` (
  `etudRef` varchar(50) COLLATE utf8_bin NOT NULL,
  `tuteurRef` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `referentRef` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `opcaRef` varchar(20) COLLATE utf8_bin DEFAULT 'inconnue',
  `typeContrat` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `debutContrat` date DEFAULT NULL,
  `finContrat` date DEFAULT NULL,
  `accordOPCA` date DEFAULT NULL,
  `signatureContrat` date DEFAULT NULL,
  `alternanceCle` varchar(20) COLLATE utf8_bin NOT NULL,
  `sudesRef` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  UNIQUE KEY `alternanceCle` (`alternanceCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contrat`
--

LOCK TABLES `contrat` WRITE;
/*!40000 ALTER TABLE `contrat` DISABLE KEYS */;
INSERT INTO `contrat` VALUES ('l3infofi1,l3miagefi11TT33','','l3infofi1,l3miagefi1','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi1,l3miagefi1',NULL),('l3infofi11AA25','routier','l3infofi11AA25R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11AA25A',NULL),('l3infofi11AA37','weinberl','l3infofi11AA37R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11AA37A',NULL),('l3infofi11AM23','kuttler','l3infofi11AM23R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11AM23A',NULL),('l3infofi11BC30','kuttler','l3infofi11BC30R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11BC30A',NULL),('l3infofi11BF35','bilasco','l3infofi11BF35R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11BF35A',NULL),('l3infofi11BT36','marvie','l3infofi11BT36R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11BT36A',NULL),('l3infofi11C23','olejnik','l3infofi11C23R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11C23A',NULL),('l3infofi11CA21','marvie','l3infofi11CA21R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11CA21A',NULL),('l3infofi11CM38','marquet','l3infofi11CM38R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11CM38A',NULL),('l3infofi11DD27','decomite','l3infofi11DD27R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11DD27A',NULL),('l3infofi11DJ26','decomite','l3infofi11DJ26R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11DJ26A',NULL),('l3infofi11DJ40','jmarti','l3infofi11DJ40R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11DJ40A',NULL),('l3infofi11DL31','vacher','l3infofi11DL31R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11DL31A',NULL),('l3infofi11DM25','decomite','l3infofi11DM25R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11DM25A',NULL),('l3infofi11DN30','martinej','l3infofi11DN30R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11DN30A',NULL),('l3infofi11DZ30','kuttler','l3infofi11DZ30R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11DZ30A',NULL),('l3infofi11EA35','kuttler','l3infofi11EA35R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11EA35A',NULL),('l3infofi11EM24','wegrzyno','l3infofi11EM24R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11EM24A',NULL),('l3infofi11FA20','lhoussai','l3infofi11FA20R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11FA20A',NULL),('l3infofi11FB38','lemaire','l3infofi11FB38R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11FB38A',NULL),('l3infofi11GL21','olejnik','l3infofi11GL21R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11GL21A',NULL),('l3infofi11GM37','martinej','l3infofi11GM37R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11GM37A',NULL),('l3infofi11GO31','pupin','l3infofi11GO31R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11GO31A',NULL),('l3infofi11HV20','kuttler','l3infofi11HV20R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11HV20A',NULL),('l3infofi11II22','decomite','l3infofi11II22R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11II22A',NULL),('l3infofi11LQ22','olejnik','l3infofi11LQ22R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi11LQ22A',NULL),('l3infofi11MM24','marquet','l3infofi11MM24R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11MM24A',NULL),('l3infofi11MS23','bilasco','l3infofi11MS23R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11MS23A',NULL),('l3infofi11MV26','kuttler','l3infofi11MV26R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11MV26A',NULL),('l3infofi11Mj21','bilasco','l3infofi11Mj21R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11Mj21A',NULL),('l3infofi11Mv34','melab','l3infofi11Mv34R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11Mv34A',NULL),('l3infofi11NQ32','lhoussai','l3infofi11NQ32R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11NQ32A',NULL),('l3infofi11PK29','decomite','l3infofi11PK29R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11PK29A',NULL),('l3infofi11PT31','nebut','l3infofi11PT31R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11PT31A',NULL),('l3infofi11RM34','marvie','l3infofi11RM34R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11RM34A',NULL),('l3infofi11RP32','tison','l3infofi11RP32R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11RP32A',NULL),('l3infofi11VM24','jctarby','l3infofi11VM24R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofi11VM24A',NULL),('l3infofiAM0','marquet','l3infofiAM0R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiAM0A',NULL),('l3infofiBJ1','mailliet','l3infofiBJ1R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiBJ1A',NULL),('l3infofiCA2','decomite','l3infofiCA2R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiCA2A',NULL),('l3infofiCN3','wegrzyno','l3infofiCN3R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofiCN3A',NULL),('l3infofiDA4','marquet','l3infofiDA4R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDA4A',NULL),('l3infofiDA8','jmarti','l3infofiDA8R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDA8A',NULL),('l3infofiDB12','mailliet','l3infofiDB12R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDB12A',NULL),('l3infofiDC15','plenacos','l3infofiDC15R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDC15A',NULL),('l3infofiDC9','kuttler','l3infofiDC9R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDC9A',NULL),('l3infofiDK6','marquet','l3infofiDK6R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDK6A',NULL),('l3infofiDL7','lhoussai','l3infofiDL7R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDL7A',NULL),('l3infofiDM13','hym','l3infofiDM13R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDM13A',NULL),('l3infofiDN5','varre','l3infofiDN5R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDN5A',NULL),('l3infofiDP11','plenacos','l3infofiDP11R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDP11A',NULL),('l3infofiDS10','bogaert','l3infofiDS10R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDS10A',NULL),('l3infofiDT14','kuttler','l3infofiDT14R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDT14A',NULL),('l3infofiDY16','routier','l3infofiDY16R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiDY16A',NULL),('l3infofiGG17','varre','l3infofiGG17R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiGG17A',NULL),('l3infofiGR20','plenacos','l3infofiGR20R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiGR20A',NULL),('l3infofiGS18','bogaert','l3infofiGS18R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiGS18A',NULL),('l3infofiGT19','vacher','l3infofiGT19R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofiGT19A',NULL),('l3infofiHP21','kuttler','l3infofiHP21R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiHP21A',NULL),('l3infofiLA23','routier','l3infofiLA23R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiLA23A',NULL),('l3infofiLD26','plenacos','l3infofiLD26R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiLD26A',NULL),('l3infofiLF24','vacher','l3infofiLF24R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiLF24A',NULL),('l3infofiLG27','marquet','l3infofiLG27R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiLG27A',NULL),('l3infofiLK22','pmathieu','l3infofiLK22R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofiLK22A',NULL),('l3infofiLL28','plenacos','l3infofiLL28R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiLL28A',NULL),('l3infofiLS29','plenacos','l3infofiLS29R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofiLS29A',NULL),('l3infofiLY25','mailliet','l3infofiLY25R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiLY25A',NULL),('l3infofiMD32','pupin','l3infofiMD32R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiMD32A',NULL),('l3infofiMG30','mailliet','l3infofiMG30R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofiMG30A',NULL),('l3infofiMJ33','decomite','l3infofiMJ33R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiMJ33A',NULL),('l3infofiMS31','plenacos','l3infofiMS31R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiMS31A',NULL),('l3infofiNL34','weinberl','l3infofiNL34R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofiNL34A',NULL),('l3infofiPA36','marquet','l3infofiPA36R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiPA36A',NULL),('l3infofiPB35','plenacos','l3infofiPB35R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiPB35A',NULL),('l3infofiQS37','noe','l3infofiQS37R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiQS37A',NULL),('l3infofiRF38','olejnik','l3infofiRF38R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiRF38A',NULL),('l3infofiSI39','noe','l3infofiSI39R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiSI39A',NULL),('l3infofiWP41','lhoussai','l3infofiWP41R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiWP41A',NULL),('l3infofiYJ42','olejnik','l3infofiYJ42R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3infofiYJ42A',NULL),('l3miagefi11BB32','devienne','l3miagefi11BB32R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefi11BB32A',NULL),('l3miagefi11BC26','yroos','l3miagefi11BC26R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11BC26A',NULL),('l3miagefi11BG23','lebbe','l3miagefi11BG23R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefi11BG23A',NULL),('l3miagefi11BJ29','decomite','l3miagefi11BJ29R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11BJ29A',NULL),('l3miagefi11BM20','decomite','l3miagefi11BM20R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11BM20A',NULL),('l3miagefi11BM28','decomite','l3miagefi11BM28R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11BM28A',NULL),('l3miagefi11Bf20','lebbe','l3miagefi11Bf20R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11Bf20A',NULL),('l3miagefi11CF40','lebbe','l3miagefi11CF40R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11CF40A',NULL),('l3miagefi11CW29','bogaert','l3miagefi11CW29R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11CW29A',NULL),('l3miagefi11DA39','beaufils','l3miagefi11DA39R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11DA39A',NULL),('l3miagefi11DB20','decomite','l3miagefi11DB20R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11DB20A',NULL),('l3miagefi11DF23','caronc','l3miagefi11DF23R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefi11DF23A',NULL),('l3miagefi11DI36','decomite','l3miagefi11DI36R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11DI36A',NULL),('l3miagefi11DJ23','pupin','l3miagefi11DJ23R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefi11DJ23A',NULL),('l3miagefi11EM33','komorows','l3miagefi11EM33R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11EM33A',NULL),('l3miagefi11HA38','olejnik','l3miagefi11HA38R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11HA38A',NULL),('l3miagefi11LS31','decomite','l3miagefi11LS31R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11LS31A',NULL),('l3miagefi11OY27','jmarti','l3miagefi11OY27R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefi11OY27A',NULL),('l3miagefi11PA27','olejnik','l3miagefi11PA27R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11PA27A',NULL),('l3miagefi11PN34','lebbe','l3miagefi11PN34R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11PN34A',NULL),('l3miagefi11PR29','bilasco','l3miagefi11PR29R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11PR29A',NULL),('l3miagefi11PR35','decomite','l3miagefi11PR35R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11PR35A',NULL),('l3miagefi11Re28','bilasco','l3miagefi11Re28R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefi11Re28A',NULL),('l3miagefi11WY25','decomite','l3miagefi11WY25R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11WY25A',NULL),('l3miagefi11YW35','olejnik','l3miagefi11YW35R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11YW35A',NULL),('l3miagefi11ZC40','pupin','l3miagefi11ZC40R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefi11ZC40A',NULL),('l3miagefiBS0','jmarti','l3miagefiBS0R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiBS0A',NULL),('l3miagefiCC2','jmarti','l3miagefiCC2R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiCC2A',NULL),('l3miagefiCC4','decomite','l3miagefiCC4R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefiCC4A',NULL),('l3miagefiCF1','urruty','l3miagefiCF1R','inconnue',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefiCF1A',NULL),('l3miagefiCG3','jctarby','l3miagefiCG3R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiCG3A',NULL),('l3miagefiDA9','mailliet','l3miagefiDA9R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiDA9A',NULL),('l3miagefiDF6','urruty','l3miagefiDF6R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiDF6A',NULL),('l3miagefiDK7','plenacos','l3miagefiDK7R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiDK7A',NULL),('l3miagefiDM8','benoit.groz','l3miagefiDM8R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiDM8A',NULL),('l3miagefiDS5','jctarby','l3miagefiDS5R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiDS5A',NULL),('l3miagefiLC10','df.romero','l3miagefiLC10R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiLC10A',NULL),('l3miagefiLG11','olejnik','l3miagefiLG11R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiLG11A',NULL),('l3miagefiLW12','plenacos','l3miagefiLW12R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiLW12A',NULL),('l3miagefiML14','df.romero','l3miagefiML14R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiML14A',NULL),('l3miagefiMM13','olejnik','l3miagefiMM13R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiMM13A',NULL),('l3miagefiVN15','mailliet','l3miagefiVN15R','inconnue',NULL,NULL,NULL,NULL,NULL,'l3miagefiVN15A',NULL);
/*!40000 ALTER TABLE `contrat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_entreprise`
--

DROP TABLE IF EXISTS `fa_entreprise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_entreprise` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `adresse` text COLLATE utf8_bin,
  `tel` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `ville` text COLLATE utf8_bin NOT NULL,
  `codePostal` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `opcaRef` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `entrepriseCle` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_entreprise`
--

LOCK TABLES `fa_entreprise` WRITE;
/*!40000 ALTER TABLE `fa_entreprise` DISABLE KEYS */;
INSERT INTO `fa_entreprise` VALUES ('Nodevo',NULL,NULL,'',NULL,NULL,'nodevo'),('ODYSYS',NULL,NULL,'',NULL,NULL,'odysys'),('Vekia',NULL,NULL,'',NULL,NULL,'vekia'),('Nicetomeetyou',NULL,NULL,'',NULL,NULL,'nicetomeetyou'),('Micropross',NULL,NULL,'',NULL,NULL,'micropross'),('Monabanq',NULL,NULL,'',NULL,NULL,'monabanq'),('Societe Française de télésurveillance',NULL,NULL,'',NULL,NULL,'soc_fr_telesurveillance'),('Lys-Adour',NULL,NULL,'',NULL,NULL,'lys-adour'),('Cofidis participations',NULL,NULL,'',NULL,NULL,'cofidis participations'),('LMCU',NULL,NULL,'',NULL,NULL,'lmcu'),('Observatoire USTL',NULL,NULL,'',NULL,NULL,'observatoire ustl'),('ENOVA',NULL,NULL,'',NULL,NULL,'enova'),('SQL Technologies',NULL,NULL,'',NULL,NULL,'sql technologies'),('Transdev Reims',NULL,NULL,'',NULL,NULL,'transdev reims'),('OPO',NULL,NULL,'',NULL,NULL,'opo'),('Artcom Production',NULL,NULL,'',NULL,NULL,'artcom production'),('Audaxis',NULL,NULL,'',NULL,NULL,'audaxis'),('Carter-Cash',NULL,NULL,'',NULL,NULL,'carter-cash'),('EADS',NULL,NULL,'',NULL,NULL,'eads'),('Aeronet',NULL,NULL,'',NULL,NULL,'aeronet'),('INRIA R2DP',NULL,NULL,'',NULL,NULL,'inria r2dp'),('Alligone',NULL,NULL,'',NULL,NULL,'alligone'),('Wid\'Op',NULL,NULL,'',NULL,NULL,'wid\'op'),('Atos Wordline',NULL,NULL,'',NULL,NULL,'atos wordline'),('Oliver Store',NULL,NULL,'',NULL,NULL,'oliver store'),('AGLAE',NULL,NULL,'',NULL,NULL,'aglae'),('CuisineAZ',NULL,NULL,'',NULL,NULL,'cuisineaz'),('Shirka',NULL,NULL,'',NULL,NULL,'shirka'),('Keynesoft',NULL,NULL,'',NULL,NULL,'keynesoft'),('ELOSI',NULL,NULL,'',NULL,NULL,'elosi'),('INRIA',NULL,NULL,'',NULL,NULL,'inria'),('GFI',NULL,NULL,'',NULL,NULL,'gfi'),('Infitex',NULL,NULL,'',NULL,NULL,'infitex'),('Oxygem',NULL,NULL,'',NULL,NULL,'oxygem'),('Axecibles',NULL,NULL,'',NULL,NULL,'axecibles'),('Reference Directe',NULL,NULL,'',NULL,NULL,'reference directe'),('Delssi',NULL,NULL,'',NULL,NULL,'delssi'),('Citadelle Scientifique',NULL,NULL,'',NULL,NULL,'citadelle scientifique'),('UNIS',NULL,NULL,'',NULL,NULL,'unis'),('Dynamic web',NULL,NULL,'',NULL,NULL,'dynamic web'),('é1',NULL,NULL,'é2',NULL,NULL,'é1'),('EDF',NULL,NULL,'Villeneuve d\'Ascq',NULL,NULL,'edf'),('CICE',NULL,NULL,'Hellemmes',NULL,NULL,'cice'),('INRIA /Dart',NULL,NULL,'Villeneuve d\'Ascq',NULL,NULL,'inria_/dart'),('Mobitic Asso 1901',NULL,NULL,'Lille',NULL,NULL,'mobitic_asso_1901'),('Keyneosoft',NULL,NULL,'Tourcoing',NULL,NULL,'keyneosoft'),('MCM groupe View-on',NULL,NULL,'Roubaix',NULL,NULL,'mcm_groupe_view-on'),('Madeco',NULL,NULL,'Pont A Marcq',NULL,NULL,'madeco'),('Leroy Merlin',NULL,NULL,'Lezennes',NULL,NULL,'leroy_merlin'),('_sans entreprise__',NULL,NULL,'',NULL,NULL,''),('Netasq',NULL,NULL,'Villeneuve d\'Ascq',NULL,NULL,'netasq'),('Caisse d\'Epargne Nord France Europe',NULL,NULL,'Lille',NULL,NULL,'caisse_d\'epargne_nord_france_europe'),('Alliances AIFC',NULL,NULL,'Marcq-en-Baroeul',NULL,NULL,'alliances_aifc'),('Norsys',NULL,NULL,'ennevelin',NULL,NULL,'norsys'),('Willemse',NULL,NULL,'',NULL,NULL,'willemse'),('Caisse d epargne',NULL,NULL,'Lille',NULL,NULL,'caisse d epargne'),('DMCO',NULL,NULL,'Tourcoing',NULL,NULL,'dmco'),('Vive la vie',NULL,NULL,'Mons-en-Baroeul',NULL,NULL,'vive_la_vie'),('Tasker',NULL,NULL,'Lille',NULL,NULL,'tasker'),('France 3 NPDC',NULL,NULL,'Lille',NULL,NULL,'france_3_npdc'),('AIRIAL conseil',NULL,NULL,'Puteaux',NULL,NULL,'airial_conseil'),('Absystech',NULL,NULL,'Roubaix',NULL,NULL,'absystech'),('Akawam',NULL,NULL,'Lille',NULL,NULL,'akawam'),('erzyiu',NULL,NULL,'reuzyi',NULL,NULL,'erzyiu'),('tert',NULL,NULL,'tre',NULL,NULL,'tert'),('NUMSOFT',NULL,NULL,'Tourcoing',NULL,NULL,'numsoft'),('Atos Worldline SAS',NULL,NULL,'Noyelles les Seclin',NULL,NULL,'atos_worldline_sas'),('Onix creation',NULL,NULL,'Saint-Omer',NULL,NULL,'onix_creation'),('Ecole superieure journalisme de lille',NULL,NULL,'Lille',NULL,NULL,'ecole_superieure_journalisme_de_lille'),('Viva Cours',NULL,NULL,'Lille',NULL,NULL,'viva_cours'),('Tape a l oeil',NULL,NULL,'Wasquehal',NULL,NULL,'tape_a_l_oeil'),('Leader informatique',NULL,NULL,'Lille',NULL,NULL,'leader_informatique'),('Lille 3 ',NULL,NULL,'Villeneuve d\'Ascq',NULL,NULL,'lille_3_'),('ITM',NULL,NULL,'Mouvaux',NULL,NULL,'itm'),('centre d\'information culturelle et economique',NULL,NULL,'Hellemmes',NULL,NULL,'centre_d\'information_culturelle_et_economique'),('Helfy',NULL,NULL,'Libercourt',NULL,NULL,'helfy'),('Heliopac',NULL,NULL,'Tourcoing',NULL,NULL,'heliopac'),('Nectup',NULL,NULL,'Lille',NULL,NULL,'nectup'),('SOC BTL',NULL,NULL,'Hellemmes',NULL,NULL,'soc_btl'),('centre d',NULL,NULL,'Hellemmes',NULL,NULL,'centre d'),('SUAPS Lille 2',NULL,NULL,'Lille',NULL,NULL,'suaps lille 2'),('Boulangerie Deblock',NULL,NULL,'Dunkerque',NULL,NULL,'boulangerie_deblock'),('urbilog',NULL,NULL,'Roubaix',NULL,NULL,'urbilog'),('Tellja',NULL,NULL,'Frankfurt am Main',NULL,NULL,'tellja'),('DMJ Communication',NULL,NULL,'Lille',NULL,NULL,'dmj_communication'),('Libertrip',NULL,NULL,'Lille',NULL,NULL,'libertrip'),('Diramode',NULL,NULL,'Villeneuve d\'Ascq',NULL,NULL,'diramode'),('CERI',NULL,NULL,'Nanjing (Chine)',NULL,NULL,'ceri'),('Apreva',NULL,NULL,'Arras',NULL,NULL,'apreva'),('Netice',NULL,NULL,'Villeneuve d\'ascq',NULL,NULL,'netice'),('LIFL',NULL,NULL,'Villeneuve d\'ascq',NULL,NULL,'lifl'),('BIgbandprojekt',NULL,NULL,'roubaix',NULL,NULL,'bigbandprojekt'),('USTL Pole calcul',NULL,NULL,'Villeneuve d\'Ascq',NULL,NULL,'ustl_pole_calcul'),('Chenelet developpement',NULL,NULL,'Bonningues les Calais',NULL,NULL,'chenelet_developpement'),('Ingersoll-rand air Solutions Hibon',NULL,NULL,'Wasquehal',NULL,NULL,'ingersoll-rand_air_solutions_hibon'),('Centre hospitalier Clermont (Oise)',NULL,NULL,'Clermont (Oise)',NULL,NULL,'centre_hospitalier_clermont_(oise)'),('INRA Avignon',NULL,NULL,'Avignon',NULL,NULL,'inra_avignon'),('RVGI Soft',NULL,NULL,'Roubaix',NULL,NULL,'rvgi_soft'),('SARL de Mine a Zhengzhou',NULL,NULL,'Zhengzhou (Chine)',NULL,NULL,'sarl_de_mine_a_zhengzhou'),('Noronweb',NULL,NULL,'',NULL,NULL,'noronweb'),('Cylande',NULL,NULL,'',NULL,NULL,'cylande'),('Logica',NULL,NULL,'',NULL,NULL,'logica'),('nordsoft',NULL,NULL,'',NULL,NULL,'nordsoft'),('Odiso',NULL,NULL,'',NULL,NULL,'odiso'),('Scotler France',NULL,NULL,'',NULL,NULL,'scotler france'),('Oxylane',NULL,NULL,'Houplines',NULL,NULL,'oxylane'),('Eurotunnel',NULL,NULL,'Coquelles',NULL,NULL,'eurotunnel');
/*!40000 ALTER TABLE `fa_entreprise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_etapeet`
--

DROP TABLE IF EXISTS `fa_etapeet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_etapeet` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `dateRencontre` date DEFAULT NULL,
  `service` text COLLATE utf8_bin NOT NULL,
  `client` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `missions` text COLLATE utf8_bin NOT NULL,
  `environnementTechnique` text COLLATE utf8_bin NOT NULL,
  `integrationEntreprise` text COLLATE utf8_bin,
  `signatureEtud` tinyint(1) DEFAULT NULL,
  `signatureTuteur` tinyint(1) DEFAULT NULL,
  `remarquesEtud` text COLLATE utf8_bin,
  `remarquesTuteur` text COLLATE utf8_bin,
  `motscles` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_etapeet`
--

LOCK TABLES `fa_etapeet` WRITE;
/*!40000 ALTER TABLE `fa_etapeet` DISABLE KEYS */;
INSERT INTO `fa_etapeet` VALUES ('l3infofiAM0A',NULL,'',NULL,'better query support for HAL websites','xquery',NULL,NULL,NULL,NULL,NULL,''),('l3infofiBJ1A',NULL,'',NULL,'dvpt .NET','',NULL,NULL,NULL,NULL,NULL,''),('l3infofiCA2A',NULL,'',NULL,'dvpt applis windows','c# visual studio,sql server',NULL,NULL,NULL,NULL,NULL,''),('l3infofiCN3A',NULL,'',NULL,'dvpt web ecommerce','php,zend,magento,mysql,html,javascript jquery',NULL,NULL,NULL,NULL,NULL,''),('l3infofiDA4A',NULL,'',NULL,'applications mobiles','iphone android',NULL,NULL,NULL,NULL,NULL,''),('l3infofiDN5A',NULL,'',NULL,'dvpt produit gestion de stock','java j2EE',NULL,NULL,NULL,NULL,NULL,''),('l3infofiDK6A','2011-05-09','','','dvp web ','php mysql wordpress','',NULL,0,NULL,'',''),('l3infofiDL7A',NULL,'',NULL,'dvpt web  ','',NULL,NULL,NULL,NULL,NULL,''),('l3infofiDA8A',NULL,'',NULL,'création ERP','php javascript',NULL,NULL,NULL,NULL,NULL,''),('l3infofiDC9A','2011-04-20','pole multimedia','','La mission est de mettre en place une messagerie pour le site client de Monabanq. Un formulaire existe deja pour permettre au client de consulter son conseiller, puis les echanges se font en passant par l adresse mail personnelle du client.\r\n\r\nIl faut mettre en place une interface de messagerie sur le site client, afin que les echanges puissent se poursuivre directement sur le site, apres l envoi du premier message via le formulaire.\r\n\r\nCharlotte travaille avec un etudiant de DUT informatique sur la partie expression du besoin. Le binome va creer une boite de messagerie avec les onglets  - Boite de reception  -- Messages envoyes -- Brouillons-- comme dans une messagerie ordinaire, ainsi qu un onglet -- Rediger un message -- qui reprendra le formulaire initial pour l envoi de messages. Cette messagerie comportera des fonctionnalites comme repondre a un message, supprimer un message, trier les messages etc.\r\n','Concernant l etude du besoin, Charlotte utilise essentiellement des diagrammes UML: cas d utilisation, diagramme de classes.\r\n\r\nL architecture du site suit le modele MCV -- Modele-Vue-Controleur --, et pour developper le projet, l etudiante utilise J2EE, notamment Struts, ainsi que Javascript, CSS, html. Elle sera certainement amenee a utiliser ulterieurement Ajax et Flash.\r\n','L equipe du pole multimedia est composee de 13 personnes: un chef de pole, 2 chefs de projet, 1 etudiant en alternance, 2 stagiaires, 3 prestataires et 4 internes. L ambiance dans l equipe est tres bonne, chacun est en mesure d aider les autres en cas de probleme.\r\n\r\nCharlotte a egalement rencontre des personnes de differents poles lors de reunions : une conseillere et le service internet et nouveaux medias.\r\nUne formation d integration appelee Monaday pour les nouveaux arrivants a egalement eu lieu pendant une matinee, ce qui a permis de connaitre un peu mieux l entreprise et de rencontrer d autres stagiaires ou prestataires.\r\n',NULL,0,NULL,'',''),('l3infofiDS10A',NULL,'',NULL,'extension logiciel gestion','php   ',NULL,NULL,NULL,NULL,NULL,''),('l3infofiDP11A',NULL,'',NULL,'dvpt web  ','',NULL,NULL,NULL,NULL,NULL,''),('l3infofiDB12A',NULL,'',NULL,'application winform domaine médical','.Net  ',NULL,NULL,NULL,NULL,NULL,''),('l3infofiDM13A','2011-03-31','','','Développement web, avec intégration de divers éléments graphiques, confection de pages web et de messages électroniques\r\nConception et développement de modules pour la solution Magento\r\nMaintenance de la solution Magento et du back office, développé entièrement en interne','Développement en PHP5, avec le Framework Zend et la solution Magento pour la partie serveur ; développement en javascript, avec jQuery pour la partie client.','La taille de l’entreprise (5 personnes) rendra la tâche aisée.\r\n',NULL,1,NULL,'',''),('l3infofiDT14A','2011-04-11','architecture applicative','','La mission principale est de realiser une application avec IHM en java cliente (processus lourd) a l aide de l API SWING et d un framework de visualisation open source pour le langage JAVA, choisi apres une etude de marche de l etudiant, afin de representer l ensemble des domaines Weblogic de l entreprise et leur dependances selon la hierarchie suivante:\r\n\r\nDomaine -> Cluster -> Managed Server -> datasource -> schema Oracle\r\n\r\nL IHM devra etre consultable et operationnelle a la fin des 3 mois de stage avec des fonctionnalites adaptees aux besoins de l entreprise.','L environnement de travail est une machine Windows Xp sur laquelle l etudiant ne dispose pas de droit administrateur, donc impossibilite d installer des logiciels. Le proxy du navigateur restreint egalement la consultation de sites basiques. C est pourquoi l etudiant travaille directement sur son PC portable avc un OS LINUX sur lequelle il est connecte au reseaux WIFI de l entreprise moins restrictif.\r\n','L etudiant occupe son poste au sein de l equipe Architecture applicative du groupe COFIDIS. Il dispose d un maitre de stage Mr PREVOT Jean-Francois, sous la direction de Mr DESMAZIERE Pascal.\r\n\r\n\r\nL ambiance est plutot bonne. L etudiant partage un bureau avec 13 personnes, prestataires de SSII et internes. Il ne profite pas de formation specifique a la mission, il se doit d etre autonome et de s auto former.\r\n\r\nAucun cahier des charges n a formellement ete etabli et communique a l etudiant.\r\nUne reunion se deroule chaque vendredi afin que l etudiant fasse le bilan de la semaine a Mr PREVOT et Mr DESMAZIERE.\r\n\r\nLe serieux de l etudiant est apprecie par l entreprise qui souhaiterai le garder pour la periode juillet-aout. L etudiant souhaite en savoir plus sur la possibilite de prolongation de la convention de stage.\r\n',NULL,0,NULL,'',''),('l3infofiDC15A',NULL,'',NULL,'application intranet','php oracle',NULL,NULL,NULL,NULL,NULL,''),('l3infofiDY16A',NULL,'',NULL,'visualisation orbit 3d de satellites','java',NULL,NULL,NULL,NULL,NULL,''),('l3infofiGG17A',NULL,'',NULL,'Dvpt d\'un serveur SOAP pour OpenERP','',NULL,NULL,NULL,NULL,NULL,''),('l3infofiGS18A',NULL,'',NULL,'dvpt internet','a definir',NULL,NULL,NULL,NULL,NULL,''),('l3infofiGT19A',NULL,'',NULL,'gestion de l\'affectation des bus','web+ à définir',NULL,NULL,NULL,NULL,NULL,''),('l3infofiGR20A',NULL,'',NULL,'dvpt web  ','php html',NULL,NULL,NULL,NULL,NULL,''),('l3infofiHP21A','2011-04-26','','','Les missions confiees a Perrine sont principalement axees sur le web. Creation d un site web et modifications sur d autres sites deja existants.\r\nNouvelle mission vers la fin du premier mois, realisation d un petit jeu en programmation 3D pour apprendre les bases de la 3D.','Equipe de 4 personnes, dont un developpeur web qui est maitre de stage. Developpement web avec Dreamweaver, programmation 3D avec Unity et Maya en C#.','Tres bonne integration dans l entreprise des la premiere semaine. Les employes ont mis a l aise l etudiante des le debut. Tout ce passe tres bien au sein de l entreprise.\r\n',NULL,0,NULL,'',''),('l3infofiLK22A',NULL,'',NULL,'dvpt  ','i2ee dotnet drupal ez publish',NULL,NULL,NULL,NULL,NULL,''),('l3infofiLA23A',NULL,'',NULL,'dvpt logiciel maison','.net vb.net',NULL,NULL,NULL,NULL,NULL,''),('l3infofiLF24A',NULL,'',NULL,'securité informatique dvpt boit a outils','asm, c ,python',NULL,NULL,NULL,NULL,NULL,''),('l3infofiLY25A',NULL,'',NULL,'application winform domaine médical','.Net  ',NULL,NULL,NULL,NULL,NULL,''),('l3infofiLD26A',NULL,'',NULL,'dvpt Web  ','',NULL,NULL,NULL,NULL,NULL,''),('l3infofiLG27A','2011-05-23','','','modification java kvm','c java j2me','',NULL,0,NULL,'',''),('l3infofiLL28A',NULL,'',NULL,'dvpt web  ','php sql python',NULL,NULL,NULL,NULL,NULL,''),('l3infofiLS29A','0000-00-00','','','calculs sur grille, migration','','',NULL,0,NULL,'',''),('l3infofiMG30A',NULL,'',NULL,'dvpt interface web d\'administration','j2e ajax jms',NULL,NULL,NULL,NULL,NULL,''),('l3infofiMS31A',NULL,'',NULL,'refonte site internet','php javascript mysql',NULL,NULL,NULL,NULL,NULL,''),('l3infofiMD32A',NULL,'',NULL,'automatiser surveillance serveurs','nagios',NULL,NULL,NULL,NULL,NULL,''),('l3infofiMJ33A',NULL,'',NULL,'dvpt web  ','',NULL,NULL,NULL,NULL,NULL,''),('l3infofiNL34A','0000-00-00','','','dvpt web','','',NULL,0,NULL,'',''),('l3infofiPB35A',NULL,'',NULL,'tests d\'integration','MVS packbase',NULL,NULL,NULL,NULL,NULL,''),('l3infofiPA36A','2011-05-06','-','-','dvpt solutions mobile commerce','java web objectivec','sans soucis',NULL,0,NULL,'',''),('l3infofiQS37A','2011-06-19','','','Dvpt Web.','dvpt web : PHP sur framework zend, ajax.','parfaite',NULL,0,NULL,'',''),('l3infofiRF38A',NULL,'',NULL,'application winform domaine médical','c# WPF visual studio',NULL,NULL,NULL,NULL,NULL,''),('l3infofiSI39A','0000-00-00','','','Dvpt web : projets .net, UOF, PYC','Dvpt web : CSS, PHP (Zend), SQL ...','parfaite',NULL,1,NULL,'',''),('l3infofiWP41A','2011-06-08','Mostrare','','méthode de construction de graphe à partir d\'espace vectoriel','','apparemment très bien',NULL,1,NULL,'',''),('l3infofiYJ42A',NULL,'',NULL,'dvpt d\'un serveur SOAP pour OpenERP','.NET vb.net',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiBS0A',NULL,'',NULL,'dvpt outil de gestion','php, mysql, graphisme',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiCF1A',NULL,'',NULL,'','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiCC2A',NULL,'',NULL,'vpt web e-business','c# extJS',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiCG3A',NULL,'',NULL,'dvpt intrante interface graphique','flex iseries',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiCC4A',NULL,'',NULL,'dvpt et maintenance web','php javascript css html',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiDS5A','2010-05-31','Pôle Flex','','Développement Flex (4 projets)','Dev sur machine XP avec FlashBuilder, dévt Flex 3, 4.5 et 4.5 mobile','Très bien, aucun souci à noter. Gestion souple des heures de travail. Bon encadrement.',NULL,1,NULL,'',''),('l3miagefiDF6A',NULL,'',NULL,'dvpt internet','php mysql ',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiDK7A',NULL,'',NULL,'dvpt web gestion contenu editorial ','php oracle javascript ajax',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiDM8A',NULL,'',NULL,'dvpt   ','php mysql erp',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiDA9A',NULL,'',NULL,'appli web ecole pilotage','TODO',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiLC10A',NULL,'',NULL,'E-commerce php','php  ',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiLG11A',NULL,'',NULL,'dvpt bdd','TODO',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiLW12A',NULL,'',NULL,'','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiMM13A',NULL,'',NULL,'CMS dvpt web','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiML14A',NULL,'',NULL,'dvpt web','php html css',NULL,NULL,NULL,NULL,NULL,''),('l3miagefiVN15A',NULL,'',NULL,'applications .NET dans le domaine médical','winform .net',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11PA27A',NULL,'',NULL,'realistation site internet','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11YW35A',NULL,'',NULL,'dvpt internet base de donnees','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11VM24A',NULL,'',NULL,'generation automatique de représentation graphique','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11DL31A',NULL,'',NULL,'outils internet pour professionnels de l\'image','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11MM24A','2011-05-06','-','-','dvpt applis mobiles et tactiles','','Sans soucis',NULL,0,NULL,'',''),('l3infofi11EM24A',NULL,'',NULL,'site web dynamique, applis mobiles','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11NQ32A',NULL,'',NULL,'dvpt internet','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11HA38A',NULL,'',NULL,'Integration du WRP navitrans dans l\'ERP Navision','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11BC26A',NULL,'',NULL,'Integration de briques externes à l\'intranet existant','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11C23A','0000-00-00','','','Implementation de tests unitaires de modules de securite reseaux','','',NULL,0,NULL,'',''),('l3miagefi11BG23A',NULL,'',NULL,'dvpt suivi portefeuilles','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11Bf20A',NULL,'',NULL,'dvpt editeur d\'etats','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11CF40A',NULL,'',NULL,'mise en place de Sterling','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11PN34A',NULL,'',NULL,'dvpt applicatif','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11DF23A','0000-00-00','','','planification d\'etat sur serveur BOXI','','',NULL,0,NULL,'',''),('l3miagefi11PR35A',NULL,'',NULL,'dvpt module postage en FLEX','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11FB38A',NULL,'',NULL,'dvpt php','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11BC30A','2011-04-21','','','Mise en place de differents serveurs et services (VPN, Nagios, Centreon), de scripts SNMP et Cloudwatch pour recuperer les metriques des machines amazon. Administration Reseau.\r\nFutur : projet ERP de l entreprise en PHP.','L etudiant travaille sur un client leger \"wyse\", en se connectant directement du wyse vers une machine virtuelle  Windows Server 2003 qui est son environnement de travail. Il utilise beaucoup putty (client ssh pour windows) pour administrer les machines a distance.\r\n','Toute l equipe travaille dans la meme piece, ce qui facilite grandement la communication. L ambiance de travail est agreable.\r\n\r\n ',NULL,1,NULL,'',''),('l3infofi11HV20A','2011-04-21','','','Test de montee en charge, recettage de l application The Nuage interfacant l offre AWS d Amazon et d autres par la suite. Correction de bugs, etude preparatoire pour la refonte de l IHM, developpement de scripts pour la mise en place d un ERP au sein de Tasker, documentation.\r\n','Depuis des boitiers wyze sur differents serveurs : connection via TSE, SSH. Travail sur Windows 2003 server, ubuntu, debian, serveur apache, Glassfish muni de Mysql, ce sont des environnements virtuels.\r\n','L integration se passe bien, l etudiant travaille a 6 dans la meme piece et l ambiance est bonne. L etudiant peut facilement avancer sur les taches qui lui sont confiees, poser des questions etc\r\n ',NULL,1,NULL,'',''),('l3infofi11EA35A','2011-04-26','service informatique','','La mission de stage est la creation d une application web dediee a la communication interne de la population France 3.\r\nIl s agit de mise en oeuvre d une plateforme multi-session, avec autant de sessions que de rubriques sur l intranet, qui permettra d alimenter\r\nla base de donnee en informations, ainsi que la diffusion en temps reel sur un site intranet en premier temps, et sur des ecrans \r\napres convertion du signal en VGA.\r\n\r\nD autre part  l etudiant participe regulierement a des manipulations sur le reseaux , les switchs et le WLAN en fin de journee.','L etudiant travaille sous windows XO masterise, avec l editeur notepad++. Il utilise du PHP, javascript, et PL SQL pour gerer la base de donnee. Il a acces a un serveur web pour tester et lancer son site.\r\n','L integration se passe dans de bonnes conditions, vu la nature du projet qui necessite d\'aller parler aux colleges des differents services concernes. L etudiant est contraint d aller discuter avec les differents contributeurs pour le site, afin de faire des pages personnalises et adequates, tel que la redaction pour le journal de midi et du soir, et d autres emissions. Pour l encadrement, il y a un developpeur\r\nainsi que le chef de service informatique.\r\n',NULL,0,NULL,'',''),('l3infofi11CM38A','2011-05-06','-','-','dvpt applis mobiles et tactiles. ','','Sans soucis. ',NULL,0,NULL,'',''),('l3miagefi11BM28A','0000-00-00','','','integration d\'un etl pour alimentation d\'un datawarehouse','','',NULL,0,NULL,'',''),('l3infofi11BF35A',NULL,'',NULL,'integration d\'un etl pour alimentation d\'un datawarehouse','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11Mj21A','2011-04-11','','','application de gestion de ressources humaines. répartition de l\'effort entre differents projets. à l\'heure actuelle, les chefs de projets se réunissent tous les lundis pour décider du planning de la semaine. l\'application développée par julien se substituera à ces réunions.\r\n\r\ndifférents niveau d\'accès seront possibles suivant les habilitations des personnes se connectant à l\'application.\r\n\r\nil existe une ébauche d\'un cahier des charges que Julien devra reprendre et retravailler.  ','Php+MySQL ou J2EE à décider ultérieuremment','Julien se déclare content de l\'environnement de travail. Il se trouve dans le même bureau que les personnes avec qui il devra le plus intéragir : resp. BD (aspects SI) et un chef de projet informatique (aspects devel).',NULL,0,NULL,'',''),('l3miagefi11EM33A',NULL,'',NULL,'dvpt web','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11BB32A',NULL,'',NULL,'dvpt web','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi1,l3miagefi1',NULL,'',NULL,'','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11DJ26A',NULL,'',NULL,'dvpt web','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11AA25A',NULL,'',NULL,'dvpt serveur Java','java',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11WY25A',NULL,'',NULL,'dvpt site web (teletravail)','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11AA37A',NULL,'',NULL,'dvp web jsp .net','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11BJ29A',NULL,'',NULL,'dvpt web','php',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11CW29A',NULL,'',NULL,'annuaire des anciens','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11FA20A',NULL,'',NULL,'dvpt portail pedagogique','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11DN30A',NULL,'',NULL,'dvpt web','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11GM37A',NULL,'',NULL,'dvpt web j2EE java','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11DM25A',NULL,'',NULL,'Projet Escucha','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11DB20A',NULL,'',NULL,'dvpt web','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11LQ22A',NULL,'',NULL,'dvpt web+BDD','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11GL21A',NULL,'',NULL,'dvpt php reseaux','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11RP32A',NULL,'',NULL,'logiciel de controle et maintenance','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11BT36A',NULL,'',NULL,'','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11CA21A',NULL,'',NULL,'migration applications web','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11Re28A','0000-00-00','','','dvpt webservices','php oracle talend','',NULL,0,NULL,'',''),('l3miagefi11DI36A',NULL,'',NULL,'dvpt web','php joomla',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11DA39A',NULL,'',NULL,'dvpt outil d\'audit','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11II22A',NULL,'',NULL,'extraction de donnees depuis un datawarehouse','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11AM23A','2011-04-21','ReflexeCE','','ReflexeCE souhaite migrer son application pour la gestion de comites d\'entreprises, developpee en PHP et MYSQL, sur une plateforme MVC. Le framework retenu est Code Igniter.  Ce stage permettra a l etudiant d accompagner le chef de projet dans le developpement -- migration -- de l application.\r\n','L etdudiant a sa disposition un PC sous Ubuntu 10.04 sans les droits administrateurs et acces aux base de donnes en temps qu administrateur ','C est une petite PME avec 15 salaries, dont 6 sur Lille. Tout le monde dit bonjour aux autres le matin, on se connait et l information circule bien. L etudiant travaille dans la meme salle que les deux autres developpeurs. Ils ont une reunion ensemble chaque lundi matin et souvent un repas commun le mercredi midi.\r\n',NULL,0,NULL,'',''),('l3infofi11RM34A',NULL,'',NULL,'ruby','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11MS23A',NULL,'',NULL,'cartographie du systeme d\'information','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11ZC40A',NULL,'',NULL,'dvpt systeme surveillance environnement','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11PR29A',NULL,'',NULL,'migration de donnees, requetes','oracle, BO',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11MV26A','2011-05-05','','','L etudiante participera au developpement de solutions web dediees a la creation de portfolios numeriques, professionnels et d apprentissage :\r\n* Participation a la realisation des etudes fonctionnelles et techniques\r\n* Developpement Web des applications\r\n\r\nElle travaillera en particulier a partir de la plateforme open source d ePortfolio Mahara pour permettre l interoperabilite avec les differents services europeens tel que Europass et Youthpass, ainsi que le respect de certaines normes comme celle du consortium Eiffel ou IMS.\r\n\r\nPar la suite, peut-etre aussi developper d autres fonctionnalites tel qu un agenda par exemple.','Mahara est un CMS pour ePortfolio code en PHP fonctionnant avec une base de donnees MySQL ou PostgreSQL. Il possede une base sur laquelle chaque fonctionnalite ajoutee est sous forme de plugin. Il existe aussi des plugins externes que l on peut telecharger et installer en fonction des besoins.','NeTice est une start-up en cours de creation, hebergee par CreIInnov, incubateur de l Universite Lille I. Ses deux co-dirigeants sont Helene Vanderstichel, ingenieur pedagogique multimedia chargee du tutorat, et Michael Bodzioch, futur gerant de l’entreprise. Il y a deux autres stagiaires presents,  un etudiant en Master ICCD a Lille 3 et l autre en Licence Commerce et Management a l IAE de Lille 1. Un troisieme stagiaire, etudiant a l EPSI d Arras, arrivera a la fin du premier mois de stage pour aider dans le developpement informatique. ',NULL,1,NULL,'',''),('l3miagefi11LS31A',NULL,'',NULL,'outils d\'info decisionnelle','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11PK29A',NULL,'',NULL,'dvpt web','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11Mv34A',NULL,'',NULL,'dvpt web','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11BM20A',NULL,'',NULL,'dvpt','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11OY27A',NULL,'',NULL,'dvpt','',NULL,NULL,NULL,NULL,NULL,''),('l3miagefi11DJ23A',NULL,'',NULL,'dvpt intranet','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11GO31A',NULL,'',NULL,'dvpt java','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11DJ40A',NULL,'',NULL,'migration, sous windows','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11DZ30A',NULL,'',NULL,'','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11PT31A',NULL,'',NULL,'développement d\'applications','',NULL,NULL,NULL,NULL,NULL,''),('l3infofi11DD27A',NULL,'',NULL,'refonte d\'applications','',NULL,NULL,NULL,NULL,NULL,'');
/*!40000 ALTER TABLE `fa_etapeet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapevisite1`
--

DROP TABLE IF EXISTS `etapevisite1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapevisite1` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `dateRencontre` date DEFAULT NULL,
  `adequationMission` text COLLATE utf8_bin,
  `integrationEtudiant` text COLLATE utf8_bin,
  `signatureEtud` tinyint(1) DEFAULT NULL,
  `remarquesEtud` text COLLATE utf8_bin,
  `signatureReferent` tinyint(1) DEFAULT NULL,
  `remarquesReferent` text COLLATE utf8_bin,
  `signatureTuteur` tinyint(1) DEFAULT NULL,
  `remarquesTuteur` text COLLATE utf8_bin,
  `typeRencontre` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapevisite1`
--

LOCK TABLES `etapevisite1` WRITE;
/*!40000 ALTER TABLE `etapevisite1` DISABLE KEYS */;
INSERT INTO `etapevisite1` VALUES ('l3infofiDT14A','2011-05-11','oui','bien',0,'',0,'',0,'',NULL),('l3infofi11AM23A','2011-05-11','Oui, Marc avance bien sur la programmation PHP. Apres des premiers pas accompagnes sur des modules existants de l application ReflexeCE, on lui a confie le developpement d un nouveau module a part entiere. Quand celui-ci sera accompli, il aidera son maitre de stage dans la redaction de document technique pour un autre produit de l entreprise.','Tres bien, il travaille en echange constant avec les deux developpeurs permanents de l entreprise, profite de leur expertise technique. D autre part il a l occasion de suivre les aspect commerciaux et strategique de l entreprise, vu la bonne circulation d information dans la PME. ',0,'',1,'',0,'',NULL),('l3infofiAM0A','2011-05-23','oui','parfait',0,'',1,'',1,'',NULL),('l3infofi11CM38A','2011-05-06','oui','- ok\r\n- autonomie nécessaire...',0,'',1,'',1,'',NULL),('l3infofi11MM24A','2011-05-06','oui','- ok\r\n- autonomie nécessaire...',0,'',1,'',1,'',NULL),('l3infofiPA36A','2011-05-06','oui','- ok\r\n- autonomie nécessaire...',0,'',1,'',1,'',NULL),('l3infofiDA4A','2011-06-11','oui','excellente',0,'',1,'',1,'',NULL),('l3infofiDK6A','2011-05-09','oui','bonne',0,'',1,'',1,'',NULL),('l3infofiLG27A','2011-05-23','oui','très bonne',0,'',1,'',1,'',NULL),('l3infofiDM13A','2011-05-24','Oui. Tous les aspects potentiellement annoncés n\'ont pas encore été abordés, les tâches particulières sur lesquelles travaille Mamadou étant dictées notamment par les problèmes rencontrés au quotidien.','Très bien, la taille de l’entreprise (5 personnes, soit 2 informaticiens seulement en comptant Mamadou) aidant.\r\nMamadou a ainsi l\'occasion de participer à toutes les tâches et de voir tous les aspects de l\'entreprise.   ',0,'',0,'',1,'',NULL),('l3miagefiDS5A','2011-06-06','Oui, tout à fait','Sans aucun problème. Il faut juste noter une difficulté sur les capacités de modélisation, peut-être à renforcer dans la formation.',0,'',0,'',1,'',NULL),('l3miagefi11Re28A','2011-06-07','Oui tout à fait. Eric a vite pris ses marques en s\'appropriant Talend Studio. \r\nLa première mission concernant la migration des informations sur les étudiants est en phase de test.\r\nLa deuxième mission concernant la formulation et l\'interpretation des règles pour la validation des cursus est bien avancée. ','Très bien. Eric est communicatif, autonome et s\'investit dans son travail.',0,'',0,'',1,'',NULL),('l3miagefi11PR29A','2011-06-06','Oui. Romain travaille sur la migration des instances du SI de Maubeuge vers le SI de l\'agence d\'Arras.\r\n\r\nPar ailleurs, il a déjà mis en production une application APEX pour la saisie des correspondances ','Il est autonome et a fait preuve des capacités de communication qui lui ont permis d\'effectuer un transfert de connaissances à l\'intention des membres ayant rejoint le projet.',0,'',0,'',1,'',NULL),('l3infofi11Mj21A','2011-06-09','Oui. Julien travaille sur l\'application permettant de gérer le planning d\'affectation de toutes les ressources du centre GFI Douai.\r\nLa première mission a été de rédiger un cahier de spécifications fonctionnelles. Suite à sa, épaulé par un autre collègue stagiaire, ils ont produit une application PHP/MySQL qui rentrera bientôt en phase de test et recette. Cette phase est réalisée par la division spécifique du GFI, cependant, Julien sera sollicité pour assurer la maintenance.','Il s\'est très bien intégré dans l\'entreprise. Il est réactif, communicatif, fort de propositions et autonome.\r\nIl a su également très bien s\'adapter au travail en binôme au sein de l\'entreprise.',0,'',0,'',1,'J\'ai beaucoup apprécié la démarche qualité mise en avant par l\'entreprise.',NULL),('l3miagefi11DF23A','2011-05-23','oui\r\ndéveloppement d\'une interface web en ASP .Net\r\nCette interface permet d\'accéder à BO et remplace un client lourd. Si j\'ai bien compris, il n\'est pas nécessaire de savoir utiliser BO mais seulement d\'y accéder par l\'intermédiaire de C#.','très bien',0,'',0,'',1,'',NULL),('l3miagefiCG3A','0000-00-00','Oui, tout à fait. ','Aucun problème. Mise en route avec l\'assistance de M. Pâques, et à présent en grande autonomie.',0,'',0,'',1,'Bon stage. Contenu intéressant et de très bons résultats.',NULL),('l3infofiDL7A','2011-06-15','Oui','Bien',0,'',0,'',0,'',NULL),('l3infofi11NQ32A','2011-06-14','L\'étudiant a effectué des taches diverses et variées parfois pas très en adéquation avec notre formation (e.g. requêtes manuelles sur google)...','Apparemment assez bien, même si l\'encadrant de l\'entreprise semblait reconnaître qu\'elle aurait pu être plus optimale...',0,'',0,'',1,'',NULL);
/*!40000 ALTER TABLE `etapevisite1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapeechanges`
--

DROP TABLE IF EXISTS `etapeechanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapeechanges` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `participants` text COLLATE utf8_bin NOT NULL,
  `typeRencontre` int(11) NOT NULL,
  `dateRencontre` date NOT NULL,
  `resume` text COLLATE utf8_bin NOT NULL,
  `sujet` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapeechanges`
--

LOCK TABLES `etapeechanges` WRITE;
/*!40000 ALTER TABLE `etapeechanges` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapeechanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapeSout`
--

DROP TABLE IF EXISTS `etapeSout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapeSout` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `titreStage` tinytext COLLATE utf8_bin NOT NULL,
  `comprehension` tinyint(4) NOT NULL,
  `efficaciteAnalyse` tinyint(4) NOT NULL,
  `rigueur` tinyint(4) NOT NULL,
  `interet` tinyint(4) NOT NULL,
  `communication` tinyint(4) NOT NULL,
  `autonomie` tinyint(4) NOT NULL,
  `receptivite` tinyint(4) NOT NULL,
  `serieux` tinyint(4) NOT NULL,
  `pourcentageObjectifs` float NOT NULL,
  `difficulteMission` text COLLATE utf8_bin NOT NULL,
  `visaReferent` text COLLATE utf8_bin NOT NULL,
  `dateVisaReferent` date NOT NULL,
  `dateSoutenance` date NOT NULL,
  `noteTravail` float NOT NULL,
  `noteRapport` float NOT NULL,
  `noteSoutenance` float NOT NULL,
  `avisJury` text COLLATE utf8_bin NOT NULL,
  `salle` text COLLATE utf8_bin NOT NULL,
  `heure` varchar(10) COLLATE utf8_bin NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapeSout`
--

LOCK TABLES `etapeSout` WRITE;
/*!40000 ALTER TABLE `etapeSout` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapeSout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapemissionsout`
--

DROP TABLE IF EXISTS `etapemissionsout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapemissionsout` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `dateRencontre` date NOT NULL,
  `typeRencontre` text COLLATE utf8_bin NOT NULL,
  `dateValidation` date NOT NULL,
  `missions` text COLLATE utf8_bin NOT NULL,
  `environnementTechnique` text COLLATE utf8_bin NOT NULL,
  `enjeux` text COLLATE utf8_bin NOT NULL,
  `signatureEtud` tinyint(1) NOT NULL,
  `signatureTuteur` tinyint(1) NOT NULL,
  `signatureReferent` tinyint(1) NOT NULL,
  `remarquesEtud` text COLLATE utf8_bin NOT NULL,
  `remarquesTuteur` text COLLATE utf8_bin NOT NULL,
  `remarquesReferent` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapemissionsout`
--

LOCK TABLES `etapemissionsout` WRITE;
/*!40000 ALTER TABLE `etapemissionsout` DISABLE KEYS */;
INSERT INTO `etapemissionsout` VALUES ('l3miagefa1BB31A','2011-03-21','mail','2011-03-21','blahM\r\nblahM2\r\nblahM3','blahT\r\nblahT2','blahE\r\nblahE2',0,1,0,'','commentairesTut','commentairesRef');
/*!40000 ALTER TABLE `etapemissionsout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapevisite2`
--

DROP TABLE IF EXISTS `etapevisite2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapevisite2` (
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `dateRencontre` date NOT NULL,
  `pointsPositifs` text COLLATE utf8_bin NOT NULL,
  `pointsProgres` text COLLATE utf8_bin NOT NULL,
  `avancementProjet` text COLLATE utf8_bin NOT NULL,
  `dateProbableSoutenance` date NOT NULL,
  `signatureEtud` tinyint(1) NOT NULL,
  `signatureTuteur` tinyint(1) NOT NULL,
  `signatureReferent` tinyint(1) NOT NULL,
  `remarquesEtud` text COLLATE utf8_bin NOT NULL,
  `remarquesTuteur` text COLLATE utf8_bin NOT NULL,
  `remarquesReferent` text COLLATE utf8_bin NOT NULL,
  KEY `alternanceRef` (`alternanceRef`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapevisite2`
--

LOCK TABLES `etapevisite2` WRITE;
/*!40000 ALTER TABLE `etapevisite2` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapevisite2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_etudiant`
--

DROP TABLE IF EXISTS `fa_etudiant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_etudiant` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(30) COLLATE utf8_bin NOT NULL,
  `tel` char(20) COLLATE utf8_bin NOT NULL,
  `mail` varchar(50) COLLATE utf8_bin NOT NULL,
  `etudCle` varchar(50) COLLATE utf8_bin NOT NULL,
  `groupeRef` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`etudCle`),
  UNIQUE KEY `etudCle` (`etudCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_etudiant`
--

LOCK TABLES `fa_etudiant` WRITE;
/*!40000 ALTER TABLE `fa_etudiant` DISABLE KEYS */;
INSERT INTO `fa_etudiant` VALUES ('ALLART','Aurore','','aurore.allart@etudiant.univ-lille1.fr','l3infofi11AA25','L3INFOFI1'),('AYAR','Adil','','adil.ayar@etudiant.univ-lille1.fr','l3infofi11AA37','L3INFOFI1'),('AMBERG','Marc',' 06 74 46 19 66','marc.amberg@etudiant.univ-lille1.fr','l3infofi11AM23','L3INFOFI1'),('BIHR','Charles-Edmond','0662383735','charles-edmond.bihr@etudiant.univ-lille1.fr','l3infofi11BC30','L3INFOFI1'),('BELLANO','Frederic','','frederic.bellano@etudiant.univ-lille1.fr','l3infofi11BF35','L3INFOFI1'),('BOURGOIS','Tristan','','tristan.bourgois@etudiant.univ-lille1.fr','l3infofi11BT36','L3INFOFI1'),('COUTURIER','Boris','','boris.couturier@etudiant.univ-lille1.fr','l3infofi11C23','L3INFOFI1'),('CAULIER','Arnaud','','arnaud.caulier@etudiant.univ-lille1.fr','l3infofi11CA21','L3INFOFI1'),('CALMELS','Matthieu','','matthieu.calmels@etudiant.univ-lille1.fr','l3infofi11CM38','L3INFOFI1'),('DUPAS','David','','david.dupas@etudiant.univ-lille1.fr','l3infofi11DD27','L3INFOFI1'),('DEBOFFLES','Jerome','','jerome.deboffles@etudiant.univ-lille1.fr','l3infofi11DJ26','L3INFOFI1'),('DERREVAUX','Jonathan','','jonathan.derreveaux@etudiant.univ-lille1.fr','l3infofi11DJ40','L3INFOFI1'),('DAARA','Loic','','loic.daara@etudiant.univ-lille1.fr','l3infofi11DL31','L3INFOFI1'),('DUEZ','Marc','','marc1.duez@etudiant.univ-lille1.fr','l3infofi11DM25','L3INFOFI1'),('DAMIE','Nathan','','nathan.damie@etudiant.univ-lille1.fr','l3infofi11DN30','L3INFOFI1'),('DENG','Zhi Yuan','','zhi-yuan.deng@etudiant.univ-lille1.fr','l3infofi11DZ30','L3INFOFI1'),('EL ACHIQI','Anas','06 49 77 57 34','anas.el-achiqi@etudiant.univ-lille1.fr','l3infofi11EA35','L3INFOFI1'),('EL AMRANI','Mohammed','','mohammed.el-amrani@etudiant.univ-lille1.fr','l3infofi11EM24','L3INFOFI1'),('FOULON','Axel','','axel.foulon@etudiant.univ-lille1.fr','l3infofi11FA20','L3INFOFI1'),('FISSET','Benjamin','','benjamin.fisset@etudiant.univ-lille1.fr','l3infofi11FB38','L3INFOFI1'),('GALLOS','Lison','','lison.gallos@etudiant.univ-lille1.fr','l3infofi11GL21','L3INFOFI1'),('GENS','Maxime','','maxime.gens@etudiant.univ-lille1.fr','l3infofi11GM37','L3INFOFI1'),('GEST','Oscar','','oscar.gest@etudiant.univ-lille1.fr','l3infofi11GO31','L3INFOFI1'),('HERBULOT','Vincent','','vincent.herbulot@etudiant.univ-lille1.fr','l3infofi11HV20','L3INFOFI1'),('IVANOV','Iliya','','iliya.ivanov@etudiant.univ-lille1.fr','l3infofi11II22','L3INFOFI1'),('LIU','Qiang','','qiang.liu@etudiant.univ-lille1.fr','l3infofi11LQ22','L3INFOFI1'),('MELLOULI','Matthias','','matthias.mellouli@etudiant.univ-lille1.fr','l3infofi11MM24','L3INFOFI1'),('MOUATASSIM','Sanaa','','sanaa.mouatassim@etudiant.univ-lille1.fr','l3infofi11MS23','L3INFOFI1'),('MAILLART','Valentine','','valentine.maillart@etudiant.univ-lille1.fr','l3infofi11MV26','L3INFOFI1'),('MILAN','Julien','','julien.milan@etudiant.univ-lille1.fr','l3infofi11Mj21','L3INFOFI1'),('MANFOUMBI','vincy','','manfoumbi-animbogo@etudiant.univ-lille1.fr','l3infofi11Mv34','L3INFOFI1'),('NGUYEN','Quang Tung','','quang-tung.nguyen@etudiant.univ-lille1.fr','l3infofi11NQ32','L3INFOFI1'),('POLLAERT','Kevin','','kevin.pollaert@etudiant.univ-lille1.fr','l3infofi11PK29','L3INFOFI1'),('PROUM ','Tony','','tony.proum@etudiant.univ-lille1.fr','l3infofi11PT31','L3INFOFI1'),('RAVERDY','Maxime','','maxime.raverdy@etudiant.univ-lille1.fr','l3infofi11RM34','L3INFOFI1'),('RAMELOT','Pierre','','pierre.ramelot@etudiant.univ-lille1.fr','l3infofi11RP32','L3INFOFI1'),('VANDROMME','Maxence','','maxence.vandromme@etudiant.univ-lille1.fr','l3infofi11VM24','L3INFOFI1'),('AUCHEDE','Morgan','','morgan.auchede@etudiant.univ-lille1.fr','l3infofiAM0','L3INFOFI1'),('BONTE','Jeremy','','jeremy.bonte@etudiant.univ-lille1.fr','l3infofiBJ1','L3INFOFI1'),('CAMUS','Alexis','','alexis.camus@etudiant.univ-lille1.fr','l3infofiCA2','L3INFOFI1'),('COUSIN','Nicolas','','nicolas1.cousin@etudiant.univ-lille1.fr','l3infofiCN3','L3INFOFI1'),('DAVID','Amaury','','amaury.david@etudiant.univ-lille1.fr','l3infofiDA4','L3INFOFI1'),('DELAHAYE','Axel','','axel.delahaye@etudiant.univ-lille1.fr','l3infofiDA8','L3INFOFI1'),('DETUNCQ','Benoit','','bc.detuncq@etudiant.univ-lille1.fr','l3infofiDB12','L3INFOFI1'),('DUFOUR','Clement','','clement1.dufour@etudiant.univ-lille1.fr','l3infofiDC15','L3INFOFI1'),('DELATTRE','Charlotte','','charlotte.delattre@etudiant.univ-lille1.fr','l3infofiDC9','L3INFOFI1'),('DEFIVES','Kevin','','kevin.defives@etudiant.univ-lille1.fr','l3infofiDK6','L3INFOFI1'),('DEKEISTER','Louis','','louis.dekeister@etudiant.univ-lille1.fr','l3infofiDL7','L3INFOFI1'),('DIALLO','Mamadou','','mcd.diallo@etudiant.univ-lille1.fr','l3infofiDM13','L3INFOFI1'),('DEBOEUF','Nathanael','','nathanael.deboeuf@etudiant.univ-lille1.fr','l3infofiDN5','L3INFOFI1'),('DENQUIN','Pierre','','pierre.denquin@etudiant.univ-lille1.fr','l3infofiDP11','L3INFOFI1'),('DENIS','Sylvain','','sylvain.denis@etudiant.univ-lille1.fr','l3infofiDS10','L3INFOFI1'),('DJEBIEN','Tarik','','tarik.djebien@etudiant.univ-lille1.fr','l3infofiDT14','L3INFOFI1'),('DUFRESNE','Yoann','','yoann.dufresne@etudiant.univ-lille1.fr','l3infofiDY16','L3INFOFI1'),('GALLANT','Guillaume','','guillaume.gallant@etudiant.univ-lille1.fr','l3infofiGG17','L3INFOFI1'),('GIOVANETTI','Romain','','romain.giovanetti@etudiant.univ-lille1.fr','l3infofiGR20','L3INFOFI1'),('GANDOSSI','Sebastien','','sebastien.gandossi@etudiant.univ-lille1.fr','l3infofiGS18','L3INFOFI1'),('GILLERY','Thomas','','thomas.gillery@etudiant.univ-lille1.fr','l3infofiGT19','L3INFOFI1'),('HONORE','Perrine','','perrine.honore@etudiant.univ-lille1.fr','l3infofiHP21','L3INFOFI1'),('LARAKI','Alien','','alien.laraki@etudiant.univ-lille1.fr','l3infofiLA23','L3INFOFI1'),('LEVEL','Damien','','damien.level@etudiant.univ-lille1.fr','l3infofiLD26','L3INFOFI1'),('LEDOUX','Florian','','florian.ledoux@etudiant.univ-lille1.fr','l3infofiLF24','L3INFOFI1'),('LOCQUET','Guillaume','','guillaume.locquet@etudiant.univ-lille1.fr','l3infofiLG27','L3INFOFI1'),('LABAT','Kevin','','kevin.labat@etudiant.univ-lille1.fr','l3infofiLK22','L3INFOFI1'),('LORIDAN','Ludovic','','ludovic.loridan@etudiant.univ-lille1.fr','l3infofiLL28','L3INFOFI1'),('LOUIS','Sebastien','','sebastien1.louis@etudiant.univ-lille1.fr','l3infofiLS29','L3INFOFI1'),('LEROY','Yannick','','yannick1.leroy@etudiant.univ-lille1.fr','l3infofiLY25','L3INFOFI1'),('MONTULET','Damien','','damien.montulet@etudiant.univ-lille1.fr','l3infofiMD32','L3INFOFI1'),('MACKE','Guillaume','','guillaume.macke@etudiant.univ-lille1.fr','l3infofiMG30','L3INFOFI1'),('MUNYANDILIKIRWA','Jean','','jp.munyandilikirwa@etudiant.univ-lille1.fr','l3infofiMJ33','L3INFOFI1'),('MERLIN','Sylvain','','sylvain.merlin@etudiant.univ-lille1.fr','l3infofiMS31','L3INFOFI1'),('NOUFLI','Larbi','','larbi.noufli@etudiant.univ-lille1.fr','l3infofiNL34','L3INFOFI1'),('PETRE','Augustin','','augustin.petre@etudiant.univ-lille1.fr','l3infofiPA36','L3INFOFI1'),('PETIT','Benoit','','benoit1.petit@etudiant.univ-lille1.fr','l3infofiPB35','L3INFOFI1'),('QUENIART','Samuel','','samuel.queniart@etudiant.univ-lille1.fr','l3infofiQS37','L3INFOFI1'),('RECOURT','Florian','','florian.recourt@etudiant.univ-lille1.fr','l3infofiRF38','L3INFOFI1'),('SOUISSI','Ismael','','ismael.souissi@etudiant.univ-lille1.fr','l3infofiSI39','L3INFOFI1'),('WAUQUIER','Pauline','','pauline.wauquier@etudiant.univ-lille1.fr','l3infofiWP41','L3INFOFI1'),('YOULHAJEN','Jamal','','jamaldine.youlhajen@etudiant.univ-lille1.fr','l3infofiYJ42','L3INFOFI1'),('BOUCHEZ','Benjamin','','benjamin.bouchez@etudiant.univ-lille1.fr','l3miagefi11BB32','L3MIAGEFI1'),('BOIDIN ','Clement','','clement1.boidin@etudiant.univ-lille1.fr','l3miagefi11BC26','L3MIAGEFI1'),('BECQUART','Guillaume','','guillaume.becquart@etudiant.univ-lille1.fr','l3miagefi11BG23','L3MIAGEFI1'),('BECUWE','Justine','','justine.becuwe@etudiant.univ-lille1.fr','l3miagefi11BJ29','L3MIAGEFI1'),('BAH','Mamadou Bassirou','','mamadou-bassirou.bah@etudiant.univ-lille1.fr','l3miagefi11BM20','L3MIAGEFI1'),('BOUCHER','Maxime','','maxime1.boucher@etudiant.univ-lille1.fr','l3miagefi11BM28','L3MIAGEFI1'),('BRIANCHON','felix','','felix.brianchon@etudiant.univ-lille1.fr','l3miagefi11Bf20','L3MIAGEFI1'),('CARPENTIER','Florian','','florian1.carpentier@etudiant.univ-lille1.fr','l3miagefi11CF40','L3MIAGEFI1'),('CHUDOBA','Willis','','willis.chudoba@etudiant.univ-lille1.fr','l3miagefi11CW29','L3MIAGEFI1'),('DUBUS','Alexandre','','alexandre1.dubus@etudiant.univ-lille1.fr','l3miagefi11DA39','L3MIAGEFI1'),('DUBOIS','Benjamin','','benjamin3.dubois@etudiant.univ-lille1.fr','l3miagefi11DB20','L3MIAGEFI1'),('DALLENNE','Florent','','florent.dallenne@etudiant.univ-lille1.fr','l3miagefi11DF23','L3MIAGEFI1'),('DIALLO','Ibrahima','','ibrahima2.diallo@etudiant.univ-lille1.fr','l3miagefi11DI36','L3MIAGEFI1'),('DESCROIZETTE','Joris','','joris.descroizette@etudiant.univ-lille1.fr','l3miagefi11DJ23','L3MIAGEFI1'),('EL HIZABRI','Mouad','','mouad.el-hizabri@etudiant.univ-lille1.fr','l3miagefi11EM33','L3MIAGEFI1'),('HONORé','Alexandre','','alexandre.honore@etudiant.univ-lille1.fr','l3miagefi11HA38','L3MIAGEFI1'),('LATIFOU','Sano','','latifou.sano@etudiant.univ-lille1.fr','l3miagefi11LS31','L3MIAGEFI1'),('OULAMINE','Youssef','','youssef.oulamine@etudiant.univ-lille1.fr','l3miagefi11OY27','L3MIAGEFI1'),('PLATEL','Alexandre','','alexandre.platel@etudiant.univ-lille1.fr','l3miagefi11PA27','L3MIAGEFI1'),('PAMULA','Noe','','noe.pamula@etudiant.univ-lille1.fr','l3miagefi11PN34','L3MIAGEFI1'),('POIRE','Romain','','romain.poire@etudiant.univ-lille1.fr','l3miagefi11PR29','L3MIAGEFI1'),('PERON','Romain','','romain.peron@etudiant.univ-lille1.fr','l3miagefi11PR35','L3MIAGEFI1'),('RAKOTOBE SITRAKA','eric','','se.rakotobe@etudiant.univ-lille1.fr','l3miagefi11Re28','L3MIAGEFI1'),('WANG','Yue','','yue.wang@etudiant.univ-lille1.fr','l3miagefi11WY25','L3MIAGEFI1'),('YU','Wenjie','','wenjie.yu@etudiant.univ-lille1.fr','l3miagefi11YW35','L3MIAGEFI1'),('ZHANG','Chennan','','chennan.zhang@etudiant.univ-lille1.fr','l3miagefi11ZC40','L3MIAGEFI1'),('BOUILLET','Severine','','severine.bouillet@etudiant.univ-lille1.fr','l3miagefiBS0','L3MIAGEFI1'),('CAPILLIEZ','Cyril','','cyril.capilliez@etudiant.univ-lille1.fr','l3miagefiCC2','L3MIAGEFI1'),('CORDINA','Charles','','ca.cordina@etudiant.univ-lille1.fr','l3miagefiCC4','L3MIAGEFI1'),('CAMUS','Florian','','florian.camus@etudiant.univ-lille1.fr','l3miagefiCF1','L3MIAGEFI1'),('CERIEZ','Gael','','gael.ceriez@etudiant.univ-lille1.fr','l3miagefiCG3','L3MIAGEFI1'),('DEVINCKE','Amelie','','amelie.devincke@etudiant.univ-lille1.fr','l3miagefiDA9','L3MIAGEFI1'),('DAVID','Franck','','franck.david@etudiant.univ-lille1.fr','l3miagefiDF6','L3MIAGEFI1'),('DELEFORTERIE','Karl','','karl.deleforterie@etudiant.univ-lille1.fr','l3miagefiDK7','L3MIAGEFI1'),('DESPREZ','Marine','','marine.desprez@etudiant.univ-lille1.fr','l3miagefiDM8','L3MIAGEFI1'),('DAHMANI','Soufiane','','soufiane.dahmani@etudiant.univ-lille1.fr','l3miagefiDS5','L3MIAGEFI1'),('LAETHEM','Christopher','','christophe.laethem@etudiant.univ-lille1.fr','l3miagefiLC10','L3MIAGEFI1'),('LONVERT','Gwennael','','gwennael.lonvert@etudiant.univ-lille1.fr','l3miagefiLG11','L3MIAGEFI1'),('LUO','Wen','','wen.luo@etudiant.univ-lille1.fr','l3miagefiLW12','L3MIAGEFI1'),('MASSON','Louis','','louis.masson@etudiant.univ-lille1.fr','l3miagefiML14','L3MIAGEFI1'),('MASCRET','Michael','','michael.mascret@etudiant.univ-lille1.fr','l3miagefiMM13','L3MIAGEFI1'),('VANDEMEULEBROUCK','Nicolas','','n.vandemeulebrouck@etudiant.univ-lille1.fr','l3miagefiVN15','L3MIAGEFI1');
/*!40000 ALTER TABLE `fa_etudiant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_formation`
--

DROP TABLE IF EXISTS `fa_formation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_formation` (
  `formationCle` varchar(10) COLLATE utf8_bin NOT NULL,
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `responsableRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `responsableRef2` varchar(20) COLLATE utf8_bin NOT NULL,
  UNIQUE KEY `formationCle` (`formationCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_formation`
--

LOCK TABLES `fa_formation` WRITE;
/*!40000 ALTER TABLE `fa_formation` DISABLE KEYS */;
INSERT INTO `fa_formation` VALUES ('L3INFOFI','Licence 3 INFO','decomite','routier'),('L3MIAGEFI','Licence 3 MIAGE FI','decomite','meftali');
/*!40000 ALTER TABLE `fa_formation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_groupe`
--

DROP TABLE IF EXISTS `fa_groupe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_groupe` (
  `groupeCle` varchar(20) COLLATE utf8_bin NOT NULL,
  `formationRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `responsableRef` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`groupeCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_groupe`
--

LOCK TABLES `fa_groupe` WRITE;
/*!40000 ALTER TABLE `fa_groupe` DISABLE KEYS */;
INSERT INTO `fa_groupe` VALUES ('L3INFOFI1','L3INFOFI','decomite'),('L3MIAGEFI1','L3MIAGEFI','decomite');
/*!40000 ALTER TABLE `fa_groupe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_groupe_old`
--

DROP TABLE IF EXISTS `fa_groupe_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_groupe_old` (
  `groupeCle` varchar(20) COLLATE utf8_bin NOT NULL,
  `formationRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `responsableRef` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_groupe_old`
--

LOCK TABLES `fa_groupe_old` WRITE;
/*!40000 ALTER TABLE `fa_groupe_old` DISABLE KEYS */;
INSERT INTO `fa_groupe_old` VALUES ('L3INFOFI1','L3INFOFI','decomite'),('L3INFOFI2','L3INFOFI','decomite'),('L3INFOFI3','L3INFOFI','decomite'),('L3INFOFI4','L3INFOFI','decomite'),('L3MIAGEFI1','L3MIAGEFI','decomite'),('L3MIAGEFI2','L3MIAGEFI','decomite');
/*!40000 ALTER TABLE `fa_groupe_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_opca`
--

DROP TABLE IF EXISTS `fa_opca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_opca` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `commentaires` text COLLATE utf8_bin NOT NULL,
  `anneesFinancees` int(11) NOT NULL DEFAULT '1',
  `representant` varchar(50) COLLATE utf8_bin NOT NULL,
  `tel` varchar(10) COLLATE utf8_bin NOT NULL,
  `mail` varchar(50) COLLATE utf8_bin NOT NULL,
  `opcaCle` varchar(50) COLLATE utf8_bin NOT NULL,
  UNIQUE KEY `opcaCle` (`opcaCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_opca`
--

LOCK TABLES `fa_opca` WRITE;
/*!40000 ALTER TABLE `fa_opca` DISABLE KEYS */;
INSERT INTO `fa_opca` VALUES ('SYNTEC','',1,'','','','SYNTEC'),('fafiec','',1,'','','','fafiec'),('forcemat','',1,'','','','forcemat'),('forco','',1,'','','','forco'),('inconnue','',1,'','','','inconnue');
/*!40000 ALTER TABLE `fa_opca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_prof`
--

DROP TABLE IF EXISTS `fa_prof`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_prof` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(30) COLLATE utf8_bin NOT NULL,
  `tel` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `mail` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `bureau` text COLLATE utf8_bin,
  `profCle` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`profCle`),
  UNIQUE KEY `tuteurCle` (`profCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_prof`
--

LOCK TABLES `fa_prof` WRITE;
/*!40000 ALTER TABLE `fa_prof` DISABLE KEYS */;
INSERT INTO `fa_prof` VALUES ('Maalej','Ahmed',NULL,'Ahmed.Maalej@lifl.fr',NULL,'ahmed.maalej'),('Feugas','Alexandre',NULL,'Alexandre.Feugas@lifl.fr',NULL,'alexandre.feugas'),('Souissi','Amen',NULL,'amen.souissi@ed.univ-lille1.fr',NULL,'amen.souissi'),('Anquetil','Nicolas',NULL,'Nicolas.Anquetil@univ-lille1.fr',NULL,'anquetil'),('Aranega','Vincent',NULL,'Vincent.Aranega@lifl.fr',NULL,'aranega'),('Aubert','Fabrice',NULL,'Fabrice.Aubert@univ-lille1.fr',NULL,'aubert'),('Beaufils','Bruno',NULL,'Bruno.Beaufils@univ-lille1.Fr',NULL,'beaufils'),('Groz','Benoit',NULL,'benoit.groz@ed.univ-lille1.fr',NULL,'benoit.groz'),('Bilasco','Marius','','marius.bilasco@lifl.fr','','bilasco'),('Bogaert','Bruno',NULL,'Bruno.Bogaert@univ-lille1.fr',NULL,'bogaert'),('Bossut','Francis',' ','francis.bossut@univ-lille1.fr',' ','bossut'),('Parra-Acevedo','Carlos-Andres',NULL,'Carlos-andres.Parra-acevedo@lifl.fr',NULL,'ca.parra-acevedo'),('Caron','Anne-Cécile',' ','anne-cecile.caron@univ-lille1.fr',' ','caronc'),('Casiez','Géry','','Gery.Casiez@lifl.fr','','casiez'),('Rodrigues','Wendell',NULL,'de-oliveira-rodrigue@ed.univ-lille1.fr',NULL,'de-oliveira-rodrigue'),('de Comité','Francesco',NULL,'Francesco.De-Comite@univ-lille1.fr',NULL,'decomite'),('Degrande','Samuel',NULL,'Samuel.Degrande@univ-lille1.fr',NULL,'degrande'),('Dekeyser','Jean-Luc',NULL,'Jean-luc.Dekeyser@univ-lille1.fr',NULL,'dekeyser'),('Derycke','Alain','','Alain.Derycke@lifl.fr','','derycke'),('Devienne','Philippe',NULL,'Philippe.Devienne@lifl.fr',NULL,'devienne'),('Romero','Daniel',NULL,'Daniel-Francisco.Romero@lifl.fr',NULL,'df.romero'),('Marchal','Damien',NULL,'damien.marchal@lifl.fr',NULL,'dmarchal'),('Duchien','Laurence','','laurence.duchien@univ-lille1.fr','','duchien'),('Durif','Philippe',NULL,'Philippe.Durif@univ-lille1.fr',NULL,'durif'),('El sayad','Ismail',NULL,'ismail.el-sayad@ed.univ-lille1.fr',NULL,'elsayed'),('Grimaud','Gilles','','Gilles.Grimaud@lifl.fr','','grimaud'),('Hym','Samuel',' ','samuel.hym@univ-lille1.fr',' ','hym'),('Tarby','Jean-Claude',NULL,'jean-claude.tarby@lifl.fr',NULL,'jctarby'),('Delahaye','Jean-Paul','','Jean-Paul.Delahaye@lifl.fr','','jdelahay'),('Marti','Jean-Claude',NULL,'Jean-claude.Marti@univ-lille1.fr',NULL,'jmarti'),('Place','Jean-Marie',NULL,'Jean-Marie.Place@univ-lille1.fr',NULL,'jmplace'),('Komorowski','Nathalie',' ','nathalie.komorowski@univ-lille1.fr',' ','komorows'),('Kuttler','Céline','','Celine.Kuttler@lifl.fr','','kuttler'),('Noé','Laurent',' ','laurent.noe@univ-lille1.Fr',' ','laurentnoe'),('Lebbe','Jean Marie','','jean-marie.lebbe@lifl.fr','','lebbe'),('Leguy','Emmanuel',NULL,'Emmanuel.Leguy@univ-lille1.fr',NULL,'leguye'),('Lemaire','François',NULL,'Francois.Lemaire@lifl.fr',NULL,'lemaire'),('Le Pallec','Xavier','','xavier.le-pallec@univ-lille1.fr','','lepallec'),('Lhoussaine','Cédric',NULL,'Cedric.Lhoussaine@lifl.fr',NULL,'lhoussai'),('Liefooghe','Arnaud',NULL,'arnaud.liefooghe@univ-lille1.fr',NULL,'liefog'),('Mailliet','Didier',NULL,'Didier.Mailliet@univ-lille1.fr',NULL,'mailliet'),('Marquet','Philippe','','Philippe.Marquet@lifl.fr  ','','marquet'),('Martinet','Jean',NULL,'Jean.Martinet@univ-lille1.fr',NULL,'martinej'),('Marvie','Raphaël','','raphael.marvie@lifl.Fr','','marvie'),('Meftali','Samy',NULL,'Samy.Meftali@univ-lille1.fr',NULL,'meftali'),('Melab','Nouredine ','','nouredine.melab@univ-lille1.fr','','melab'),('Mosser','Sebastien',NULL,'Sebastien.Mosser@lifl.fr',NULL,'mosser'),('Nebut','Mirabelle',NULL,'Mirabelle.Nebut@univ-lille1.fr',NULL,'nebut'),('Noe','Laurent',NULL,'Laurent.Noe@univ-lille1.fr',NULL,'noe'),('Olejnik','Richard',NULL,'Richard.Olejnik@univ-lille1.fr',NULL,'olejnik'),('OTT','Louise',NULL,'Louise.OTT@lifl.fr',NULL,'ottl'),('Oussous','Nour-Eddine',NULL,'Nour-Eddine.Oussous@univ-lille1.fr',NULL,'oussous'),('Caron','Pierre-André',NULL,'Pierre-Andre.Caron@univ-lille1.fr',NULL,'pa2caron'),('Panzoli','David',NULL,'David.Panzoli@lifl.fr',NULL,'panzoli'),('Plenacoste','Patricia',NULL,'Patricia.Plenacoste@lifl.fr',NULL,'plenacos'),('Mathieu','Philippe',NULL,'Philippe.Mathieu@univ-lille1.fr',NULL,'pmathieu'),('Pupin','Maude',' ','maude.pupin@univ-lille1.fr',' ','pupin'),('Quadri','Imran',NULL,'Imran.quadri@lifl.fr  ',NULL,'quadri'),('Nzekwa','Russel',NULL,'RUSSEL.NZEKWA@lifl.fr',NULL,'ra.nzekwa-nana'),('Roos','Jean-François',' ','jean-francois.roos@univ-lille1.fr',' ','roos'),('Routier','Jean-Christophe',NULL,'jean-christophe.routier@lifl.fr',NULL,'routier'),('Rouvoy','Romain',' ','romain.rouvoy@univ-lille1.fr',' ','rouvoy'),('Kaddouci','Sarra',NULL,'sarra.kaddouci@ed.univ-lille1.fr',NULL,'sarra.kaddouci'),('Sedoglavic','Alexandre',NULL,'Alexandre.Sedoglavic@univ-lille1.fr',NULL,'sedoglav'),('Seinturier','Lionel','','Lionel.Seinturier@lifl.fr','','seinturi'),('Staworko','Slawomir',NULL,'Slawomir.Staworko@lifl.fr',NULL,'staworko'),('Luong','Thé van',NULL,'the-van.luong@ed.univ-lille1.fr',NULL,'the-van.luong'),('Tison','Sophie',NULL,'Sophie.Tison@univ-lille1.fr',NULL,'tison'),('Urruty','Thierry',NULL,'Thierry.Urruty@lifl.fr',NULL,'urruty'),('Vacher','Camille',NULL,'Camille.Vacher@lifl.fr',NULL,'vacher'),('Vantroys','Thomas',NULL,'Thomas.Vantroys@univ-lille1.fr',NULL,'vantroys'),('Varre','Jean-Stephane','','jean-stephane.varre@lifl.fr','','varre'),('Wannous','Hazem',NULL,'Hazem.Wannous@univ-lille1.fr',NULL,'wannous'),('Wegrzynowski','Eric',NULL,'Eric.Wegrzynowski@univ-lille1.fr',NULL,'wegrzyno'),('Weinberg','Léopold',NULL,'Leopold.Weinberg@univ-lille1.fr',NULL,'weinberl'),('Yahiaoui','Tarek',NULL,'Tarek.Yahiaoui@univ-lille1.fr',NULL,'yahiaoui'),('Roos','Yves','','yves.roos@lifl.fr','','yroos');
/*!40000 ALTER TABLE `fa_prof` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_referent`
--

DROP TABLE IF EXISTS `fa_referent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_referent` (
  `nom` varchar(50) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tel` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `mail` varchar(50) COLLATE utf8_bin NOT NULL,
  `referentCle` varchar(20) COLLATE utf8_bin NOT NULL,
  `entrepriseRef` varchar(100) COLLATE utf8_bin NOT NULL,
  `ville` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fonction` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`referentCle`),
  UNIQUE KEY `referentCle` (`referentCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_referent`
--

LOCK TABLES `fa_referent` WRITE;
/*!40000 ALTER TABLE `fa_referent` DISABLE KEYS */;
INSERT INTO `fa_referent` VALUES ('','','','','l3infofi1,l3miagefi1','','',NULL),('Bailleul','Guillaume','0320648324','guillaume.bailleul@atosorigin.com','l3infofi11AA25R','atos_worldline_sas','Noyelles les Seclin',''),('Maillard','Anthony','0320132413','amaillard@shirka.com','l3infofi11AA37R','shirka','Marcq en Baroeul',NULL),('Silaczuk','David','0671798871','davidsilaczuk@reflexce.com','l3infofi11AM23R','dmj_communication','Lille',''),('Dupuich','Jonathan','0972221415','jonathan.dupuich@tasker.fr','l3infofi11BC30R','tasker','Lille',''),('Lagorsse','Eric','0328801040','eric.lagorsse@airial.com','l3infofi11BF35R','airial_conseil','Villeneuve d\'Ascq',NULL),('Tierny','Benjamin','627852931','benjamin.tierny@nectup.fr','l3infofi11BT36R','nectup','Lille',''),('Dumont','Nicolas','0320619637','nicolas.dumont@netasq.com','l3infofi11C23R','netasq','Villeneuve d\'Ascq',''),('Leclercq','Mickael','0320415232','m.leclercq@anios.com','l3infofi11CA21R','soc_btl','Hellemmes',''),('Kerampran','Guillaume','07773114568','gkerampran@keyneosoft.fr','l3infofi11CM38R','keyneosoft','Tourcoing',NULL),('Buttin','Richard','0321006502','richard.buttin@eurotunnel.com','l3infofi11DD27R','eurotunnel','Coquelles',NULL),('Creton','Olivier','0612184649','ocreton@numsoft.fr','l3infofi11DJ26R','numsoft','Tourcoing',NULL),('Giethlen','Herve','0684768128','ffg@rvgi.fr','l3infofi11DJ40R','rvgi_soft','Roubaix',''),('Servant','regis','663773328','regis;servant@gmail.com','l3infofi11DL31R','mobitic_asso_1901','Lille',NULL),('Tiffon','Vincent','0687329413','vinvent.tiffon@univ-lille3.fr','l3infofi11DM25R','lille_3_','Villeneuve d\'Ascq',NULL),('Derbesse','Gael','0328335738','gderbesse@t-a-o.com','l3infofi11DN30R','tape_a_l_oeil','Wasquehal',NULL),('Wang','Zhenjiang','8637167642238','dzylcl@yahoo.com','l3infofi11DZ30R','sarl_de_mine_a_zhengzhou','Zhengzhou (Chine)',NULL),('Wacongne','Yannig','0320132169','mailto:Yannig.Wacongne@francetv.fr','l3infofi11EA35R','france_3_npdc','Lille',''),('Lefebvre','Pierre','320860200','plefebvre@view-on.fr','l3infofi11EM24R','mcm_groupe_view-on','Roubaix',NULL),('Brown','Morgane','0362276267','contact@vivacours.fr','l3infofi11FA20R','viva_cours','Lille',NULL),('Tondeux','Vincent','0328769333','vtondeux@vivelavie.fr','l3infofi11FB38R','vive_la_vie','Mons-en-Baroeul',NULL),('Keller','Celine','03211404102','celine.keller@helfy.fr','l3infofi11GL21R','helfy','Libercourt',NULL),('Rombouts','Julien','0362848400','jrombouts@leaderinfo.com','l3infofi11GM37R','leader_informatique','Lille',NULL),('Bouchet','Jean-Paul','0432722723','jean-paul.bouchet@avignon.inra.fr','l3infofi11GO31R','inra_avignon','Avignon',''),('Gourdin','Christophe','0972221415','christophe.gourdin@tasker.fr','l3infofi11HV20R','tasker','Lille',''),('Stoehr','Michael','','michael.stoehr@tellja.de','l3infofi11II22R','tellja','Frankfurt am Main',NULL),('Hu','Kun','635470954','cice.kun@gmail.com','l3infofi11LQ22R','centre_d\'information_culturelle_et_economique','Hellemmes',''),('Delcourt','Nicolas','362648131','ndelcourt@keyneosoft.fr','l3infofi11MM24R','keyneosoft','Tourcoing',NULL),('Verscheure','Nicolas','0320233232','nicolas.verscheure@pimkie.com','l3infofi11MS23R','diramode','Villeneuve d\'Ascq',NULL),('Vanderstichel','Helene','0670882436','helene.vanderstichel@netice.fr','l3infofi11MV26R','netice','Villeneuve d\'ascq',NULL),('Pomart','Bertrand','','bertrand.pomart@gfi.fr','l3infofi11Mj21R','gfi','Douai',NULL),('Bonamy','Cyrille','0320436750','cyrille.bonamy@univ-lille1.fr','l3infofi11Mv34R','ustl_pole_calcul','Villeneuve d\'Ascq',NULL),('Cuingnet','Julien','320211407','jcuingnet@agence-aeronet;com','l3infofi11NQ32R','aeronet','Lille',NULL),('Tuminello','Cedric','0320684092','cedric@oxygem.tv','l3infofi11PK29R','dynamic_web','Roubaix',NULL),('Ollivier','Erwan','','erwan.ollivier@oxylane.fr','l3infofi11PT31R','oxylane','Houplines',NULL),('Posczywala','Julien','0682874509','julien@roottrip.com','l3infofi11RM34R','libertrip','Lille',NULL),('Camilleri','Florian','320271060','florian.camilleri@heliopac.com','l3infofi11RP32R','heliopac','Tourcoing',NULL),('Gamatie','Abdoulaye','359577816','abdoulaye.gamatie@lifl.fr','l3infofi11VM24R','inria_/dart','Villeneuve d\'Ascq',NULL),('NIEHREN','Joachim','359577848','joachim.niehren@inria.fr','l3infofiAM0R','inria','Villeneuve d\'ascq',NULL),('VALMONT','Mathieu','320619405','mvalmont@scotler.fr','l3infofiBJ1R','scotler france','Villeneuve d\'ascq',NULL),('GUTIERREZ','Vincent','344263672','vgutierrez@nodevo.com','l3infofiCA2R','nodevo','Chantilly',NULL),('Boussekeyt','Simon','','Sboussekeyt@cylande.com','l3infofiCN3R','cylande','Roubaix',''),('DECOOL','Laurent','320404124','ldecool@odysys.fr','l3infofiDA4R','odysys','villeneuve d\'ascq',NULL),('LECLERCQ','Thomas','320683979','tleclercq@odiso.com','l3infofiDA8R','odiso','Roubaix',NULL),('PIERRE-HUBERT','Olivier','320616400','polivier@scotler.fr','l3infofiDB12R','scotler france','Villeneuve d\'ascq',NULL),('ROBERT','Patrice','320213795','probert@lillemetropole.fr','l3infofiDC15R','lmcu','Lille',NULL),('PROVO','Dominique','359353719','dprovo@monabanq.com','l3infofiDC9R','monabanq','Villeneuve d\'ascq',NULL),('MILLE','Clement','629964221','cmille@ntmy.fr','l3infofiDK6R','nicetomeetyou','Lille Hellemmes',NULL),('LAYES','Stéphane','320746630','slayes@micropross.com','l3infofiDL7R','micropross','Lille',NULL),('CUVILLIER','Damien','673352166','damien.cuvillier@lysadour.com','l3infofiDM13R','lys-adour','Roubaix',NULL),('WAUTERS','Vincent','658247793','vwauters@vekia.fr','l3infofiDN5R','vekia','Lille',NULL),('ORJEKH','Romain','320211407','rorjekh@agence-aeronet.com','l3infofiDP11R','aeronet','Lille',NULL),('BOITEL','Loic','327099009','l.boitel@sofratel.fr','l3infofiDS10R','soc_fr_telesurveillance','Bouchain',NULL),('DEMAZIÈRE','Pascal','320998208','pdesmaziere@cofidis.fr','l3infofiDT14R','cofidis participations','Villeneuve d\'ascq',NULL),('DELEFLIE','Florent','','florent.deleflie@univ-lille1.fr','l3infofiDY16R','observatoire ustl','Lille',NULL),('DEHEELE','Romain','328551280','rd@enova.fr','l3infofiGG17R','enova','Attiches',NULL),('AGE','Marion','3020550140','hello@opo.fr','l3infofiGR20R','opo','Lille',NULL),('VASSEUR','Raphael','327968384','r.vasseur@sqltechnologies.com','l3infofiGS18R','sql technologies','Douai',NULL),('NEPPER','Stephane','0326043778','stephane.nepper@veoliatransdev.com','l3infofiGT19R','transdev reims','Reims',''),('BOUILLON','Emmanuel','320209695','emmanuel@artcom.pro','l3infofiHP21R','artcom production','Lille',NULL),('HERBAUT','Nicolas','320343734','nherbaut@carter-cash.com','l3infofiLA23R','carter-cash','Villeneuve d\'ascq',NULL),('CUINGNET','Julien','3202111407','jcuingnet@agence-aeronet.com','l3infofiLD26R','aeronet','Lille',NULL),('BIONDI','Philippe','620255252','philippe.biondi@eads.net','l3infofiLF24R','eads','Suresnes',NULL),('HAUSPIE','Michael','362531549','michael.hauspie@lifl.fr','l3infofiLG27R','inria r2dp','Villeneuve d\'ascq',NULL),('COLPIN','Michael','320638888','mco@audaxis.com','l3infofiLK22R','audaxis','Lille',''),('DERESMES','Camille','354680852','camille.deresmes@alligone.com','l3infofiLL28R','alligone','Villeneuve d\'ascq',NULL),('Melab','Nouredine','0328778552','nouredine.melab@lifl.fr','l3infofiLS29R','lifl','Villeneuve d\'ascq',''),('PIERRE-HUBERT','Olivier','320616400','polivier@scotler.fr','l3infofiLY25R','scotler france','Villeneuve d\'ascq',NULL),('SIMON','Thierry','320169140','simon.thieffry@association-aglae.fr','l3infofiMD32R','aglae','Lille',NULL),('Furmaniak','Christophe','','Christophe.Furmaniak@atosorigin.com','l3infofiMG30R','atos_worldline','Noyelles les Seclin',''),('FLORIN','Gregory','320689080','gflorin@oxygem.tv','l3infofiMJ33R','cuisineaz','Roubaix',NULL),('CARROY','Nicolas','320812830','n.carroy@stores-discount.fr','l3infofiMS31R','oliver store','Roubaix',NULL),('Maillard','Antony','0320132413','amaillard@shirka.com','l3infofiNL34R','shirka','Marcq en Baroeul',''),('DELCOURT','Nicolas','362648131','ndelcourt@keyneosoft.fr','l3infofiPA36R','keyneosoft','Tourcoing',NULL),('BIAUX','Jérôme','612711004','jerome.biaux@logica.com','l3infofiPB35R','logica','Lille',NULL),('LOPES','Olivier','320133939','olivier.lopes@elosi.com','l3infofiQS37R','elosi','Roubaix',NULL),('PIERRE-HUBERT','Olivier','620619406','polivier@scotler.fr','l3infofiRF38R','scotler france','Villeneuve d\'ascq',NULL),('LOPES','Olivier','320133939','olivier.lopes@elosi.com','l3infofiSI39R','elosi','Roubaix',NULL),('GEMMA','Garriga','','gemma.garriga@inria.fr','l3infofiWP41R','inria','Villeneuve d\'ascq',NULL),('PIERRE-HUBERT','Olivier','320616400','polivier@scotler.fr','l3infofiYJ42R','scotler france','Villeneuve d\'ascq',NULL),('Bouchez','Arnaud','','arnaud.bouchez@akawam.com','l3miagefi11BB32R','akawam','Lille',''),('Metzler','Damien','','damien.metzler@leroymerlin.fr','l3miagefi11BC26R','leroy_merlin','Lezennes',NULL),('Baudoux','Didier','0320666734','didier.baudoux@cenfe.caisse-epargne.fr','l3miagefi11BG23R','caisse_d\'epargne_nord_france_europe','Lille',''),('Tuminello','Cedric','320684092','cedric@oxygem.tv','l3miagefi11BJ29R','dynamic_web','Roubaix',NULL),('Gaudin','Jeremie','0669795134','jegaudin@chenelet.org','l3miagefi11BM20R','chenelet_developpement','Bonningues les Calais',NULL),('Lagorsse','Eric','0328801040','eric.lagorsse@airial.com','l3miagefi11BM28R','airial_conseil','Puteaux',NULL),('Bilasco','Celine','0673487753','cbialisco@aig.fr','l3miagefi11Bf20R','alliances_aifc','Marcq-en-Baroeul',NULL),('Poignard','Jerome','0362599314','jerome.poignard@logica.com','l3miagefi11CF40R','logica','Lille',NULL),('Bouchema','Louisa','0320304445','louisa.bouchema@esj-lille.fr','l3miagefi11CW29R','ecole_superieure_journalisme_de_lille','Lille',NULL),('Hoel','Michel','0328552130','m.hoel@urbilog.fr','l3miagefi11DA39R','urbilog','Roubaix',NULL),('Courouble','Nicolas','0328368484','ncourouble@itm.fr','l3miagefi11DB20R','itm','Mouvaux',NULL),('Patoir','Philippe','0320257979','philippe.patoir@willemsefrance.fr','l3miagefi11DF23R','willemse','Tourcoing',''),('Deblock','Philippe','0328669817','philippe.deblock@hotmail.fr','l3miagefi11DI36R','boulangerie_deblock','Dunkerque',NULL),('Flambard','Nicole','0344775180','nicole.flambard@chi.clermont.fr','l3miagefi11DJ23R','centre_hospitalier_clermont_(oise)','Clermont (Oise)',''),('Gwiazdowski','Jeremie','699999575','jgwiazdowski@absystech.fr','l3miagefi11EM33R','absystech','Roubaix',NULL),('Desaunois','Guillaume','0320180606','gdesaunois@madeco.fr','l3miagefi11HA38R','madeco','Pont A Marcq',NULL),('Leroy','Thomas','0320703567','thomas@bigbandprojekt.com','l3miagefi11LS31R','bigbandprojekt','roubaix',NULL),('Izzikitene','Abdelaziz','0320453968','abdelaziz_izzikitene@irco.com','l3miagefi11OY27R','ingersoll-rand_air_solutions_hibon','Wasquehal',''),('Leroy','Vincent','0320715824','vincent-joel.leroy@edf.fr','l3miagefi11PA27R','edf','Villeneuve d\'Ascq',NULL),('Lefebvre','M','0328765666','mlefebvre@norsys.fr','l3miagefi11PN34R','norsys','ennevelin',NULL),('Beaudelot','Laurent','0321518679','laurent.beaudelot@apreva.fr','l3miagefi11PR29R','apreva','Arras',NULL),('Foratier','Julien','0359306544','julien.foratier@dmco.fr','l3miagefi11PR35R','dmco','Tourcoing',NULL),('Lecourt','Fabien','0320537201','fabien.lecourt@univ-lille2.fr','l3miagefi11Re28R','suaps lille 2','Lille',''),('Dewaele','Pierre','0677572201','onix.creation@gmail.com','l3miagefi11WY25R','onix_creation','Saint-Omer',NULL),('Hu','Kun','635470954','cice.kun@gmail.com','l3miagefi11YW35R','cice','Hellemmes',NULL),('Wang','Yu','','wangyu1@ceri.com.cn','l3miagefi11ZC40R','ceri','Nanjing (Chine)',NULL),('GOMEZ','Samuel','320275056','samuel.gomez@noronweb.com','l3miagefiBS0R','noronweb','Roubaix',NULL),('SLOMOWIKZ','Vincent','320685611','vslomowicz@odiso.com','l3miagefiCC2R','odiso','Roubaix',NULL),('DEPREZ','Romain','613460493','rdeprey@oxygem.tv','l3miagefiCC4R','oxygem','Roubaix',''),('Daugan','Fabrice','0320484499','fabrice.daugan@gfi.fr','l3miagefiCF1R','gfi','Lille',''),('PÂQUES','Alain','','apaques@infitex.fr','l3miagefiCG3R','infitex','Villeneuve d\'Ascq',NULL),('DELCAMBRE','Maxime','320799411','m.delcambre@delssi.fr','l3miagefiDA9R','delssi','Villeneuve d\'Ascq',NULL),('CIANCI','Mathias','826101040','mcianci@axecibles.com','l3miagefiDF6R','axecibles','Marcq-en-Baroeul',NULL),('DECOSTER','Jean-michel','320414175','jmdecoster@nordsoft.fr','l3miagefiDK7R','nordsoft','villeneuve d\'ascq',NULL),('MATHIEU','François','320289900','m.francois@reference-directe.fr','l3miagefiDM8R','reference directe','Roubaix',NULL),('VANNIEUXHUYZE','Arnaud','359000688','avannieuwenhuyze@cylande.com','l3miagefiDS5R','cylande','Roubaix',NULL),('PESEZ','Christelle','362599359','christelle.pesez@logica.com','l3miagefiLC10R','logica','Lille',NULL),('MAQUET','Julien','328414042','jmaquet@nordsoft.fr','l3miagefiLG11R','nordsoft','Villeneuve d\'Ascq',NULL),('ZHENGWEI','Qu','668196888','commchina@hotmail.com','l3miagefiLW12R','citadelle scientifique','Lomme',NULL),('TUMINELLO','Cedric','320684092','cedric@oxygem.tv','l3miagefiML14R','dynamic web','Roubaix',NULL),('MACQUART','Mickael','320055613','mmacquart@unis .fr','l3miagefiMM13R','unis','Villeneuve d\'Ascq',NULL),('PIERRE-HUBERT','Olivier','320616400','polivier@scotler.fr','l3miagefiVN15R','scotler france','Villeneuve d\'Ascq',NULL);
/*!40000 ALTER TABLE `fa_referent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_sec_roles`
--

DROP TABLE IF EXISTS `fa_sec_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_sec_roles` (
  `roleDesc` text COLLATE utf8_bin NOT NULL,
  `roleCle` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`roleCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_sec_roles`
--

LOCK TABLES `fa_sec_roles` WRITE;
/*!40000 ALTER TABLE `fa_sec_roles` DISABLE KEYS */;
INSERT INTO `fa_sec_roles` VALUES ('ALL_RESP','ALL_RESP'),('','L3INFOFI_RESP'),('','L3MIAGEFI_RESP');
/*!40000 ALTER TABLE `fa_sec_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_sec_user_roles`
--

DROP TABLE IF EXISTS `fa_sec_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_sec_user_roles` (
  `userRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `roleRef` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_sec_user_roles`
--

LOCK TABLES `fa_sec_user_roles` WRITE;
/*!40000 ALTER TABLE `fa_sec_user_roles` DISABLE KEYS */;
INSERT INTO `fa_sec_user_roles` VALUES ('ALL_RESP','L3INFOFI_RESP'),('ALL_RESP','L3MIAGEFI_RESP'),('routier','L3INFOFI_RESP'),('meftali','L3MIAGEFI_RESP'),('bilasco','ALL_RESP'),('decomite','ALL_RESP'),('kuttler','ALL_RESP');
/*!40000 ALTER TABLE `fa_sec_user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_soutenance`
--

DROP TABLE IF EXISTS `fa_soutenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_soutenance` (
  `formationRef` varchar(10) CHARACTER SET latin1 NOT NULL,
  `dateRemise` text CHARACTER SET latin1 NOT NULL,
  `datesSoutenances` text CHARACTER SET latin1 NOT NULL,
  `longueurRapport` text CHARACTER SET latin1 NOT NULL,
  `dur√©eSoutenance` text CHARACTER SET latin1 NOT NULL,
  `observationsTous` text CHARACTER SET latin1,
  `observationsTuteurs` text CHARACTER SET latin1,
  `lienExterne` text CHARACTER SET latin1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_soutenance`
--

LOCK TABLES `fa_soutenance` WRITE;
/*!40000 ALTER TABLE `fa_soutenance` DISABLE KEYS */;
INSERT INTO `fa_soutenance` VALUES ('L3MIAGEFI','30 juin 2011 ?† 20h','6 juillet 2011','20 ?† 30 pages','25 ?† 30 minutes d\'expos?©\r\npuis 10 minutes de question','Remettez 1 version imprim?©e du rapport le jour de la soutenance. \r\nEnvoyer 1 version pdf au tuteur le 30/06/2011.\r\n\r\n<a href=\'http://www.lifl.fr/~bilasco/RAPPORT_Mission_MIAGE.pdf\'> Consignes d?©taill?©es </a>','suivant les cas de figures sp?©cifiques vous pouvez donner plus de temps aux ?©tudiants pour vous remettre la version pdf.','http://www.lifl.fr/~bilasco/RAPPORT_Mission_MIAGE.pdf'),('L3INFOFI','30 mai 2010','du 7 au 9 juin 2010','Une page A3','20 minutes expos?©\r\n10 minutes pr?©sentation','Les ?©tudiants ont une page A3 pour faire une synth?®se de leur mission (Probl?®me, contexte, r?©alisation, difficult?©, bilan)\r\n\r\nLe document doit ?™tre clair et visuel\r\n\r\nDans le cas d\'une p?©riode avec plusieurs missions, l\'?©tudiant en choisi une qu\'il pr?©sente de cette mani?®re.\r\n\r\n<a href=\'http://www.coe.montana.edu/ie/faculty/sobek/a3/index.htm\' style=\'color:red\'>Plus d\'informations sur le rapport</a>\r\n\r\nUne s?©ance de pr?©sentation de cette m?©thode est pr?©vue le 21 mars.\r\n\r\nLes ?©tudiants doivent rendre une version PDF et une version imprim?©e.','Le suivi d\'un stage, inclus aussi un suivi de la r?©daction du m?©moire et un suivi de la pr?©paration de la soutenance. Merci aux tuteurs universitaires de prendre le temps de relire le m?©moire avant le d?©p?¥t et de faire un retour sur les slides ?† l\'?©tudiant avant la soutenance.','http://www.coe.montana.edu/ie/faculty/sobek/a3/index.htm');
/*!40000 ALTER TABLE `fa_soutenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_sudes`
--

DROP TABLE IF EXISTS `fa_sudes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_sudes` (
  `sudesCle` int(11) NOT NULL AUTO_INCREMENT,
  `nomSudes` varchar(100) COLLATE utf8_bin NOT NULL,
  `tel` varchar(40) COLLATE utf8_bin NOT NULL,
  `mail` varchar(200) COLLATE utf8_bin NOT NULL,
  `nomPrenomContact` int(100) NOT NULL,
  PRIMARY KEY (`sudesCle`),
  UNIQUE KEY `sudesRef` (`sudesCle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_sudes`
--

LOCK TABLES `fa_sudes` WRITE;
/*!40000 ALTER TABLE `fa_sudes` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_sudes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_temp_tuteurs`
--

DROP TABLE IF EXISTS `fa_temp_tuteurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_temp_tuteurs` (
  `etat` int(11) NOT NULL,
  `tuteurRef` varchar(50) COLLATE utf8_bin NOT NULL,
  `alternanceRef` varchar(20) COLLATE utf8_bin NOT NULL,
  `nom_tuteur` varchar(50) COLLATE utf8_bin NOT NULL,
  `prenom_tuteur` varchar(50) COLLATE utf8_bin NOT NULL,
  `mail_tuteur` varchar(50) COLLATE utf8_bin NOT NULL,
  `formationRef` varchar(20) COLLATE utf8_bin NOT NULL,
  KEY `tuteurRef` (`tuteurRef`,`formationRef`),
  KEY `alternanceRef` (`alternanceRef`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='table temporaire \r\nutilis dans l''attribution des tuteurs';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_temp_tuteurs`
--

LOCK TABLES `fa_temp_tuteurs` WRITE;
/*!40000 ALTER TABLE `fa_temp_tuteurs` DISABLE KEYS */;
INSERT INTO `fa_temp_tuteurs` VALUES (0,'tison','','','','','');
/*!40000 ALTER TABLE `fa_temp_tuteurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fi_emails`
--

DROP TABLE IF EXISTS `fi_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fi_emails` (
  `nom` text COLLATE utf8_bin NOT NULL,
  `prenom` text COLLATE utf8_bin NOT NULL,
  `mail` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fi_emails`
--

LOCK TABLES `fi_emails` WRITE;
/*!40000 ALTER TABLE `fi_emails` DISABLE KEYS */;
INSERT INTO `fi_emails` VALUES ('Abdolmohammadi','Sasan','sasan.abdolmohammadi@etudiant.univ-lille1.fr'),('Abushahin','Shahin','shahine.aboushahine@etudiant.univ-lille1.fr'),('Agostino','Flavio','flavio.agostino@etudiant.univ-lille1.fr'),('Allart','Aurore','aurore.allart@etudiant.univ-lille1.fr'),('Amberg','Marc','marc.amberg@etudiant.univ-lille1.fr'),('Amriou','Smail','smail.amriou@etudiant.univ-lille1.fr'),('Anselin','Cyril','cyril.anselin@etudiant.univ-lille1.fr'),('Auchede','Morgan','morgan.auchede@etudiant.univ-lille1.fr'),('Ayar','Adil','adil.ayar@etudiant.univ-lille1.fr'),('Azangue Donchieu','Cedric','c.azangue-donchieu@etudiant.univ-lille1.fr'),('Bah','Alhassane','alhassane.bah@etudiant.univ-lille1.fr'),('Belhaj','Ilyas','i.belhaj@etudiant.univ-lille1.fr'),('Bellano','Frederic','frederic.bellano@etudiant.univ-lille1.fr'),('Ben Ali','Adel','adel.ben-ali@etudiant.univ-lille1.fr'),('Benbrik','Othmane','o.benbrik@etudiant.univ-lille1.fr'),('Benouiz','El-Mehdi','em.benouiz@etudiant.univ-lille1.fr'),('Bihr','Charles-Edmond','charles-edmond.bihr@etudiant.univ-lille1.fr'),('Bonte','Jeremy','jeremy.bonte@etudiant.univ-lille1.fr'),('Bouazza','Younes','younes.bouazza@etudiant.univ-lille1.fr'),('Boumezrag','Hadj-Abdelkader','ha.boumezrag@etudiant.univ-lille1.fr'),('Bourgois','Tristan','tristan.bourgois@etudiant.univ-lille1.fr'),('Brunel','Maxime','maxime.brunel@etudiant.univ-lille1.fr'),('Calmels','Matthieu','matthieu.calmels@etudiant.univ-lille1.fr'),('Camus','Alexis','alexis.camus@etudiant.univ-lille1.fr'),('Caulier','Arnaud','arnaud.caulier@etudiant.univ-lille1.fr'),('Chtiwi','Elmehdi','elmehdi.chtiwi@etudiant.univ-lille1.fr'),('Courtens','Maxence','m.courtens@etudiant.univ-lille1.fr'),('Cousin','Nicolas','nicolas1.cousin@etudiant.univ-lille1.fr'),('Couturier','Boris','boris.couturier@etudiant.univ-lille1.fr'),('Daara','Loic','loic.daara@etudiant.univ-lille1.fr'),('Damie','Nathan','nathan.damie@etudiant.univ-lille1.fr'),('Darmal','Rida','rida.darmal@etudiant.univ-lille1.fr'),('David','Amaury','amaury.david@etudiant.univ-lille1.fr'),('Deboeuf','Nathanael','nathanael.deboeuf@etudiant.univ-lille1.fr'),('Deboffles','Jerome','jerome.deboffles@etudiant.univ-lille1.fr'),('Debrumetz','Sebastien','sebastien.debrumetz@etudiant.univ-lille1.fr'),('Debureau','Theau','theau.debureau@etudiant.univ-lille1.fr'),('Defives','Kevin','kevin.defives@etudiant.univ-lille1.fr'),('Dekeister','Louis','louis.dekeister@etudiant.univ-lille1.fr'),('Delahaye','Axel','axel.delahaye@etudiant.univ-lille1.fr'),('Delattre','Charlotte','charlotte.delattre@etudiant.univ-lille1.fr'),('Deng','Zhi-Yuan','zhi-yuan.deng@etudiant.univ-lille1.fr'),('Denis','Sylvain','sylvain.denis@etudiant.univ-lille1.fr'),('Denquin','Pierre','pierre.denquin@etudiant.univ-lille1.fr'),('Derreveaux','Jonathan','jonathan.derreveaux@etudiant.univ-lille1.fr'),('Detuncq','Benoit-Charles','bc.detuncq@etudiant.univ-lille1.fr'),('Dia Alhassane','Abdoul-Aziz','aa.dia-alhassane@etudiant.univ-lille1.fr'),('Diallo','Mamadou-Cellou-Dara','mcd.diallo@etudiant.univ-lille1.fr'),('Diaz','Jeremy','jeremy.diaz@etudiant.univ-lille1.fr'),('Djebien','Tarik','tarik.djebien@etudiant.univ-lille1.fr'),('Doutreligne','Sebastien','s.doutreligne@etudiant.univ-lille1.fr'),('Duez','Marc','marc1.duez@etudiant.univ-lille1.fr'),('Dufour','Clement','clement1.dufour@etudiant.univ-lille1.fr'),('Dufresne','Yoann','yoann.dufresne@etudiant.univ-lille1.fr'),('Dupas','David','david.dupas@etudiant.univ-lille1.fr'),('El Achiqi','Anas','anas.el-achiqi@etudiant.univ-lille1.fr'),('El Amrani','Mohammed','mohammed.el-amrani@etudiant.univ-lille1.fr'),('Fisset','Benjamin','benjamin.fisset@etudiant.univ-lille1.fr'),('Flamant','Sebastien','sebastien.flamant@etudiant.univ-lille1.fr'),('Fleurquin','Morgan','morgan1.fleurquin@etudiant.univ-lille1.fr'),('Foulon','Axel','axel.foulon@etudiant.univ-lille1.fr'),('Gallant','Guillaume','guillaume.gallant@etudiant.univ-lille1.fr'),('Gallos','Lison','lison.gallos@etudiant.univ-lille1.fr'),('Gandossi','Sebastien','sebastien.gandossi@etudiant.univ-lille1.fr'),('Gaza','Bogdan-Constantin','bc.gaza@etudiant.univ-lille1.fr'),('Gence','Eric','eric.gence@etudiant.univ-lille1.fr'),('Gens','Maxime','maxime.gens@etudiant.univ-lille1.fr'),('Gest','Oscar','oscar.gest@etudiant.univ-lille1.fr'),('Gharagozlou','Roshanak','roshanak.gharagozlou@etudiant.univ-lille1.fr'),('Gillery','Thomas','thomas.gillery@etudiant.univ-lille1.fr'),('Giovanetti','Romain','romain.giovanetti@etudiant.univ-lille1.fr'),('Gombart','Diane','diane.gombert@etudiant.univ-lille1.fr'),('Gourch','Ali','ali.gourch@etudiant.univ-lille1.fr'),('Gueye','Hassane','hassane.gueye@etudiant.univ-lille1.fr'),('Hassaine','Nassim','nassim.hassaine@etudiant.univ-lille1.fr'),('Herbulot','Vincent','vincent.herbulot@etudiant.univ-lille1.fr'),('Honore','Perrine','perrine.honore@etudiant.univ-lille1.fr'),('Houdart','Eglantine','eglantine.houdart@etudiant.univ-lille1.fr'),('Ivanov','Iliya','iliya.ivanov@etudiant.univ-lille1.fr'),('Kaya','Ulas','ulas.kaya@etudiant.univ-lille1.fr'),('Labat','Kevin','kevin.labat@etudiant.univ-lille1.fr'),('Laraki','Alien','alien.laraki@etudiant.univ-lille1.fr'),('Ledoux','Florian','florian.ledoux@etudiant.univ-lille1.fr'),('Leflon','Damien','damien.leflon@etudiant.univ-lille1.fr'),('Lelievre','Antoine','antoine.lelievre@etudiant.univ-lille1.fr'),('Leroy','Yannick','yannick1.leroy@etudiant.univ-lille1.fr'),('Level','Damien','damien.level@etudiant.univ-lille1.fr'),('Liu','Qiang','qiang.liu@etudiant.univ-lille1.fr'),('Locquet','Guillaume','guillaume.locquet@etudiant.univ-lille1.fr'),('Loridan','Ludovic','ludovic.loridan@etudiant.univ-lille1.fr'),('Louis','Sebastien','sebastien1.louis@etudiant.univ-lille1.fr'),('Macke','Guillaume','guillaume.macke@etudiant.univ-lille1.fr'),('Maillart','Valentine','valentine.maillart@etudiant.univ-lille1.fr'),('Manfoumbi Animbogo','Glenn-Vincy','manfoumbi-animbogo@etudiant.univ-lille1.fr'),('Mellouli','Matthias','matthias.mellouli@etudiant.univ-lille1.fr'),('Merlin','Sylvain','sylvain.merlin@etudiant.univ-lille1.fr'),('Milan','Julien','julien.milan@etudiant.univ-lille1.fr'),('Monkerhey','Florent','florent.monkerhey@etudiant.univ-lille1.fr'),('Montulet','Damien','damien.montulet@etudiant.univ-lille1.fr'),('Mouatassim','Sanaa','sanaa.mouatassim@etudiant.univ-lille1.fr'),('Munyandilikirwa','Jean-Parfait','jp.munyandilikirwa@etudiant.univ-lille1.fr'),('Nguyen','Quang-Tung','quang-tung.nguyen@etudiant.univ-lille1.fr'),('Noufli','Larbi','larbi.noufli@etudiant.univ-lille1.fr'),('Noumi','Liv-Armand','liv-armand.noumi@etudiant.univ-lille1.fr'),('Petit','Benoit','benoit1.petit@etudiant.univ-lille1.fr'),('Petre','Augustin','augustin.petre@etudiant.univ-lille1.fr'),('Pollaert','Kevin','kevin.pollaert@etudiant.univ-lille1.fr'),('Proum','Tony','tony.proum@etudiant.univ-lille1.fr'),('Queniart','Samuel','samuel.queniart@etudiant.univ-lille1.fr'),('Ramelot','Pierre','pierre.ramelot@etudiant.univ-lille1.fr'),('Raverdy','Maxime','maxime.raverdy@etudiant.univ-lille1.fr'),('Recourt','Florian','florian.recourt@etudiant.univ-lille1.fr'),('Rouault','Xavier','xavier.rouault@etudiant.univ-lille1.fr'),('Saint Georges','Claude','claude.saint-georges@etudiant.univ-lille1.fr'),('Sayadi','Othmane','othmane.sayadi@etudiant.univ-lille1.fr'),('Souissi','Ismael','ismael.souissi@etudiant.univ-lille1.fr'),('Szczepaniak','Amaury','amaury.szczepaniak@etudiant.univ-lille1.fr'),('Vanderheyden','Thomas','thomas.vanderheyden@etudiant.univ-lille1.fr'),('Vandromme','Maxence','maxence.vandromme@etudiant.univ-lille1.fr'),('Verbeke','Nicolas','nicolas2.verbeke@etudiant.univ-lille1.fr'),('Vielle','Gwenael',''),('Wauquier','Pauline','pauline.wauquier@etudiant.univ-lille1.fr'),('Yasar','Abdurrahman','abdurrahman.yasar@etudiant.univ-lille1.fr'),('Youlhajen','Jamal-Dine','jamaldine.youlhajen@etudiant.univ-lille1.fr'),('Amara','Djamel','djamel.amara@etudiant.univ-lille1.fr'),('Azaroual','Zakariae','zakariae.azaroual@etudiant.univ-lille1.fr'),('Bah','Mamadou-Bassirou','mamadou-bassirou.bah@etudiant.univ-lille1.fr'),('Becquart','Guillaume','guillaume.becquart@etudiant.univ-lille1.fr'),('Becuwe','Justine','justine.becuwe@etudiant.univ-lille1.fr'),('Boidin','Clement','clement1.boidin@etudiant.univ-lille1.fr'),('Boucher','Maxime','maxime1.boucher@etudiant.univ-lille1.fr'),('Bouchez','Benjamin','benjamin.bouchez@etudiant.univ-lille1.fr'),('Bouillet','Severine','severine.bouillet@etudiant.univ-lille1.fr'),('Brianchon','Felix','felix.brianchon@etudiant.univ-lille1.fr'),('Camus','Florian','florian.camus@etudiant.univ-lille1.fr'),('Capilliez','Cyril','cyril.capilliez@etudiant.univ-lille1.fr'),('Carpentier','Florian','florian1.carpentier@etudiant.univ-lille1.fr'),('Ceriez','Gael','gael.ceriez@etudiant.univ-lille1.fr'),('Chikhaoui','Maher','maher.chikhaoui@etudiant.univ-lille1.fr'),('Chudoba','Willis','willis.chudoba@etudiant.univ-lille1.fr'),('Cordina','Charles-Antoine','ca.cordina@etudiant.univ-lille1.fr'),('Dahmani','Soufiane','soufiane.dahmani@etudiant.univ-lille1.fr'),('Dallenne','Florent','florent.dallenne@etudiant.univ-lille1.fr'),('David','Franck','franck.david@etudiant.univ-lille1.fr'),('Deleforterie','Karl','karl.deleforterie@etudiant.univ-lille1.fr'),('Descroizette','Joris','joris.descroizette@etudiant.univ-lille1.fr'),('Desprez','Marine','marine.desprez@etudiant.univ-lille1.fr'),('Devincke','Amelie','amelie.devincke@etudiant.univ-lille1.fr'),('Diallo','Ibrahima','ibrahima2.diallo@etudiant.univ-lille1.fr'),('Dubois','Benjamin','benjamin3.dubois@etudiant.univ-lille1.fr'),('Dubus','Alexandre','alexandre1.dubus@etudiant.univ-lille1.fr'),('El Hizabri','Mouad','mouad.el-hizabri@etudiant.univ-lille1.fr'),('Goubel','Antoine','antoine.goubel@etudiant.univ-lille1.fr'),('Hadhri','Wissem','wissem.hadhri@etudiant.univ-lille1.fr'),('Honore','Alexandre','alexandre.honore@etudiant.univ-lille1.fr'),('Laethem','Christopher','christophe.laethem@etudiant.univ-lille1.fr'),('Lonvert','Gwennael','gwennael.lonvert@etudiant.univ-lille1.fr'),('Luo','Wen','wen.luo@etudiant.univ-lille1.fr'),('Mascret','Michael','michael.mascret@etudiant.univ-lille1.fr'),('Masson','Louis','louis.masson@etudiant.univ-lille1.fr'),('Oulamine','Youssef','youssef.oulamine@etudiant.univ-lille1.fr'),('Pamula','Noe','noe.pamula@etudiant.univ-lille1.fr'),('Peron','Romain','romain.peron@etudiant.univ-lille1.fr'),('Platel','Alexandre','alexandre.platel@etudiant.univ-lille1.fr'),('Poire','Romain','romain.poire@etudiant.univ-lille1.fr'),('Rakotobe','Sitraka-Eric','se.rakotobe@etudiant.univ-lille1.fr'),('Sano','Latifou','latifou.sano@etudiant.univ-lille1.fr'),('Thouvenot','Erwan','erwan.thouvenot@etudiant.univ-lille1.fr'),('Vandemeulebrouck','Nicolas','n.vandemeulebrouck@etudiant.univ-lille1.fr'),('Wang','Yue','yue.wang@etudiant.univ-lille1.fr'),('Yu','Wenjie','wenjie.yu@etudiant.univ-lille1.fr'),('Zhang','Chennan','chennan.zhang@etudiant.univ-lille1.fr');
/*!40000 ALTER TABLE `fi_emails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-10-28 19:08:28
