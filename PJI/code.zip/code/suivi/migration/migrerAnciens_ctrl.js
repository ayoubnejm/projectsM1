/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function reloadStudentListByGroupYear(form) {
  //alert ('creating xhr');
  var xhr=getXMLHttpRequest();
   xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            loadStudentListByGroupYear(xhr.responseXML,form);
        }
    };

    xhr.open("POST", "../migration/migrerAnciens_mdl.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
     params="";
    //alert("submit Data!");

    groupeRef=getOptionCle(form,'groupeRef');
    if (groupeRef.length>0)
        params="groupeRef=" + groupeRef;

    yearRef=getFieldValue(form,'yearRef');
    //alert(bur_adresse);
    if (yearRef.length>0)
        params+="&yearRef=" + yearRef;

    //alert("params: "+params);
    xhr.send(params);

}

function loadStudentListByGroupYear(oData,form) {
  //alert("read Data!");
  
  var nodes=oData.getElementsByTagName("item");
  var i=0;
  listRefElt=getFormCtrl(form,"etudList");
  listRefElt.length=0;
  listRefElt.size=5;
  for (i=0;i<nodes.length;i++) {
    var nom=nodes[i].getAttribute("etudNom").toString()
    var cle=nodes[i].getAttribute("etudRef").toString()
    listRefElt.options.add(new Option(nom,cle));
  }
  listRefElt.size=listRefElt.length<10?10:listRefElt.length;
  
}

function doAction() {
  reloadStudentListByGroupYear("anneeCourante");
  reloadStudentListByGroupYear("anneeSuivante");
}