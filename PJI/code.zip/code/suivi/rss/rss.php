<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once (ABS_START_PATH."/dbmngt/queries.php");
require_once (ABS_START_PATH."/config/auth.ini.php");
require_once (ABS_START_PATH."/secure/auth.php");

function regenerateAllTuteursChoixRss()
{
    $formations=constructGrantedGroupesKeys(true,true,"FA/FI",true);
    $keys=$formations["keys"];
    $values=$formations["values"];

    for ($i=0;$i<count($keys);$i++) {
        //if (strpos($keys[$i],",")===FALSE)
        //echo $values[$i]." - ".$keys[$i]."<br/>";
        generateTuteursChoixRss(str_replace("-","",str_replace(" ","",$values[$i])),$keys[$i]);
    }
    //generateTuteursChoixRss("ALL","%");
    //generateTuteursChoixRss("MIAGE","%MIAGE%");
    //generateTuteursChoixRss("INFO","");
}

function generateTuteursChoixRss($nomRss,$formation)
{
    $conn=doConnection();
    $now=date(DATE_RFC822);

    //printf("%s<br/>",$nomRss);
    $file=fopen(ABS_START_PATH."/xml/choix_".$nomRss.".rss","w");
    $header="<?xml version='1.0' encoding='UTF-8'?>\n".
                  "\t<rss version='2.0'>\n".
                  "\t\t<channel>\n".
                  "\t\t\t<title>Choix tuteurs ".$nomRss." </title>\n".
                  "\t\t\t<description>Tuteurs souhaitant encadrant un ou plusieurs alternants en ".$nomRss." </description>\n".
                  "\t\t\t<link>".INDEX_PAGE."</link>\n".
                  "\t\t\t<lastBuildDate>".$now."</lastBuildDate>\n";
    fprintf($file,$header);

    $rows=doQueryTuteursPotentielsParFormation($conn,$formation);

    for ($row=mysql_fetch_row($rows);$row;$row=mysql_fetch_row($rows))
    {
        $item="\t\t\t<item>\n".
              "\t\t\t\t<title>".$row[1]." ".$row[0]." souhaite encadrer ".$row[3]." ".$row[2]." (".$row[4].")</title>\n".
              "\t\t\t\t<description>".$nomRss." : ".$row[1]." ".$row[0]." souhaite encadrer ".$row[3]." ".$row[2]." (".$row[4].")</description>\n".
              "\t\t\t\t<pubDate>".$now."</pubDate>\n".
              "\t\t\t\t<link>".INDEX_PAGE."</link>\n".
              "\t\t\t</item>\n";
        fprintf($file,$item);
        //printf("%s<br/>",$item);
    }

    fprintf($file,"\t\t</channel>\n".
                  "\t</rss>");

    fclose($file);
    
}
?>
