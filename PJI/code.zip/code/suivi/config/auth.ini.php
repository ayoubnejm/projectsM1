<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
    //define('INDEX_PAGE','http://localhost/~marius/fam2/index.php');

    //define('INDEX_PAGE','http://www.fil.univ-lille1.fr/~bilasco/fam2/index.html');


    define('CAS_BASE','https://sso-cas.univ-lille1.fr');
    define('CK_USER','CK_USER');
    define('CK_ROLES','CK_ROLES');
    define('PROF_ROLE','PROF');
    define('STUD_ROLE','ETUD');
    define('RESP_ROLE','RESP');
	/* ajout de role secr par an et se 04/2013 */ 
	define('SECR_ROLE','SECR');
    define('ALL_RESP_ROLE','ALL_RESP');



   
?>
