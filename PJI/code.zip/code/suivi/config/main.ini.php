<?php

//    define('INDEX_PAGE','http://localhost/~marius/fam3');
//    define('ABS_START_PATH','/Volumes/DATA/UsersData/marius/Sites/fam3');
//    define('ABS_START_URL','/~marius/fam3');

   
	define('INDEX_PAGE','http://localhost/code/suivi');
    define('ABS_START_PATH','/var/www/code/suivi');
    define('ABS_START_URL','/code/suivi');

	 //define('INDEX_PAGE','http://stages.fil.univ-lille1.fr/suivi');
    //define('ABS_START_PATH','/var/www/suivi');
    //define('ABS_START_URL','/suivi');

    define('REF_YEAR','refYear');
    define('DEFAULT_APPLI','FA');
    define('REF_FORMATIONTYPE','refFT');
    define('MODE','mode');
    define('RESP_MODE','resp');
    define('SECR_MODE','secr');
    define('PROF_MODE','tut');


    function getCurrYear() {
      //error_log ("currentYear : ". (date("Y")-(date("n")<9)));
      //return date("Y")-(date("n")<9);
      return 2012;
    }

    function getAvailableYears() {
      $years=array();
      for ($i=getCurrYear()+1;$i>2008;$i--) {
        $years[]=$i;
      }
      return $years;
    }

    function getMigrationYears() {
      $years=array();
      for ($i=getCurrYear()+1;$i>getCurrYear()-1;$i--) {
        $years[]=$i;
      }
      return $years;
    }
?>
