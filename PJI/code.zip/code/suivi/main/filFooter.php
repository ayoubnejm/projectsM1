
<center>
      <div id="footer">
          <div id= "zone-logo-bas">  </div>
          <div id= "zone-titre-bas">  </div>
	  <div id= "zone-texte-bas1">  </div>
          <div id= "zone-texte-bas2">
            <p>
	      FIL - Bât. M3 - Cité Scientifique 59655 Villeneuve d'Ascq Cedex Tél. +33 (0) 3.20.43.44.94 |
              <a href="http://fil.univ-lille1.fr/mentions-legales/" accesskey="8">Mentions légales</a>
              | <a href="mailto:portail@lifl.fr" accesskey="7">Webmaster</a>
	    </p>
          </div>
        </div>
</center>


    