<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
  require_once (ABS_START_PATH."/secure/auth.php");
  if (!hasRole(PROF_ROLE))
      redirectAuth();
?>

<div class="menuligne3">
  <?php
    $menuItem=array("interface/actionsEtudiantsParTuteur_act",
                "interface/choixEtudiantsParTuteur_act",
                "interface/sansTuteur_act",
                "interface/informationsSoutenanceEtRapportParTuteur_act"
                );
    $menuItemLabel=array("Mes étudiants","Mes choix","Choisir étudiants","Rapport &amp; Soutenance");
    for ($i=0;$i<count($menuItem);$i++) {
      echo " : <a ".($page==$menuItem[$i]?"class='highlight'":"")." href='".INDEX_PAGE."/index.php?mode=".PROF_MODE."&page=".$menuItem[$i]."'>".$menuItemLabel[$i]."</a>";
    }
    ?>
</div>
<div class="menuligne4"></div>

