<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
 require_once ABS_START_PATH.'/secure/auth.php';
?>

<div id="centre-accessibilite">
   <div id="zone-accessibilite">
     <ul>
        <li><a href="#menuprincipal">Aller au menu</a> |  </li>
        <li> <a href="#contenu" accesskey="s">Aller au contenu</a> |
	</li>
<li> <a href="http://fil.univ-lille1.fr/accessibilite/" accesskey="0">Accessibilité</a></li>
     </ul>
   </div>
</div>


<div id="main_top" style="height:150px">
  <div id="top">
    <div id="zone-logo">
      <a href="http://www.univ-lille1.fr">
        <img src="http://fil.univ-lille1.fr/digitalAssets/1/1742_Lille1.jpg" alt="Université Lille1"/></a>
      <img src="http://fil.univ-lille1.fr/digitalAssets/5/5747_Titre-IEEA-BIS2.gif" alt="IEEA - Formations en informatique"/>
    </div>
  </div>
    <div id="menu">
                <a name="menuprincipal"></a>
        	<div id="home"><a href="<?php echo ABS_START_URL.'/index.php'; ?>" title="suivi"></a></div>
          <form action="index.php" method="get" id="menuForm">
          <input type="hidden" name="page" value="<?php if (substr($page,0,9)=="interface") echo $page; else echo 'index';?>"/>
          <input type="hidden" name="action" value="<?php if (isset($_REQUEST["action"])) echo $_REQUEST["action"]; else echo '';?>"/>
          <?php if (isset($_REQUEST["selection"])) {
            $sel=$_REQUEST["selection"];
            for ($i=0;$i<count($sel);$i++) {
              echo "<input type='hidden' name='selection[]' value='".$sel[$i]."'/>\n";
            }
            echo "<SCRIPT src='".ABS_START_URL."/js/form.js' lang='javascript'></SCRIPT>";
          } ?>

          <ul id="nav">
            <li class="menuHorizontal">
               <?php if (strlen($_SESSION[CK_USER])>0) {
                      echo "&nbsp;Hey ".$_SESSION[CK_USER];
                      echo "<ul>
                        <li><a href='".ABS_START_URL."/disconnect.php'>Deconnexion</a></li>
                      </ul>";
                     } else {
                       echo "<a href='".ABS_START_URL."/interface/index.php'>Connexion</a>";
                     }
               ?>
            </li>
            
            <li class="menuHorizontal">
                
              &nbsp;
              <?php

              if (hasRole(PROF_ROLE)) {
                createSelectWithOnChange(
                REF_FORMATIONTYPE,
                array("FA","FI","FA_FI"),
                array("Alternance","Stages","Alt./Stages"),
                (strcmp($refFormationRef,"FA")==0)?0:((strcmp($refFormationRef,"FI")==0)?1:2),
                "javascript:submit();");
              } ;
              ?>
              
              <?php
              $years=getAvailableYears();
              createSelectWithOnChange(
                    REF_YEAR,
                    $years,
                    $years,
                    $CURR_YEAR-$refYear+1,
                    "javascript:".
                      (isset($sel)?(
                          " var elts=getElt('menuForm').elements;
                            for (i=0;i<elts.length;i++)
                            {
                                if (elts[i].name=='selection[]') {
                                    
                                    elts[i].value=elts[i].value.substr(0,elts[i].value.length-4)+getOptionCle('menuForm','".REF_YEAR."');
                                }
                            };
                          ")
                        :(""))."submit();");
             ?>
            
            </li>
           
          </ul>
    </form>
    </div>
  <!--div id="bandeau"></div-->

</div>


