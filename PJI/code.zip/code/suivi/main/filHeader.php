
<div id="acces">
   <form action="http://www.univ-lille1.fr/Accueil/redirection/" method="get">


<div>

            <img src="http://fil.univ-lille1.fr/digitalAssets/3/3301_Lille1Top.jpg" alt="Université Lille1" title="Université Lille1">
<div id="englobe_acces">

		<p><label for="acces_direct">Accéder aux autres sites de l'Université:</label></p>

<select name="lien" id="acces_direct"><option value="http://www.univ-lille1.fr">Universit&eacute; Lille1</option>

                <optgroup label="UFR et FacultÃ©">
				<option value="http://ses.univ-lille1.fr/">FacultÃ© des Sciences Economiques et Sociales</option>
				<option value="http://sm-wimereux.univ-lille1.fr/">Station Marine de Wimereux</option>
				<option value="http://biologie.univ-lille1.fr/">UFR Biologie</option>
				<option value="http://chimie.univ-lille1.fr/">UFR Chimie</option>
				<option value="http://geographie.univ-lille1.fr/">UFR GÃ©ographie</option>
				<option value="http://ieea.univ-lille1.fr/">UFR IEEA</option>
				<option value="http://mathematiques.univ-lille1.fr/">UFR MathÃ©matiques</option>
				<option value="http://physique.univ-lille1.fr/">UFR Physique</option>
				<option value="http://sciences-de-la-terre.univ-lille1.fr">UFR Sciences de la Terre</option>
		</optgroup>
                <optgroup label="Ecoles et Instituts">
				<option value="http://cueep.univ-lille1.fr/cueep/">CUEEP</option>
				<option value="http://www.iae.univ-lille1.fr/">IAE</option>
				<option value="http://www-iut.univ-lille1.fr/">IUT A</option>
				<option value="http://www.polytech-lille.fr/">Polytech&#039;Lille</option>
				<option value="http://www.telecom-lille1.eu/">TELECOM Lille 1</option>
		</optgroup>
                <optgroup label="Services">
				<option value="http://doc.univ-lille1.fr/">BibliothÃšque universitaire</option>
				<option value="http://cri.univ-lille1.fr">Centre de Ressources Informatiques</option>
				<option value="http://ci.univ-lille1.fr/">Centre international</option>
				<option value="http://ofip.univ-lille1.fr/">OFIP</option>
				<option value="http://pass-pro.univ-lille1.fr">Pass&#039;Pro</option>
				<option value="http://suaio.univ-lille1.fr">SUAIO</option>
				<option value="http://suaps.univ-lille1.fr/">SUAPS</option>
				<option value="http://www.univ-lille1.fr/sudes">SUDES</option>
				<option value="http://semm.univ-lille1.fr">Service MultimÃ©dia</option>
		</optgroup>
                <optgroup label="Divers">
				<option value="http://culture.univ-lille1.fr/">Espace Culture</option>
				<option value="http://lille1tv.univ-lille1.fr/">Lille1.tv</option>
				<option value="http://patrimoine-artistique.univ-lille1.fr">Patrimoine artistique</option>
		</optgroup>
</select>


                <input title="Accéder au site" value="ok" type="submit">
        </div>
</div>
	</form>

</div>



