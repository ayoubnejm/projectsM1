<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
  require_once (ABS_START_PATH."/secure/auth.php");
  if (!hasRole(RESP_ROLE))
      redirectAuth();
?>
<div class="menuligne3" style="background-color:orange">
  <?php
    $menuItem=array("interface/listeTuteursParEtudiant_act",
                "interface/listeEtudiantsParResponsable_act",
                "interface/actionsEtudiantsParResponsable_act",
                "interface/attributionTuteurs_act",
                "interface/informationsSoutenanceEtRapportParResp_act",
                "stats/stats_act",
                "interface/inscrireEtudiant_act",
                "interface/admin_act"
                );
    $menuItemLabel=array("Encadrement par étud.","par tuteur","Actions","Attribution","Rapport &amp; Soutenance","Stats","Inscrire Etud","Admin");
    for ($i=0;$i<count($menuItem)-1;$i++) {
      echo "| <a ".($page==$menuItem[$i]?"class='highlight'":"")." href='".INDEX_PAGE."/index.php?mode=".RESP_MODE."&page=".$menuItem[$i]."'>".$menuItemLabel[$i]."</a>";
    }
    if (hasRole(ALL_RESP_ROLE))
    {
      echo "| <a ".($page==$menuItem[$i]?"class='highlight'":"")." href='".INDEX_PAGE."/index.php?mode=".RESP_MODE."&page=".$menuItem[$i]."'>".$menuItemLabel[$i]."</a>";
    }
    ?>
</div>
