<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 03/03/2013
 */
    function doConnectionPDO($dbname)
    {
        
	try{
		$bdd = new PDO('mysql:host=127.0.0.1;dbname='.$dbname, 'root', 'root');
		$bdd->exec("SET CHARACTER SET utf8");
		}
		catch (Exception $e)
			{
					die('Erreur : ' . $e->getMessage());
			}

				return $bdd;
    }
    
?>
