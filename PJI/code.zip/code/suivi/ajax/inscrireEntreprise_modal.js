function constructOPCAList(opcaSelectID) {
  var xhr=getXMLHttpRequest();
  xhr.onreadystatechange = function() {
          if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
              var nodes=xhr.responseXML.getElementsByTagName("item");
              var opcaSelect=getElt(opcaSelectID);
              for (var i=0;i<nodes.length;i++) {
                opcaSelect.options[i]=new Option(nodes[i].getAttribute("value"),nodes[i].getAttribute("name"),false,false);
               }
          }
      };
    xhr.open("POST", "ajax/getOPCAList.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send("");
}

function generateInscrireEntrepriseForm() {
    
     
    document.write("<div id='inscrireEntreprise_div' style='visibility:hidden;position:absolute;width:100%;textalign:center;zIndex:1000;left:200;background-color:rgba(100,100,0,1);' >\n\
                <form id='inscrireEntreprise' action='#' method='POST'> "+
            "<input type='hidden' name='entr_cle' value='default'/>"+
            "<input type='hidden' name='entr_regie' value='entr'/>"+
            "<input type='hidden' name='main_form' value='form0'/>"+
            "<input type='hidden' name='source_page' value=''/>"+
            "<input type='hidden' name='source_recno' value=''/>"+
            "<h2>Inscrire une nouvelle entreprise : \n\
            <table witdh='500'>"+'\n\
                <tr>\n\
                    <td width="250">\n\
            Nom entreprise * : </td><td><input type="text" name="entr_nom" value=""/>\n\
                    </td></tr><tr><td>\n\
            Adresse * : </td><td><input type="text" name="entr_adresse" value=""/>\n\
            </td></tr><tr><td>\n\
                        Ville * :</td><td><input type="text" name="entr_ville" value=""/>\n\
            </td></tr><tr><td>\n\
                        Code Postal * :</td><td><input type="text" name="entr_cp" value=""/>\n\
            </td></tr><tr><td>\n\
                        Téléphone :</td><td><input type="text" name="entr_tel" value=""/>\n\
            </td></tr><tr><td>OPCA</td><td>\n\
                        <select id="entr_opcaRefID" name="entr_opcaRef"/>\n\
                </td>\n\
                </tr>\n\
                <tr> \n\
                    <td>\n\
                        * Champ obligatoire \n\
                    </td> \n'+
                    "<td><table width='100%'><tr> \n\
                        <td><input type='button' style='color:red' name='cancel' value='Annuler' onClick='javascript:showHideModal(\"inscrireEntreprise_div\")'/>\n\
                        </td><td><input type='button' style='color:orange' name='inscrire' \n\
                                onClick='javascript:\n\
                                            faireInscrireEntreprise(\"inscrireEntreprise\");' \n\
                                 value='Inscrire'/> \n\
                        </td></tr> \n\
                        </table> \n\
                    </td> \n\
                </tr> \n\
            </table> \n\
        </form></div>");
        constructOPCAList("entr_opcaRefID");

        doModal('inscrireEntreprise_div');
 }

 function faireInscrireEntreprise(form) {
   var xhr=getXMLHttpRequest();
   xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            if (getFieldValue("inscrireEntreprise","source_page")=="interface/importCandidatures_act")
              readInscrireEntrepriseDataImportCandidatures(xhr.responseXML,form);
            else
                readInscrireEntrepriseData(xhr.responseXML,form);
        }
    };

    xhr.open("POST", "ajax/faireInscrireEntreprise.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
     params="";
    //alert("submit Data!");

    entr_nom=getFieldValue(form,'entr_nom');
    if (entr_nom.length>0)
        params="entr_nom=" + entr_nom;
    //alert(entr_nom);
    
    entr_adresse=getFieldValue(form,'entr_adresse');
    //alert(entr_adresse);
    if (entr_adresse.length>0)
        params+="&entr_adresse=" + entr_adresse;

    entr_ville=getFieldValue(form,'entr_ville');
    //alert(entr_ville);
    if (entr_ville.length>0)
        params+="&entr_ville=" + entr_ville;

    entr_cp=getFieldValue(form,'entr_cp');
    //alert(entr_cp);
    if (entr_cp.length>0)
      params+="&entr_cp=" + entr_cp;

    entr_tel=getFieldValue(form,'entr_tel');
    //alert(entr_tel);
    if (entr_tel.length>0)
      params+="&entr_tel=" + entr_tel;

    entr_opcaRef=getFieldValue(form,'entr_opcaRef');
    //alert(entr_tel);
    if (entr_opcaRef.length>0)
      params+="&entr_opcaRef=" + entr_opcaRef;
    //alert(params);
    xhr.send(params);

 }

 function readInscrireEntrepriseData(oData,form) {
  var entrType=getFieldValue(form,"entr_regie");
  var entrForm=getFieldValue(form,"main_form");
  //var refCount=getFieldValue(form,"ref_count");
  //alert(oData);
  var nodes=oData.getElementsByTagName("item");
  //alert(nodes);
  var msg=nodes[0].getAttribute("msg").toString();
  if (nodes[0].getAttribute("code").toString()=="0") {
    optsName="fa_"+((entrType=="regie")?"regie":"entreprise")+"_cle";
    opts=getElt(entrForm).elements.namedItem(optsName).options;
    opts.length+=1;
    opts[opts.length-1]=new Option(getFieldValue(form,'entr_nom'),
                          msg.substr(5),true,true);
    optsName="fa_"+((entrType!="regie")?"regie":"entreprise")+"_cle";
    opts=getElt(entrForm).elements.namedItem(optsName).options;
    opts.length+=1;
    opts[opts.length-1]=new Option(getFieldValue(form,'entr_nom'),
                          msg.substr(5),false,false);
    showHideModal('inscrireEntreprise_div');
    
    (entrType=="regie")?choixRegie(getElt(entrForm)):choix(getElt(entrForm));
    
    alert("Entreprise inscrite avec succès!");
  } else {
    alert("Erreur : "+nodes[0].getAttribute("msg").toString());
    }
 }

 function readInscrireEntrepriseDataImportCandidatures(oData,form) {
  var entrForm=getFieldValue(form,"main_form");
  //var refCount=getFieldValue(form,"ref_count");

  var nodes=oData.getElementsByTagName("item");
  var msg=nodes[0].getAttribute("msg").toString();
  if (nodes[0].getAttribute("code").toString()=="0") {
    elts=getElt(entrForm).elements;
    for (i=0;i<elts.length;i++) {
      if (elts[i].name.substr(0,"fa_entreprise_cle_".length)=="fa_entreprise_cle_") {
        
        startsWith=elts.namedItem("raw_"+elts[i].name).value.substr(0,3);
        if (elts[i].options[0].text=="SANS ENTREPRISE" || elts[i].options[0].value.substr(0,3)==startsWith) {

          opts=elts[i].options;
          opts.length+=1;
          opts[opts.length-1]=new Option(getFieldValue(form,'entr_nom'),
                            msg.substr(5),false,false);
        }
      }
      }
    showHideModal('inscrireEntreprise_div');
    //alert('fa_entreprise_cle_'+getFieldValue('inscrireEntreprise','source_recno'));
    selfield=elts.namedItem('fa_entreprise_cle_'+getFieldValue('inscrireEntreprise','source_recno'));
    //alert(selfield);
    selfield.selectedIndex=selfield.options.length-1;
    //alert(selfield.onchange());
    alert("Entreprise inscrite avec succès!");
  } else {
    alert("Erreur : "+nodes[0].getAttribute("msg").toString());
    }
 }

function inscrireEntreprise(formName,entr_regie)
{
    setFieldValue("inscrireEntreprise","main_form",formName);
    setFieldValue("inscrireEntreprise","entr_regie",entr_regie);
    //alert('go Modal');
    showHideModal('inscrireEntreprise_div');
    return "#";
}