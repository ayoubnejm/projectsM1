function generateUpdateBureauForm() {
    document.write("<div id='updateBureau_div' style='visibility:hidden;position:absolute;width:100%;textalign:center;zIndex:1000;left:200;background-color:rgba(100,100,100,1);' >\n\
                <form id='updateBureau' action='#' method='POST'> "+
            "<input type='hidden' name='bur_cle' value='default'/>"+
            "<input type='hidden' name='entr_regie' value='entr'/>"+
            "<input type='hidden' name='main_form' value='form0'/>"+
            "<h2>Mis à jour informations bureau  : \n\
              <div id='nom_div_bureau_update'>Default</div></h2> \n\
            <table witdh='500'>"+'\n\
                <tr>\n\
                    <td>\n\
                        Adresse *: \n\
                    </td>\n\
                    <td>\n\
                        <input type="text" name="bur_adresse" value=""/>\n\
                    </td>\n\
                </tr>\n\
                <tr>\n\
                    <td>\n\
                        Ville *:\n\
                    </td>\n\
                    <td>\n\
                        <input type="text" name="bur_ville" value=""/>\n\
                    </td>\n\
                </tr>\n\
                <tr>\n\
                    <td>\n\
                        Code Postal *:\n\
                    </td>\n\
                    <td>\n\
                        <input type="text" name="bur_cp" value=""/>\n\
                    </td>\n\
                </tr><tr>\n\
                    <td>\n\
                        Téléphone *:\n\
                    </td>\n\
                    <td>\n\
                        <input type="text" name="bur_tel" value=""/>\n\
                    </td>\n\
                </tr>\n\
                <tr> \n\
                    <td>\n\
                        * Laisser vide si pas de modification \n\
                    </td> \n'+
                    "<td><table width='100%'><tr> \n\
                        <td><input type='button' style='color:red' name='cancel' value='Annuler' onClick='javascript:showHideModal(\"updateBureau_div\")'/>\n\
                        </td><td><input type='button' style='color:orange' name='update' \n\
                                onClick='javascript:\n\
                                            faireUpdateBureau(\"updateBureau\");' \n\
                                 value='Update'/> \n\
                        </td></tr> \n\
                        </table> \n\
                    </td> \n\
                </tr> \n\
            </table> \n\
        </form></div>");
        doModal('updateBureau_div');
 }

 function faireUpdateBureau(form) {
   var xhr=getXMLHttpRequest();
   xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            readUpdateBureauData(xhr.responseXML,form);
        }
    };

    xhr.open("POST", "ajax/faireUpdateBureau.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
     params="";
    //alert("submit Data!");

    bur_cle=getFieldValue(form,'bur_cle');
    if (bur_cle.length>0)
        params="bur_cle=" + bur_cle;
    
    bur_adresse=getFieldValue(form,'bur_adresse');
    //alert(bur_adresse);
    if (bur_adresse.length>0)
        params+="&bur_adresse=" + bur_adresse;

    bur_ville=getFieldValue(form,'bur_ville');
    //alert(bur_ville);
    if (bur_ville.length>0)
        params+="&bur_ville=" + bur_ville;

    bur_cp=getFieldValue(form,'bur_cp');
    //alert(bur_cp);
    if (bur_cp.length>0)
      params+="&bur_cp=" + bur_cp;

    bur_tel=getFieldValue(form,'bur_tel');
    //alert(bur_tel);
    if (bur_tel.length>0)
      params+="&bur_tel=" + bur_tel;
    
    xhr.send(params);

 }

 function readUpdateBureauData(oData,form) {
  //alert("read Data!");
  var entrType=getFieldValue(form,"entr_regie");
  var entrForm=getFieldValue(form,"main_form");
  //var refCount=getFieldValue(form,"ref_count");

  var nodes=oData.getElementsByTagName("item");
  var msg=nodes[0].getAttribute("msg").toString();
  var cle=nodes[0].getAttribute("cle").toString();
  if (nodes[0].getAttribute("code").toString()=="0") {
    alert("Bureau mis à jour avec succès!");
    optsName="fa_"+((entrType=="regie")?"regie_":"")+"bureau_cle";
    //alert(entrType+" - "+optsName);
    opts=getElt(entrForm).elements.namedItem(optsName).options;
    
    opts[0]=new Option(msg.substr(5),
                          cle,true,true);
    showHideModal('updateBureau_div');
  } else {
    alert("Erreur : "+nodes[0].getAttribute("msg").toString());
    }
 }

 function updateBureau(formName,entr_regie)
{
    //alert(entr_regie+' - regie - '+getOptionCle(formName,'fa_regie_bureau_cle'));
    //alert(entr_regie+' - entr - '+getOptionCle(formName,'fa_bureau_cle'));
    if((entr_regie=='regie' && getOptionCle(formName,'fa_regie_bureau_cle').length>0) ||
      (entr_regie=='entr' && getOptionCle(formName,'fa_bureau_cle').length>0))
    {

        selectEntr=(entr_regie=="regie")?getElt(formName).fa_regie_bureau_cle:
                                          getElt(formName).fa_bureau_cle;
        getElt("nom_div_bureau_update").innerHTML=selectEntr.options[selectEntr.selectedIndex].label;
        //alert("bureauCle");
        setFieldValue("updateBureau","bur_cle",selectEntr.options[selectEntr.selectedIndex].value);
        setFieldValue("updateBureau","main_form",formName);
        setFieldValue("updateBureau","entr_regie",entr_regie);
        showHideModal('updateBureau_div');
        return "#";
    }
    else
    {
        alert("Veuillez sélectionner une entreprise!");
        return "#";
    }
}