<?php
// Ajout class de gestion des referents du 10/05/2012 JTA
header("Content-Type: text/xml");

require_once '../secure/auth.php';

if (!hasRole(PROF_ROLE) && !hasRole(STUD_ROLE))
    redirectAuth(null);


require_once '../html/utils.php';
require_once '../html/dbutils.php';
require_once '../dbmngt/inscrire.php';
echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";


$conn = doConnection();
$entreprise = trim(getParam("entr_cle", ""));
$entrepriseNom = trim(getParam("entr_nom", ""));
$ref_nom = trim(getParam("ref_nom", ""));
$ref_prenom = trim(getParam("ref_prenom", ""));
$ref_email = trim(getParam("ref_email", ""));
$ref_tel = trim(getParam("ref_tel", ""));
$ref_fonction = trim(getParam("ref_fonction", ""));
$ref_bureau = trim(getParam("ref_bureau", ""));

$err_msg = faireInscrireReferent(
                            $ref_nom, $ref_prenom, $ref_email, $ref_tel, $ref_fonction, $ref_bureau, $entreprise
           );

echo "<list><item code=\"".($err_msg[0]=='N'?1:0)."\" msg=\"".$err_msg."\" ></item></list>";
error_log ("<list><item code=\"".($err_msg[0]=='N'?1:0)."\" msg=\"".$err_msg."\" ></item></list>");
?>
