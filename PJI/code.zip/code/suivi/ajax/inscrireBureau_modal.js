/* Déclaration des variables globales */ 
 var geocoder = new google.maps.Geocoder();
 var addr, latitude, longitude;
var map;
function generateInscrireBureauForm() {
    document.write("<div id='inscrireBureau_div' style='visibility:hidden;position:absolute;width:100%;textalign:center;zIndex:1000;left:200;background-color:rgba(100,100,100,1);' >\n\
                <form id='inscrireBureau' action='#' method='POST'> "+
            "<input type='hidden' name='entr_cle' value='default'/>"+
            "<input type='hidden' name='entr_regie' value='entr'/>"+
            "<input type='hidden' name='entr_nom' value='default'/>"+
            "<input type='hidden' name='main_form' value='form0'/>"+
            "<input type='hidden' name='source_page' value=''/>"+
            "<input type='hidden' name='source_recno' value=''/>"+
            "<h2>Inscrire un nouveau bureau pour l'entreprise : \n\
              <div id='nom_div_bureau'>Default</div></h2> \n\
            <table style=\"float: left\" witdh='300'>"+'\n\
                <tr>\n\
                    <td>\n\
                        Adresse *: \n\
                    </td>\n\
                    <td>\n\
                        <input type="text" id="Idadresse" name="bur_adresse" value=""/>\n\
                    </td>\n\
                </tr>\n\
                <tr>\n\
                    <td>\n\
                        Ville *:\n\
                    </td>\n\
                    <td>\n\
                        <input type="text" id="Idville" name="bur_ville" value=""/>\n\
                    </td>\n\
                </tr>\n\
				         <tr>\n\
                    <td>\n\
                        Code Postal *:\n\
                    </td>\n\
                    <td>\n\
                        <input type="text"  id="Idpostal" name="bur_cp" value=""/>\n\
                    </td>\n\
                </tr><tr>\n\
                    <td>\n\
                        Latitude :\n\
                    </td>\n\
                    <td>\n\ <input type="text" id="lat" name="latitude" value="" disabled />\n\</td>\n\
                </tr>\n\
				<tr>\n\
                    <td>\n\
                        Longitude :\n\
                    </td>\n\
                    <td>\n\ <input type="text" id="lng" name="longitude" value="" disabled />\n\</td>\n\
                </tr>\n\
       			<tr>\n\
                    <td>\n\
                        Téléphone :\n\
                    </td>\n\
                    <td>\n\
                        <input type="text" name="bur_tel" value=""/>\n\
                    </td>\n\
                </tr>\n\
                <tr> \n\
                    <td>\n\
                        * Champ obligatoire \n\
                    </td> \n'+
                    "<td><table width='100%'><tr> \n\
                        <td><input type='button' style='color:red' name='cancel' value='Annuler' onClick='javascript:showHideModal(\"inscrireBureau_div\")'/>\n\
                        </td><td><input type='button' style='color:orange' name='inscrire' \n\
                                onClick='javascript:\n\
                                            faireInscrireBureau(\"inscrireBureau\");' \n\
                                 value='Inscrire'/> \n\
                        </td></tr> \n\
						<tr><td><input type='button' style='color:orange'  name='verifier' \n\
                                onClick='javascript:\n\
                                            geolocalise();' \n\
                                 value='vérifier'/> \n\
                        </td><td></td></tr> \n\
                        </table> \n\
                    </td> \n\
                </tr> \n\
            </table> \n\
        <div  id=\"carte\" style=\"width:50%; float: right; height:40%\"></div> \n\
		<script type=\"text/javascript\">initialiser(50.6371834, 3.063017400000035);</script>\n\
		<div  id=\"answer\" style=\"width:50%; height:20%\"></div> </div></form>");
	        
	doModal('inscrireBureau_div');
		
 }
 

 /* Fonction chargée de géolocaliser l'adresse ajouté par an et se*/ 
 function geolocalise(){
  /* Récupération du champ "adresse" */ 
  addresse = document.getElementById('Idadresse').value;
  ville = document.getElementById('Idville').value; 
  postal = document.getElementById('Idpostal').value;
  addr = addresse+ " "+postal+ " "+ville;
   
  /* Tentative de géocodage */ 
  geocoder.geocode( { 'address': addr}, function(results, status) {
   /* Si géolocalisation réussie */ 
   if (status == google.maps.GeocoderStatus.OK) {
    /* Récupération des coordonnées */ 
    latitude = results[0].geometry.location.lat();
    longitude = results[0].geometry.location.lng();
    /* Insertion des coordonnées dans les input text */ 
    document.getElementById('lat').value = latitude;
    document.getElementById('lng').value = longitude;
	z=10;


initialiser(latitude,longitude,z);
}else alert(addr + " " +"ne correspond à aucune adresse.");
 });
}



//initialisation de la carte ajouté par an et se
 function initialiser(a,b) {
          var latLng = new google.maps.LatLng(a,b); // Correspond au coordonnées de Lille
	  var myOptions = {
	    zoom      : 14,
	    center    : latLng,
	    mapTypeId : google.maps.MapTypeId.TERRAIN, // Type de carte, différentes valeurs possible HYBRID, ROADMAP, SATELLITE, TERRAIN
	    maxZoom   : 20
	  };
	 
	  map      = new google.maps.Map(document.getElementById('carte'), myOptions);
	var marker = new google.maps.Marker({
	    position : latLng,
	    map      : map,
	    title    : "Lille"
	    //icon     : "marker_lille.gif"
	});
}


 function faireInscrireBureau(form) {
   var xhr=getXMLHttpRequest();
   xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            if (getFieldValue("inscrireBureau","source_page")=="interface/importCandidatures_act")
              readInscrireBureauDataImportCandidatures(xhr.responseXML,form);
            else
              readInscrireBureauData(xhr.responseXML,form);
        }
    };

    xhr.open("POST", "ajax/faireInscrireBureau.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
     params="";
    //alert("submit Data!");

    entr_cle=getFieldValue(form,'entr_cle');
    if (entr_cle.length>0)
        params="entr_cle=" + entr_cle;
    
    bur_adresse=getFieldValue(form,'bur_adresse');
    //alert(bur_adresse);
    if (bur_adresse.length>0)
        params+="&bur_adresse=" + bur_adresse;

    bur_ville=getFieldValue(form,'bur_ville');
    //alert(bur_ville);
    if (bur_ville.length>0)
        params+="&bur_ville=" + bur_ville;

    bur_cp=getFieldValue(form,'bur_cp');
    //alert(bur_cp);
    if (bur_cp.length>0)
      params+="&bur_cp=" + bur_cp;

    bur_tel=getFieldValue(form,'bur_tel');
    //alert(bur_tel);
    if (bur_tel.length>0)
      params+="&bur_tel=" + bur_tel;

    //ajout des deux champs latitude et longitude ajouté par an et se
	latitude=getFieldValue(form,'latitude');
	if (latitude.length>0)
      params+="&latitude=" + latitude;
   
	longitude=getFieldValue(form,'longitude');
	if (longitude.length>0)
      params+="&longitude=" + longitude;

    xhr.send(params);

 }

 function readInscrireBureauData(oData,form) {
  var entrType=getFieldValue(form,"entr_regie");
  var entrForm=getFieldValue(form,"main_form");
  //var refCount=getFieldValue(form,"ref_count");

  var nodes=oData.getElementsByTagName("item");
  var msg=nodes[0].getAttribute("msg").toString();
  if (nodes[0].getAttribute("code").toString()=="0") {
    alert("Bureau inscrit avec succès!");
    optsName="fa_"+((entrType=="regie")?"regie_":"")+"bureau_cle";
    opts=getElt(entrForm).elements.namedItem(optsName).options;
    opts.length+=1;
    opts[opts.length-1]=new Option(msg.substr(5),
                          msg.substr(5),false,true);
    showCoords(optsName);

    showHideModal('inscrireBureau_div');
  } else {
    alert("Erreur : "+nodes[0].getAttribute("msg").toString());
    }
 }

 function readInscrireBureauDataImportCandidatures(oData,form) {
  var entrForm=getFieldValue(form,"main_form");
  //var refCount=getFieldValue(form,"ref_count");

  var nodes=oData.getElementsByTagName("item");
  var msg=nodes[0].getAttribute("msg").toString();
  //alert("reponse : "+msg);
  if (nodes[0].getAttribute("code").toString()=="0") {
    elts=getElt(entrForm).elements;
    for (i=0;i<elts.length;i++) {
      if (elts[i].name.substr(0,"fa_bureau_cle_".length)=="fa_bureau_cle_" &&
        elts.namedItem(elts[i].name.replace("bureau","entreprise")).value==
          getFieldValue("inscrireBureau","entr_cle")) {
       opts=elts[i].options;
       opts.length+=1;
       opts[opts.length-1]=new Option(msg.substr(5),
                            msg.substr(5),false,false); 
      }
    }
    showHideModal('inscrireBureau_div');
    //alert('fa_bureau_cle_'+getFieldValue('inscrireBureau','source_recno'));
    selfield=elts.namedItem('fa_bureau_cle_'+getFieldValue('inscrireBureau','source_recno'));
    //alert(selfield);
    selfield.selectedIndex=selfield.options.length-1;
    //alert(selfield.onchange());
    alert("Bureau inscrit avec succès!");
  } else {
    alert("Erreur : "+nodes[0].getAttribute("msg").toString());
    }
 }

function getSelectedItemBureau(formName,entr_regie)
{
    if(entr_regie=='regie' && getOptionCle(formName,'fa_regie_cle')!='SANS ENTREPRISE' ||
      entr_regie=='entr' && getOptionCle(formName,'fa_entreprise_cle')!='SANS ENTREPRISE')
    {

        selectEntr=(entr_regie=="regie")?getElt(formName).fa_regie_cle:
                                          getElt(formName).fa_entreprise_cle;
        getElt("nom_div_bureau").innerHTML=selectEntr.options[selectEntr.selectedIndex].label;
        setFieldValue("inscrireBureau","entr_cle",selectEntr.options[selectEntr.selectedIndex].value);
        setFieldValue("inscrireBureau","main_form",formName);
        setFieldValue("inscrireBureau","entr_regie",entr_regie);
        showHideModal('inscrireBureau_div');
        return "#";
    }
    else
    {
        alert("Veuillez sélectionner une entreprise!");
        return "#";
    }
}

function inscrireBureauImportCandidatures(form,adr,page,idx) {
  selectEntr=getElt(form).elements.namedItem("fa_entreprise_cle_"+idx);
  getElt("nom_div_bureau").innerHTML=selectEntr.options[selectEntr.selectedIndex].label;
  setFieldValue("inscrireBureau","entr_cle",selectEntr.options[selectEntr.selectedIndex].value);
  setFieldValue("inscrireBureau","main_form",form);
  setFieldValue('inscrireBureau','bur_adresse',adr);
  setFieldValue('inscrireBureau','bur_ville',adr);
  alert(page);
  setFieldValue('inscrireBureau','source_page',page);
  setFieldValue('inscrireBureau','source_recno',idx);
  showHideModal('inscrireBureau_div');
}
