<?php
// Ajout class de gestion des referents du 10/05/2012 JTA
header("Content-Type: text/xml");

require_once '../secure/auth.php';

if (!hasRole(PROF_ROLE) && !hasRole(STUD_ROLE))
    redirectAuth(null);


require_once '../html/utils.php';
require_once '../html/dbutils.php';
require_once '../dbmngt/update.php';
echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";


$conn = doConnection();
$bur_cle = trim(getParam("bur_cle", ""));
$bur_adresse = trim(getParam("bur_adresse", ""));
$bur_tel = trim(getParam("bur_tel", ""));
$bur_ville = trim(getParam("bur_ville", ""));
$bur_cp = trim(getParam("bur_cp", ""));

$err_msg = faireUpdateBureau(
                                $bur_cle,$bur_adresse, $bur_tel, $bur_ville, $bur_cp
                        );

echo "<list><item code=\"".($err_msg[0]=='N'?1:0)."\" msg=\"".$err_msg."\" cle=\"".$bur_cle."\"></item></list>";
error_log ("<list><item code=\"".($err_msg[0]=='N'?1:0)."\" msg=\"".$err_msg."\" cle=\"".$bur_cle."\"></item></list>");
?>
