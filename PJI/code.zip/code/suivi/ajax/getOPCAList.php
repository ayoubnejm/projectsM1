<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once ("../config/main.ini.php");

require_once (ABS_START_PATH."/dbmngt/queries.php");
//Auteur JTA
header("Content-Type: text/xml");
require_once ABS_START_PATH.'/dbmngt/connect.php';
echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
echo "<list>\n";

    $conn = doConnection();
    $result = doQueryListOPCA($conn);
    $row = mysql_fetch_row($result);

    while ($row)
    {
        echo "\t<item id=\"opca\" name=\"" . $row[0] . "\" value=\"".$row[1]."\" />\n";
        $row = mysql_fetch_row($result);
    }

echo "</list>";
?>
