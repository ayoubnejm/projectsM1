function generateInscrireReferentForm() {
    document.write("<div id='inscrireReferent_div' style='visibility:hidden;position:absolute;width:100%;textalign:center;zIndex:1000;left:200;background-color:rgba(100,100,100,1);' >\n\
                <form id='inscrireReferent' action='#' method='POST'> "+
            "<input type='hidden' name='entr_cle' value='default'/>"+
            "<input type='hidden' name='ref_count' value='1'/>"+
            "<input type='hidden' name='entr_regie' value='entr'/>"+
            "<input type='hidden' name='entr_nom' value='default'/>"+
            "<input type='hidden' name='main_form' value='form0'/>"+
            "<input type='hidden' name='source_page' value=''/>"+
            "<input type='hidden' name='source_recno' value=''/>"+
            "<h2>Inscrire un nouveau référent pour l'entreprise : \n\
              <div id='nom_div'>Default</div></h2> \n\
            <table witdh='500'>"+
                "<tr><td>Nom *:</td><td><input type='text' name='ref_nom' value=''/></td></tr>"+
                "<tr><td>Prenom *:</td><td><input type='text' name='ref_prenom' value=''/></td></tr>"+
                "<tr><td>Email *:</td><td><input type='text' name='ref_email' value=''/></td></tr>"+
                "<tr><td>Téléphone *:</td><td><input type='text' name='ref_tel' value=''/></td></tr>"+
                "<tr><td>Fonction *:</td><td><input type='text' name='ref_fonction' value=''/></td></tr>"+

                "<tr> \n\
                    <td> \n\
                        Bureau : \n\
                    </td> \n\
                    <td> \n\
                        <select name='ref_bureau'/> \n\
                        <br/><a target='main' href='../interface/inscrireBureau.php?entr_cle=' . $entreprise . '.&entr_nom=' . $entrepriseNom . ''/>saisir Bureau</a>'; \n\
                    </td> \n\
                </tr> \n\
                <tr> \n\
                    <td>\n\
                        * Champ obligatoire \n\
                    </td> \n\
                    <td><table width='100%'> \n\
                        <td><input type='button' style='color:red' name='cancel' value='Annuler' onClick='javascript:showHideModal(\"inscrireReferent_div\")'/>\n\
                        </td><td><input type='button' style='color:orange' name='inscrire' \n\
                                onClick='javascript:\n\
                                            faireInscrireReferent(\"inscrireReferent\");' \n\
                                 value='Inscrire'/> \n\
                        </td> \n\
                        </td></tr> \n\
                        </table> \n\
                    </td> \n\
                </tr> \n\
            </table> \n\
        </form></div>");
        doModal('inscrireReferent_div');
 }

 function faireInscrireReferent(form) {
   var xhr=getXMLHttpRequest();
   xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            if (getFieldValue("inscrireReferent","source_page")=="interface/importCandidatures_act")
              readInscrireReferentDataImportCandidatures(xhr.responseXML,form);
            else
              readInscrireReferentData(xhr.responseXML,form);
        }
    };

    xhr.open("POST", "ajax/faireInscrireReferent.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
     params="";
    //alert("submit Data!");

    entr_cle=getFieldValue(form,'entr_cle');
    if (entr_cle.length>0)
        params="entr_cle=" + entr_cle;
    
    ref_nom=getFieldValue(form,'ref_nom');
    //alert(ref_nom);
    if (ref_nom.length>0)
        params+="&ref_nom=" + ref_nom;

    ref_prenom=getFieldValue(form,'ref_prenom');
    //alert(ref_prenom);
    if (ref_prenom.length>0)
        params+="&ref_prenom=" + ref_prenom;

    ref_email=getFieldValue(form,'ref_email');
    //alert(ref_email);
    if (ref_email.length>0)
      params+="&ref_email=" + ref_email;

    ref_tel=getFieldValue(form,'ref_tel');
    //alert(ref_tel);
    if (ref_tel.length>0)
      params+="&ref_tel=" + ref_tel;

    ref_fonction=getFieldValue(form,'ref_fonction');
    //alert(ref_fonction);
    if (ref_fonction.length>0)
      params+="&ref_fonction=" + ref_fonction;
    
    ref_bureau=getOptionCle(form,'ref_bureau');
    //alert(ref_bureau);
    if (ref_bureau.length>0)
      params+="&ref_bureau=" + ref_bureau;
    
    xhr.send(params);

 }

 function readInscrireReferentDataImportCandidatures(oData,form) {
  var entrType=getFieldValue(form,"entr_regie");
  var entrForm=getFieldValue(form,"main_form");
  
  var nodes=oData.getElementsByTagName("item");
  var msg=nodes[0].getAttribute("msg").toString();
  if (nodes[0].getAttribute("code").toString()=="0") {
    elts=getElt(entrForm).elements;
    for (i=0;i<elts.length;i++) {
      if (elts[i].name.substr(0,"fa_referent_cle_".length)=="fa_referent_cle_" &&
        elts.namedItem(elts[i].name.replace("referent","entreprise")).value==
          getFieldValue("inscrireReferent","entr_cle")) {
       opts=elts[i].options;
       opts.length+=1;
       opts[opts.length-1]=new Option(msg.substr(5),
                            msg.substr(5),false,false);
      }
    }
    showHideModal('inscrireReferent_div');
    //alert('fa_referent_cle_'+getFieldValue('inscrireReferent','source_recno'));
    selfield=elts.namedItem('fa_referent_cle_'+getFieldValue('inscrireReferent','source_recno'));
    //alert(selfield);
    selfield.selectedIndex=selfield.options.length-1;
    //alert(selfield.onchange());
    alert("Réferent inscrit avec succès!");

    /*
    //alert("Référent inscrit avec succès!");
    optsName="fa_"+((entrType=="regie")?"regie_":"")+"referent_cle";
    //alert(entrType+" - "+optsName);
    opts=getElt(entrForm).elements.namedItem(optsName).options;
    opts.length+=1;
    opts[opts.length-1]=new Option(getFieldValue(form,"ref_prenom")+" "+getFieldValue(form,"ref_nom"),
                          msg.substr(5),refCount==1,refCount==1);
    optsName="fa_"+((entrType=="regie")?"regie_":"")+"referent2_cle";
    opts=getElt(entrForm).elements.namedItem(optsName).options;
    opts.length+=1;
    opts[opts.length-1]=new Option(getFieldValue(form,"ref_prenom")+" "+getFieldValue(form,"ref_nom"),
                          msg.substr(5),refCount==2,refCount==2);
    showHideModal('inscrireReferent_div');*/
  } else {
    alert("Erreur : "+nodes[0].getAttribute("msg").toString());
    //getElt('inscrireReferent_err').innerHTML="Erreur : "+nodes[0].getAttribute("msg").toString();
  }
 }

 function readInscrireReferentData(oData,form) {
  //alert("read Data!");
  var entrType=getFieldValue(form,"entr_regie");
  var entrForm=getFieldValue(form,"main_form");
  var refCount=getFieldValue(form,"ref_count");

  var nodes=oData.getElementsByTagName("item");
  var msg=nodes[0].getAttribute("msg").toString();
  if (nodes[0].getAttribute("code").toString()=="0") {
    alert("Référent inscrit avec succès!");
    optsName="fa_"+((entrType=="regie")?"regie_":"")+"referent_cle";
    //alert(entrType+" - "+optsName);
    opts=getElt(entrForm).elements.namedItem(optsName).options;
    opts.length+=1;
    opts[opts.length-1]=new Option(getFieldValue(form,"ref_prenom")+" "+getFieldValue(form,"ref_nom"),
                          msg.substr(5),refCount==1,refCount==1);
    optsName="fa_"+((entrType=="regie")?"regie_":"")+"referent2_cle";
    opts=getElt(entrForm).elements.namedItem(optsName).options;
    opts.length+=1;
    opts[opts.length-1]=new Option(getFieldValue(form,"ref_prenom")+" "+getFieldValue(form,"ref_nom"),
                          msg.substr(5),refCount==2,refCount==2);
    showHideModal('inscrireReferent_div');
  } else {
    alert("Erreur : "+nodes[0].getAttribute("msg").toString());
    //getElt('inscrireReferent_err').innerHTML="Erreur : "+nodes[0].getAttribute("msg").toString();
  }
 }

 function inscrireReferent(formName,entr_regie,refCount)
{

    if(entr_regie=='regie' && getOptionCle(formName,'fa_regie_cle')!='SANS ENTREPRISE' ||
      entr_regie=='entr' && getOptionCle(formName,'fa_entreprise_cle')!='SANS ENTREPRISE')
    {
        optsDst=getElt('inscrireReferent').elements.namedItem("ref_bureau").options;
        optsSrc=(entr_regie=="regie")?getElt(formName).elements.namedItem("fa_regie_bureau_cle").options:
                                        getElt(formName).elements.namedItem("fa_bureau_cle").options;
        //alert(optsSrc.length);
        //alert(optsDst.length);
        optsDst.length=optsSrc.length;
        var i=0;
        for (i=0;i<optsDst.length;i++)
            optsDst[i]=new Option(optsSrc[i].label,optsSrc[i].value);
        selectEntr=(entr_regie=="regie")?getElt(formName).fa_regie_cle:
                                          getElt(formName).fa_entreprise_cle;
        getElt("nom_div").innerHTML=selectEntr.options[selectEntr.selectedIndex].label;
        setFieldValue("inscrireReferent","ref_count",refCount);
        setFieldValue("inscrireReferent","main_form",formName);
        setFieldValue("inscrireReferent","entr_regie",entr_regie);
        setFieldValue("inscrireReferent","entr_cle",selectEntr.options[selectEntr.selectedIndex].value);
        showHideModal('inscrireReferent_div');
        return "#";//return "../interface/inscrireReferent.php?entr_cle="+fa_regie_cle+"&entr_nom="+fa_regie_nom;
    }
    else
    {
        alert("Veuillez sélectionner une entreprise!");
        return "#";
    }
}

function inscrireReferentImportCandidatures(form,nomprenom,email,tel,fonction,page,idx) {
  selectEntr=getElt(form).elements.namedItem("fa_entreprise_cle_"+idx);
  getElt("nom_div").innerHTML=selectEntr.options[selectEntr.selectedIndex].label;

  optsDst=getElt('inscrireReferent').elements.namedItem("ref_bureau").options;
  optsSrc=getElt(form).elements.namedItem("fa_bureau_cle_"+idx);

  optsDst.length=optsSrc.length;
  var i=0;
  for (i=0;i<optsDst.length;i++)
      optsDst[i]=new Option(optsSrc[i].label,optsSrc[i].value);


  setFieldValue("inscrireReferent","entr_cle",selectEntr.options[selectEntr.selectedIndex].value);
  setFieldValue("inscrireReferent","main_form",form);

  setFieldValue('inscrireReferent','ref_nom',nomprenom);
  setFieldValue('inscrireReferent','ref_prenom',nomprenom);
  setFieldValue('inscrireReferent','ref_email',email);
  setFieldValue('inscrireReferent','ref_tel',tel);
  setFieldValue('inscrireReferent','ref_fonction',fonction);
  
  setFieldValue('inscrireReferent','source_page',page);
  setFieldValue('inscrireReferent','source_recno',idx);
  showHideModal('inscrireReferent_div');
}