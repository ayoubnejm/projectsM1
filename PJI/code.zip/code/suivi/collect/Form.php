<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Informations concernant votre inscription en FA</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <?php
            include ("../html/utils.php");
        // put your code here
        ?>
        <h2>Notice explicative</h2>
        Les informations, que nous vous demandons de remplir,  feront partie de votre livret d'alternance électronique... <br/>
        .. Que nous expérimentons cette année. Soyez donc indulgents en cas de problème :) .<br/>
        <br/>
        Dans un premier temps, ces informations vont servir à faciliter l'attribution des tuteurs (tuteurs universitaire et référents en entreprise).<br/>
        Essayez de nous fournir le plus rapidement possible, au moins, les informations concernant votre mission (lieu, descriptif) et votre réferent en entreprise.<br/>
        <br/>
        Nous vous remercions de votre participation. En cas de problème envoyer un mail à <a href="mailto:marius.bilasco@lifl.fr">cette @</a>!<br/>
        
        <form method="post" action="CollectData.php">
        <div id="vous">
            <h2> Vous ...</h2>
            <table>
                <tr>
                    <td>Login (Webmail) Univ Lille 1 </td><td> <input type="text" maxlength="50" name="fa_etudiant_id_ustl"/></td>
                    <td colspan="2"> - <i> pour l'ouverture d'accès à l'application de suivi</i></td>
                </tr>
                <tr>
                    <td>Nom</td><td> <input type="text" maxlength="50" name="fa_etudiant_nom"/></td>
                    <td>Prenom</td><td> <input type="text" maxlength="30" name="fa_etudiant_prenom"/></td>
                </tr>
                <tr>
                    <td>Télephone</td><td><input type="text" maxlength="15" name="fa_etudiant_tel"/></td>
                    <td>Mail</td><td><input type="text" size="20" maxlength="50" name="fa_etudiant_email"/></td>
                </tr>
                <tr>
                    <td>Formation</td>
                    <td>
                        <?php
                           $keys=array("NONE","M1MIAGEFA1","M2MIAGEFA1","M1INFOFA1", "M2IAGLFA1","M2ESERVFA1", "M2TIIRFA1", "M2IVIFA1", "M2MOCADFA1");
                           $values=array("Choisir formation","M1 MIAGE FA","M2 MIAGE FA","M1 INFO FA","M2 IAGL FA","M2 E-SERV FA","M2 TIIR FA", "M2 IVI FA","M2 MOCAD FA" );
                           createSelect("fa_etudiant_groupeRef",$keys,$values,0);
                        ?>
                    </td>
                </tr>
            </table>
        </div>

        <div id="entreprise">
            <h2>L'entreprise et votre référent en entreprise...</h2>
            <table>
                <tr>
                    <td>Nom entreprise</td><td><input type="text" name="fa_entreprise_nom" maxlength="50"/>
                    <td>Ville (lieu de la mission)</td><td><input type="text" name="fa_referent_ville" maxlength="50"/>
                </tr>
                <tr>
                    <td>Nom référent</td><td> <input type="text" maxlength="50" name="fa_referent_nom"/></td>
                    <td>Prenom référent</td><td> <input type="text" maxlength="30" name="fa_referent_prenom"/></td>
                </tr>
                <tr>
                    <td>Télephone référent</td><td><input type="text" maxlength="15" name="fa_referent_tel"/></td>
                    <td>Mail référent</td><td><input type="text" size="20" maxlength="50" name="fa_referent_email"/></td>
                </tr>
            </table>
        </div>

        <div id="missions">
            <h2>Vos missions ...</h2>
            <table>
                <tr>
                    <td>Mots clés (5 max)<br/>
                        <input type="text" name="fa_etapeet_motscles" size="60"/></td>

                </tr>
                <tr>
                    <td>Service/Projet<br/><textarea name="fa_etapeet_service" row="3" cols="50"></textarea>
                </tr>
                <tr>
                <td>Client eventuel<br/><input type="text" name="fa_etapeet_client" maxlength="50"/>
                </tr>
                <tr>
                    <td>Résumé de vos missions (5 lignes)<br/>
                        <textarea rows="6" cols="60" name="fa_etapeet_missions"></textarea></td>
                </tr><tr>
                    <td>Description de  l'environnement technique (5 lignes)<br/>
                        <textarea rows="6" cols="60" name="fa_etapeet_environnementTechnique"></textarea></td>

                </tr>
            </table>
        </div>

        <div id="contrat">
            <h2>Votre contrat ...</h2>
            <table>
                <tr>
                    <td>OPCA</td><td><input type="text" maxlength="20" name="fa_opca_name"/></td>
                </tr>
                <tr>
                    <td>Date signature contrat</td><td><input type="text" value="jj/mm/aaaa" name="fa_alternace_signatureContrat" maxlength="50"/>
                    <td>Date accord OPCA</td><td><input type="text" value="jj/mm/aaaa" name="contrat_accordOPCA" maxlength="50"/>
                </tr>
                <tr>
                    <td>Debut contrat</td><td> <input type="text" value="jj/mm/aaaa" maxlength="50" name="contrat_debutContrat"/></td>
                    <td>Fin contrat</td><td> <input type="text" value="jj/mm/aaaa" maxlength="30" name="contrat_finContrat"/></td>
                </tr>
            </table>
        </div>

            <input type="submit" value="Envoyer"/>
        </form>
    </body>
</html>
