<?php
    require_once 'secure/auth.php';

    if (!isset($_SESSION[CK_USER]) || strlen($_SESSION[CK_USER])==0) {
      $service = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
      authenticate($service);
    }

    $doRolesUpdate=false;
    $CURR_YEAR=getCurrYear();
    $refYear=getParam(REF_YEAR,$CURR_YEAR);
    if (!isset($_SESSION[REF_YEAR])|| ($_SESSION[REF_YEAR]!=$refYear))
      $doRolesUpdate=true;
    $_SESSION[REF_YEAR]=$refYear;

    $refFormationRef=getParam(REF_FORMATIONTYPE,"FA/FI");
    if (!isset($_SESSION[REF_FORMATIONTYPE])|| ($_SESSION[REF_FORMATIONTYPE]!=$refFormationRef))
      $doRolesUpdate=true;

    $_SESSION[REF_FORMATIONTYPE]=$refFormationRef;
    if ($doRolesUpdate==true)
    {
      checkAllRoles();
    }
    //echo "ref formation type ",$refFormationRef," ",strcmp($refFormationRef,"FA")==0?0:1," ",date("Y-n-d-m-s");

    
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Menu Stages & Alternances au FIL IEEA U. Lille 1</title>
        <link rel="shortcut icon" type="image/x-icon" href="http://fil.univ-lille1.fr/digitalAssets/4/4420_favicon.ico" />
        <link href="http://www.fil.univ-lille1.fr/portail/css/fil-screen.css" media="screen" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/tableSort.css" type="text/css" media="print, projection, screen" />
    
        <?php if (isset($_REQUEST["action"]) && $_REQUEST["action"]=="actions/genererOrdreDeMissions_act") {
            error_log("SPECIFIC SHEET ");
            ?>
        
        <style type="text/css">
            fieldset { border:1px; width:480px;}
            table {font-size:12px}
            .prev, .next { background-color:#b0232a; padding:5px 10px; color:#fff; text-decoration:none;}
            .prev:hover, .next:hover { background-color:#000; text-decoration:none;}
            .prev { float:left;}
            .next { float:right;}
            legend {font-size:24px;font-style:bold;}
            #steps { list-style:none; width:100%; overflow:hidden; margin:0px; padding:0px;}
            #steps li {font-size:24px; float:left; padding:10px; color:#b0b1b3;}
            #steps li span {font-size:11px; display:block;}
            #steps li.current { color:#000;}
            #makeWizard { background-color:#b0232a; color:#fff; padding:5px 10px; text-decoration:none; font-size:18px;}
            #makeWizard:hover { background-color:#000;}
        </style>
        <?php } ?><!--MOdification  -->
			<!--Modification pour l'api google maps-->			 
			<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
	         <!--Modification pour table dynamique ajouté par an et se -->    
			<script type="text/javascript" src="js/jquery-latest.js"></script>
			<script type="text/javascript" src="js/jquery.tablesorter.js"></script>
			<script type="text/javascript" id="js">$(document).ready(function() {
		$("#tableau_triable").tablesorter({
		sortList: [[0,0]]
		// pass the headers argument and assing a object
	
	});
});</script>
    </head>
    <body>
        <?php $page=getParam("page","interface/welcome_act");
              $_SESSION[MODE]=getParam("mode",isset($_SESSION[MODE])?$_SESSION[MODE]:"tut");
        ?>
      <?php require_once ABS_START_PATH."/main/filHeader.php" ?>
      <div id="principal">
      <?php require_once ABS_START_PATH."/main/mainTop.php" ?>
      
      <?php require_once ABS_START_PATH."/main/main.php" ?>

      <?php require_once ABS_START_PATH."/main/filFooter.php" ?>
      
      </div>

    </body>
</html>
