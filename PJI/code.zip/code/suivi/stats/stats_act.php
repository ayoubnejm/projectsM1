<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queries.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/dbutils.php");

      $conn=doConnection();

      $formation=getParam("formation","L3MIAGEFA");
      $_SESSION["formation"]=$formation;

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Statistiques</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>

</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>
      <h2>Statistiques / Formations</h2>
      <ul>
        <li>
          <a href="<?php echo ABS_START_URL; ?>/index.php?page=stats/repartitionParFormation_act">Nombre d'étudiants par formation</a>
        </li>
      </ul>
      <h2>Statistiques / Encadrement</h2>
      <ul>
        <li>
          <a href="<?php echo ABS_START_URL; ?>/index.php?page=stats/repartitionEncadrement_act">Repartition de l'éncadrement étudiants par tuteurs</a>
        </li><li>
          <a href="<?php echo ABS_START_URL; ?>/index.php?page=stats/besoinsEncadrement_act">Besoins en termes d'encadrement</a>
        </li>
      </ul>
      <h2>Statistiques / Entreprises</h2>
      <ul>
        <li>
          <a href="<?php echo ABS_START_URL; ?>/index.php?page=stats/repartitionParEntreprise_act">Repartition étudiants par entreprise</a>
        </li>
      </ul>
      <h2>Statistiques / OPCAs</h2>
      <ul>
        <li>
          <a href="<?php echo ABS_START_URL; ?>/index.php?page=stats/repartitionParOPCA_act">Repartition étudiants par OPCA</a>
        </li>
      </ul>
        </div>
        </div>