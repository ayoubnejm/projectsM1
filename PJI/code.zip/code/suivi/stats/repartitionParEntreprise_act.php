<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queries.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/dbutils.php");

      $conn=doConnection();

      $formation=getParam("formation","L3MIAGEFA");
      $_SESSION["formation"]=$formation;

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Statistiques</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>

</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>
        <?php
            require_once(ABS_START_PATH."/dbmngt/connect.php");
            require_once(ABS_START_PATH."/dbmngt/queriesStats.php");
            require_once(ABS_START_PATH."/html/utils.php");

            $conn=doConnection();
            $emails="";

            $keysValues=constructGrantedGroupesKeys();
            $formation=getParam("formation",$keysValues["keys"][0]);
            $_SESSION["formation"]=$formation;

            ?>
            <h1>Tableau de situation par entreprise étudiants</h1>

            <?php
              $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");
            ?>
        <table border="1">
                <thead><tr>
                        <!--td></td-->
                        <td>Nom entreprise</td>
                        <td>Nombre étudiants</td>
                       </tr>
                </thead>
                <tbody>
                    <?php
                    $i=0;
                    $divs="'head'";
                    $entrs=doQueryEtudiantsParEntreprises($conn,$formation);
                    $nbEntr=0;
                    $total=0;
                    $row=mysql_fetch_row($entrs);
                    while ($row)
                    {
                        echo "<tr>";
                        echo "<td>",$row[0],"</td>";
                        echo "<td align='center'>",$row[1],"</td>";
                        echo "</tr>";
                        $total+=$row[1];
                        $nbEntr++;

                        $row=mysql_fetch_row($entrs);
                        $i=$i+1;
                    }
                    echo "<tr height='4pt'/><tr>";
                        echo "<td> Total (",$nbEntr," entr.)</td>";
                        echo "<td align='center'>",$total,"</td>";
                        echo "</tr>";

                    ?>
                </tbody>
            </table>
    </div>
</div>