<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
function doQueryListe1eresVisitesPasSaisies($conn)
{
    $queryString="select '11ereVisiteEntreprise' as etape,
                          concat (concat(tut.prenom,' '),tut.nom) as nomTut,
                          tut.mail as tutMail,
                          concat(concat(etud.nom,' '),etud.prenom) as nomEtud,
                          etud.mail as etudMail,
                          etud.groupeRef as niveau
                  from contrat inner join etudiant etud on etudCle=contrat.etudRef
                       inner join membre tut on profCle=tuteurRef
                  where alternanceCle not in (select alternanceRef from etapevisite1
                                              where dateRencontre is not NULL)
               order by nomTut,niveau,nomEtud";

    $result=mysql_query($queryString,$conn);
    echo "querying ",$queryString,"<br/>",mysql_error();

    return $result;
}

function doQueryListeMissionsSoutPasSaisies($conn,$etudRef)
{
    $queryString="select '11ereVisiteEntreprise' as etape,
                          concat (concat(tut.prenom,' '),tut.nom) as nomTut,
                          tut.mail as tutMail,
                          concat(concat(etud.nom,' '),etud.prenom) as nomEtud,
                          etud.mail as etudMail,
                          eg.groupeRef as niveau
                  from contrat inner join etudiant etud on etudCle=contrat.etudRef
                       inner join membre tut on profCle=tuteurRef
                        inner join etudiant_groupe eg on eg.etudRef=contrat.etudRef and annee=anneeCle
                  where alternanceCle not in (select alternanceRef from etapemissionsout
                                              where dateRencontre is not NULL) ".
                       "and groupeRef not like 'M1MIAGEFA%'".
              "order by nomTut,niveau,nomEtud";

    $result=mysql_query($queryString,$conn);
    echo "querying ",$queryString,"<br/>",mysql_error();
    return $result;
}


function doQueryListeRencontresEtudiantPasSaisies($conn)
{
    $queryString="select '1rencontreEtudiant' as etape,
                          concat (concat(tut.prenom,' '),tut.nom) as nomTut,
                          tut.mail as tutMail,
                          concat(concat(etud.nom,' '),etud.prenom) as nomEtud,
                          etud.mail as etudMail,
                          eg.groupeRef as niveau
                  from contrat inner join etudiant etud on etudCle=contrat.etudRef
                       inner join membre tut on profCle=tuteurRef
                       inner join etudiant_groupe eg on eg.etudRef=contrat.etudRef and annee=anneeCle
                  where alternanceCle not in (select alternanceRef from etapeetudtut
                                              where dateRencontre is not NULL)
               order by nomTut,niveau,nomEtud";

    $result=mysql_query($queryString,$conn);
    echo "querying ",$queryString,"<br/>",mysql_error();
    return $result;
}
?>
