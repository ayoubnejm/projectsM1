<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

//ATTENTION cela ne supporte qu'un groupe pour l'instant

function doQueryListEtudiantsAMigrerParGroupe($conn, $groupeRef, $yearRef=null) {
    if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];
    $queryString = "select
        etudiant.nom,
        etudiant.prenom,
        eg.groupeRef,
        etudiant.etudCle
    from
      etudiant inner join etudiant_groupe eg on etudiant.etudCle=eg.etudRef
      where $yearRef=eg.annee and '".str_replace(",","1,",$groupeRef)."1' like concat('%',groupeRef,'%') and
          not exists (select * from etudiant_groupe eg2 where ".($yearRef+1)."=eg.annee and eg.etudRef=eg2.etudRef)
              order by etudiant.nom;";

    error_log("querying ".$queryString);
    error_log("error ");
    mysql_error($conn);
    $result = mysql_query($queryString, $conn);
    return $result;
}

?>
