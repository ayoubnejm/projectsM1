<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/config/main.ini.php");
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function doListeCandidatsAdmisParFormation($conn, $formation) {
  $queryString="select
                      nom,
                      prenom,
                      statut,
                      mail,
                      entr,
                      entrAddr,
                      concat(formation,'1'),
                      motscles,
                      ref,
                      refMail,
                      refTel,
                      refFonction,
                      tel
                from candidatures
                      
                where '".$formation."' like concat('%',formation,'%')
                      and decision like 'accept%'
                order by nom,prenom";

  $result = mysql_query($queryString, $conn);

  //echo "querying ",$queryString."<br/>".mysql_error($conn)."<br/>";

  return $result;
}

function doListeEtudiantsSelectionnesParFormation($conn, $altRefs) {
  $queryString="select
                      e.nom,
                      e.prenom,
                      'FI/FA-ignored',
                      e.mail,
                      b.entrepriseRef,
                      b.bureauCle,
                      eg.groupeRef,
                      NULL as motscles,
                      r.referentCle,
                      r.mail,
                      r.tel,
                      r.fonction,
                      e.tel,
                      e.etudCle,
                      c.tuteurRef
                from contrat c inner join etudiant_groupe eg on c.etudRef=eg.etudRef and c.anneeCle=eg.annee
                      inner join etudiant e on e.etudCle=c.etudRef
                      left join bureau b on bureauRef=b.bureauCle
                      left join referent r on referentCle=c.referentRef

                where c.alternanceCle in ($altRefs) order by e.nom,e.prenom";

  $result = mysql_query($queryString, $conn);

  //echo "querying ",$queryString."<br/>".mysql_error($conn)."<br/>";

  return $result;
}
?>
