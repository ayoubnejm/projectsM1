<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
function deleteFromEtudiantGroupe($annee,$etudRef,$conn,$debug=true) {
  $queryString = "delete from etudiant_groupe where annee=$annee ".
                            "and etudRef='".$etudRef."';";
  if ($debug) echo $queryString . "<br/>";
  mysql_query($queryString, $conn);
  if ($debug) echo mysql_error($conn);
  return mysql_errno($conn);
}

function deleteFromContrat($alternanceCle,$conn,$deleteEtapes=false,$debug=true) {
  if ($deleteEtapes) {
    $queryString = "delete from etapeechanges where alternanceRef='".$alternanceCle."';";

    if ($debug) echo $queryString . "<br/>";
    mysql_query($queryString, $conn);
    if ($debug) echo mysql_error($conn);
    if (mysql_errno($conn)!=0) return mysql_errno($conn);

    $queryString = "delete from etapeetudtut where alternanceRef='".$alternanceCle."';";
    if ($debug) echo $queryString . "<br/>";
    mysql_query($queryString, $conn);
    if ($debug) echo mysql_error($conn);
    if (mysql_errno($conn)!=0) return mysql_errno($conn);

    $queryString = "delete from etapemissionsout where alternanceRef='".$alternanceCle."';";
    if ($debug) echo $queryString . "<br/>";
    mysql_query($queryString, $conn);
    if ($debug) echo mysql_error($conn);
    if (mysql_errno($conn)!=0) return mysql_errno($conn);

    $queryString = "delete from etapesout where alternanceRef='".$alternanceCle."';";
    if ($debug) echo $queryString . "<br/>";
    mysql_query($queryString, $conn);
    if ($debug) echo mysql_error($conn);
    if (mysql_errno($conn)!=0) return mysql_errno($conn);

    $queryString = "delete from etapevisite1 where alternanceRef='".$alternanceCle."';";
    if ($debug) echo $queryString . "<br/>";
    mysql_query($queryString, $conn);
    if ($debug) echo mysql_error($conn);
    if (mysql_errno($conn)!=0) return mysql_errno($conn);

    $queryString = "delete from etapevisite2 where alternanceRef='".$alternanceCle."';";
    if ($debug) echo $queryString . "<br/>";
    mysql_query($queryString, $conn);
    if ($debug) echo mysql_error($conn);
    if (mysql_errno($conn)!=0) return mysql_errno($conn);

    $queryString = "delete from infoetud where alternanceRef='".$alternanceCle."';";
    if ($debug) echo $queryString . "<br/>";
    mysql_query($queryString, $conn);
    if ($debug) echo mysql_error($conn);
    if (mysql_errno($conn)!=0) return mysql_errno($conn);

    $queryString = "delete from temp_tuteurs where alternanceRef='".$alternanceCle."';";
    if ($debug) echo $queryString . "<br/>";
    mysql_query($queryString, $conn);
    if ($debug) echo mysql_error($conn);
    if (mysql_errno($conn)!=0) return mysql_errno($conn);
  }
  
  $queryString = "delete from contrat where alternanceCle='".$alternanceCle."';";
  echo $queryString . "<br/>";
  mysql_query($queryString, $conn);
  echo mysql_error($conn);

  return mysql_errno($conn);
}
?>
