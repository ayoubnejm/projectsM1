<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
function doQueryUpdateUID($oldUID,$uid,$mail=null,$conn)
{
  
    mysql_select_db("fil_dept",$conn);
    $updateQuery="set autocommit=0;";
    mysql_query($updateQuery,$conn);
    error_log($updateQuery." - ".mysql_error($conn));

    $updateQuery="update etudiant set etudCle='$uid'".(strlen($mail)?", mailLille1='$mail'":"")." where etudCle='$oldUID';";
    $res=!(!mysql_query($updateQuery,$conn));
    error_log($updateQuery." - ".mysql_error($conn));

    if ($res!=false) {
      $updateQuery="update etudiant_groupe set etudRef='$uid' where etudRef='$oldUID';";
      $res=$res && !(!mysql_query($updateQuery,$conn));
      error_log($updateQuery." - ".mysql_error($conn));
    }

    if ($res!=false) {
      mysql_select_db("stalt",$conn);
      $updateQuery="update contrat set etudRef='$uid' where etudRef='$oldUID';";
      $res=$res && !(!mysql_query($updateQuery,$conn));
      error_log($updateQuery." - ".mysql_error($conn));
    }

    if ($res!=false) {
      mysql_select_db("fil_dept",$conn);
      $updateQuery="delete from etudiant where etudCle='$oldUID';";
      $res=$res && !(!mysql_query($updateQuery,$conn));
      error_log($updateQuery." - ".mysql_error($conn));
    }

    if ($res!=false) {
      $updateQuery="delete from etudiant_groupe where etudRef='$oldUID';";
      $res=$res && !(!mysql_query($updateQuery,$conn));
       error_log($updateQuery." - ".mysql_error($conn));
    }

    if ($res!=false) {
      mysql_select_db("stalt",$conn);
      $updateQuery="delete from contrat where etudRef='$oldUID';";
      $res=$res && !(!mysql_query($updateQuery,$conn));
      error_log($updateQuery." - ".mysql_error($conn));
    }

    if ($res!=false) {
      $updateQuery="commit;";
      $res=$res && !(!mysql_query($updateQuery,$conn));
      error_log($updateQuery." - ".mysql_error($conn));
      return $res;
    } else {
      $updateQuery="rollback;";
      mysql_query($updateQuery,$conn);
      error_log($updateQuery." - ".mysql_error($conn));
      return $res;
    }
    
}

?>
