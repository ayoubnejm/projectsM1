<?php
require_once "../config/main.ini.php";

require_once (ABS_START_PATH."/dbmngt/queries.php");
//Auteur JTA
header("Content-Type: text/xml");
require_once ABS_START_PATH.'/dbmngt/connect.php';

echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
echo "<list>";

$fa_entreprise_cle = (isset($_POST["entrepriseCle"])) ? htmlentities($_POST["entrepriseCle"]) : NULL;

if ($fa_entreprise_cle) {
    $conn = doConnection();
    $result = doQueryListBureau($conn,$fa_entreprise_cle);
        
    $row = mysql_fetch_row($result);
    
    while ($row)
    {
        echo "<item id=\"bureau\" name=\"" . $row[0] . "\" value=\"".$row[1]."\" />";
        $row = mysql_fetch_row($result);
    }
    
    $result = doQueryListReferent($conn,$fa_entreprise_cle);
        
    $row = mysql_fetch_row($result);
    
    while ($row)
    {
        echo "<item id=\"referent\" name=\"" . $row[0] . "\" value=\"".$row[1]."\" />";
        $row = mysql_fetch_row($result);
    }
}

echo "</list>";
?>

