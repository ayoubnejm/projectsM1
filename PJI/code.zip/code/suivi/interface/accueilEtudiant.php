<?php
    require '../secure/auth.php';
    //error_log("accueilTuteur for ".getParam(CK_USER,"UNKOWNN"));

    if (!hasRole(STUD_ROLE))
        redirectAuth(null);
?>
<html>
     <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Etudiants</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
    </head>
    <frameset rows="45pt,*">
        <frame name="menu" src="menuEtudiant.php"/>
        <frame name="main" src="welcomeEtudiant.php"/>
    </frameset>
</html>