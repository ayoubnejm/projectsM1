<?php
require_once(ABS_START_PATH."/secure/auth.php");

if (!hasRole(RESP_ROLE))
    redirectAuth(null);

require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/dbmngt/queries.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once(ABS_START_PATH."/html/dbutils.php");

$selectString = generateSelectOption(
        array("aucune","majEtape0_act","mettreAJourMailLille1_act","majEtape1_act","majInfoMissionEtud_act",
                      "aucune","majEtape2_act","1ereVisitePrevue_act",
                      "aucune",
                      "majEtapeMissionSoutenance_act","missionSoutenancePrevue_act",
                      "aucune","majEtapeBilan_act","2emeVisitePrevue_act",
                      "aucune","priseContact_act","aucune","dissocierTuteur_act","aucune","migrerEtud_act","supprimerEtud_act"),
                    array("aucune","Maj fiche étudiant","Maj mail ULille1","Maj mission","Maj mission Etud",
                      "-----------------------------","Maj CR 1ere visite en entr.","<b>1ere visite<b/> prévue",
                      "-----------------------------","Maj mission soutenance","<b>Missions soutenance discutée</b>",
                      "-----------------------------","Maj CR 2eme visite en entr.","<b>2eme visite<b/> prévue",
                      "-----------------------------","Envoie mail prise de contact e.-t.",
                      "-----------------------------","Enlever tuteur",
                      "-----------------------------","Migrer/Changer formation étud.","Suppr. étud. de l'application"),0);


$formation = getParam("formation", "%");
$_SESSION["formation"] = $formation;

$tuteurParam = getParam("tuteurParam", "%");
$_SESSION["tuteurParam"] = $tuteurParam;

$situationEtud = getParam("situationEtud", "OUI");
$_SESSION["situationEtud"] = $situationEtud;

$conn = doConnection();

$emails = "";
?>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
<div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 5 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Tableau de situation des étudiants</a></div>
<div class="menuitem2" id="item_1"><a href="#" onclick="changeClass(this)">Emails étudiants ULille1</a></div>
<div class="menuitem2" id="item_2"><a href="#" onclick="changeClass(this)">Emails étudiants ULille1 + perso</a></div>
<div class="menuitem2" id="item_3"><a href="#" onclick="changeClass(this)">Emails étudinats perso</a></div>
<div class="menuitem2" id="item_4"><a href="#" onclick="changeClass(this)">Légende couleurs</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>      
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>
          <br/> <?php
            $keys = Array("TOUS",
                "AVEC_TUTEUR",
                //"AVEC_TUTEURP",
                "SANS_TUTEUR",
                //"SANS_TUTEURP",
                "AVEC_ENTR",
                "SANS_ENTR"
            );
            $values = Array("tous les étudiants",
                "les étudiants avec tuteur retenu",
                //"les étudiants avec tuteurs potentiels",
                "les étudiants sans tuteur retenu",
                //"les étudiants sans tuteurs potentiels",
                "les étudiants avec entreprise",
                "les étudiants sans entreprise");

            $keysValuesSituation=Array();
            $keysValuesSituation["keys"]=$keys;
            $keysValuesSituation["values"]=$values;
            $situationEtud=createSelectFormKeyValuesAndTargetPage("situationForm","situationEtud",$keysValuesSituation,$situationEtud,getParam("page"),"Situation des étudiants : ");

            ?>
           
        <?php
               //echo "Tuteur en mémoire", $tuteurParam;
                $tuteurs=doQueryListTuteurs($conn);
                $tuteur=mysql_fetch_row($tuteurs);
                $keysTut[0]="%";$valuesTut[0]="Tous";
                $tuteurNo=1;
                while ($tuteur)
                {
                    $keysTut[$tuteurNo]=$tuteur[0];
                    $valuesTut[$tuteurNo]=$tuteur[1]." ".$tuteur[2];
                    $tuteur=mysql_fetch_row($tuteurs);
                    $tuteurNo++;
                }
                $keysValuesTuteur=array();
                $keysValuesTuteur["keys"]=$keysTut;
                $keysValuesTuteur["values"]=$valuesTut;

                $tuteurParam=createSelectFormKeyValuesAndTargetPage("tuteurForm","tuteurParam",$keysValuesTuteur,$tuteurParam,getParam("page"),"Choisissez le tuteur : ");

         ?>


            <?php
            $keysValues=constructGrantedGroupesKeys();
            $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");

            ?>
         <form action="<?php echo ABS_START_URL;?>/index.php" method="post" id="actionForm">
          <input type="hidden" name="page" value="interface/faireActionsEtudiants_act"/>
            <?php
            $i = 0;
            $divs = "'head'";
//            TODO: adapt the query output
//              if ($situationEtud==="AVEC_TUTEUR")
//                $etudiants=doQueryListEtudiantsParTuteur($conn,$formation,$tuteurParam);
//            else
         
            $etudiants = doQueryListEtudiantsParFormation($conn, $formation);
            if (!mysql_num_rows($etudiants)) {
                echo "<h4 style='color:red'>Aucun étudiant</h4>";
                exit();
            }
            ?>

            <a onClick="javascript:checkAll('actionForm','selection[]',true);"><font style="color:blue; text-decoration:underline;">Tous</font></a>
            <a onClick="javascript:checkAll('actionForm','selection[]',false);"><font style="color:blue; text-decoration:underline;">Aucun</font></a>
  

     <table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1">
                <thead><tr>
                        <th></th>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Formation</th>
                        <th>Ville</th>
                        <th>Entreprise</th>
                        <th>Référent</th>
                        <th>Tuteur <br/> (nb. notifs)</th>
                        <th width="200pt"><div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">details</a--></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $missingMix = "";
                    $emailsULille1 = "";
                    $missingULille1 = "";
                    $emailsMix = "";
                    $missing ="";
                    do {

                        $row = mysql_fetch_row($etudiants);
                        if (!$row)
                            break;

                        $altCle = $row[0];
                        $tuteur = $row[15];

                        if ($tuteur !== $tuteurParam && $tuteurParam !== "%")
                            continue;

                        if ($situationEtud === "AVEC_TUTEUR"
                                && (strstr($tuteur, $tuteurParam) === FALSE && ($tuteurParam !== "%") || (strcmp($tuteur, "aucun") == 0)))
                            continue;
                        if ($situationEtud === "SANS_TUTEUR" && strcmp($tuteur, "aucun") != 0)
                            continue;

                        $entreprise = $row[9];


                        if ($situationEtud === "AVEC_ENTR" && $entreprise === "__sans entreprise__")
                            continue;
                        if ($situationEtud === "SANS_ENTR" && $entreprise !== "__sans entreprise__")
                            continue;

                        $et_pn = $row[2] . " " . $row[1];
                        if ($row[19]) {
                            $emails = $emails . ", " . $row[19];
                        } else {
                            $missing.=", " . $et_pn;
                        }
                        if ($row[22]) {                            
                            $emailsULille1.=", " . $row[22];
                        } else                            
                        $missingULille1.=", " . $et_pn;
                        if ($row[22]) {                            
                            $emailsMix.=", " . $row[22];
                        } else
                        if ($row[19]) {                            
                            $emailsMix.=", " . $row[19];
                        } else {                            
                            $missingMix.=", " . $et_pn;
                        }


                        $notifAttribTuteur = $row[21];
                        $nom = $row[1];
                        $prenom = $row[2];
                        $formation = $row[3];
                        $ville = $row[6];
                        $referent = $row[7];
                        $motscles = $row[16];

                        $missions = $row[10];
                        $services = $row[11];
                        $clients = $row[12];
                        $envTech = $row[13];

                        echo "<td><input type='checkbox' id=\"chbox_$i\" name='selection[]' value='";
                        echo $row[0], "'/>";
                        echo "</td>";

                        echo "<td>&nbsp;", $nom, "</td>";
                        echo "<td>&nbsp;", $prenom, "</td>";

                        echo "<td>&nbsp;", $formation, "</td>";

                        echo "<td>&nbsp;", $ville, " </td>";
                        echo "<td>&nbsp;", substr($entreprise,0,20), " </td>";
                        echo "<td>&nbsp;", $referent, " </td>";
                        echo "<td>&nbsp;", $tuteur, " ($notifAttribTuteur) </td>";

                        echo "<!--td>&nbsp;" . $motscles . " </td-->";
                        $divs = $divs . ",'td" . $i . "'";
                        echo "<td>";

                        echo "<select name=\"a_" . str_replace('.', '_', $altCle) . "\"
                              onChange=\"javascript:checkAll('actionForm','selection[]',false);
                                          getElt('chbox_" . $i . "').checked=true;
                                          submit();\">";
                        echo $selectString;
                        echo "</select>";

                        echo "</td>";
                        echo "</tr>";

                        $i = $i + 1;
                    } while ($row);
                    $nbDivs = $i;
                    ?>
                </tbody>
            </table>
            <a onClick="javascript:checkAll('actionForm','selection[]',true);"><font style="color:blue; text-decoration:underline;">Tous</font></a>
            <a onClick="javascript:checkAll('actionForm','selection[]',false);"><font style="color:blue; text-decoration:underline;">Aucun</font></a>
            <br/>
            <?php
            echo "<select name='action'>";
            echo $selectString;
            echo "</select>";
            ?>
            <input type="submit" value="Effectuer actions"/>
        </form>
        </div>

        <div id="cadre_1" class="contenu-item2 off">
            <br/><?php
                $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");
                ?>
        <ul><li>
                <b>Emails</b> : <?php if (strlen($emailsULille1) > 2)
                echo substr($emailsULille1, 2); ?> <br/>
            </li><li>
                <b style="color:red">Manquants</b> : <?php if (strlen($missingULille1) > 2)
                    echo substr($missingULille1, 2); ?>
            </li></ul>

        </div>

        <div id="cadre_2" class="contenu-item2 off">
            <br/><?php
                $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");
        ?><ul><li>
                <b>Emails</b> : <?php if (strlen($emailsMix) > 2)
                    echo substr($emailsMix, 2); ?> <br/>
            </li><li>
                <b style="color:red">Manquants</b> : <?php if (strlen($missingMix) > 2)
                    echo substr($missingMix, 2); ?>
            </li></ul>


        </div>

        <div id="cadre_3" class="contenu-item2 off">
            <br/><?php
                $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");
        ?><ul><li>
                <b>Emails</b> : <?php if (strlen($emails) > 2)
                    echo substr($emails, 2); ?>
            </li><li>
                <b style="color:red">Manquants</b> : <?php if (strlen($missing) > 2)
                    echo substr($missing, 2); ?>
            </li></ul>

        </div>
          <div id="cadre_4" class="contenu-item2 off">
    <br/>
    <ul>
      <li>Lignes <font style="background-color:red">rouges</font> - étudiants sans tuteur
      </li>
      <li>Lignes <font style="background-color:darkgray">grises</font> - étudiants avec tuteur</li>
    </ul>
  </div>
     </div>
