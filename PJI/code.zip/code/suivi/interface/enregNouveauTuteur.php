<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <TITLE>Enregistrer nouveau étudiant</TITLE>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
    </head>
    <body>
<?php
    require_once (ABS_START_PATH."/dbmngt/connect.php");
    
    if ((array_key_exists("prenom",$_REQUEST) && strlen($_REQUEST["prenom"])>0)
                        ||(array_key_exists("nom",$_REQUEST)&& strlen($_REQUEST["nom"])>0 ))
                    echo "<b>", $_REQUEST["prenom"]," ",$_REQUEST["nom"], "</b> <br/>";
                else
                    die("<h2>Problème</h2>Vous devez renseigner votre nom! <br/><a href='sansTuteur.php'>Revenez à l'étape de sélection!</a>");

    $updateQuery="INSERT INTO `fa_temp_tuteurs` (`etat`,`tuteurRef`,`nom_tuteur`,`prenom_tuteur`,`mail_tuteur`,`formationRef`,`alternanceRef`) VALUES ";
            $updateQuery=$updateQuery."("."0".",";
            $updateQuery=$updateQuery."'nouveau',";
            $updateQuery=$updateQuery."'".$_REQUEST["nom"]."',";
            $updateQuery=$updateQuery."'".$_REQUEST["prenom"]."',";
            $updateQuery=$updateQuery."'".$_REQUEST["mail"]."',";
            $updateQuery=$updateQuery."'0',";
            $updateQuery=$updateQuery."'0');";

            $conn=doConnection();
            $res=mysql_query($updateQuery,$conn);

            if(!$res)
            {   echo "problème avec l'update!!!<br/>contacter marius.bilasco at lifl.Fr<br/>";
                die();
            }
            else
            {
                echo "d'ici peu vous serez ajoutés à l'applications. revenez bientôt!";
            }

            echo("<br/><a href='http://www.fil.univ-lille1.fr'>PORTAIL FIL</a>");
            echo("<br/><a href='index.php'>RECONNEXION</a>");
        ?>
    </body>
</html>