<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queries.php");
      require_once(ABS_START_PATH."/dbmngt/inscrire.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/dbutils.php");

      $conn=doConnection();

      $formation=getParam("formation","L3MIAGEFA");
      $_SESSION["formation"]=$formation;

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Inscrire Etudiants</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
  
  

</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>

        <?php
          if (getCurrYear()>$_SESSION[REF_YEAR]+1) {
            die("<b>Impossible d'inscrire d'étudiants pour l'année courante $_SESSION[REF_YEAR] !</b> </div></div>");
          }
        ?>

      <?php
     

        echo "<table border='1'>";
        $iRowMax=getParam("iRowMax",0);
        for ($i=0;$i<$iRowMax;$i++) {
          $checked=getParam("chkbox_$i",false);
          if ($checked==false) continue;
          $nom=getParam("fa_etud_nom_$i");
          $prenom=getParam("fa_etud_prenom_$i");
          $etudCle=getParam("fa_etud_cle_$i","");
          $tel=getParam("fa_etud_tel_$i","");
          //$status=$data[2];
          $mail=getParam("fa_etud_mail_$i");
          $et_entrCle=getParam("fa_entreprise_cle_$i");
          $bureau_bureauCle=getParam("fa_bureau_cle_$i");
          $ref_refCle=getParam("fa_referent_cle_$i");
          $groupeRef=(getParam("formationCible","")."1");
          if ($groupeRef=="1")
            $groupeRef=(getParam("groupeRef_$i",""));
          $motsCles=getParam("motsCles_$i");
          $anneeCible=getParam("anneeCible",$_SESSION[REF_YEAR]);
          $tuteurRef=getParam("fa_tuteur_ref_$i",null);

          echo "<tr><td>$nom</td><td>$prenom</td><td>$groupeRef</td><td>";
          {
              $res=faireInscrireEtudiant(
                $groupeRef,
                $nom,
                $prenom,
                $tel,
                $mail,
                $et_entrCle,
                 $tuteurRef,
                 $motsCles,
                 $anneeCible,
                 $bureau_bureauCle,
                 $ref_refCle,
                 $etudCle
              );
            echo $res;
          }
          echo "</td></tr>";
        }
        echo "</table>";
      
      ?>
        

    </div>
</div>