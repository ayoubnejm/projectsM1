<?php
// Auteur VIJ
require_once(ABS_START_PATH."/secure/auth.php");

   
    if (!hasRole(RESP_ROLE))
        redirectAuth(null);


require_once(ABS_START_PATH."/dbmngtPDO/connectPDO.php");
require_once(ABS_START_PATH."/dbmngtPDO/queriesPDO.php");
require_once(ABS_START_PATH."/dbmngt/queries.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/dbutils.php");

 		$selectString = generateSelectOption(
        array("aucune","modifTuteur_act","desactiverTuteur_act"),
                    array("aucune","Maj tuteur","désactiver tuteur"),0);

?>

      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 5 ;
-->

</script>
<div class="menuitem2" id="item_0"><a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/inscrireTuteur_act">Inscrire un tuteur universitaire </a>
   | <a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/gestionTuteurs_act">Liste des tuteurs universitaires actifs</a>
| <a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/gestionTuteursInactifs_act">Liste des tuteurs universitaires Inactifs</a>
</div>

 <script type="text/javascript">
         function verif() {
            if (confirm('Etes-vous sur de supprimer ?')) {
              <?php 
                $bureauCle = getParam("lebureau", "");
                $conn = doConnection();

                $res2 = doQuerySupprimerBureau($conn, $bureauCle);
               ?>
            } else {
                 return false;
            }
         }

         function verif2() {
            if (confirm('Etes-vous sur de supprimer ?')) {
              <?php 
                  $referent = getParam("referent", "");
                  $conn = doConnection();
                  $res2 = doQuerySupprimerReferent($conn, $referent);
               ?>
            } else {
                 return false;
            }
         }
      </script>


<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
<SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
                   <script language="javascript" type="text/javascript">
function pop_it(the_form) {
   my_form = eval(the_form)
   window.open("./wait.php", "popup", "height=200,width=300,menubar='no',toolbar='no',location='no',status='no',scrollbars='no'");
   my_form.target = "popup";
   my_form.submit();
}
</script>
</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2"><br/>
              <?php
           
            $conn=doConnection("fil_dept");
            $modifierTuteur = getParam("modifierTut", "");
            $desactiver=getParam("desactiver","");
                
                if($desactiver==1){
                    if (date("Y")==$_SESSION[REF_YEAR] or date("Y")==$_SESSION[REF_YEAR]+1) {
            die("<b>Impossible de desactiver des tuteurs pour l'année ".$_SESSION[REF_YEAR]." !</b> </div></div>");
          } 
                 
                  $tuteurRef = getParam("tuteurRef", "");
                
                  $res = doQueryDesactiverTuteur($conn, $tuteurRef);
                  if ($res >= 1){ ?> <script type="text/javascript"> window.alert('Le tuteur est desactivé avec succès !!')</script>
                  <?php } else{ ?> <script type="text/javascript"> window.alert('Erreur!! Desactivation ko ...')</script><?php  }
                
              }


          if($modifierTuteur==1){
 
                            $profCle = getParam("profCle","");
                           $nom = getParam("nom","");
                           $prenom = getParam("prenom","");
                           $tel = getParam("tel", "");
                           $mail = getParam("mail", "");
                           $anneeReference=getParam("anneeReference", "");
                           $bureau=getParam("bureau", "");
                           $conn = doConnection();
                           $res = doQueryUpdateTuteur($conn, $profCle,$nom,$prenom,$tel, $mail, $anneeReference, $bureau); 
                        if($res ){ ?>
                              <script type="text/javascript">
                             window.alert(" Modification avec succes ");
                            </script>
                        <?php }else{ ?>
                           <script type="text/javascript">
                             window.alert(" erreur : Impossible de modifier les informations de ce tuteurs  ");
                            </script>

                       <?php }

               }
            ?>
            <h1> Liste des tuteurs universitaires actifs </h1> 

   <form action="<?php echo ABS_START_URL;?>/index.php" method="post" id="actionForm">
            <input type="hidden" name="page" value="interface/faireActionsTuteur_act"/>
	    <?php
			    $i = 0;
		$divs = "'head'";
            ?>

  <a onClick="javascript:checkAll('actionForm','selection[]',true);"><font style="color:blue; text-decoration:underline;">Tous</font></a>
  <a onClick="javascript:checkAll('actionForm','selection[]',false);"><font style="color:blue; text-decoration:underline;">Aucun</font></a>


  <table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1">
                <thead> <tr>
                        <!--td></td--> 

                        <th>  </th>
                        <th> Nom </th>
                        <th> Prenom </th>
                        <th> Mail </th>    
			<th> Date d'inscription </th>    
                        <th> &nbsp; Nombre étudiants &nbsp; </th>          
                         <th width="200pt">Actions<div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">details</a--></th>  
                    </tr>
                </thead>
                <tbody>

                    <?php

                    $bdd=doConnectionPDO("stalt2");

                    $res=doQueryListTuteursParAnnee($conn, $_SESSION[REF_YEAR]);

                   while ($tuteur=mysql_fetch_row($res))
                    {
                        
                      $nombreEtudiantParTuteur = doQueryNombreEtudiantsEncadresParUnTuteur( $bdd,$tuteur[0], $_SESSION[REF_YEAR]);
                    $nombreTotalEtudiantParTuteur = doQueryNombreTotalEtudiantsEncadresParUnTuteur( $bdd,$tuteur[0], $_SESSION[REF_YEAR]);
                   
                        echo "<tr><td><input type='checkbox' id=\"chbox_$i\" name='selection[]' value='". $tuteur[0]. "' /> </td>";
			
                        echo "<td align= 'center'>".$tuteur[1]."</td>";
                        echo "<td align= 'center'>".$tuteur[2]."</td>";
                        echo "<td align= 'center'>".$tuteur[3]."</td>";  
                        echo "<td align= 'center'>".$tuteur[5]."</td>"; 
 
                         while ($donnees = $nombreEtudiantParTuteur->fetch())
                            {
                                 echo "<td align= 'center' >".$donnees['nbreEtudiant'];
                              }
			  while ($donnees2 = $nombreTotalEtudiantParTuteur->fetch())
                            {
                                 echo "/".$donnees2['nbreEtudiant']."</td>";
                             }


			$nombreEtudiantParTuteur->closeCursor(); // Termine le traitement de la requête

                      /*  echo  "<td align= 'center' ><form method='post' action='".ABS_START_URL."/index.php'>
                       
                      <input type='hidden' name='page' value='interface/gestionTuteurs_act'/>
                       <input type='hidden' value='1' name='desactive'>
                       <input type='hidden' value='".$tuteur[1]."' name='tuteurNom' />
                       <input type='hidden' value='".$tuteur[2]."' name='tuteurPrenom' />
                      <input type='submit' name='desactiver' value= 'Desactiver' onclick=\"return confirm('Etes-vous sur de Desactiver ce tuteur ?')\" ></form></td>";


<td align= 'center'><form method='post' id='chatform' action='".ABS_START_URL."/index.php'>
                       <input type='hidden' name='page' value='interface/modifTuteur_act'/>
                       <input type='hidden' value='".$tuteur[1]."' name='tuteurNom'>
                       <input type='hidden' value='".$tuteur[2]."' name='tuteurPrenom'>
                       <input type='submit' name='modifier' value='Modifier'/></form></td></tr>";*/


                       echo  "<td><select name=\"a_".str_replace('.', '_', $tuteur[0]) ."\" 
					 onChange=\"javascript:checkAll('actionForm','selection[]',false);
                                          getElt('chbox_" . $i . "').checked=true;
                                          submit();\">".$selectString."</select></td></tr>";

 			$i = $i + 1;
                    } 
                    
                    ?>
                </tbody>
     </table>
     <a onClick="javascript:checkAll('actionForm','selection[]',true);"><font style="color:blue; text-decoration:underline;">Tous</font></a>
    <a onClick="javascript:checkAll('actionForm','selection[]',false);"><font style="color:blue; text-decoration:underline;">Aucun</font></a>
    <br/>
       <?php
            echo "<select name='action'>";
            echo $selectString;
            echo "</select>";
            ?>
            <input type="submit" value="Effectuer actions"/>
            </form>
        </div>
</div>

