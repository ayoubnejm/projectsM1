<?php
// Ajout class de gestion des bureau du 30/01/2012 JTA 

require_once '../secure/auth.php';

if (!hasRole(PROF_ROLE) && !hasRole(STUD_ROLE))
    redirectAuth(null);


require_once '../html/utils.php';
require_once '../html/dbutils.php';
require_once '../dbmngt/inscrire.php';
?>
<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Nouveau Bureau</title>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <form id="inscrirebureau" action="inscrireBureau.php" method="POST">
            <?php 
                $entreprise = getParam("entr_cle", ""); 
                $entrepriseNom = getParam("entr_nom", ""); 
            ?>
            <input type="hidden" name="entr_cle" value="<?php echo $entreprise; ?>"/>
            <input type="hidden" name="entr_nom" value="<?php echo $entrepriseNom; ?>"/>
            <h2>Inscrire un nouveau bureau pour l'entreprise : <?php echo $entrepriseNom ?> </h2>
            <table witdh="500">

                <?php
                $inscrire = getParam("inscrire", "");
                $fa_bur_adresse = getParam("fa_bur_adresse", "");
                $fa_bur_tel = getParam("fa_bur_tel", "");
                $fa_bur_ville = getParam("fa_bur_ville", "");
                $fa_bur_cp = getParam("fa_bur_cp", "");

                if (strlen($inscrire) > 0) {
                    if ($fa_bur_cp != "") {
                        $err_msg = faireInscrireBureau(
                                $fa_bur_adresse, $fa_bur_tel, $fa_bur_ville, $fa_bur_cp, $entreprise
                        );
                        if (strlen($err_msg)) {
                            echo "<h4 style='color:red'>$err_msg</h4>";
                        } else {
                            echo "Inscription reussie!<br/>";
                            echo "<a href='javascript:history.go(-2);'>Retour</a>";
                            exit();
                        }
                    } else {
                        echo "<h4 style='color:red'>Le code postal est obligatoire</h4>";
                    }
                }
                ?>
                <tr>
                    <td>
                        Adresse *: 
                    </td>
                    <td>
                        <input type="text" name="fa_bur_adresse" value="<?php echo $fa_bur_adresse; ?>"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Ville *:
                    </td>
                    <td>
                        <input type="text" name="fa_bur_ville" value="<?php echo $fa_bur_ville; ?>"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Code Postal *:
                    </td>
                    <td>
                        <input type="text" name="fa_bur_cp" value="<?php echo $fa_bur_cp; ?>"/>
                    </td>
                </tr><tr>
                    <td>
                        Téléphone :
                    </td>
                    <td>
                        <input type="text" name="fa_bur_tel" value="<?php echo $fa_bur_tel; ?>"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        * Champ obligatoire
                    </td>
                    <td>
                        <input type="submit" style="color:orange" name="inscrire" value="Inscrire"/>
                    </td>
                </tr>
            </table>

        </form>

    </body>
</html>