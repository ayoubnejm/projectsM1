<?php
    require_once ABS_START_PATH.'/secure/auth.php';

    if (!hasRole(PROF_ROLE))
        redirectAuth(null);
?>
<?php
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/dbmngt/queries.php");
        require_once(ABS_START_PATH."/html/utils.php");

        $actionCodes=array("aucune",
                        "renduGlobal_act",
                        "renduEtape0_act",
                        //"majEtape0",
                        "renduEtape1_act",
                        //"majEtape1",
                        "renduEtape2_act",
                        //"majEtape2",
                        "renduEtapeMissionSoutenance_act",
                        //"majEtapeMissionSoutenance",
                        "renduEtapeBilan_act",
                        "aucune",
                        //"majEtapeBilan",
                        "choixEtudiantGenerationOrdreMission_act",
                        "aucune",
                        "dissocierTuteur_act");
        $actionLabels=array("aucune",
                        "Dossier global",
                        "Informations générales",
                        //"MAJ Informations générales sur les dossier",
                        "Rencontre etudiant tuteur",
                        //" - maj étape 1",
                        "1ère visite pédagogique",
                        //" - maj étape 2",
                        "Mission soutenance (sauf M1 MIAGE FA)",
                        //    " - maj étape Choix de la mission pour la soutenance (L3 et M2)",
                        "2ème visite pédagogique",
                        "------------",
                        //    " - maj Bilan",
                        "Génération ordre de mission",
                        "------------",
                        "Ne plus suivre cet étudiant"
                        );

        $selectString=generateSelectOption($actionCodes,$actionLabels,0);
                    

        $formation=getParam("formation","%");
        $_SESSION["formation"]=$formation;
        
        $tuteurParam=getParam(CK_USER,$_SESSION[CK_USER]);
        
        //setcookie("Cookie_formation",$formation,(time()+600));
        //setcookie(CK_USER,$tuteurParam,(time()+600));
        

        $conn=doConnection();
?>

        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
    <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 1 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Vos étudiants</a></div>
<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
<!-- FIN MENU -->
<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        
        
         <form id="formationForm" action="<?php echo ABS_START_URL;?>/index.php" method="POST">
            <input type="hidden" name="page" value="interface/actionsEtudiantsParTuteur_act"/>
            <?php
                           $formations = doTuteurQueryFormationsSuivies($conn,$tuteurParam);
                           if (!mysql_num_rows($formations))
                           {
                               echo "</form><br/>Pour l'instant vous ne suivez aucun étudiant!";
                               exit(1);
                           }
                           $keys=Array();
                           $values=Array();
                           
                           for ($k=1,$form=mysql_fetch_row($formations);
                               $form;
                               $form=mysql_fetch_row($formations),$k=$k+1)
                           {
                            //echo "processing ".$formation[1]." ".$formation[0]."<br/>";
                            $keys[$k]=$form[1];
                            $values[$k]=$form[0];
                            //echo "processing ".$keys[$k]." ".$values[$k]."<br/>";
                           }

                           if ($k>1) {
                                $keys[0]=$keys[1];
                                $values[0]="Toutes";
                                for ($i=2;$i<$k;$i++)
                                    $keys[0] .= ",".$keys[$i];
                           }
                           
                           $i=0;
                           for (;($i<count($keys)) AND ($keys[$i]!==$formation);$i++);
                           if ($i==count($keys)) {
                               $i=0;
                               $formation=$keys[$i];
                           }
                           
                           echo "Choisissez la formation : ";
                           createSelectWithOnChange("formation",$keys,$values,$i,"javascript:submit();");
            ?>
        </form>
        <form action="<?php echo ABS_START_URL;?>/index.php" method="post" id="actionForm">
          <input type="hidden" name="page" value="interface/faireActionsEtudiants_act"/>
        <?php
            $i=0;
            $divs="'head'";
            $etudiants=doQueryListEtudiantsParTuteur($conn,$formation,$tuteurParam);
            if (!mysql_num_rows($etudiants))
            {
               echo "<h4 style='color:red'>Aucun étudiant</h4>";    
            }
            if (!mysql_num_rows($etudiants))
                exit();

        ?>

        <a onClick="javascript:checkAll('actionForm','selection[]',true);"><font style="color:blue; text-decoration:underline;">Tous</font></a>
        <a onClick="javascript:checkAll('actionForm','selection[]',false);"><font style="color:blue; text-decoration:underline;">Aucun</font></a>

           <table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1" style="font-size:9pt">
                <thead><tr class="entete">
                        <th></th>
                        <th>Nom</th>
                        <th>Formation</th>
                        <th>Ville</th>
                        <th>Entreprise</th>
                        <th>Référent</th>
                        <th>Action</th>
                        <!--td>Tuteur</td-->
                        <!--td><div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">details</a--></td-->
                    </tr>
                </thead>
                <tbody>
                  
                    <?php
                    
                    
                    $row=mysql_fetch_row($etudiants);
                    while ($row)
                    {
                      $altCle=$row[0];
                      echo "<tr",($row[17]>0?"":" class='cours' "),">";
                        echo "<td><input type='checkbox' id=\"chbox_$i\" name='selection[]' value='";
                        echo $altCle,"'/>";
                        echo "</td>";

                        echo "<td><a href='#' onClick=\"javascript:checkAll('actionForm','selection[]',false);
                                          getElt('sel_".$i."').selectedItem=0;
                                          gelElt('chbox_".$i."').checked=true;
                                          getElt('actionForm').submit();\">",$row[1], " ", $row[2],"</a>",($row[17]>0?"":"<br/>&nbsp;- non notifié(e)"),"</td>";
                        echo "<!--td>",$row[14],"</td-->";
                        
                        echo "<td>",$row[3],"</td>";

                        echo "<td>",$row[4],"</td>";
                        echo "<td>",$row[7],"</td>";
                        echo "<td><a href='mailto:",$row[6],"'>",$row[5],"</a></td>";
                        echo "<!--td>",$row[12],"</td-->";
                        
                        echo "<!--td>".$row[15]." <div id='td",$i,"'><a name=\"x",$i,"\"/>";
                        echo "<div style='top:30%;left:15%;width:60%;border:3px solid black;background-color:rgba(100,100,100,1);'>";
                        echo "<table border='1' bgcolor='#aaaaaa'>";
                        echo "<tr><td>Referent</td>","<td>",$row[5] ,"</td></tr>";
                        echo "<tr><td>Missions</td>","<td>",$row[8] ,"</td></tr>";
                        echo "<tr><td>Services</td>","<td>",$row[9] ,"</td></tr>";
                        echo "<tr><td>Clients</td>","<td>",$row[10] ,"</td></tr>";
                        echo "<tr><td>Envirnmnt Tech.</td>", "<td>",$row[11] ,"</td></tr>";
                        echo "</table><input type='button' value='Cacher' onClick='javascript:showHideModal(\"td",$i,"\");'/></div>";
                        echo "</div><a href='#",$i,"' onClick='javascript:showHideModal(\"td",$i,"\");'>détails</a></td-->";           $divs=$divs.",'td".$i."'";
                        echo "<td>";
                        
                        echo "<select id='sel_".$i."' name=\"a_".str_replace('.','_',$altCle)."\"
                              onChange=\"javascript:checkAll('actionForm','selection[]',false);
                                          getElt('chbox_".$i."').checked=true;
                                          submit();\">";
                        echo $selectString;
                        echo "</select>";
                      
                        echo "</td>";
                        echo "</tr>";
                        $row=mysql_fetch_row($etudiants);
                        $i=$i+1;
                    }
                    $nbDivs=$i;
                    ?>
                </tbody>
            </table>
            <a onClick="javascript:checkAll('actionForm','selection[]',true);"><font style="color:blue; text-decoration:underline;">Tous</font></a>
            <a onClick="javascript:checkAll('actionForm','selection[]',false);"><font style="color:blue; text-decoration:underline;">Aucun</font></a>
            <br/>
            <?php
                createSelect("action",$actionCodes,$actionLabels,0);
            ?>
            <input type="submit" value="Effectuer actions"/>
        </form>
            <br/>
            
         <script type="text/javascript">
          <?php
          echo "layer = new Array(",$divs,");";
          echo "doModalAll(layer);";
          echo "closeAll(layer)";
          ?>
         </script>
</div>
</div>
