<?php
     require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
?>

        <?php

        function inscrireTuteur($conn, $alternanceCle,$tuteurRef)
        {
            $dejaAttribueQuery="select alternanceCle from contrat where
                              alternanceCle='$alternanceCle' and tuteurRef='$tuteurRef'";
            //error_log($dejaAttribueQuery);
            $q=mysql_query($dejaAttribueQuery,$conn);
            //error_log("query : ".$q);
            if (mysql_fetch_row($q)) {
              //error_log("already registered");
              return 2;
            }

            $updateQuery="update contrat Set tuteurRef=";
            if ($tuteurRef==='__aucun__')
                $updateQuery.="NULL";
            else 
                $updateQuery.="'".$tuteurRef."', notifAttribTuteur=0";
            $updateQuery.=" where alternanceCle='".$alternanceCle."';";
            //echo $updateQuery;
            
            if (!mysql_query($updateQuery,$conn))
            {
                echo "pb updating tuteur";
                return 1;
            }

            return 0;
        }

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/dbmngt/queries.php");
        require_once(ABS_START_PATH."/html/utils.php");

        ?>
                <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 3 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Etat de l'attribution des tuteurs</a></div>
<div class="menuitem2" id="item_1"><a href="#" onclick="changeClass(this)">Purger table tuteurs</a></div>
<div class="menuitem2" id="item_2"><a href="#" onclick="changeClass(this)">Légénde couleurs</a></div>


<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
<!-- FIN MENU -->
<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        
        
        
        <table class="edt" style="font-size:9pt">
            <thead>
                <tr class="entete">
                    <td>Nom</td>
                    <td>Prenom</td>
                    <td>IdentifiantTuteur</td>
                    <td>Etat</td>
            </thead>
            <tbody>
            
        <?php


        if (!array_key_exists("alternance",$_REQUEST))
        {
            echo 'Rien à faire ici! Comment etes-vous rentré?';
            exit();
        }


        $alternants=$_REQUEST["alternance"];
        $noms=$_REQUEST["nom"];
        $prenoms=$_REQUEST["prenom"];
        $conn=doConnection();

        if (count($alternants)==0)
        {
            die("Comment est-vous arrivé sur la page? <br/>
                    <a href='index.php'>Retour accueil</a>");
        }

        $countPB=0;
        $successfullyAdded=array();
        for ($i=0;$i<count($alternants);$i++)
        {

            $champTuteur="tuteur_".str_replace('.','_',$alternants[$i]);
            $tuteurRef=null;
            if (array_key_exists($champTuteur,$_REQUEST))
                $tuteurRef=$_REQUEST[$champTuteur];
            $ok=3;
            if ($tuteurRef)
            {
                $ok=inscrireTuteur($conn, $alternants[$i],$tuteurRef);
            }
            if ($ok>1) continue;
            if ($ok==0)
            {
                echo "<tr bgcolor='green'>";
                if ($tuteurRef!=="__aucun__")
                  $successfullyAdded[]=$alternants[$i];
            }
            else
                echo "<tr>";
            echo "<td>",$noms[$i],"</td>";
            echo "<td>",$prenoms[$i],"</td>";
            echo "<td>",($tuteurRef&&($tuteurRef!=="__aucun__"))?$tuteurRef:"aucun tuteur","</td>";
            echo "<td>",($ok==0?"enregistré":($ok==1?"problème":"")),"</td>";
            echo "</tr>";
            if ($ok==1)
                $countPB++;
        }
       ?>
            </tbody>
        </table>
        <br>


        <?php
        if ($countPB>0)
        {
//            echo "Quelques tuteurs manquants.</br>";
//            echo "Revenez à l'<a href=\"attributionTuteurs.php\">étape précedente</a>";
        }
        ?>
        <br/>
        </div>

  <div id="cadre_1" class="contenu-item2 off">
        
        <br/>
        <ul>
          <li>
              Nettoyer la table des tuteurs potentiels pour les étudiants ayant un tuteur : <ul><li>
                  <a href="<?php echo ABS_START_URL;?>/index.php?page=interface/purgerTuteursPotentiels_act&formation=<?php echo getParam("formation"); ?>" style="font-size:9pt">Toutes</a>
                </li>
                  <?php 
                    $forms=explode(",",getParam("formation"));
                    for ($i=0;$i<count($forms);$i++)
                    {
                      echo "<li><a href='".ABS_START_URL."/index.php?page=interface/purgerTuteursPotentiels_act&formation=".$forms[$i];
                      echo "' style='font-size:9pt'>".$forms[$i]."</a></li>";
                    }
                  ?>

              </ul>
            </a>
          </li>
          <?php if (count($successfullyAdded)>0) { ?>

          <li>
           <form action="<?php echo ABS_START_URL;?>/index.php" method="post" id="sendMail">
              <input type="hidden" name="page" value="interface/faireActionsEtudiants_act"/>  <a href="#" onclick="sendMail.submit();" style="font-size:9pt">Envoyer mail pour prise de contact tuteur/étudiant pour les nouvelles attributions.</a>
            <!--input type="submit" value="Envoyer mail pour la prise de contact tuteur/étudiant."/-->
            <input type="hidden" name="action" value="priseContact_act"/>
            <?php

            for ($i=0;$i<count($successfullyAdded);$i++)
              echo "<input type='hidden' name='selection[]' value='$successfullyAdded[$i]'/>";
            ?>
          </form>
          </li>
          <?php } ?>
          </ul>
        </div>

  <div id="cadre_2" class="contenu-item2 off">
    <br/><ul>
      <li>Lignes <font style="background-color:red">rouges</font> - étudiants sans tuteur
      </li>
      <li>Lignes <font style="background-color:green">green</font> - étudiants avec tuteur</li>
     </ul>
  </div>