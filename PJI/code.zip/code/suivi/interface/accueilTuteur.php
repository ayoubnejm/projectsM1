<?php
    require_once '../secure/auth.php';
    //error_log("accueilTuteur for ".getParam(CK_USER,"UNKOWNN"));
    //require_once '../config/main.ini.php';

    
    $CURR_YEAR=getCurrYear();
    $refYear=getParam(REF_YEAR,$CURR_YEAR);
    $_SESSION[REF_YEAR]=$refYear;

    $refFormationRef=getParam(REF_FORMATIONTYPE,"FA");
    $_SESSION[REF_FORMATIONTYPE]=$refFormationRef;
    
    checkAllRoles();
    if (!hasRole(PROF_ROLE))
        redirectAuth(null);
    
?>

<html>
     <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Tuteurs</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
    </head>
    <frameset rows="45pt,*">
        <frame name="menu" src="menuTuteur.php"/>
        <frame name="main" src="welcomeTuteur.php"/>
    </frameset>
</html>