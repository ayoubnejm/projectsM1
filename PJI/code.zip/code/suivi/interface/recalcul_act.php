<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);

    require_once(ABS_START_PATH."/distance/calculDistance.php");
?>

<div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Recalcul distances</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>

</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
     <?php
if($_GET['cal']==1)
{
$Distance = new calculDistance();
$Distance->recalculerDistance();

echo "<br/><br/><br/><h3>le recalcul des distances a été effectué avec succes</h3>\n";
}
else echo "<br/><br/><br/><h3>erreur lors du recalcul</h3>\n";
?>

</body>
</html>

