<?php
require_once(ABS_START_PATH."/secure/auth.php");
if (!hasRole(PROF_ROLE))
    redirectAuth(null);

require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/dbmngt/queries.php");
require_once(ABS_START_PATH."/dbmngt/queriesSout.php");
require_once(ABS_START_PATH."/html/utils.php");

$conn = doConnection();

if ($_SESSION[MODE]==PROF_MODE) {
  $formations = doTuteurQueryFormationsSuivies($conn, $_SESSION[CK_USER]);
} else {
  $formations = doTuteurQueryFormationsResponsable($conn, $_SESSION[CK_ROLES]);
}

$formation = mysql_fetch_row($formations);
?>

<div class="menuitem2" id="item_0">Informations concernant le rapport et la soutenance</a></div>

 <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">


      
        <?php
        while ($formation) {

            if (strcmp($formation[1], "M1MIAGEFA") == 0) {
                $formation = mysql_fetch_row($formations);
                continue;
            }

            echo "<h2> " . $formation[1] . " </h2>";
            $req = doQueryDetailsSoutenanceRapport($conn, $formation[1]);
            if ($req) {
                $res = mysql_fetch_row($req);
            } else {
                $res = null;
            }
            echo "
              <table width='95%' style='font-size:9pt;border:1px solid #000000;padding:3px 7px 2px 7px;'>
              ";
            if ($_SESSION[MODE]==RESP_MODE && $_SESSION[REF_YEAR]>=getCurrYear()) {
              
              echo "<tr><td colspan='2' align='right'>
                <form action='".ABS_START_URL."/index.php' method='post'>
                  <input type='hidden' name='formation' value='".$formation[1]."'/>\n".
                  "<input type='hidden' name='page' value='interface/majInformationsSoutenanceEtRapportParProf_act'/>\n
                    <input type='submit' name='modifier' value='Modifier'/>\n
                  </form>
              </td></tr>";
            }
        echo "
        <tr>
          <td>
            <b>Date de remise du rapport</b>
          </td>
          <td>" .
            to_html($res[1]) .
            "</td>
        </tr>

      <tr><td><b>Dates de soutenances</b></td><td>" .
            to_html($res[2]) . "</td></tr>
      

      <tr><td><b>Longueur du rapport</b></td><td>" . to_html($res[3]) . "</td></tr>


      <tr><td><b>Durée de la soutenance</b></td><td>" . to_html($res[4]) . "</td></tr>
      
      <tr><td><b>Observations <br> (réservées aux étudiants)</b></td><td>" . to_html($res[5]) . "</td></tr>
      <tr><td><b>Observations <br/> (réservées aux tuteurs uniquement)</b></td><td>" . to_html($res[6]) . "</td></tr>

      <tr><td><b>Lien externe</b></td><td><a href='" .to_html($res[7]) ."' target='_blank'>".to_html($res[7]) . "</a></td></tr>

      </table>";
            echo "<br/><hr width='800pt' align='left'/><br/>";
            $formation = mysql_fetch_row($formations);
        }
        ?>

        </div>
 </div>
