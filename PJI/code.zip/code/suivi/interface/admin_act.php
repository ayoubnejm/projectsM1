<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queries.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/dbutils.php");

      $conn=doConnection();

      $formation=getParam("formation","L3MIAGEFA");
      $_SESSION["formation"]=$formation;

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Administration</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>

</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>
      <h1>Etudiants</h1>
      <form id="migrationForm" method="post" action="<?php echo ABS_START_URL; ?>/index.php">
      <ul>
        <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/inscrireEtudiants_act">Inscrire étudiants en mode batch</a></li>
        <li>Migrer étudiants déjà inscrits en :
          
          <input type='hidden' name="page" value="interface/faireActionsEtudiants_act"/>
          <input type='hidden' name="action" value="migrerEtud_act"/>
          <input type='hidden' name="selection[]" value="ACT_MIGRATION_ETUD"/>
          <?php
            $keysValues = constructGrantedGroupesKeys(true,true,'FA/FI');
            $formation=createSelectKeyValuesOnChange("formationSource",$keysValues,"","");
            echo " - ";
            $years=getAvailableYears();
            $refYear=$_SESSION[REF_YEAR];
            createSelectWithOnChange(
                  "anneeSource",
                  $years,
                  $years,
                  $CURR_YEAR-$refYear+1,
                  "");
         ?>
          <input type="submit" value="Migrer" style="color:orange"/>
          
        </li>
      </ul>
      </form>
      <?php if (getCurrYear()+1==$_SESSION[REF_YEAR]) { ?> <ul>
        <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/importCandidatures_act">Inscrire depuis site Candidatures.FIL.Univ-Lille1.FR en mode batch</a></li>
      </ul>
      <?php } ?>
      <ul>
        <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=ldap/doUpdateFILStuds_act">Récupérer Univ Lille 1 UIDs et mails @etudiant.univ-lille1.fr</a></li>
        <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=ldap/doUpdateMails_act">Récupérer mails @etudiant.univ-lille1.fr</a></li>
      </ul>
          
      <h1>Tuteurs</h1>
      <ul>
        <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=ldap/checkProfMails_act">Vérifier validité mail des profs</a></li>
         <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/gestionTuteurs_act">Gestion tuteurs universitaires</a></li>
      </ul>
      <?php if ($_SESSION[REF_FORMATIONTYPE]!="FI") { ?>
      <h1>Suivi</h1>
      <ul>
        <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=suivi/rappel_act&etapeSuivi=rencontreEtudiant">Lister tuteurs n'ayant pas effectué la rencontre avec l'étudiant</a></li>
        <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=suivi/rappel_act&etapeSuivi=1ereVisite">Lister tuteurs n'ayant pas effectué la 1ere visite</a></li>

        <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=suivi/rappel_act&etapeSuivi=missionSoutenance">Lister tuteurs n'ayant pas établie la mission soutenance</a></li>
      </ul>
      <?php } ?>
      <h1>Bureaux - en travaux</h1>
       <ul>
        <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/gestionBureaux_act">Gestion des bureaux</a></li>
      </ul>
       <ul>
        <li><a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/recalcul_act&cal=1">Recalcul des distances des bureaux</a></li>
       </ul>      
      
    </div>
</div>