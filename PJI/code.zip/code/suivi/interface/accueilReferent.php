<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Accueil Référent</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
    </head>
  <body>
      <h1>Bienvenue!</h1>
      <h2>Informations</h2>
      <br/>
      <h2>Opérations</h2>
      <ul>
          <li><a href="#">Mes étudiants</a></li>
      </ul>
  </body>
</html>
