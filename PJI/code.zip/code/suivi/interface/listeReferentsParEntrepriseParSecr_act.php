
<?php

    require_once(ABS_START_PATH."/secure/auth.php");
    
    if (!hasRole(SECR_ROLE))
        redirectAuth(null);


        require_once(ABS_START_PATH."/dbmngtPDO/connectPDO.php");
        require_once(ABS_START_PATH."/dbmngtPDO/queriesPDO.php");
        require_once(ABS_START_PATH."/html/utils.php");
        require_once(ABS_START_PATH."/html/dbutils.php");
 

        $formation=getParam("formation","%");
        $_SESSION["formation"]=$formation;
        
 
        

        $bdd=doConnectionPDO("stalt2");
		?>


       <div class="menuinterne2">
		<script type="text/javascript">
		<!--
		var dernierItem = 5 ;
		-->
		</script>
		<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Liste de référents</a></div>
		<div class="menuitem2" id="item_1"><a href="#"  onclick="changeClass(this)">Emails des référents</a></div>

		<script type="text/javascript">
		<!--
		  document.getElementById("item_"+0).className = 'menuitem2-current';
		-->
		</script>




       <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
         

   		<br/>
 

		<form id="gestionbureau" method="post" action="<?php echo ABS_START_URL;?>/index.php">
		  <input type="hidden" name="page" value="interface/listeReferentsParEntrepriseParSecr_act"/>
		   <?php
		   $entr=$_REQUEST["entr"];
		   $conn=doConnection();
		   echo " Choisissez une entreprise  : ";
		   createEntrepriseSelect($conn,"entr", $entr,"submit();");

        
		   ?>
		</form>
	 	
<br/>
<h2>La liste des référents de l'entreprise : </h2><br/>
 <?php
 
	 	$entreprise = getParam("entr", "");
		$resultat=doQuerieListReferentParEntreprise($bdd,$entreprise);
	   
?>



 	
<table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1">
		<thead>
			<tr>
				<th>Nom</th>
				<th>Prenom</th>  
				<th>Téléphone</th>
				<th>Mail</th>
				<th>Bureau</th>
				<th>Fonction</th>  
  
			</tr>
		</thead>
		<tbody><?php 
					while ($donnees = $resultat->fetch())
			{ 
				//if (strlen($donnees['mail'])>0) {$mail= $donnees['mail'];} else{ $mail= "_";}
				echo "
				<tr>

					<td>".$donnees['nom']."</td> 				
					<td>".$donnees['prenom']."</td>  
					<td>".$donnees['tel']."</td>
					<td><a href='mailto:".$donnees['mail']."'>".$donnees['mail']."</a></td> 
					<td>".$donnees['bureauRef']."</td>
					<td>".$donnees['fonction']."</td> 

				
				</tr>";
			}

 
			$resultat->closeCursor(); // Termine le traitement de la requête
		?>
		</tbody>
	</table>



</div>

 <div id="cadre_1" class="contenu-item2 off">
            <br/><?php
              
                $listeMail = doQuerieListMailReferents($bdd,$entreprise);

                echo "<b>Mails des référents</b> : <br/>";
                
                while ($donnees = $listeMail->fetch()) { 
			     
	                echo  $donnees['mail'];

	                echo "<br/>";

               }

            ?>
        </div>

</div>
