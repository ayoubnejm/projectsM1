<?php
// Auteur VIJ
require_once(ABS_START_PATH."/secure/auth.php");

   
    if (!hasRole(SECR_ROLE) && !hasRole(RESP_ROLE))
        redirectAuth(null);

require_once(ABS_START_PATH."/dbmngt/queries.php");
require_once(ABS_START_PATH."/html/utils.php");

require_once(ABS_START_PATH."/dbmngtPDO/connectPDO.php");

require_once(ABS_START_PATH."/dbmngtPDO/queriesPDO.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/dbutils.php");
?>

      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Administration</a></div>
 
 <script type="text/javascript">
         function verif() {
            if (confirm('Etes-vous sur de supprimer ?')) {
              <?php 
                $bureauCle = getParam("lebureau", "");
                $conn = doConnection();

                $res2 = doQuerySupprimerBureau($conn, $bureauCle);
               ?>
            } else {
                 return false;
            }
         }

         function verif2() {
            if (confirm('Etes-vous sur de supprimer ?')) {
              <?php 
                  $referent = getParam("referent", "");
                  $conn = doConnection();
                  $res2 = doQuerySupprimerReferent($conn, $referent);
               ?>
            } else {
                 return false;
            }
         }
	function desactiver() {
              if (confirm('Etes-vous sur de vouloir désactiver ce bureau ?')) {
		<?php 
		        $bureauCle = getParam("clebureauactif", "");
	  		$conn = doConnection();
		        $res2 = doQueryDesactiverBureau($conn, $bureauCle);
		     
 		?>
            } else {
                 return false;
            }
         }
	function activer() {
            if (confirm('Etes-vous sur de vouloir activer ce bureau ?')) {
              <?php 
                $bureauCle = getParam("clebureauinactif", "");
               
  		$bdd=doConnectionPDO("stalt2");
		
                $res2 = doQueryActiverBureau($bdd, $bureauCle);
		
               ?>
            } else {
                 return false;
            }
         }
      </script>


<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
<SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
                   <script language="javascript" type="text/javascript">
function pop_it(the_form) {
   my_form = eval(the_form)
   window.open("./wait.php", "popup", "height=200,width=300,menubar='no',toolbar='no',location='no',status='no',scrollbars='no'");
   my_form.target = "popup";
   my_form.submit();
}
</script>
</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2"><br/>

<form id="gestionbureau" method="post" action="<?php echo ABS_START_URL;?>/index.php">
  <input type="hidden" name="page" value="interface/gestionBureaux_act"/>
   <?php
   $entr=$_REQUEST["entr"];
   $conn=doConnection();
   echo "selected : ".$entr;
   createEntrepriseSelect($conn,"entr", $entr,"submit();");
   ?>
</form>


<br/>

<h2>La liste des bureaux actifs de l'entreprise : </h2><br/>
 <?php
    
////////////////////////////////// partie bureau actif //////////////////////////////////////////


//ici affichage des bureaux
 $entreprise = getParam("entr", "");
   
  $conn = doConnection();
  $res = doQueryAvoirBureaux($conn, $entreprise);
   
     echo ' <table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1">
                <thead><tr> <th align=center>Bureau</th><th align=center>Adresse</th><th align=center>Nbr etudiants</th>
         <th align=center>Désactivation</th><th align=center>Suppression</th></tr>';

       while ( $bureau = mysql_fetch_row($res)) {
       echo "<tr><td align=center>".$bureau[0]."</td><td align=center>".$bureau[1]." ".$bureau[2]."</td><td align=center>";
	$res2 = doQueryEtudiantParBureau($conn, $bureau[0]);
         while ($nbr = mysql_fetch_row($res2)){
          echo $nbr[0]."/";
          }
          $res3 = doQueryNombreTotalEtudiant($conn, $bureau[0]);
          while ($nbre = mysql_fetch_row($res3)){
          echo $nbre[0]."</td>";
          }


	echo "<td align=center> <form  method='post' action='".ABS_START_URL."/index.php'>
                      <input type='hidden' name='page' value='interface/gestionBureaux_act'/>
                      <input type='hidden' name='entr' value='$entr'/>
                       <input type='hidden' value='".$bureau[0]."' name='clebureauactif'>".
                       ((substr($bureau[0],strlen($bureau[0])-6,6)!="_siege")?"<INPUT type=submit value=Désactiver  onclick=\"return desactiver()\">":"")."</form></td>";

       echo "<td align=center> <form  method='post' action='".ABS_START_URL."/index.php'>
                      <input type='hidden' name='page' value='interface/gestionBureaux_act'/>
                      <input type='hidden' name='entr' value='$entr'/>
                       <input type='hidden' value='".$bureau[0]."' name='lebureau'>".
                       ((substr($bureau[0],strlen($bureau[0])-6,6)!="_siege")?"<INPUT type=submit value=Supprimer  onclick=\"return verif()\">":"")."</form></td></tr>";
       
       
       }
  
  echo'</table>';
  
  ?> 
 

<br/>

<h2>La liste des bureaux inactifs  de l'entreprise : </h2><br/>
 <?php
    
////////////////////////////////// partie bureau inactifs //////////////////////////////////////////


//ici affichage des bureaux
 $entreprise = getParam("entr", ""); 
  $res = doQueryAvoirBureauxInactifs($conn, $entreprise);
   
     echo ' <table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1">
                <thead><tr> <th align=center>Bureau</th><th align=center>Adresse</th><th align=center>Activation</th>
		<th align=center>Suppression</th></tr>';

       while ( $bureauInactif = mysql_fetch_row($res)) {
       echo "<tr><td align=center>".$bureauInactif[0]."</td><td align=center>".$bureauInactif[1]." ".$bureauInactif[2]."</td>";
        

	echo "<td align=center> <form  method='post' action='".ABS_START_URL."/index.php'>
                      <input type='hidden' name='page' value='interface/gestionBureaux_act'/>
                      <input type='hidden' name='entr' value='$entr'/>
                       <input type='hidden' value='".$bureauInactif[0]."' name='clebureauinactif'>".
                       ((substr($bureauInactif[0],strlen($bureauInactif[0])-6,6)!="_siege")?"<INPUT type=submit value=Activer  onclick=\"return activer()\">":"")."</form></td>";

       echo "<td> <form  method='post' action='".ABS_START_URL."/index.php'>
                      <input type='hidden' name='page' value='interface/gestionBureaux_act'/>
                      <input type='hidden' name='entr' value='$entr'/>
                       <input type='hidden' value='".$bureauInactif[0]."' name='lebureau'>".
                       ((substr($bureauInactif[0],strlen($bureauInactif[0])-6,6)!="_siege")?"<INPUT type=submit value=Supprimer  onclick=\"return verif()\">":"")."</form></td></tr>";
       
       
       }
  
  echo'</table>';
  
  ?> 
<br/> 


<?php
/////////////////////////////sara


?>


<br/> 

<h2>La Liste des référents de l'entreprise :</h2><br/>
  <?php    
////////////////////////////////// partie referent //////////////////////////////////////////




 $res = doQueryAvoirReferents($conn, $entreprise);
   //select nom,prenom,tel,mail,fonction, referentCle
     
   echo '<table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1">
                <thead><tr> <th align=center>Nom</th><th align=center>Prenom</th><th align=center>Telephone</th>
       <th align=center>Mail</th><th align=center>Fonction</th><th align=center>Bureau</th><th align=center>Modification</th><th align=center>Suppression</th></tr>';
       while ( $referent = mysql_fetch_row($res)) {
       echo "<tr><td align=center>".$referent[0]."</td>
           <td align=center>".$referent[1]."</td>
               <td align=center>".$referent[2]."</td>
                   <td align=center>".$referent[3]."</td>
                       <td align=center>".$referent[4]."</td>
                        <td align=center>".$referent[6]."</td>
                         
                       <td>".
                       ($referent[0]!="__sans"?"
                            <form method='post' id='chatform' action='".ABS_START_URL."/index.php'>
                        <input type='hidden' name='page' value='interface/modifRefPopUp_act'/>

                       <INPUT type='hidden' value='".$referent[5]."' name='referent'>
                       <input type='submit' name='modifier' value='Modifier'/></form></td>
                        
                        
                        <td> <form method='post' action='".ABS_START_URL."/index.php'>
                        <input type='hidden' name='page' value='interface/gestionBureaux_act'/>
                        <input type='hidden' name='entr' value='$entr'/>

                       <INPUT type='hidden' value='".$referent[5]."' name='referent'>
                       <INPUT type='hidden' value='1' name='supprimer'>
                       <INPUT type='submit' value='Supprimer'  onclick=\"return verif2()\"></form>":"").
                        "</td></tr>";
        }
  
  echo'</table>';
  
?>
</div>
</div>
