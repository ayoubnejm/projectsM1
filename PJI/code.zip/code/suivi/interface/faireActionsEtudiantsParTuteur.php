<?php
require '../secure/auth.php';

if (!hasRole(PROF_ROLE))
    redirectAuth(null);
?>
<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Action</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
        <!--SCRIPT src='../ajax/inscrireReferent_modal.js' lang='javascript'></SCRIPT-->
    </head>
    <body>
        <?php
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/log/log.php");

        /*
         * To change this template, choose Tools | Templates
         * and open the template in the editor.
         */
        ?>
        <h1>Etat de l'opération</h1> <!--(<a href="actionsEtudiantsParTuteur.php">Revenir</a>)-->

        <?php
        $action = $_REQUEST["action"];
        //echo "en train de faire l'action : ".$action." pour ".$_REQUEST["selection"]."<br/>";
        require_once(ABS_START_PATH."/actions/" . $action . ".php");
        action_log($_SESSION[CK_ROLES], $_SESSION[CK_USER], $_REQUEST["action"],
                                        $_REQUEST["selection"]);

        faireAction($_REQUEST["selection"]);
        ?>
        <!--hr/><br/-->
        <p>

        </p>
        <!--hr/><br/-->
        <p>

        </p>
    </body>


</html>
