<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queries.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/dbutils.php");

      $conn=doConnection();

      $formation=getParam("formation","L3MIAGEFA");
      $_SESSION["formation"]=$formation;

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Attribution tutuers aux étudiants</a></div>
<div class="menuitem2" id="item_1"><a href="#" onclick="changeClass(this)">Légénde</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>

</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>
          <br/>
        <?php
            $keysValues=constructGrantedGroupesKeys();
            $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");

        ?>

        <form action="<?php echo ABS_START_URL;?>/index.php" method="post" id="actionForm">
          <input type="hidden" name="page" value="interface/enregAttributionTuteurs_act"/>
          <input type="hidden" name="formation" value="<?php echo $formation; ?>"/>

         <table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1">
                <thead><tr>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Formation</th>
                        <th>Tuteurs<br/>candidats</th>
                        <th>Tuteurs précedents</th>
                        <th>Ville</th>
                        <th>Entreprise</th>
                        <th>Tuteurs potentiels</th>
                        <th>Details<div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">details</a--></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i=0;
                    $divs="'head'";
                    $etudiants=doQueryListEtudiantsParFormation($conn,$formation);

                    $row=mysql_fetch_row($etudiants);
                    while ($row)
                    {

                        $etud=$row[14];
                        $nbTuteurs=0;
                        $tuteurSelectionne=-1;
                        $clesTuteurs=array();$nomsTuteurs=array();

                        $tuteurEtabli=mysql_fetch_row(doQueryTuteurEtudiant($conn,$etud));
                        if ($tuteurEtabli)
                        {
                            $clesTuteurs[$nbTuteurs]=$tuteurEtabli[0];
                            $nomsTuteurs[$nbTuteurs++]=$tuteurEtabli[1]." ".$tuteurEtabli[2].($row[21]==0?"<br/> - non notifié":"");
                            $tuteurSelectionne=0;
                        }

                        $tuteursPotentiels=doQueryTuteursPotentielsParEtudiant($conn,$etud);
                        $nbTuteursPotentiels=mysql_num_rows($tuteursPotentiels);

                        if (($nbTuteursPotentiels+$nbTuteurs)==0)
                           echo "<tr bgcolor=\"red\">";
                        else if ($tuteurSelectionne==0)
                                echo "<tr bgcolor='gray'>";
                             else
                                echo "<tr>";

                        echo "<!--td-->";
                        echo "<input type='hidden' name='alternance[]' value='",$row[0],"'/>";
                        echo "<!--/td-->";

                        echo "<td><input type='hidden' name='nom[]' value='",$row[1],"'/>",$row[1],"</td>";
                        echo "<td><input type='hidden' name='prenom[]' value='",$row[2],"'/>",$row[2],"</td>";

                        echo "<td>$row[3]</td>";
                        echo "<td>";
                        if ($nbTuteursPotentiels+$nbTuteurs>0)
                        {
                     
                                
                                for ($tuteurPotentiel=mysql_fetch_row($tuteursPotentiels);
                                        $tuteurPotentiel;
                                        $tuteurPotentiel=mysql_fetch_row($tuteursPotentiels)
                                    )
                                {
                                    if ($tuteurSelectionne==0 && $tuteurPotentiel[0]==$clesTuteurs[0])
                                        continue;

                                    $clesTuteurs[$nbTuteurs]=$tuteurPotentiel[0];
                                    $nomsTuteurs[$nbTuteurs++]=$tuteurPotentiel[1]." ".$tuteurPotentiel[2];
                                }
                            $clesTuteurs[$nbTuteurs]="__aucun__";
                            $nomsTuteurs[$nbTuteurs]="aucun";
                            createRadioGroup("tuteur_".str_replace('.','_',$row[0]),$clesTuteurs,$nomsTuteurs,$tuteurSelectionne);
                        } 
                        
                        echo "</td>";
                        
                        /*dbname, lastname, firstname, id*/
                        $pastTuteurs=getTuteurAutreAnnee($conn,$row[20]);
                        $yearRef=$_SESSION[REF_YEAR];
                        echo "<td> ".$pastTuteurs[0]." (".(($yearRef-1)%2000).")<br/>".$pastTuteurs[1]." (".(($yearRef-2)%2000).")</td>";
                        echo "<td>",substr($row[6],0,20),"</td>";
                        echo "<td>",substr($row[9],0,20),"</td>";
                        echo "<td>&nbsp;";
                            $tuteurs=doQueryTuteursPotentiels($conn,$formation,$row[0]);
                            $tuteur=null;
                            if ($tuteurs)
                                $tuteur=mysql_fetch_row($tuteurs);
                            while ($tuteur) {
                                if (strcmp($tuteur[0],"nouveau")!=0)
                                    echo $tuteur[0];
                                else
                                    echo $tuteur[1]."_".$tuteur[2];
                                echo "<br/>";
                                $tuteur=mysql_fetch_row($tuteurs);
                            }
                        echo "</td>";
                        echo "<td>".$row[16]." <div id='td",$i,"'><table border='1' style='background-color:orange'>
             <tr>
             <td>Referent</td>
             <td>Missions</td>
             <td>Services</td>
             <td>Clients</td>
             <td>Envirnmnt Tech.</td>
             </tr><tr>";
                        echo "<td>",$row[7] ,"</td>";
                        echo "<td>",$row[10] ,"</td>";
                        echo "<td>",$row[11] ,"</td>";
                        echo "<td>",$row[12] ,"</td>";
                        echo "<td>",$row[13] ,"</td>";
                        echo "</tr><tr><td colspan='5' align='right'><a href='#' onClick='javascript:showHideModal(\"td",$i,"\");'>details</a></td></tr></table></div><a href='#' onClick='javascript:showHideModal(\"td",$i,"\");'>details</a></td>";
                        echo "</tr>";
                        $divs=$divs.",'td".$i."'";
                        $row=mysql_fetch_row($etudiants);
                        $i=$i+1;
                    }
                    $nbDivs=$i;
                    ?>
                </tbody>
            </table>
            <br/>
            <input type="submit" value="Enregistrer choix tuteurs"/>

        </form>
        </div>
          <div id="cadre_1" class="contenu-item2 off">
            <br/><ul>
      <li>Lignes <font style="background-color:red">rouges</font> - étudiants sans tuteur
      </li>
      <li>Lignes <font style="background-color:darkgray">grises</font> - étudiants avec tuteur</li>
      <li>Choisir les tuteurs, puis Enregistrer en bas de la page </li>
    </ul>
           
          </div>
        </div>
         <script type="text/javascript">
<?php
echo "layer = new Array(",$divs,");";
echo "doModalAll(layer);";
//echo "closeAll()";
?>
            </script>