<?php

    require_once(ABS_START_PATH."/secure/auth.php");
    
    if (!hasRole(RESP_ROLE))
        redirectAuth(null);

        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/dbmngt/queries.php");
        require_once(ABS_START_PATH."/html/utils.php");
        require_once(ABS_START_PATH."/html/dbutils.php");

        $formation=getParam("formation","%");
        $tuteurParam=getParam("tuteurParam","%");

        $_SESSION["tuteurParam"]=$tuteurParam;
        
        $_SESSION["formation"]=$formation;
        

        $conn=doConnection();

?>

        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
    <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 5 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Tableau de situation des étudiants</a></div>
<div class="menuitem2" id="item_1"><a href="#" onclick="changeClass(this)">Emails tuteurs Lille 1</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>        
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>
         <?php 
               //echo "Tuteur en mémoire", $tuteurParam;
                $tuteurs=doQueryListTuteurs($conn);
                $tuteur=mysql_fetch_row($tuteurs);
                $keysTut[0]="%";$valuesTut[0]="Tous";
                $tuteurNo=1;
                while ($tuteur)
                {
                    $keysTut[$tuteurNo]=$tuteur[0];
                    $valuesTut[$tuteurNo]=$tuteur[1]." ".$tuteur[2];
                    $tuteur=mysql_fetch_row($tuteurs);
                    $tuteurNo++;
                }
                $keysValuesTuteur=array();
                $keysValuesTuteur["keys"]=$keysTut;
                $keysValuesTuteur["values"]=$valuesTut;

                $tuteurParam=createSelectFormKeyValuesAndTargetPage("tuteurForm","tuteurParam",$keysValuesTuteur,$tuteurParam,getParam("page"),"Choisissez le tuteur : ");
                $totalHeures=0;
         ?>

         
            <?php
            
             $keysValues=constructGrantedGroupesKeys();
            $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");
            
            ?>
        

        <?php
            $i=0;
            $divs="'head'";
            
            $tuteurs2=doQueryListTuteursLike($conn,$tuteurParam);
            $aliasMailTuteurs="";
			// export csv
            $csv_hdr = "NomTuteur;Nom; Prenom; Formation; Ville; Entreprise";
            //Quickly create a variable for our output that'll go into the CSV file (we'll make it blank to start).
            $csv_output="";
	       //
            
            $tuteur=mysql_fetch_row($tuteurs2);
            while ($tuteur) 
            {
                $etudiants=doQueryListEtudiantsParTuteur($conn,$formation,$tuteur[2]);
                    if (!mysql_num_rows($etudiants))
                    {
                       //echo "<h4 style='color:red'>Aucun étudiant</h4>";
                       $tuteur=mysql_fetch_row($tuteurs2);
                    }
                    if (!mysql_num_rows($etudiants))
                        continue;
                    echo "<H3>".$tuteur[0]." ".$tuteur[1];

				
                    $aliasMailTuteurs.=$tuteur[3]."<br/>";
					$outputString="<table id='tableau_triable' class='tablesorter' border='0' cellpadding='1' cellspacing='1'>
									<thead>
										<tr>
											 <th>Nom</th>
													<th>Prenom</th>
													<th>Formation</th>
													<th>Ville</th>
													<th>Entreprise</th>
													<th><div id=\"head\"><!--for backward comp--></div><!--a href=\"#\" onClick=\"javascript:openAll(layer);\">details</a--></th>
										</tr>
									</thead>
											<tbody>";
		
                   
                    $row=mysql_fetch_row($etudiants);
                    $nbHeures=0;
                    while ($row)
                    {
                        //echo "fa_temp_tuteurs ".$row[16]."\n";
                        //if ($row[16]===NULL)
                        
                        if (substr($row[3],strlen($row[3])-2,2)=="FA") {
                          $nbHeures+=$row[3]!='M1MIAGEFA'?8:6;
                        } else {
                          $nbHeures+=substr($row[3],0,2)=="M1"?0:4;
                        }
                            $outputString.= "<tr class='".($i%2==0?"tp":"td")."'>";
//                        else
//                            echo "<tr style='color:yellow'>";
                        $outputString.= "<td>".$row[1]."</td>";
                        $outputString.= "<td>".$row[2]."</td>";
                        
                        $outputString.= "<td>".$row[3]."</td>";

                        $outputString.= "<td>".$row[4]."</td>";
                        $outputString.= "<td>".$row[7]."</td>";

                        //csv
                         $csv_output .= $tuteur[0]." ".$tuteur[1] . ";";
                         $csv_output .= $row[1] . ";" . $row[2] . ";" . $row[3]. ";" .$row[4]. ";" . $row[7] . "\n";
                                          
                        $outputString.= "<td>".$row[15]." <div id='td".$i."' style='visibility:hidden'><a name=\"td".$i."\"/>";
                        $outputString.= "<div style='top:30%;left:15%;width:60%;border:3px solid black;background-color:rgba(100,100,100,1);'>";
                        $outputString.= "<table id='tableau_triable' class='tablesorter' border='0' cellpadding='0' cellspacing='1'>";
                        $outputString.= "<tr><td>Referent</td>"."<td>".$row[5]."</td></tr>";
                        $outputString.= "<tr><td>Missions</td>"."<td>".$row[8]."</td></tr>";
                        $outputString.= "<tr><td>Services</td>"."<td>".$row[9]."</td></tr>";
                        $outputString.= "<tr><td>Clients</td>"."<td>".$row[10]."</td></tr>";
                        $outputString.= "<tr><td>Envirnmnt Tech.</td>". "<td>".$row[11]."</td></tr>";
                        $outputString.= "</table><input type='button' value='Cacher' onClick='javascript:showHideModal(\"td".$i."\");'/></div>";
                        $outputString.= "</div><a href='#td".$i."' onClick='javascript:showHideModal(\"td".$i."\");'>détails</a></td>";
                        $divs=$divs.",'td".$i."'";
                        $outputString.= "</tr>";
                        $row=mysql_fetch_row($etudiants);
                        $i=$i+1;
                    }
                    $nbDivs=$i;
                    
                    
               $outputString.= " </tbody>
            </table>";
                echo " ($nbHeures h) </H2>";
                echo $outputString;
                $totalHeures+=$nbHeures;
            
                $tuteur=mysql_fetch_row($tuteurs2);
                }

                echo "<h2> Total heures tuteurs : $totalHeures (h) </h2>";
            ?>
                
            <form action="<?php echo ABS_START_URL;?>/actions/export_csv.php" method="post" >
            <input type="submit" value="Export table to CSV">
            <input type="hidden" value="<? echo $csv_hdr; ?>" name="csv_hdr">
            <input type="hidden" value="<? echo $csv_output; ?>" name="csv_output">
        </div>

        <div id="cadre_1" class="contenu-item2 off">
            <br/><?php
                $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");

                echo "<b>Mails tuteurs</b> : <br/>";
                echo  $aliasMailTuteurs;
                echo "<br/>";

            ?>
        </div>
          </div>
<script type="text/javascript">
<?php
echo "layer = new Array(",$divs,");";
echo "doModalAll(layer);";
//echo "closeAll()";
?>
</script>

