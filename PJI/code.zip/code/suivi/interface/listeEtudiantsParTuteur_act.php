<?php

    require_once(ABS_START_PATH."/secure/auth.php");
    
    if (!hasRole(PROF_ROLE))
        redirectAuth(null);

    require_once(ABS_START_PATH."/dbmngt/connect.php");
    require_once(ABS_START_PATH."/dbmngt/queries.php");
    require_once(ABS_START_PATH."/html/utils.php");

    $formation=getParam("formation","%");
    $_SESSION["formation"]=$formation;

    $tuteurParam=getParam(CK_USER,$_SESSION[CK_USER]);
    $_SESSION["tuteurParam"]=$tuteurParam;


    $conn=doConnection();
?>
<div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Encadrement des étudiants par tuteur</a></div>
<div class="menuitem2" id="item_1"><a href="#" onclick="changeClass(this)">Emails tuteurs</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
<!-- FIN MENU -->
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>

        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">


         <form id="formationForm" action="listeEtudiantsParTuteur.php" method="POST">
            
            <?php
                           $formations = doTuteurQueryFormationsSuivies($conn,$tuteurParam);
                           if (!mysql_num_rows($formations))
                           {
                               echo "</form><br/>Pour l'instant vous ne suivez aucun étudiant!";
                               exit(1);
                           }

                           $keys=Array();
                           $values=Array();

                           for ($k=0,$formation=mysql_fetch_row($formations);
                               $formation;
                               $formation=mysql_fetch_row($formations),$k=$k+1)
                           {
                            //echo "processing ".$formation[1]." ".$formation[0]."<br/>";
                            $keys[$k]=$formation[1];
                            $values[$k]=$formation[0];
                            //echo "processing ".$keys[$k]." ".$values[$k]."<br/>";
                           }
                           
                           $i=0;
                           for (;($i<count($keys)) AND ($keys[$i]!==$formation);$i++);
                           if ($i==count($keys)) {
                               $i=0;
                               $formation=$keys[$i];
                           }

                           echo "Choisissez la formation : ";
                           createSelectWithOnChange("formation",$keys,$values,$i,"javascript:submit();");
            ?>
        </form>

        <?php
            $i=0;
            $divs="'head'";
            
            $tuteurs2=doQueryListTuteursLike($conn,$tuteurParam);
            $tuteur=mysql_fetch_row($tuteurs2);
            while ($tuteur) 
            {
                echo "<H3>".$tuteur[1]." ".$tuteur[0]."</H3>";
                $etudiants=doQueryListEtudiantsParTuteur($conn,$formation,$tuteur[2]);
                    if (!mysql_num_rows($etudiants))
                    {
                       echo "<h4 style='color:red'>Aucun étudiant</h4>";
                       $tuteur=mysql_fetch_row($tuteurs2);
                    }
                    if (!mysql_num_rows($etudiants))
                        continue;

        ?>
            
        <table border="1" class="edt" style="font-size:9pt">
                <thead><tr>
                        <td>Nom</td>
                        <td>Prenom</td>
                        <td>Formation</td>
                        <td>Ville</td>
                        <td>Entreprise</td>
                        <td><div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">details</a--></td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    
                    
                    $row=mysql_fetch_row($etudiants);
                    while ($row)
                    {                
                        //if ($row[16]===NULL)
                            echo "<tr>";
//                        else
//                            echo "<tr style='color:yellow'>";
//                        
                        echo "<td>",$row[1],"</td>";
                        echo "<td>",$row[2],"</td>";
                        
                        echo "<td>",$row[3],"</td>";

                        echo "<td>",$row[4],"</td>";
                        echo "<td>",$row[7],"</td>";
                        
                        echo "<td>".$row[15]." <div id='td",$i,"'><a name=\"x",$i,"\"/>";
                        echo "<div style='top:30%;left:15%;width:60%;border:3px solid black;background-color:rgba(100,100,100,1);'>";
                        echo "<table border='1' bgcolor='#aaaaaa'>";
                        echo "<tr><td>Referent</td>","<td>",$row[5] ,"</td></tr>";
                        echo "<tr><td>Missions</td>","<td>",$row[8] ,"</td></tr>";
                        echo "<tr><td>Services</td>","<td>",$row[9] ,"</td></tr>";
                        echo "<tr><td>Clients</td>","<td>",$row[10] ,"</td></tr>";
                        echo "<tr><td>Envirnmnt Tech.</td>", "<td>",$row[11] ,"</td></tr>";
                        echo "</table><input type='button' value='Cacher' onClick='javascript:showHideModal(\"td",$i,"\");'/></div>";
                        echo "</div><a href='#",$i,"' onClick='javascript:showHideModal(\"td",$i,"\");'>détails</a></td>";           $divs=$divs.",'td".$i."'";
                        echo "</tr>";
                        $row=mysql_fetch_row($etudiants);
                        $i=$i+1;
                    }

                    $nbDivs=$i;
                    ?>
                </tbody>
            </table>
            <?php
                $tuteur=mysql_fetch_row($tuteurs2);
                }
            ?>
                
            <br/>
        </div>
        </div>
            
         <script type="text/javascript">
<?php
echo "layer = new Array(",$divs,");";
echo "doModalAll(layer);";
//echo "closeAll()";
?>
            </script>

