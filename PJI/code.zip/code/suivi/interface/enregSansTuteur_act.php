<?php
    require_once ABS_START_PATH.'/secure/auth.php';

    if (!hasRole(PROF_ROLE))
        redirectAuth(null);
?>

        <?php
            require_once(ABS_START_PATH."/dbmngt/connect.php");
            require_once(ABS_START_PATH."/rss/rss.php");
            
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

    ?>

<div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 1 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Etat de l'opération</a></div>
<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
<!-- FIN MENU -->

     <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        <?php
            if (!array_key_exists("tuteurRef",$_REQUEST))
                die("Comment etes-vous arrivés ici?");
            echo "<p><b>";
            if ($_REQUEST["tuteurRef"]=="nouveau")
                if ((array_key_exists("prenom",$_REQUEST) && strlen($_REQUEST["prenom"])>0)
                        ||(array_key_exists("nom",$_REQUEST)&& strlen($_REQUEST["nom"])>0 ))
                    echo $_REQUEST["prenom"]," ",$_REQUEST["nom"];
                else
                    die("<h2>Problème</h2>Vous devez renseigner votre nom! <br/><a href='sansTuteur.php'>Revenez à l'étape de sélection!</a>");
              else
                echo $_REQUEST["tuteurRef"];
              echo "</b>";
              echo " nous vous rémercions pour vos choix!</p>";

            $choix=$_REQUEST["selection"];
            $formation=$_REQUEST["formationRef"];
            $altRef=$_REQUEST["altRef"];
            $mail_resp=$_REQUEST["mail_resp"];
            $tuteurRef=$_REQUEST["tuteurRef"];
            $et_pn=$_REQUEST["et_pn"];

        ?>
        <!--p>
        Les personnes suivantes : <b><?php echo $_REQUEST["mail_resp"]; ?></b>
        - ont été informés de vos choix.
        </p-->
        <!--br/>Détail rêquete ... Ne sera pas réténu dans la version finale.<hr/-->
        <?php
            
            $updateQuery="INSERT INTO `temp_tuteurs` (`etat`,`tuteurRef`,`formationRef`,`alternanceRef`) VALUES ";
        
            echo "<ol>";
            $updateQuery=$updateQuery."("."0".",";
            $updateQuery=$updateQuery."'".$tuteurRef."',";
            $updateQuery=$updateQuery."'".$formation[$choix[0]]."',";
            $updateQuery=$updateQuery."'".$altRef[$choix[0]]."')\n";

            echo "<li>".$et_pn[$choix[0]]."(".$formation[$choix[0]].")</li>";

            for ($i=1;$i<count($choix);$i++)
            {
                $updateQuery=$updateQuery.",("."0".",";
                $updateQuery=$updateQuery."'".$tuteurRef."',";
                $updateQuery=$updateQuery."'".$formation[$choix[$i]]."',";
                $updateQuery=$updateQuery."'".$altRef[$choix[$i]]."')\n";

                echo "<li>".$et_pn[$choix[$i]]."(".$formation[$choix[$i]].")</li>";
            }
            $updateQuery=$updateQuery.";";

            echo "</ol>";
            //echo $updateQuery;

            $conn=doConnection();
            $res=mysql_query($updateQuery,$conn);

            if(!$res) 
            {   echo "Vos choix n'ont pas pu être enregistrés.<br/>contacter marius.bilasco at lifl.Fr<br/>";
                die();
            }
        ?>
        <p>
        Vous avez choisi <b><?php echo count($choix); ?> étudiant<?php if (count($choix)>1) echo "s"; ?></b>.</p>
        <p>Bientôt, les responsables de formation vous informeront des étudiants qui vous seront attribués.<br/>
        Nous vous rémercions d'avoir pris le temps de compléter le formulaire.<br/>
        </p>

        
        <!--hr/><br/-->
        <?php
            regenerateAllTuteursChoixRss();
        ?>
       <!-- ?php
        //TODO adapter les envois de mails aux tuteurs et responsables
        $headersMail  = 'MIME-Version: 1.0' . "\r\n";
        $headersMail .= 'Content-type: text/plain; charset=utf-8' . "\r\n";
        $headersMail .= "From: \"Marius Bilasco\" <marius.bilasco@univ-lille1.fr> \r\n".

                    "Subject: [stalt] souhaits étudiant \r\n".
                    "To: \"".$_REQUEST["mail_resp"]."> \r\n".
                    "Cc: \"".
                    "\"Marius Bilasco\" <marius.bilasco@univ-lille1.fr> \r\n";
        $file=file(ABS_START_PATH."/msgs/souhaitTuteur_template.txt");

        $msgMail=str_replace("%TUTEUR%",$p_p." ".$p_n,implode('',$file));


        echo "<p>",str_replace("\n","<br/>",$headersMail),"</p>";
        echo "<p>",str_replace("\n","<br/>",$msgMail),"</p>";
//        echo "<p>",$headersMail,"</p>";
//        echo "<p>",$msgMail,"</p>";
//
        echo "<hr/>";

      if (mail("","",$msgMail,$headersMail))

            echo "E-mail envoyé avec succès à ",$et_p," ",$et_n," et ", $p_p, " ", $p_n, " !";
      else
            echo "Pb. avec envoi!";
       ?-->
        </div>
     </div>