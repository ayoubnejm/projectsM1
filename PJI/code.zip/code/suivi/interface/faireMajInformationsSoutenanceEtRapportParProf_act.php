<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        <?php
        require_once(ABS_START_PATH."/secure/auth.php");
        if (!hasRole(RESP_ROLE))
            redirectAuth(null);
        /*
         * To change this template, choose Tools | Templates
         * and open the template in the editor.
         */
        
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/html/dbutils.php");
        require_once(ABS_START_PATH."/html/escaping.php");

        
        $formation=getParam("formation",null);
        if ($formation==null) die("Demande de maj invalide!");
       
        $dateRemise=doDBEscape(getParam("dateRemise",null));
        $datesSoutenance=doDBEscape(getParam("datesSoutenance",null));
        $longueurRapport=doDBEscape(getParam("longueurRapport",null));
        $dureeSoutenance=doDBEscape(getParam("dureeSoutenance",null));
        $obsEtuds=doDBEscape(getParam("obsEtuds",null));
        $obsTuteurs=doDBEscape(getParam("obsTuteurs",null));
        $lienExterne=doDBEscape(getParam("lienExterne",null));
        
        ?>
        <h2>Mise à jour des informations concernant le rapport et la soutenance de la formation <?php echo $formation ?></h2>
        <a onClick="javascript:history.go(-2)"><font style="color:blue;text-decoration: underline">Revenir à la page précédente</font></a><br/>
        <?php
            $conn=doConnection("fil_dept");
            $queryString="select * from soutenance where formationRef='".
                            $formation."' and obsolete=0 and anneeReference=".$_SESSION[REF_YEAR];
            echo $queryString;
            $rows=mysql_query($queryString,$conn);
            if (mysql_fetch_row($rows)!=false)
              $exists=1;
            else
              $exists=0;
              
            $res=true;
            $queryString="set autocommit=0 ";
            $res=$res && !(!mysql_query($queryString,$conn));
            $queryString="begin ";
            $res=$res && !(!mysql_query($queryString,$conn));
            if ($res!=false)
            {
              $queryString=$exists==1?("update soutenance set dateRemise='".$dateRemise."',
                                datesSoutenances='".$datesSoutenances."',
                                longueurRapport='".$longueurRapport."',
                                duréeSoutenance='".$dureeSoutenance."',
                                observationsTous='".$obsEtuds."',
                                observationsTuteurs='".$obsTuteurs."',
                                lienExterne='".$lienExterne."'
                                where formationRef='".$formation."' and anneeReference<=".$_SESSION[REF_YEAR]):
                                ("insert into soutenance values (".$_SESSION[REF_YEAR].",0,'".$formation."',
                                                '".$dateRemise."',
                                                '".$datesSoutenance."',
                                                '".$longueurRapport."',
                                                '".$dureeSoutenance."',
                                                '".$obsEtuds."',
                                                '".$obsTuteurs."',
                                                '".$lienExterne."'
                                                )");
              $res=$res && !(!mysql_query($queryString,$conn));
              echo $queryString;
            }  
            if ($res!=false && $exists==0)
            {
              $queryString="update soutenance set obsolete=1
                                where formationRef='".$formation."' and anneeReference<".$_SESSION[REF_YEAR];
              $res=$res && !(!mysql_query($queryString,$conn));
              echo $queryString;
            }

            if ($res==false)
            {
                echo "<br/>";echo mysql_errno($conn)." - ".mysql_error($conn);echo "<br/>";
                mysql_query("rollback",$conn);
                die("pb updating information");
            }
            $queryString="commit ";
            $res=$res && !(!mysql_query($queryString,$conn));

            echo "Informations mise à jour!<hr/>";
            return true;
        ?>

 </div>
        </div>