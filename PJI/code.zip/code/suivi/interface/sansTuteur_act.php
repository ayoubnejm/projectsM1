<?php
require_once  ABS_START_PATH.'/secure/auth.php';

if (!hasRole(PROF_ROLE))
    redirectAuth(null);
?>
<?php
//require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/dbmngt/queries.php");

require_once(ABS_START_PATH."/html/utils.php");
require_once(ABS_START_PATH."/html/dbutils.php");

// Ajout JTA
require_once(ABS_START_PATH."/distance/calculDistance.php");
// Fin ajout
$formation = getParam("formation", "L3INFOFI,L3MIAGEFI,M2MIAGEFI,M2ESERVFI,M2IAGLFI,M2TIIRFI,M2MOCADFI,M2IVIFA");
//$formation=getParam("formation","L3INFOFI,L3MIAGEFI,M2MIAGEFI,M2ESERVFI,M2IAGLFI,M2TIIRFI,M2MOCADFI,M2IVIFA");
$sansTuteur = getParam("sansTuteur", "OUI");

$_SESSION["formation"] = $formation;
$_SESSION["sansTuteur"] = $sansTuteur;

$login = getParam(CK_USER, null);
$conn = doConnection();
//$res=doQuerySansTuteur($conn,$formation);
?>

<SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
<SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>


<div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Choix</a></div>
<div class="menuitem2" id="item_1"><a href="#" onclick="changeClass(this)">Notice d'utilisation</a></div>
<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
<!-- FIN MENU -->

     <div id="contenu">
        <div id="cadre_1" class="contenu-item2 off">
        Veuillez sélectionner la formation et l(es)'étudiant(s) que vous souhaitez encadrer.<br/>
        Vos choix seront validés ultérieurement par les responsables de formation et vous
        serez prévenus par mail.
        <br/><br/>
        </div>
     <div id="cadre_0" class="contenu-item2 on">
       <br/>
     <?php
            $keysValues=constructGrantedGroupesKeys(false,true);
            $formation=createSelectFormKeyValuesAndTargetPage("formationForm","formation",$keysValues,$formation,getParam("page"),"Choisissez formation : ");

            $res = doQueryListEtudiantsParFormation($conn, $formation);
            
            $keysSansTuteur= array("OUI", "NON", "EXCL", "ENTR");
            $valuesSansTuteur = array("tous les étudiants",
                "les étudiants sans tuteurs potentiels",
                "les étudiants sans tuteur retenu",
                "les étudiants ayant trouvé une entreprise");
          $sansTuteur=createSelectFormKeyValuesAndTargetPage("sansTuteurForm","sansTuteur",array("keys"=>$keysSansTuteur,"values"=>$valuesSansTuteur),$sansTuteur,getParam("page"),"Situation étudiants :  : ");

        ?>
        <form id="choixEtudiantsForm" action="<?php echo ABS_START_URL; ?>/index.php" method="POST">
            <input type="hidden" value="interface/enregSansTuteur_act" name="page"/>
            <?php
            //echo "<input type='hidden' name='service' value='". $service ."'/>";
            ?>
            <h2>Informations sur les étudiants</h2>
            <?php
            if (mysql_num_rows($res) == 0)
                die("problem query for retrieving students! No student found!");

            $row = mysql_fetch_row($res);
            ?>
            &nbsp;&nbsp;&nbsp; - cochez les cases des étudiants qui vous intéressent, puis transmettez vos choix.
            <!--input type="submit" value="Transmettre choix"/-->
            <br/><br/>
                <table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1">
                <thead><tr>
      
                        <th></th>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Formation</th>
                        <th>Ville / Kilométrage</th>
                        <th>Entreprise</th>
                        <th>Tuteur (potentiels)</th>
                        <th><div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">dÃ©tails</a--></td>
                    </tr>
                </thead>
                <tbody>
<?php
$i = 0;
$divs = "'head'";
echo "<input type='hidden' name='tuteurRef' value='" . $login . "'/>";
$cmptEtud = 0;


$Distance = new calculDistance();

for (; $row; $row = mysql_fetch_row($res), $i = $i + 1) {



    echo "<input type='hidden' name='mail_resp[]' value='marius.bilasco@lifl.fr,", $row[4];
    if ($row[5])
        echo ",", $row[5];
    echo "'/>";

    $tuteurs = doQueryTuteursPotentiels($conn, $formation, $row[0]);
    $tuteur = null;
    $tuteurString = $row[15] ? "<b>" . $row[15] . "</b>" : null;

    if ((strcmp($row[15], "aucun") != 0) && ($sansTuteur == "EXCL" || $sansTuteur == "NON"))
        continue;

    if ((($tuteurs && mysql_num_rows($tuteurs) > 0) || (strcmp($row[15], "aucun") != 0)) && $sansTuteur == "NON")
        continue;

    $entr = $row[9];
    //echo "entreprise:".$entr;
    if (($entr === "__sans entreprise__") && ($sansTuteur === "ENTR"))
        continue;

    if ($tuteurs)
        $tuteur = mysql_fetch_row($tuteurs);

    $tuteurPot = "(";
    while ($tuteur) {
        if (strcmp($tuteur[0], "nouveau") != 0)
            $tuteurPot.=" " . $tuteur[0];
        else
            $tuteurPot.=" " . $tuteur[1] . "_" . $tuteur[2];
        $tuteur = mysql_fetch_row($tuteurs);
    }
    $tuteurPot.=" )";

    if ($tuteurPot !== "( )") {
        //$tuteurString.=" ".$tuteurPot;
        $nbTutPot = (substr_count($tuteurPot, ' ') - 1);
        $tuteurString.=" ( " . $nbTutPot;
        //if ($nbTutPot>1)
        //  $tuteurString.="s";
        $tuteurString.=" )";
        if (strchr($tuteurPot, $_SESSION[CK_USER])) {
            $tuteurString.="<br/> dont vous-même";
        }
    } else {
        $tuteurString.=" (aucun)";
    }

    if ($row[15] != 'aucun')
        echo "<tr bgcolor=\"gray\">";
    else
    if ($tuteurPot !== "( )")
        echo "<tr>";
    else
        echo "<tr>";

    echo "<td>
                            <input type='checkbox' name='selection[]' value='", $cmptEtud, "'/>
                            <input type='hidden' name='altRef[]' value='", $row[0], "'/>
                        </td>";
    $cmptEtud++;

    echo "<td>", $row[1], "<input type='hidden' name='et_pn[]' value='" . $row[2] . " " . $row[1] . "'/></td>\n";
    echo "<td>", $row[2], "</td>\n";
    echo "<td>", $row[3];
    echo "<input type='hidden' name='formationRef[]' value='", $row[3], "'/>";
    echo "</td>\n";


// modification pour avoir la distance avec la ville

    echo "<td>", $row[6], "/"
            
           /* "<input type='button' value='Itineraire' onClick='window.location.href ='".$Distance->getLien($row[6])."'/>" ,*/
            ,"<a href='".$Distance->getLien($row[24]." ".$row[25]." ".$row[6])."' target='_blank'>$row[23] km</a> ",
            "</td>\n";
//Fin modif
    echo "<td>", substr($row[9],0,20), "</td>\n";
    echo "<td align='center'>&nbsp;", $tuteurString, "</td>\n";
    echo "<td>" . $row[16] . " <div id='td", $i, "' style='visibility:hidden'><a name=\"#", $i, "\"/>";
    echo "<div style='top:30%;left:15%;width:60%;border:3px solid black;background-color:rgba(100,100,100,1);'>";
    echo "<table border='1' bgcolor='#aaaaaa'>";
    echo "<tr><td>Referent</td>", "<td>", $row[7], "</td></tr>";
    echo "<tr><td>Missions</td>", "<td>", $row[10], "</td></tr>";
    echo "<tr><td>Services</td>", "<td>", $row[11], "</td></tr>";
    echo "<tr><td>Clients</td>", "<td>", $row[12], "</td></tr>";
    echo "<tr><td>Envirnmnt Tech.</td>", "<td>", $row[13], "</td></tr>";
    echo "</table><input type='button' value='Cacher' onClick='javascript:showHideModal(\"td", $i, "\");'/></div>";
    echo "</div><a href='#", $i, "' onClick='javascript:showHideModal(\"td", $i, "\");'>détails</a></td>";
    echo "\n</tr>";
    $divs = $divs . ",'td" . $i . "'";
}
$nbDivs = $i;
?>
                </tbody>
            </table>
            <br/>
            <input type="submit" value="Transmettre choix"/>
            <script type="text/javascript">
<?php
echo "layer = new Array(",$divs,");";
echo "doModalAll(layer);";
?>
            </script>

        </form>
     </div>
     </div>