<?php
// Auteur VIJ
require_once(ABS_START_PATH."/secure/auth.php");


    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
require_once(ABS_START_PATH."/dbmngt/queries.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/dbutils.php");
?>

<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Accès aux pages d'administration</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
    
<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
		

<br/><br/>	

 <?php
 
 // partie relative a la modification des informations du referent

 

            $modificationReferent = getParam("modifierReferent", "");

            if($modificationReferent==1){
 
                           $tel = getParam("tel", "");
                           $mail = getParam("mail", "");
                           $fonction=getParam("fonction", "");
                           $referentCle=getParam("referent", "");
                           $conn = doConnection();
                           $res= doQueryUpdateReferent($conn, $referentCle,$tel,$mail,$fonction); 

                        if($res){ ?>
                           <script type="text/javascript">
                                 window.alert(" Modification avec succes. ");
                           </script>
                        <?php }else{ ?>
                           <script type="text/javascript">
                                  window.alert(" erreur : Impossible de modifier les informations de ce référent  ");
                           </script>

                       <?php }

            }

 
 // Ajout d'un petit formulaire permettant de ressaisir les informations relatives au référents
 $referentz = getParam("referent", "");
 $conn = doConnection();
 $res = doQueryAvoirLeReferent($conn, $referentz);
   


     
   
       while ( $referent = mysql_fetch_row($res)) {
       echo "<form  method = 'post' action=".ABS_START_URL."/index.php >
              <INPUT type='hidden' value='interface/modifRefPopUp_act' name='page'>
             <INPUT type='hidden' value='1' name='modifierReferent'>
             <INPUT type='hidden' value='".$referentz."' name='referent'>"
             ." <table witdh='400'>
                <tr>
                <td width='180'>
               Nom :</td><td>'".$referent[0]."'<br/><br/> 
                          </td></tr><tr><td>
               Prenom :</td><td>'".$referent[1]."'<br/><br/>
                          </td></tr><tr><td>
               Telephone :</td><td><INPUT type=text name='tel' value='".$referent[2]."'><br/>
                          </td></tr><tr><td>
               Mail :    </td><td><INPUT type=text name='mail' value='".$referent[3]."'><br/>
                          </td></tr><tr><td>
               Fonction :</td><td><INPUT type=text name='fonction' value='".$referent[4]."'><br/>
                          </td></tr><tr><td>
                          </td></tr><tr>
                          <td><INPUT type=submit value='Modifier' style='color:orange' onclick=\"return confirm('Etes-vous sur de modifier ces informations ?')\" /></td>
               </form>

               <form  method='post' action=".ABS_START_URL."/index.php >
               <input type='hidden' name='page' value='interface/gestionBureaux_act'/>
               <td colspan='2' align='center'><input type='submit' style='color:orange'  value=' Précédent '/></td></tr>
               </table>  </form>";
       }
      

?>
</div>
</div>
</body>
</html>
