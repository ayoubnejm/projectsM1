<?php
    require '../secure/auth.php';
    error_log("accueilTuteur for ".getParam(CK_USER,"UNKOWNN"));

    if (!hasRole(STUD_ROLE))
        redirectAuth(null);
?>
<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Menu tuteurs</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
    </head>
    <body>
        <H2 style="margin-bottom:1pt">Bonjour <b><?php echo $_SESSION[CK_USER];?> (étudiant)</b>

        </H2>
        <table>
          <tr style="font-size:10pt">
          <td> <a href="welcomeEtudiant.php" target="main">Accueil</a> |</td>
          <td><a href="../disconnect.php" target="_top">Déconnexion</a></td>

          </tr>
        </table>

    </body>
</html>
