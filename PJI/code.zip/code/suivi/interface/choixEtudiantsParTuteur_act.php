<?php
require_once(ABS_START_PATH."/secure/auth.php");

if (!hasRole(PROF_ROLE))
    redirectAuth(null);
?>
<?php
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/dbmngt/queriesTuteur.php");
require_once(ABS_START_PATH."/html/utils.php");
//Ajout JTA 
require_once(ABS_START_PATH."/distance/calculDistance.php");
// Fin ajout 

$formation = getParam("formation", "%");
$_SESSION["formation"] = $formation;

$tuteurParam = getParam(CK_USER, $_SESSION[CK_USER]);
$_SESSION["tuteurParam"] = $tuteurParam;


$conn = doConnection();
?>

<div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 1 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Vos choix</a></div>
<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
<!-- FIN MENU -->
<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">

        <form id="formationForm" action="<?php echo ABS_START_URL; ?>/index.php" method="POST">
          <input type="hidden" name="page" value="interface/choixEtudiantsParTuteur_act"/>
            <?php
            $formations = doTuteurQueryChoosedFormations($conn, $tuteurParam);
            if (!mysql_num_rows($formations)) {
                echo "</form><br/>Pour l'instant vous n'avez demandé de suivre d'étudiant!";
                exit(1);
            }

            $keys = Array();
            $values = Array();
            $keys[0]='%';
            $values[0]="Toutes";
            for ($k = 1, $formation = mysql_fetch_row($formations); $formation; $formation = mysql_fetch_row($formations), $k = $k + 1) {
                //echo "processing ".$formation[1]." ".$formation[0]."<br/>";
                $keys[$k] = $formation[1];
                $values[$k] = $formation[0];
                //echo "processing ".$keys[$k]." ".$values[$k]."<br/>";
            }

            $i = 0;
            for (; ($i < count($keys)) AND ($keys[$i] !== $formation); $i++)
                ;
            if ($i == count($keys)) {
                $i = 0;
                $formation = $keys[$i];
            }

            echo "Choisissez la formation : ";
            createSelectWithOnChange("formation", $keys, $values, $i, "javascript:submit();");
            ?>
        </form>

        <?php
        $i = 0;
        $divs = "'head'";

        $etudiants = doTuteurQueryListChoices($conn, $tuteurParam);

        if (!mysql_num_rows($etudiants)) {
            echo "<h4 style='color:red'>Aucun étudiant</h4>";
            $tuteur = mysql_fetch_row($tuteurs2);
        }
        if (!mysql_num_rows($etudiants))
            die();
        ?>

        <table class="edt" style="font-size:9pt">
            <thead><tr class="entete">
                    <td>Nom</td>
                    <td>Prenom</td>
                    <td>Formation</td>
                    <td>Ville/Kilométrage</td>
                    <td>Entreprise</td>
                    <td><div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">details</a--></td>
                </tr>
            </thead>
            <tbody>
                <?php
                $Distance = new calculDistance();
                $row = mysql_fetch_row($etudiants);
                while ($row) {
                    //if ($row[16]===NULL)
                    echo "<tr class='t".($i%2==0?'d':'p')."' >";
//                        else
//                            echo "<tr style='color:yellow'>";
//                      
                    echo "<td>", $row[1], " </td>";
                    echo "<td>", $row[2], " </td>";

                    echo "<td>", $row[3], " </td>";
                    if ($row[4]) {
                        echo "<td>", $row[4], "/", $row[6], "Km"
                        , "<a href='" . $Distance->getLien($row[7] . " " . $row[8] . " " . $row[4]) . "' target='_blank'>Itineraire</a ></td>";
                        echo "<td>", $row[5], "</td>";
                    }                    
                    echo "<td><form name='form", $i, "' action='".ABS_START_URL."/index.php' method='post'>";
                    echo "<input type='hidden' name='page' value='actions/faireSupprimerChoix_act'/>";
                    echo "<input type='hidden' name='altCle' value='", $row[0], "'/>";
                    echo "<input type='hidden' name='tuteurRef' value='", $tuteurParam, "'/>";
                    echo "<input type='submit' value='Retirer'/>";
                    echo "</form></td>";
                    echo "</tr>";
                    $row = mysql_fetch_row($etudiants);
                    $i = $i + 1;
                }
                ?>
            </tbody>
        </table>

        <br/>


        <script type="text/javascript">
<?php
echo "layer = new Array(", $divs, ");";
echo "doModalAll(layer);";
//echo "closeAll()";
?>
        </script>
        </div>
</div>