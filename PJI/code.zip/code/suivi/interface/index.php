<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/config/auth.ini.php");
header('Location: '.INDEX_PAGE) ;
?>
