<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Config
 *
 * @author Julien
 */
class Config {
   
    protected $fi_stage;
    protected $fil_dept;
    protected $fil_entr;
    
       function __construct()
    {
        $this->fi_stage = "fi_stages112";
        $this->fil_dept = "fil_dept2";
        $this->fil_entr = "fil_entr2";
    }
    
    
   function getFi_stage(){
       return $this->fi_stage;
   }
    
   function getFil_dept(){
       return $this->fil_dept;
   }
    
   function getFil_entr(){
       return $this->fil_entr;
   }
}

?>
