<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/secure/auth.php");
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");

    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

   $alts=doQueryRenduEtapeBilan($conn,$altRefs);

   error_log($_SESSION[REF_YEAR]." vs ".getCurrYear());
   
   if (hasRole(PROF_ROLE)==FALSE)
      echo "<a href='../interface/accueilEtudiant.php'>Retour page accueil.</a>";
   else
      if($_SESSION[REF_YEAR]>=getCurrYear()-1){
        error_log("update available");
                echo "<table width='100%'><tr><td width='75%'></td><td align='center'>".
                        "<form method='post' action='".ABS_START_URL."/index.php'>".
                          "<input type='hidden' name='page' value='interface/faireActionsEtudiants_act'/>".
                            "<input type='hidden' name='action' value='majEtapeBilan_act' />".
                            "<input type='hidden' name='selection[]' value='".$selection[0]."' />".
                            "<input type='submit' style='color:orange' value='Modifier'/>".
                        "</form>\n".
                        "</td><td align='right'>".
                        ($alts?("<form method='post' action='".ABS_START_URL."/index.php'>".
                          "<input type='hidden' name='page' value='interface/faireActionsEtudiants_act'/>".
                            "<input type='hidden' name='action' value='notifierCrEtapeBilan_act' />".
                            "<input type='hidden' name='selection[]' value='".$selection[0]."' />".
                            "<input type='submit' style='color:orange' value='Notifier Ref-Etud' alt='Notifier par mail référent et étudiant'/>".
                        "</form>"):"").
                        "</td></tr></table>";
            }
             
    if ($alts===FALSE) {
      echo "<table align='center' style='border-width: 0px;border-style:solid;font-size:11px' width='".$width."'>
                <tr>
                    <td>Aucune information!</td>";
      echo "</tr></table>";
      
    } else {
    
    $alt=mysql_fetch_row($alts);
    
    $nbCols=2;
    $space=50;
    $width="95%";

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $et_pn=$alt[1]." ".$alt[2]; 
        $avecSoutenance=strpos($alt[3],"M1MIAGE")===FALSE;

        $dateR=$alt[4]=="0000-00-00"?"":$alt[4];
        
        $pointsPositifs=to_minimum_lines(to_html($alt[5]),5);
        $pointsProgres=to_minimum_lines(to_html($alt[6]),5);
        $avancementProjet=to_minimum_lines(to_html($alt[7]),4);
        $dateS=$alt[8]=="0000-00-00"?"":$alt[8];

        $signEtud=$alt[9]!=0?"OUI":"NON";
        $rmqEtud=to_minimum_lines(to_html($alt[10]),3);

        $signRef=$alt[11]!=0?"OUI":"NON";
        $rmqRef=to_minimum_lines(to_html($alt[12]),3);

        $signTut=$alt[13]!=0?"OUI":"NON";
        $rmqTut=to_minimum_lines(to_html($alt[14]),3);
        
        echo "<div id='cadre_0' class='contenu-item2 on'>";
        echo " <table align='center' style='border-width: 0px;border-style:solid;font-size:11px' width='".$width."'>
                      <tr class='entete'><td>$et_pn</td></tr>
                        ";
       echo "
                <tr>
                    <td style='border-width: 1px;border-style:' width='".$width."'>
                        <b>Date rencontre (aaaa-mm-jj) </b>: ",$dateR,"<br/></td>
                    </td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Quels sont les points positifs ?</b><br/>
                        <div style='width:".$width."'>
                        <p>",$pointsPositifs,"</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Quels sont les points de progrès ?</b><br/>
                        <div style='width:".$width."'>
                        <p>",$pointsProgres,"</p>
                        </div>
                    </div></td>
                </tr>";
        if ($avecSoutenance)
            echo  "
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Quel est l'avancement du projet ?</b><br/>
                        <div style='width:".$width."'>
                        <p>",$avancementProjet,"</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td style='border-width: 1px;border-style:' width='".$width."'>
                        <b>Date probable de soutenance (aaaa-mm-jj) :</b> ",$dateS,"<br/></td>
                    </td>
                </tr>
                ";
        echo "
                 <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation de l'étudiant </b> <i>".$signEtud."</i> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p>".$rmqEtud."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation du référent </b> <i>".$signRef."</i> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p>".$rmqRef."</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation du tuteur MIAGE </b> <i>".$signTut."</i> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p>".$rmqTut."</p>
                        </div>
                    </div></td>
                </tr>
            </table>";
        echo "</div>";

    }
   
}
?>