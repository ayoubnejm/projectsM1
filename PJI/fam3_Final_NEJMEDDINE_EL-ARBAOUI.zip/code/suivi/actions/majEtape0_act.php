
<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/html/dbutils.php");
require_once (ABS_START_PATH."/calendar/tc_calendar.php");
    $conn = doConnection();

    $altRefs = "'" . $selection[0] . "'";
    for ($i = 1; $i < count($selection); $i++)
        $altRefs.=", " . "'" . $selection[$i] . "'";

    //echo $altRefs;
    $alts = doQueryRenduEtape0($conn, $altRefs);
    $alt = mysql_fetch_row($alts);
    if ($alt==false) {
      die("Aucune information dispo à mettre à jour!");
    }

    $nbCols = 2;
    $space = 50;
    //$width = ((1000 - $space * $nbCols) / $nbCols) < 500 ? 500 : ((1000 - $space * $nbCols) / $nbCols);
    $width=600;
   

    for ($i = 0; $alt; $alt = mysql_fetch_row($alts), $i++) {
        $altCle = $alt[0];
        $et_pn = $alt[1] . " " . $alt[2];
        $et_entrNom = $alt[3];
        $et_entrCle = $alt[21];
        $et_tel = $alt[4];
        $et_m = $alt[5];
        $et_mlille1 = $alt[24];

        $t_p = $alt[6];
        $t_n = $alt[7];
//
        $t_ref = $alt[20];
        $entr_bureauRef = $alt[22];

        $r_p = $alt[10];
        $r_n = $alt[11];
        $r_fonction = $alt[12];
        $r_tel = $alt[13];
        $r_m = $alt[14];
        $r_cle= $alt[26];
        $r2_cle= $alt[27];
        $r_opca = $alt[15];

        $d_sign = $alt[16] == "0000-00-00" ? "" : $alt[16];
        $d_opca = $alt[17] == "0000-00-00" ? "" : $alt[17];
        $d_deb = $alt[18] == "0000-00-00" ? "" : $alt[18];
        $d_fin = $alt[19] == "0000-00-00" ? "" : $alt[19];

        $regie_entrCle=$alt[28];
        $regie_bureauRef=$alt[29];
        $regie_referent=$alt[30];
        $regie_referent2=$alt[31];
        $regie_adresse=$alt[32];
        $entr_adresse=$alt[33];
        $ref_coords=$alt[34];
        $ref2_coords=$alt[35];
        $regieRef_coords=$alt[36];
        $regieRef2_coords=$alt[37];
        $formationRef=$alt[38];
        $nbNotifs=$alt[39];
        $estFA=substr($formationRef,strlen($formationRef)-2,2)=="FA";

        
        echo "<SCRIPT src='".ABS_START_URL."/js/common.js' lang='javascript'></SCRIPT>";
        echo "<SCRIPT src='".ABS_START_URL."/js/modal.js' lang='javascript'></SCRIPT>";
        echo "<SCRIPT src='".ABS_START_URL."/js/form.js' lang='javascript'></SCRIPT>";

        echo "<SCRIPT src='".ABS_START_URL."/calendar/calendar.js' lang='javascript'></SCRIPT>";
        echo "<SCRIPT src='http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js' lang='javascript' ></SCRIPT>";

        echo "<SCRIPT src='".ABS_START_URL."/ajax/inscrireEntreprise_modal.js' lang='javascript'></SCRIPT>
                \n<script type='text/javascript'>generateInscrireEntrepriseForm();</script>";

        echo "<SCRIPT src='".ABS_START_URL."/ajax/inscrireBureau_modal.js' lang='javascript'></SCRIPT>
                \n<script type='text/javascript'>generateInscrireBureauForm();</script>";

        echo "<SCRIPT src='".ABS_START_URL."/ajax/inscrireReferent_modal.js' lang='javascript'></SCRIPT>
                \n<script type='text/javascript'>generateInscrireReferentForm();</script>";

        echo "<SCRIPT src='".ABS_START_URL."/ajax/updateBureau_modal.js' lang='javascript'></SCRIPT>
                \n<script type='text/javascript'>generateUpdateBureauForm();</script>";

        echo "<SCRIPT src='".ABS_START_URL."/ajax/updateReferent_modal.js' lang='javascript'></SCRIPT>
                \n<script type='text/javascript'>generateUpdateReferentForm();</script>";
        
        echo "<div id='cadre_0' class='contenu-item2 on'>";
        
        echo "<form id='form0' name='form", $i, "' action='".ABS_START_URL."/index.php' method='post'>";
        echo "<input type='hidden' name='page' value='actions/faireMajEtape0_act'/>";
        echo "<input type='hidden' name='altCle' value='", $altCle, "'/>";
        echo " <table align='center' class='edt' style='font-size:11px'>
                <tr class='entete'>
                    <td colspan='2' style='border-width: 1px;border-style:solid;text-align:left' colspan='2'>
                        L'ETUDIANT : $et_pn <input type='hidden' name='et_pn' value='".$et_pn."'/><input type='hidden' name='et_cle' value='" . $alt[23] . "'/></td>
                <tr><td>tél. perso</td><td><input type='text' value='", $et_tel, "' name='et_tel'/></td></tr>
                        <tr><td>e-mail</td><td><input type='text' value='", $et_m, "' name='et_m'/></td></tr>
                        <tr><td>e-mail Lille1</td><td>", (strlen($et_mlille1) > 0 ? $et_mlille1 : 'en attente d\'inscription'), "</td></tr>
                        
                    <tr class='entete'>
                    <td style='border-width: 1px;border-style:solid;text-align:left' colspan='2'>
                        LE TUTEUR : ";
        if (hasRole(RESP_ROLE))
            createTuteurSelect($conn, "t_ref", $t_ref, true, '');
        else {
             if ($nbNotifs>0) {
                echo $t_p, " ", $t_n;
             } else if ($t_ref) echo "en attente"; else echo "aucun";

             echo "<input type='hidden' value='", $t_ref, "' name='t_ref'/>";
        }


        echo
                "</td></tr>
                <tr class='entete'><td style='border-width: 1px;border-style:solid;text-align:left' colspan='2'>
                        L'ENTREPRISE : ";
            createEntrepriseSelect($conn, "fa_entreprise_cle", $et_entrCle, "choix(this.form)");
        echo "<a href='#' onclick=\"inscrireEntreprise('form".$i."','entr')\"/><font size='-1'>nouvelle Entreprise</font></a>
        <br/>
              </td></tr>
              <tr><td>Bureau </td><td>";
        createBureauSelect($conn,"fa_bureau_cle",$et_entrCle,$entr_bureauRef,"showCoords('fa_bureau_cle')");
        echo " <a  href=\"#\" onclick=\"window.location=getSelectedItemBureau('form".$i."','entr')\"><font size='-1'>nouveau bureau</font></a>
            <br/><font size='-1' style='color:lightgrey'><div id='fa_bureau_cle_coords' style=".((strlen($entr_adresse)==0)?'display:none':'').">
             <a href=\"#\" onclick=\"updateBureau('form".$i."','entr')\"> ... modifier adresse siège</a>
            </div>
            </font></td></tr>
            ";
        echo "<tr>
            <td> 
                        Referent : 
                        </td>
                        <td>";
        createReferentSelect($conn,"fa_referent_cle",$et_entrCle,$r_cle,"showCoords('fa_referent_cle')");
        echo "<a  href=\"#\" onclick=\"inscrireReferent('form".$i."','entr',1)\"><font size='-1'>nouveau référent</font></a>";
        echo "<br/><font size='-1' style='color:lightgrey'><div id='fa_referent_cle_coords' style=".((strlen($ref_coords)==0)?'display:none':'').">
           <a href=\"#\" onclick=\"updateReferent('form".$i."','entr',1)\"> ... modifier coordonnées</a>
            </div></font>
            <div id='nv_ref'></div></td></tr><tr>
            <td>
                        Referent 2 :
                        </td>
                        <td>";
        createReferentSelect($conn,"fa_referent2_cle",$et_entrCle,$r2_cle,"showCoords('fa_referent2_cle')");
        echo "<a  href=\"#\" onclick=\"inscrireReferent('form".$i."','entr',2)\"><font size='-1'>nouveau référent</font></a>";
        echo "<br/>
            <font size='-1' style='color:lightgrey'>
            <div id='fa_referent2_cle_coords' style=".((strlen($ref2_coords)==0)?'display:none':'').">
           <a href=\"#\" onclick=\"updateReferent('form".$i."','entr',2)\"> ... modifier coordonnées</a>
            </div></font>
                    </td>
                    </tr>
        ";
        //Fin ajout
        if ($estFA) {
          echo "<tr><td>OPCA concerné</td><td>";
          createOPCASelect($conn, "r_opca", $r_opca);
          //echo "<a href='".ABS_START_URL."/index.php?page=interface/inscrireOPCA_act'/><font size='-1'>nouvelle OPCA</font></a>";
          echo "</td></tr>";
        }

      echo "
                       
                <tr class='entete'>
                    <td style='border-width: 1px;border-style:solid;text-align:left'> Contrat
                        </td><td style='text-align:left'></td></tr>
                        <tr><td  width='", $width / 2, "'>date de signature du contrat </td><td>";
                   
                    $myCalendarSIGN = new tc_calendar("d_sign", true);
                    $myCalendarSIGN->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    //$myCalendarSIGN->setDate(date('d'), date('m'), date('Y'));
                    //$myCalendarSIGN->setDate(intval(substr($d_sign,8,2)),intval(substr($d_sign,5,2)),intval(substr($d_sign,0,4)));
                    $myCalendarSIGN->setDateYMD($d_sign);
                    $myCalendarSIGN->disabledDay("sun");
                    //error_log("from time : ".strtotime((intval(date('Y'))-3).'-1-1'));
                    //error_log("to time : ".strtotime((intval(date('Y'))+3).'-1-1'));
                    //$myCalendarSIGN->dateAllow((intval(date('Y'))-3).'-1-1', (intval(date('Y'))+3).'-1-1', true);
                    $myCalendarSIGN->setPath(ABS_START_URL."/calendar/");
                    $myCalendarSIGN->setDateFormat('Y-F-j');
                    $myCalendarSIGN->setAlignment('left', 'bottom');
                    error_log("d_sign : ".substr($d_sign,8,2)." - ".substr($d_sign,5,2)." - ".substr($d_sign,0,4));
                    $myCalendarSIGN->writeScript();
                    
         echo "</td></tr>";
      if ($estFA) {
          echo "<tr><td>date de l'accord OPCA </td><td>";
               
                    $myCalendarOPCA = new tc_calendar("d_opca", true);
                    $myCalendarOPCA->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    $myCalendarOPCA->setDate(intval(substr($d_opca,8,2)),intval(substr($d_opca,5,2)),intval(substr($d_opca,0,4)));
                    $myCalendarOPCA->disabledDay("sun");
                    //$myCalendarOPCA->dateAllow('' . date('d') . '-' . date('m') . '-' . date('Y'), '', false);
                    $myCalendarOPCA->setPath(ABS_START_URL."/calendar/");
                    $myCalendarOPCA->setDateFormat('Y-F-j');
                    $myCalendarOPCA->setAlignment('left', 'bottom');
                    //error_log("d_opca : ".substr($d_opca,8,2)." - ".substr($d_opca,5,2)." - ".substr($d_opca,0,4));
                    $myCalendarOPCA->writeScript();
                    
        echo "</td></tr>";
      }
      echo "<tr><td>début du contrat</td><td>";
         
                    $myCalendarDebut = new tc_calendar("d_deb", true);
                    $myCalendarDebut->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    $myCalendarDebut->setDate(intval(substr($d_deb,8,2)),intval(substr($d_deb,5,2)),intval(substr($d_deb,0,4)));
                    $myCalendarDebut->disabledDay("sun");
                    //$myCalendarDebut->dateAllow('' . date('d') . '-' . date('m') . '-' . date('Y'), '', false);
                    $myCalendarDebut->setPath(ABS_START_URL."/calendar/");
                    $myCalendarDebut->setDateFormat('Y-F-j');
                    $myCalendarDebut->setAlignment('left', 'bottom');
                    error_log("d_deb : ".substr($d_deb,8,2)." - ".substr($d_deb,5,2)." - ".substr($d_deb,0,4));
                    $myCalendarDebut->writeScript();

        
      echo "</td></tr><tr><td>fin du contrat</td><td>";
               
                    $myCalendarFin = new tc_calendar("d_fin", true);
                    $myCalendarFin->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    $myCalendarFin->setDate(intval(substr($d_fin,8,2)),intval(substr($d_fin,5,2)),intval(substr($d_fin,0,4)));
                    $myCalendarFin->disabledDay("sun");
                    //$myCalendarFin->dateAllow('' . date('Y') . '-' . date('m') . '-' . date('d'), '', false);
                    $myCalendarFin->setPath(ABS_START_URL."/calendar/");
                    $myCalendarFin->setDateFormat('Y-F-j');
                    $myCalendarFin->setAlignment('left', 'bottom');
                    error_log("d_fin : ".substr($d_fin,8,2)." - ".substr($d_fin,5,2)." - ".substr($d_fin,0,4));

                    $myCalendarFin->writeScript();

         
     echo "</td></tr>";
     echo "<tr class='entete'>
                    <td style='border-width: 1px;border-style:solid;text-align:left' colspan='2'>
        REGIE : ";
    createEntrepriseSelect($conn, "fa_regie_cle", $regie_entrCle, "choixRegie(this.form)");
    echo "<a href='#' onclick=\"inscrireEntreprise('form".$i."','entr')\"/><font size='-1'>nouvelle Entreprise</font></a>";

    echo "<br/>
      </td></tr>
                        <tr><td>Bureau (lieu d'alternance)</td><td>";
        createBureauSelect($conn,"fa_regie_bureau_cle",$regie_entrCle,$regie_bureauRef,"showCoords('fa_regie_bureau_cle')");
        echo "<a  href=\"#\" onclick=\"window.location=getSelectedItemBureau('form".$i."','regie')\"><font size='-1'>nouveau bureau</font></a>
            <br/><font size='-1' style='color:lightgrey'><div id='fa_regie_bureau_cle_coords' style=".((strlen($regie_adresse)==0)?'display:none':'').">
            <a href=\"#\" onclick=\"updateBureau('form".$i."','regie')\"> ... modifier adresse siège</a>
            </div>
            </font></td></tr>
            ";
        echo "<tr>
            <td>
                        Referent :
                        </td>
                        <td>";
        createReferentSelect($conn,"fa_regie_referent_cle",$regie_entrCle,$regie_referent,"showCoords('fa_regie_referent_cle')");
        echo "<a  href=\"#\" onclick=\"inscrireReferent('form".$i."','regie',1)\"><font size='-1'>nouveau référent</font></a>";
        echo "<br/><font size='-1' style='color:lightgrey'><div id='fa_regie_referent_cle_coords' style=".((strlen($regieRef_coords)==0)?'display:none':'').">
           <a href=\"#\" onclick=\"updateReferent('form".$i."','regie',1)\"> ... modifier coordonnées</a>
            </div></font>
</td></tr><tr>
            <td>
                        Referent 2 :
                        </td>
                        <td>";
        createReferentSelect($conn,"fa_regie_referent2_cle",$regie_entrCle,$regie_referent2,"showCoords('fa_regie_referent2_cle')");



        echo "<a  href=\"#\" onclick=\"inscrireReferent('form".$i."','regie',2)\"><font size='-1'>nouveau référent</font></a>";
        echo "<br/><font size='-1' style='color:lightgrey'><div id='fa_regie_referent2_cle_coords' style=".((strlen($regieRef2_coords)==0)?'display:none':'').">
           <a href=\"#\" onclick=\"updateReferent('form".$i."','regie',2)\"> ... modifier coordonnées</a>
            </div></font></td></tr>
          ";
        echo "<tr><td>
          <!--input type='button' value='Revenir en arrière' onclick='javascript:history.go(-1);'/-->
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        echo "</td><td align='right'><input type='submit' style='background-color:orange' value='Valider'/></td>
                </tr>";
       
        echo     "</table>";
        echo "</form>";
        echo "</div>";

        echo "<script type='text/javascript'>
            showCoords('fa_bureau_cle');
            showCoords('fa_referent_cle');
            showCoords('fa_referent2_cle');
            showCoords('fa_regie_bureau_cle');
            showCoords('fa_regie_referent_cle');
            showCoords('fa_regie_referent2_cle');

            </script>";
    }

?>
