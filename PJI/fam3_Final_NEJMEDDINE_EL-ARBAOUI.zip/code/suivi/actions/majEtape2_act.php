<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once (ABS_START_PATH."/calendar/tc_calendar.php");


   echo "<SCRIPT src='".ABS_START_URL."/calendar/calendar.js' lang='javascript'></SCRIPT>";
   echo "<SCRIPT src='http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js' lang='javascript' ></SCRIPT>";

    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtape2($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    $nbCols=2;
    $space=50;
    $width="95%";

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $et_pn=$alt[1]." ".$alt[2]; 
        $date=$alt[3]=="0000-00-00"?"":$alt[3];
        
        $adeqMission=to_minimum_lines(to_text($alt[4]),0);
        $integration=to_minimum_lines(to_text($alt[5]),0);

        $signEtud=$alt[6];
        $rmqEtud=to_minimum_lines(to_text($alt[7]),0);

        $signRef=$alt[8];
        $rmqRef=to_minimum_lines(to_text($alt[9]),0);

        $signTut=$alt[10];
        $rmqTut=to_minimum_lines(to_text($alt[11]),0);
        
        echo "<div id='cadre_0' class='contenu-item2 on' >";
        echo "<form name='form",$i,"' action='".ABS_START_URL."/index.php' method='post'>";
        echo "<input type='hidden' name='page' value='actions/faireMajEtape2_act'/>";
        echo "<input type='hidden' name='altCle' value='",$altCle,"'/>";
        echo "
                <b>L'ETUDIANT : ",$et_pn,"<input type='hidden' value='",$et_pn,"' name='et_pn'/></b><br/>
                <table align='center'>
                <tr>
                    <td style='border-width: 1px;border-style:' width='".$width."'>
                        <table>
                        <tr>
                            <td>Date rencontre (aaaa-mm-jj) : </td><td>";
                    $myCalendarRecontre = new tc_calendar("date", true);
                    $myCalendarRecontre->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    //$myCalendarSIGN->setDate(date('d'), date('m'), date('Y'));
                    //$myCalendarSIGN->setDate(intval(substr($d_sign,8,2)),intval(substr($d_sign,5,2)),intval(substr($d_sign,0,4)));
                    $myCalendarRecontre->setDateYMD($date);
                    $myCalendarRecontre->disabledDay("sun");
                    //error_log("from time : ".strtotime((intval(date('Y'))-3).'-1-1'));
                    //error_log("to time : ".strtotime((intval(date('Y'))+3).'-1-1'));
                    //$myCalendarSIGN->dateAllow((intval(date('Y'))-3).'-1-1', (intval(date('Y'))+3).'-1-1', true);
                    $myCalendarRecontre->setPath(ABS_START_URL."/calendar/");
                    $myCalendarRecontre->setDateFormat('Y-F-j');
                    $myCalendarRecontre->setAlignment('left', 'bottom');
                    //error_log("d_sign : ".substr($d_sign,8,2)." - ".substr($d_sign,5,2)." - ".substr($d_sign,0,4));
                    $myCalendarRecontre->writeScript();
      echo "</td></tr></table></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Le travail est-il en adéquation avec la mission confiée ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='adeqMission' style='width:95%' rows='6'>",$adeqMission,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Comment s'est passé l'intégration de l'étudiant ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='integration' style='width:95%' rows='6'>",$integration,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation de l'étudiant ",$signEtud," (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>",$rmqEtud,"</p>
                        
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation du référent <input type='checkbox' name='signRef'",($signRef!=0?"checked='checked' value='1'":""),"/>(remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='rmqRef' style='width:95%' rows='2'>",$rmqRef,"</textarea></p>

                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation du tuteur <input type='checkbox' name='signTut'",($signTut!=0?"checked='checked' value='1'":""),"/> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'>&nbsp;&nbsp;&nbsp;<textarea name='rmqTut' style='width:95%' rows='2'>",$rmqTut,"</textarea></p>
                        </div>
                    </div></td>
                </tr>";
                echo "<tr><td align='center'><input type='button' value='Revenir en arrière' onclick='javascript:history.go(-1);'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                echo "<input type='submit' style='align:right;background-color:orange' value='Valider'/></td>
                </tr>
            </table>";
        echo "</form>";
        echo "</div>";

    }

?>