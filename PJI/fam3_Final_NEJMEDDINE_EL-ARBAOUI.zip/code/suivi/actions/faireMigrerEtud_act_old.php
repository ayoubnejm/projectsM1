<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");

function faireAction($selection)
{
    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++) {

        //$altRefs.=", "."'".$selection[$i]."'";
       $altCle=$selection[$i];
       $query="insert into table fa_tutorat11.fa_etudiant (
                    select * from fa_tutorat.fa_etudiant
                      where etudCle in (select etudRef from contrat where alternanceCle like '".$altCle."')
                )";
       echo $query;
       $query="insert into table fa_tutorat11.fa_entreprise (
                    select * from fa_tutorat.fa_entreprise
                      where entrepriseCle in (select entrepriseRef from contrat inner join where alternanceCle like '".$altCle."')
                )";

       $query="insert into table fa_tutorat11.contrat ("
    }
}
?>