<?php 
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/dbmngt/queries.php");
        require_once(ABS_START_PATH."/html/dbutils.php");


        $altRefs=str_replace("\\","",getParam("altRefs",null));
        if ($altRefs===FALSE) die("Demande de migration invalide!");
        $etudNames=getParam("etudNames",null);
        $formationCible=getParam("formationCible",null);
        $anneeCible=getParam("anneeCible",null);


        echo "Migration de ".$etudNames." vers $formationCible - $anneeCible ... <br/> ";
        //echo "Vous pouvez re-inscrire des étudiants depuis le menu Re-Inscription ".$etudNames." de l'application STALT en cours ... <br/> ";

        $conn=doConnection();
        $etudCles=getEtudClesListFromAlternanceCle($conn,$altRefs);
        $res=true;
        $queryString="set autocommit=0 ";
        $res=$res && !(!mysql_query($queryString,$conn));
        $queryString="begin ";
        $res=$res && !(!mysql_query($queryString,$conn));

        if ($res!=false)
        {
            $queryString="delete from infoetud where alternanceRef in (".$altRefs.");";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

        if ($res!=false)
        {
            $queryString="delete from etapeetudtut where alternanceRef in (".$altRefs.");";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

        if ($res!=false)
        {
            $queryString="delete from etapevisite1 where alternanceRef in (".$altRefs.");";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

        if ($res!=false)
        {
            $queryString="delete from etapeechanges where alternanceRef in (".$altRefs.");";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

        if ($res!=false)
        {
            $queryString="delete from etapeSout where alternanceRef in (".$altRefs.");";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

        if ($res!=false)
        {
            $queryString="delete from etapemissionsout where alternanceRef in (".$altRefs.");";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

        if ($res!=false)
        {
            $queryString="delete from etapevisite2 where alternanceRef in (".$altRefs.");";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

        if ($res!=false)
        {
            $queryString="delete from temp_tuteurs where alternanceRef in (".$altRefs.");";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }


        /*if ($res!=false)
        {
            $queryString="delete from fa_referent where referentCle in
                (select referentRef from contrat where alternanceCle in (".$altRefs."));";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }*/

        
        if ($res!=false)
        {
            $queryString="delete from contrat where alternanceCle in (".$altRefs.");";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

        if ($res!=false)
        {
            $queryString="commit;";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

/*
        $connDept=doConnection("fil_dept");


        if ($res!=false)
        {
            $queryString="delete from etudiant_groupe where etudRef in ($etudCles);";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

        if ($res!=false)
        {
            $queryString="delete from etudiant where etudCle in ($etudCles);";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }
*/
        if ($res!=false)
        {
            echo "Suppression réussie!";
        } else {
            $queryString="rollback;";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
            echo "Echec!";
        }




?>