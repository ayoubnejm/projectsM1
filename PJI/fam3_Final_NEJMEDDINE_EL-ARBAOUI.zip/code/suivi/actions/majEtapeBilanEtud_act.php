<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");


    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtapeBilan($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    $nbCols=2;
    $space=50;
    $width="95%";

    if ($alt[4]==null) {
      die("<div id='cadre_0' class='contenu-item2 on' >
            Aucune information saisie par le tuteur pour l'instant!
            <a href='index.php'>Revenir à la page d'accueil</a>
           </div>");
    }
    //echo "<H3 style='color:red'>Evitez les accents, apostrophes, guillIemets...</H3>";
    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];


        //echo "Dealing with etudiant having :", $altCle, "<br/>";
        
        $et_pn=$alt[1]." ".$alt[2]; 
        $avecSoutenance=strpos($alt[3],"M1MIAGE")===FALSE;

        $dateR=$alt[4]=="0000-00-00"?"":$alt[4];
        
        $pointsPositifs=to_minimum_lines(to_text($alt[5]),5);
        $pointsProgres=to_minimum_lines(to_text($alt[6]),5);
        $avancementProjet=to_minimum_lines(to_text($alt[7]),4);
        $dateS=$alt[8]=="0000-00-00"?"":$alt[8];

        $signEtud=$alt[9];
        $rmqEtud=to_minimum_lines(to_text($alt[10]),0);

        $signRef=$alt[11]?"OUI":"NON";
        $rmqRef=to_minimum_lines(to_text($alt[12]),0);

        $signTut=$alt[13]==1?"OUI":"NON";
        $rmqTut=to_minimum_lines(to_text($alt[14]),0);
        
        echo "<div id='cadre_0' class='contenu-item2 on' >";
        echo "<form name='form",$i,"' action='".ABS_START_URL."/index.php' method='post'>";
        echo "<input type='hidden' name='page' value='actions/faireMajEtapeBilanEtud_act'/>";
        echo "<input type='hidden' name='altCle' value='",$altCle,"'/>";
        echo "
                <b>L'ETUDIANT : ",$et_pn,"</b><br/>
                <table align='center' style='border-width: 0px;border-style:solid;font-size:11px'>
                <tr>
                    <td style='border-width: 1px;border-style:' width='".$width."'>
                        Date rencontre (aaaa-mm-jj) : ",$dateR,"<br/>               
                    </td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Quels sont les points positifs ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>",$pointsPositifs,"</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Quels sont les points de progrès ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>",$pointsProgres,"</p>
                        </div>
                    </div></td>
                </tr>";
        if ($avecSoutenance)
            echo  "
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Quel est l'avancement du projet ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>",$avancementProjet,"</p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td style='border-width: 1px;border-style:' width='".$width."'>
                        Date probable de soutenance (aaaa-mm-jj) :  ",$dateS,"<br/>
                    </td>
                </tr>
                ";
        echo "
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation de l'étudiant <input type='checkbox' name='signEtud'",($signEtud!=0?"checked='checked' value='1'":""),"/>(remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='rmqEtud' style='width:95%' rows='2'>",$rmqEtud,"</textarea></p>

                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation du référent </b> ",$signRef," (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>&nbsp;&nbsp;&nbsp;",$rmqRef,"</p>

                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        <b>Validation du tuteur</b> ",$signTut," (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>&nbsp;&nbsp;&nbsp;",$rmqTut,"</p>
                        </div>
                    </div></td>
                </tr>";
            echo "<tr><td align='center'><input type='button' value='Revenir en arrière' onclick='javascript:history.go(-1);'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            echo "<input type='submit' style='align:right;background-color:orange' value='Valider'/></td>
            </tr>
            </table>";
        echo "</form>";
        echo "</div>";

    
}
?>