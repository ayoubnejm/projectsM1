<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">

<?php

require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/html/dbutils.php");


    $conn=doConnection();

    echo "<form action='".ABS_START_URL."/index.php' method='post' id='actionForm'>
          <input type='hidden' name='page' value='actions/faireSupprimerEtudSecr_act'/>";
    echo "<br/>Les étudiants suivants seront effacés de l'appli pour l'année ".$_SESSION[REF_YEAR]." - ".$_SESSION[REF_FORMATIONTYPE].":<br/>\n";
    echo "<br/><ul>\n";
    $altRefs='';
    $etudNames='<ul>';
    for ($i=0;$i<count($selection);$i++)
    {
        $altRefs.=", "."'".$selection[$i]."'";
        $etudNames.="<li>".$selection[$i]."</li>";
        echo "<li>";
        echo $selection[$i];
        
        echo "</li>";
    }
    $etudNames.="</ul>";
    echo "</ul>";
    echo "<br/><br/>";

    echo "<input type='hidden' value=\"".substr($altRefs,1)."\" name='altRefs'/>";
    echo "<input type='hidden' value=\"".$etudNames."\" name='etudNames'/>";
    echo "<input type='button' value='Annuler' onclick='javascript:history.go(-1);'/>";
    echo "<input type='submit' style='color:orange' value='Desactiver'/>";
    echo "</form>";


?>
</div>
</div>
