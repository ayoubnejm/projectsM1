<?php 
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/dbmngt/queries.php");
        require_once(ABS_START_PATH."/html/dbutils.php");
        require_once(ABS_START_PATH."/log/log.php");


        $altRefs=str_replace("\\","",getParam("altRefs",null));
        if ($altRefs===FALSE) die("Demande de suppression invalide!");
        $etudNames=getParam("etudNames",null);
        


        echo "L'étudiant ".$etudNames." ne sera plus suivi par son tuteur actuel  ... <br/> ";
        //echo "Vous pouvez re-inscrire des étudiants depuis le menu Re-Inscription ".$etudNames." de l'application STALT en cours ... <br/> ";

        $conn=doConnection();
        $etudCles=getEtudClesListFromAlternanceCle($conn,$altRefs);
        $res=true;
        $queryString="set autocommit=0 ";
        $res=$res && !(!mysql_query($queryString,$conn));
        $queryString="begin ";
        $res=$res && !(!mysql_query($queryString,$conn));

        if ($res!=false)
        {
            $queryString="update  contrat set tuteurRef=null, notifAttribTuteur=0 where alternanceCle in (".$altRefs.");";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }

        if ($res!=false)
        {
            $queryString="commit;";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
        }


        if ($res!=false)
        {
            echo "<b style='color:green'>Suppression réussie!</b>";
        } else {
            error_log("CAUSE ROLLBACK : ".$queryString." - ".mysql_error($conn));
            $queryString="rollback;";
            echo $queryString."<br/>";
            $res=$res && !(!mysql_query($queryString,$conn));
            echo "<b style='color:red'>Echec !</b>!";
        }




?>