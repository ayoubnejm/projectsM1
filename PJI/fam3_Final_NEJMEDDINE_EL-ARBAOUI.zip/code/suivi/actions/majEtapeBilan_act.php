<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once (ABS_START_PATH."/calendar/tc_calendar.php");


   echo "<SCRIPT src='".ABS_START_URL."/calendar/calendar.js' lang='javascript'></SCRIPT>";
   echo "<SCRIPT src='http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js' lang='javascript' ></SCRIPT>";

    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtapeBilan($conn,$altRefs);

    $alt=mysql_fetch_row($alts);

    $nbCols=2;
    $space=50;
    $width="95%";
    
    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];


        //echo "Dealing with etudiant having :", $altCle, "<br/>";
        
        $et_pn=$alt[1]." ".$alt[2]; 
        $avecSoutenance=strpos($alt[3],"M1MIAGE")===FALSE;

        $dateR=$alt[4]=="0000-00-00"?"":$alt[4];
        
        $pointsPositifs=to_minimum_lines(to_text($alt[5]),0);
        $pointsProgres=to_minimum_lines(to_text($alt[6]),0);
        $avancementProjet=to_minimum_lines(to_text($alt[7]),0);
        $dateS=$alt[8]=="0000-00-00"?"":$alt[8];

        $signEtud=$alt[9];
        $rmqEtud=to_minimum_lines(to_text($alt[10]),0);

        $signRef=$alt[11];
        $rmqRef=to_minimum_lines(to_text($alt[12]),0);

        $signTut=$alt[13];
        $rmqTut=to_minimum_lines(to_text($alt[14]),0);
        
        echo "<div id='cadre_",$i,"' class='contenu-item2 on'>";

        echo "<form id='form'",$i,"' name='form", $i, "' action='".ABS_START_URL."/index.php' method='post'>";
        echo "<input type='hidden' name='page' value='actions/faireMajEtapeBilan_act'/>";
        echo "<input type='hidden' name='altCle' value='",$altCle,"'/>";
        echo "
                <b>L'ETUDIANT : ",$et_pn,"<input type='hidden' value='",$et_pn,"' name='et_pn'/></b><br/>
                <td style='border-width: 1px;border-style:' width='".$width."'>
                        <table>
                        <tr>
                            <td>Date rencontre (aaaa-mm-jj) : </td><td>";
                    $myCalendarRecontre = new tc_calendar("dateR", true);
                    $myCalendarRecontre->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    //$myCalendarSIGN->setDate(date('d'), date('m'), date('Y'));
                    //$myCalendarSIGN->setDate(intval(substr($d_sign,8,2)),intval(substr($d_sign,5,2)),intval(substr($d_sign,0,4)));
                    $myCalendarRecontre->setDateYMD($dateR);
                    $myCalendarRecontre->disabledDay("sun");
                    //error_log("from time : ".strtotime((intval(date('Y'))-3).'-1-1'));
                    //error_log("to time : ".strtotime((intval(date('Y'))+3).'-1-1'));
                    //$myCalendarSIGN->dateAllow((intval(date('Y'))-3).'-1-1', (intval(date('Y'))+3).'-1-1', true);
                    $myCalendarRecontre->setPath(ABS_START_URL."/calendar/");
                    $myCalendarRecontre->setDateFormat('Y-F-j');
                    $myCalendarRecontre->setAlignment('left', 'bottom');
                    //error_log("d_sign : ".substr($d_sign,8,2)." - ".substr($d_sign,5,2)." - ".substr($d_sign,0,4));
                    $myCalendarRecontre->writeScript();
      echo "</td></tr></table></td>
                        </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Quels sont les points positifs ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='pointsPositifs' style='width:95%' rows='6'>",$pointsPositifs,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Quels sont les points de progrès ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='pointsProgres' style='width:95%' rows='6'>",$pointsProgres,"</textarea></p>
                        </div>
                    </div></td>
                </tr>";
        if ($avecSoutenance) {
            echo  "
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Quel est l'avancement du projet ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='avancementProjet' style='width:95%' rows='6'>",$avancementProjet,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td style='border-width: 1px;border-style:' width='".$width."'>
                    <table>
                    <tr><td>
                        Date probable de soutenance (aaaa-mm-jj) :
                    </td><td>";
                    $myCalendarSoutenance = new tc_calendar("dateS", true);
                    $myCalendarSoutenance->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    //$myCalendarSIGN->setDate(date('d'), date('m'), date('Y'));
                    //$myCalendarSIGN->setDate(intval(substr($d_sign,8,2)),intval(substr($d_sign,5,2)),intval(substr($d_sign,0,4)));
                    $myCalendarSoutenance->setDateYMD($dateS);
                    $myCalendarSoutenance->disabledDay("sun");
                    //error_log("from time : ".strtotime((intval(date('Y'))-3).'-1-1'));
                    //error_log("to time : ".strtotime((intval(date('Y'))+3).'-1-1'));
                    //$myCalendarSIGN->dateAllow((intval(date('Y'))-3).'-1-1', (intval(date('Y'))+3).'-1-1', true);
                    $myCalendarSoutenance->setPath(ABS_START_URL."/calendar/");
                    $myCalendarSoutenance->setDateFormat('Y-F-j');
                    $myCalendarSoutenance->setAlignment('left', 'bottom');
                    //error_log("d_sign : ".substr($d_sign,8,2)." - ".substr($d_sign,5,2)." - ".substr($d_sign,0,4));
                    $myCalendarSoutenance->writeScript();

          echo          "</td></tr>
                    </table>
                    </td>
                </tr>
                ";
        }
        echo "
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation de l'étudiant ",($signEtud!=0?"OUI":"NON"),"(remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='rmqEtud' style='width:95%' rows='2'>",$rmqEtud,"</textarea></p>
                        
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation du référent <input type='checkbox' name='signRef'",($signRef!=0?"checked='checked' value='1'":""),"/>(remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='rmqRef' style='width:95%' rows='2'>",$rmqRef,"</textarea></p>

                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation du tuteur <input type='checkbox' name='signTut'",($signTut!=0?"checked='checked' value='1'":""),"/> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'>&nbsp;&nbsp;&nbsp;<textarea name='rmqTut' style='width:95%' rows='2'>",$rmqTut,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
            </table>";
        echo "<input type='submit' value='Modifier'/></form>";
        echo "</div>";

    
}
?>