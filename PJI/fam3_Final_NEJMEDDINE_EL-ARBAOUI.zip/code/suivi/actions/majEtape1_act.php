<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once (ABS_START_PATH."/calendar/tc_calendar.php");


   echo "<SCRIPT src='".ABS_START_URL."/calendar/calendar.js' lang='javascript'></SCRIPT>";
   echo "<SCRIPT src='http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js' lang='javascript' ></SCRIPT>";

   $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    //echo $altRefs;
    
    $alts=doQueryRenduEtape1($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    $nbCols=2;
    $space=50;
    $width="95%";

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $et_pn=$alt[1]." ".$alt[2]; 
        $date=$alt[3]=="0000-00-00"?"":$alt[3];
        $entr=$alt[4];
        $serv=$alt[5];
        $client=$alt[6];

        $missions=to_minimum_lines(to_text($alt[7]),0);
        $env=to_minimum_lines(to_text($alt[8]),0);
        $integration=to_minimum_lines(to_text($alt[9]),0);

        $signEtud=$alt[10]!=0?"OUI":"NON";
        $rmqEtud=to_minimum_lines(to_html($alt[11]),0);
        
        $signTut=$alt[12];
        $rmqTut=to_minimum_lines(to_text($alt[13]),0);

        $mots=$alt[14];
        
        echo "<div id='cadre_0' class='contenu-item2 on' >";

        echo "<form name='form",$i,"' action='".ABS_START_URL."/index.php' method='post'>";
        echo "<input type='hidden' name='page' value='actions/faireMajEtape1_act'/>";
        echo "<input type='hidden' name='altCle' value='",$altCle,"'/>";
        
        echo " <table align='center' style='border-width: 0px;border-style:solid;font-size:11px' width='".$width."'>
                <tr class='entete'>
                    <td>$et_pn<input type='hidden' value='",$et_pn,"' name='et_pn'/></td></tr>",
                
                "<tr>
                    <td>
                        Date rencontre (aaaa-mm-jj) : <br/>";
                    $myCalendarRecontre = new tc_calendar("date", true);
                    $myCalendarRecontre->setIcon(ABS_START_URL."/calendar/images/iconCalendar.gif");
                    //$myCalendarSIGN->setDate(date('d'), date('m'), date('Y'));
                    //$myCalendarSIGN->setDate(intval(substr($d_sign,8,2)),intval(substr($d_sign,5,2)),intval(substr($d_sign,0,4)));
                    $myCalendarRecontre->setDateYMD($date);
                    $myCalendarRecontre->disabledDay("sun");
                    //error_log("from time : ".strtotime((intval(date('Y'))-3).'-1-1'));
                    //error_log("to time : ".strtotime((intval(date('Y'))+3).'-1-1'));
                    //$myCalendarSIGN->dateAllow((intval(date('Y'))-3).'-1-1', (intval(date('Y'))+3).'-1-1', true);
                    $myCalendarRecontre->setPath(ABS_START_URL."/calendar/");
                    $myCalendarRecontre->setDateFormat('Y-F-j');
                    $myCalendarRecontre->setAlignment('left', 'bottom');
                    //error_log("d_sign : ".substr($d_sign,8,2)." - ".substr($d_sign,5,2)." - ".substr($d_sign,0,4));
                    $myCalendarRecontre->writeScript();
      echo "</td></tr></tr><td>
                        Entreprise chosie : <input type='hidden' value='",$entr,"' name='entr'/>",$entr,"<br/>
                        Service/Projet : <input type='text' value='",$serv,"' name='serv'/><br/>
                        (éventuellement client) : <input type='text' value='",$client,"' name='client'/><br/>
                    </td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Quels sont (ou seront) les missions confiées ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='missions' style='width:95%' rows='6'>",$missions,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Dans quel environnement technique ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='env' style='width:95%' rows='6'>",$env,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Comment se passe l'intégration dans l'entreprise ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='integration' style='width:95%' rows='6'>",$integration,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Mots clés ?<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'><textarea name='motscles' style='width:95%' rows='1'>",$mots,"</textarea></p>
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation de l'étudiant ".$signEtud."(remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:left;margin-top:0'>".$rmqEtud."</p>
                        
                        </div>
                    </div></td>
                </tr>
                <tr>
                    <td><div style='border-width: 1px;border-style:solid' width='".$width."'>
                        Validation du tuteur <input type='checkbox' name='signTut'",($signTut!=0?"checked='checked' value='1'":""),"/> (remarques éventuelles)<br/>
                        <div style='width:".$width."'>
                        <p style='text-align:center;margin-top:0'>&nbsp;&nbsp;&nbsp;<textarea name='rmqTut' style='width:95%' rows='2'>",$rmqTut,"</textarea></p>
                        </div>
                    </div></td>
                </tr>";
                echo "<tr><td align='center'><input type='button' value='Revenir en arrière' onclick='javascript:history.go(-1);'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                echo "<input type='submit' style='align:right;background-color:orange' value='Valider'/></td>
                </tr>
            </table>";
        echo "</form>";
        echo "</div>";
    }

?>