<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/secure/auth.php");
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");

  $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtapeBilan($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $altCle=$alt[0];
        $etud=$alt[1]." ".$alt[2];
        $avecSoutenance=strpos($alt[3],"M1MIAGE")===FALSE;

        $dateR=$alt[4]=="0000-00-00"?"":$alt[4];

        $pointsPositifs=$alt[5];
        $pointsProgres=$alt[6];
        $avancementProjet=$alt[7];
        $dateS=$alt[8]=="0000-00-00"?"aucune date retenue pour l'instant.":$alt[8];

        $ref=$alt[18]." ".$alt[19];
        $tuteur=$alt[20]." ".$alt[21];
        $mailRef=$alt[17];
        $mailTut=$alt[16];
        $mailEtud=$alt[15];
        $ref2=$alt[23]." ".$alt[24];
        $mailRef2=$alt[22];

        $file=file("msgs/notifierCrEtapeBilan".($avecSoutenance?"":"SANSPROJET")."_template.txt");
        $msgMail=str_replace("%REFERENT%",$ref,implode('',$file));
        $msgMail=str_replace("%POINTS_POSITIFS%",$pointsPositifs,$msgMail);
        $msgMail=str_replace("%POINTS_PROGRES%",$pointsProgres,$msgMail);
        if ($avecSoutenance) {
           $msgMail=str_replace("%AVANCEMENT_PROJET%",$avancementProjet,$msgMail);
           $msgMail=str_replace("%DATE_SOUTENANCE%",$dateS,$msgMail);
        }
        $msgMail=str_replace("%TUTEUR%",$tuteur,$msgMail);

        $headersMail  = 'MIME-Version: 1.0' . "\r\n";
        $headersMail .= 'Content-type: text/plain; charset=utf-8' . "\r\n";
        $headersMail .= "From: \"".$tuteur."\" <".$mailTut."> \r\n".

                    "Subject: [stalt] Compte rendu 2eme visite entreprise  ".$etud."\r\n".
                    "To: \"".$ref.",\"<".$mailRef.">".
                      (strlen($mailRef2)>0?"\"".$ref2."\"<".$mailRef2.">":"")." \r\n".
                    "Cc: \"".$etud."\"<".$mailEtud.">, ".
                    "\"".$tuteur."\" <".$mailTut."> \r\n";

        echo "
            <p>".
            to_html($headersMail)."<br/>".
            to_html($msgMail)."<br/>".
            "</p>
            <form method='post' action='".ABS_START_URL."/index.php'>
                <input type='hidden' name='page' value='interface/faireActionsEtudiants_act'/>
                <input type='hidden' name='action' value='faireNotifierCrEtapeBilan_act'/>
                <input type='hidden' name='selection[]' value='".$alt[0]."'/>
                <input type='submit' value='Envoyer mail'/>
            </form>
        ";
       
    }
?>
