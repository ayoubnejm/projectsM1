<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        <?php
        /*
         * To change this template, choose Tools | Templates
         * and open the template in the editor.
         */
        
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once (ABS_START_PATH."/html/dbutils.php");
        require_once (ABS_START_PATH."/html/escaping.php");
        require_once(ABS_START_PATH."/log/log.php");
        
        $altCle=getParam("altCle",null);
        if ($altCle==null) die("Demande de maj invalide!");

        //echo "dealing with etudiant having key : ", altCle, "<br/>";
        
        $et_pn=getParam("et_pn",null);
        $et_cle=substr($altCle,0,-1);
        //$et_entr=getParam("et_entr",null);

        $dateR=getParam("dateR","0000-00-00");
        


        $pointsPositifs=doDBEscape(getParam("pointsPositifs",null));
        $pointsProgres=doDBEscape(getParam("pointsProgres",null));
        
        $avancementProjet=doDBEscape(getParam("avancementProjet",null));
        $dateProbableSoutenance=getParam("dateS","0000-00-00");

        $signEtud=(getParam("signEtud",null)==null?0:1);
        $rmqEtud=doDBEscape(getParam("rmqEtud",null));

        $signRef=(getParam("signRef",null)==null?0:1);
        $rmqRef=doDBEscape(getParam("rmqRef",null));

        $signTut=(getParam("signTut",null)==null?0:1);
        $rmqTut=doDBEscape(getParam("rmqTut",null));

        action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"faireMajEtapeBilan",array($altCle));

        ?>
        <h2>Mise à jour des informations concernant le bilan depuis le début de l'année universitaire pour l'étudiant <?php echo $et_pn ?></h2>
        <a onClick="javascript:history.go(-2)"><font style="color:blue;text-decoration: underline">Revenir à la page précédente</font></a><br/>
        <?php
            $conn=doConnection();
            $res=true;
            $queryString="set autocommit=0 ";
            $res=$res && !(!mysql_query($queryString,$conn));
            $queryString="begin ";
            $res=$res && !(!mysql_query($queryString,$conn));
            if ($res!=false)
            {
                $queryString="select alternanceRef from etapevisite2 where alternanceRef='".$altCle."'";
                //echo $queryString."<br/>";
                if (mysql_query($queryString,$conn)==false || mysql_num_rows(mysql_query($queryString,$conn))==0)
                {
                    $queryString="insert into etapevisite2 (`alternanceRef`) values ('".$altCle."');";
                    //echo $queryString."<br/>";
                    $res=$res && !(!mysql_query($queryString,$conn));
                }

                $queryString="update etapevisite2 set dateRencontre='".$dateR.
                             "', pointsPositifs='".$pointsPositifs.
                             "', pointsProgres='".$pointsProgres.
                             "', avancementProjet='".$avancementProjet.
                             "', dateProbableSoutenance='".$dateProbableSoutenance.
                             "', signatureEtud='".$signEtud."', signatureTuteur='".$signTut."', signatureReferent='".$signRef.
                             "', remarquesEtud='".$rmqEtud."', remarquesTuteur='".$rmqTut."', remarquesReferent='".$rmqRef."' ".
                             "where alternanceRef LIKE '".$altCle."'";
                //echo $queryString;
                if (!mysql_query($queryString,$conn))
                {
                    mysql_query("rollback",$conn);
                    echo "pb updating information<hr/>";

                    include("../actions/majEtapeBilan.php");
                    faireAction(array($altCle));
                    die();
                }
                $queryString="commit ";
                $res=$res && !(!mysql_query($queryString,$conn));

                echo "Informations mise à jour!<hr/>";
            
                $selection=array();
                $selection[]=$altCle;
                require_once(ABS_START_PATH."/actions/renduEtapeBilan_act.php");
            }
            return true;
        ?>
</div>
        </div>