<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE) || !hasRole(SECR_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queriesCandidatures.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/escaping.php");
      require_once(ABS_START_PATH."/html/dbutils.php");

      $conn=doConnection();

      $formation=getParam("formation","");
      $_SESSION["formation"]=$formation;

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Inscrire Etudiants</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>

  <SCRIPT src='<?php echo ABS_START_URL; ?>/ajax/inscrireEntreprise_modal.js' lang='javascript'></SCRIPT>
  <script type='text/javascript'>generateInscrireEntrepriseForm();</script>

  <SCRIPT src='<?php echo ABS_START_URL; ?>/ajax/inscrireBureau_modal.js' lang='javascript'></SCRIPT>
  <script type='text/javascript'>generateInscrireBureauForm();</script>

  <SCRIPT src='<?php echo ABS_START_URL; ?>/ajax/inscrireReferent_modal.js' lang='javascript'></SCRIPT>
  <script type='text/javascript'>generateInscrireReferentForm();</script>


</div>
<div id="contenu">
<div id="cadre_0" class="contenu-item2 on"><br/>

<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/html/dbutils.php");

  $conn=doConnection();

    $altRefs='';

    if ($selection[0]=="ACT_MIGRATION_ETUD") {
      $q=doQueryListEtudiantsParFormation($conn,$_REQUEST["formationSource"],$_REQUEST["anneeSource"]);
      $row=mysql_fetch_row($q);
      for (;$row;$row=mysql_fetch_row($q))
      {
        $altRefs.=", "."'".$row[0]."'";
      }
    }
    else {
      for ($i=0;$i<count($selection);$i++)
      {
          $altRefs.=", "."'".$selection[$i]."'";
      }
    }
    $altRefs=substr($altRefs,1);


  
  if (getCurrYear()>$_SESSION[REF_YEAR]+1) {
    die("<b>Impossible d'inscrire d'étudiants pour l'année $_SESSION[REF_YEAR] !</b> </div></div>");
  }

  $entrKeysValues=convertRowsToArray(doQueryListEntr($conn));


  $rows=doListeEtudiantsSelectionnesParFormation($conn,$altRefs);

  $iRow=0;
  $row=mysql_fetch_row($rows);
  echo "<form id='form0' method='post' action='".ABS_START_URL."/index.php'>";
  echo "<input type='hidden' value='interface/faireImportCandidatures_act' name='page'/>";
      echo "<br/>Les étudiants suivants seront migrés vers la formation ";
    $keysValues = constructGrantedGroupesKeys(true,false,'FA/FI');
    $formation=createSelectKeyValuesOnChange("formationCible",$keysValues,"","");
    echo " pour l'année : ";
    $years=getMigrationYears();
    $refYear=$_SESSION[REF_YEAR];
    createSelectWithOnChange(
          "anneeCible",
          $years,
          $years,
          $CURR_YEAR-$refYear+1,
          "");
    echo "<br/>\n";
   ?>
  <a onClick="javascript:checkAll('form0','chkbox_',true);"><font style="color:blue; text-decoration:underline;">Tous</font></a>
  <a onClick="javascript:checkAll('form0','chkbox_',false);"><font style="color:blue; text-decoration:underline;">Aucun</font></a>

  <?php
  echo "<table style='font-size:9pt' class='edt'>";
  while ($row) {
    $oldGroupeRef=$row[6];
    //error_log("MIGRATION TUTEUR : $oldGroupeRef - ".);
    echo "<tr>";
    echo "<td><input type='checkbox' name='chkbox_$iRow' /></td>";//checked='checked'
    echo "<td>$row[0] $row[1] <br/> $row[3]
          <input type='hidden' name='fa_etud_cle_$iRow' value='$row[13]'/>
          <input type='hidden' name='fa_etud_nom_$iRow' value='$row[0]'/>
          <input type='hidden' name='fa_etud_prenom_$iRow' value='$row[1]'/>
          <input type='hidden' name='fa_etud_mail_$iRow' value='$row[3]'/>
          <input type='hidden' name='fa_etud_tel_$iRow' value='$row[12]'/>
          <input type='hidden' name='fa_tuteur_ref_$iRow' value='".
              ((strcmp(substr($oldGroupeRef,0,2),"M1")==0 && strcmp(substr($oldGroupeRef,strlen($oldGroupeRef)-3,2),"FA")==0)?$row[14]:"")."'/>
          <!--input type='hidden' name='groupeRef_$iRow' value='".$formation."1'/-->
          <input type='hidden' name='motscles_$iRow' value='$row[7]'/>
          </td>";
    echo "<td><table class='edt' style='font-size:9pt' width='100%'><tr class='tp'><td colspan='2'>
          Entreprise actuelle <b>$row[4]</b> : <br/>";
          $entrCle=createSelectFromArray($entrKeysValues, "fa_entreprise_cle_$iRow", "$row[4]","","updateBureau('form0','fa_bureau_cle_$iRow',getFieldValue('form0','fa_entreprise_cle_$iRow'));updateReferent('form0','fa_referent_cle_$iRow',getFieldValue('form0','fa_entreprise_cle_$iRow'));");
    echo "<input type='hidden' name='raw_fa_entreprise_cle_${iRow}' value='".""."'/>";
    echo "<a href='#' onclick=\"setFieldValue('inscrireEntreprise','entr_nom','".""."');
                                setFieldValue('inscrireEntreprise','entr_adresse','".""."');
                                setFieldValue('inscrireEntreprise','entr_ville','".""."');
                                setFieldValue('inscrireEntreprise','source_page','interface/importCandidatures_act');
                                setFieldValue('inscrireEntreprise','source_recno','".$iRow."');
                                inscrireEntreprise('form0','entr')\"/>
          <font size='+1'><b>+</b></font></a>";
    echo "</td></tr><tr class='td'><td>Bureau actuel  : <b>$row[5]</b> <br/>";
          createBureauSelect($conn,"fa_bureau_cle_$iRow",$entrCle,$row[5],"");
    echo "<a  href=\"#\" onclick=\"inscrireBureauImportCandidatures('form0','".""."','$page',$iRow);\"><font size='+1'><b>+</b></font></a>
                <br/>";

    echo "</td>";
    echo "<td>Réferent actuel : <b>$row[8]</b> <br/>";
        createReferentSelect($conn,"fa_referent_cle_$iRow",$entrCle,"$row[8]","");
    echo "<a  href=\"#\" onclick=\"inscrireReferentImportCandidatures('form0','".""."','".""."','".
          ""."','".""."','$page','$iRow');\"><font size='+1'><b>+</b></font></a>";
    echo "<br/>";
    echo "</td>";
    echo "</tr></td></tr></table></td></tr>";
    $row=mysql_fetch_row($rows);
    $iRow++;
  }
  echo "</table>";
  ?>
  
  <a onClick="javascript:checkAll('form0','chkbox_',true);"><font style="color:blue; text-decoration:underline;">Tous</font></a>
  <a onClick="javascript:checkAll('form0','chkbox_',false);"><font style="color:blue; text-decoration:underline;">Aucun</font></a>
  <br/>
  
  <?php echo "<input type='hidden' name='iRowMax' value='$iRow'/>";
  echo "<input type='button' value='Migrer' onClick=\"javascript:if (confirm('Migration de l\'ensemble des étudiants vers -- '+
                            getFieldValue('form0','formationCible')+' -- et -- '+
                            getFieldValue('form0','anneeCible')+'--')) submit();\"/>
        </form>";
?>


</div>
</div>
