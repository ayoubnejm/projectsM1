<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
          
<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(ABS_START_PATH."/dbmngt/queries.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/mail/sendMail.php");

        $conn=doConnection();
    action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"prevenirTuteur",array($selection));

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryTuteurReferentEtudiants($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    for (;$alt;$alt=mysql_fetch_row($alts))
    {
        $altCle=$alt[0];
        $et_n=$alt[1]; $et_p=$alt[2]; $et_e=$alt[3];
        $f=$alt[4];
        $p_n=$alt[5]; $p_p=$alt[6]; $p_e=$alt[7];
        $r_n=$alt[8]; $r_p=$alt[9]; $r_e=$alt[10];
        $resp_e=$alt[11];
        $resp_noms=$alt[12];

        echo "<h3>",$et_p." ".$et_n,"</h3>";

        if (count_chars($et_e)==0)
            echo "Impossible de contacter l'étudiant ",$et_n," ",$et_p," par mail!";

        if (count_chars($p_e)==0)
            echo "Impossible de contacter le tuteur (",$p_n," ",$p_p,") de l'étudiant ",$et_n," ",$et_p," par mail!";
        if (count_chars($p_e)==0)
            continue;

        $file=file(ABS_START_PATH."/msgs/prevenirTuteur_".$f."_template.txt");
        if ($file===false) {
          $file=file(ABS_START_PATH."/msgs/prevenirTuteur_".substr($f,strlen($f)-2,2)."_template.txt");
          if ($file===false)
            $file=file(ABS_START_PATH."/msgs/prevenirTuteur_template.txt");
        }
        
        $msgMail=str_replace("%TUTEUR%",$p_p." ".$p_n,implode('',$file));
        $msgMail=str_replace('%RESPS%',$resp_noms,$msgMail);
        $msgMail=str_replace('%FORMATION%',$f,$msgMail);

               
        echo "<p>",str_replace("\n","<br/>",$msgMail),"</p>";
        echo "<hr/>";

      $to=$p_e;
      $cc=$resp_e;
      $subject="[stalt] Reconduite du suivi de l'étudiant (".$et_p." ".$et_n.")" ;
      $body=$msgMail;

      error_log("sending mail $to $cc $subject");

      echo $to,"<br/>",$cc,"<br/>";
      echo $msgMail;

      $result=sendAuthenticatedMail($to,$cc,$subject,$msgMail);
      //$result=FALSE;
      error_log($result);
      
      if ($result===TRUE) {
            echo "<p>E-mail envoyé avec succès à ",$et_p," ",$et_n," et ", $p_p, " ", $p_n, " !</p>";
            //$updateQuery="update contrat set notifAttribTuteur=ifnull(notifAttribTuteur,0)+1 where alternanceCle='$altCle'";
            //mysql_query($updateQuery,$conn);
      }
      else
            /* message déja affiché par sendAuthenticatedMail */
            echo "<p>Pb. avec envoi!<br/>$result</p>";
    
    
    }
    mysql_close($conn);

?>
</div>
</div>
