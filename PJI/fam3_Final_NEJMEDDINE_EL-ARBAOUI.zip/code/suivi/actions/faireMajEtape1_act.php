<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        <?php
        /*
         * To change this template, choose Tools | Templates
         * and open the template in the editor.
         */
        
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/html/dbutils.php");
        require_once(ABS_START_PATH."/html/escaping.php");
        
        require_once (ABS_START_PATH."/config/auth.ini.php");
        require_once (ABS_START_PATH."/log/log.php");

        $altCle=getParam("altCle",null);
        if ($altCle==null) die("Demande de maj invalide!");

        action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"faireMajEtape1",array($altCle));

        $et_pn=getParam("et_pn",null);
        $et_cle=substr($altCle,0,-1);
        //$et_entr=getParam("et_entr",null);
        $date=getParam("date","0000-00-00");
        $entr=doDBEscape(getParam("entr",null));
        $serv=doDBEscape(getParam("serv",null));
        $client=doDBEscape(getParam("client",null));

        $missions=doDBEscape(getParam("missions",null));
        $env=doDBEscape(getParam("env",null));
        $integration=doDBEscape(getParam("integration",null));

//        $signEtud=(getParam("signEtud",null)==null?0:1);
//        $rmqEtud=getParam("rmqEtud",null);

        $signTut=(getParam("signTut",null)==null?0:1);
        $rmqTut=doDBEscape(getParam("rmqTut",null));

        $motsCles=doDBEscape(getParam("motscles",null));
        
        ?>
        <h2>Mise à jour des informations concernant la rencontre avec l'étudiant <?php echo $et_pn ?></h2>
        <?php
            $conn=doConnection();
            $res=true;
            $queryString="set autocommit=0 ";
            $res=$res && !(!mysql_query($queryString,$conn));
            $queryString="begin ";
            $res=$res && !(!mysql_query($queryString,$conn));
            if ($res!=null)
            {
                $queryString="select alternanceRef from etapeetudtut where alternanceRef='".$altCle."'";
                //echo $queryString."<br/>";
                if (mysql_query($queryString,$conn)===false || mysql_num_rows(mysql_query($queryString,$conn))===0)
                {
                    $queryString="insert into etapeetudtut (`alternanceRef`) values ('".$altCle."');";
                    //echo $queryString."<br/>";
                    $res=$res && !(!mysql_query($queryString,$conn));
                }
            
                $queryString="update etapeetudtut set dateRencontre='".$date."', service='".$serv."', client='".$client.
                             "', missions='".$missions."', environnementTechnique='".$env."', integrationEntreprise='".$integration.
                             "', signatureTuteur='".$signTut."', remarquesTuteur='".$rmqTut.
                             "', motscles='".$motsCles."' where alternanceRef='".$altCle."'";
            
                //echo $queryString."<br/>";
            }
            
            if (!mysql_query($queryString,$conn))
            {
                mysql_query("rollback",$conn);
                echo "pb updating information<hr/>";

                include("../actions/majEtape1.php");
                faireAction(array($altCle));
                die();
            }

            /*$queryString="update infoetud set motscles='$motsCles' where alternanceRef='$altCle'";
            mysql_query($queryString,$conn);
            error_log($queryString." - ".mysql_error());
            *//* if (!mysql_query($queryString,$conn))
            {
                mysql_query("rollback",$conn);
                echo "pb updating mots cles<hr/>";

                include("../actions/majEtape1.php");
                faireAction(array($altCle));
                die();
            }*/

            $queryString="commit ";
            $res=$res && !(!mysql_query($queryString,$conn));

            echo "Informations mise à jour!<hr/>";

            $selection=array();
            $selection[]=$altCle;
            require_once(ABS_START_PATH."/actions/renduEtape1_act.php");
            
            return true;
        ?>
</div>
        </div>