<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        <?php
        /*
         * To change this template, choose Tools | Templates
         * and open the template in the editor.
         */
        
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once (ABS_START_PATH."/html/dbutils.php");
        require_once (ABS_START_PATH."/html/escaping.php");
        require_once(ABS_START_PATH."/log/log.php");
        
        $altCle=getParam("altCle",null);
        if ($altCle==null) die("Demande de maj invalide!");
        $et_pn=getParam("et_pn",null);
        $et_cle=substr($altCle,0,-1);
        //$et_entr=getParam("et_entr",null);
        $dateR=getParam("dateR","0000-00-00");
        $typeR=getParam("typeR","0000-00-00");
        $dateV=getParam("dateV","0000-00-00");


        $missions=doDBEscape(getParam("missions",null));
        $envtTechnique=doDBEscape(getParam("envtTechnique",null));
        $enjeux=doDBEscape(getParam("enjeux",null));

        $signEtud=(getParam("signEtud",null)==null?0:1);
        $rmqEtud=doDBEscape(getParam("rmqEtud",null));

        $signRef=(getParam("signRef",null)==null?0:1);
        $rmqRef=doDBEscape(getParam("rmqRef",null));

        $signTut=(getParam("signTut",null)==null?0:1);
        $rmqTut=doDBEscape(getParam("rmqTut",null));

        action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"faireMajEtapeMissionSoutenance",array($altCle));

        ?>
        <h2>Mise à jour des informations concernant le choix de la mission à présenter pendant la soutenance par l'étudiant <?php echo $et_pn ?></h2>
   
        <?php
            $conn=doConnection();
            $res=true;
            $queryString="set autocommit=0 ";
            $res=$res && !(!mysql_query($queryString,$conn));
            $queryString="begin ";
            $res=$res && !(!mysql_query($queryString,$conn));
            if ($res!=false)
            {
                $queryString="select alternanceRef from etapemissionsout where alternanceRef='".$altCle."'";
                //echo $queryString."<br/>";
                if (mysql_query($queryString,$conn)==false || mysql_num_rows(mysql_query($queryString,$conn))==0)
                {
                    $queryString="insert into etapemissionsout (`alternanceRef`) values ('".$altCle."');";
                  //  echo $queryString."<br/>";
                    $res=$res && !(!mysql_query($queryString,$conn));
                }

                $queryString="update etapemissionsout set dateRencontre='".$dateR.
                             "', typeRencontre='".$typeR.
                             "', dateValidation='".$dateV.
                             "', missions='".$missions.
                             "', environnementTechnique='".$envtTechnique.
                             "', enjeux='".$enjeux.
                             "', signatureEtud='".$signEtud."', signatureTuteur='".$signTut."', signatureReferent='".$signRef.
                             "', remarquesEtud='".$rmqEtud."', remarquesTuteur='".$rmqTut."', remarquesReferent='".$rmqRef."' ".
                             "where alternanceRef='".$altCle."'";
                //echo $queryString;
                if (!mysql_query($queryString,$conn))
                {
                    mysql_query("rollback",$conn);
                    echo "pb updating information<hr/>";

                    include("../actions/majEtapeMissionSoutenance.php");
                    faireAction(array($altCle));
                    die();
                }
                $queryString="commit ";
                $res=$res && !(!mysql_query($queryString,$conn));

                echo "Informations mise à jour!<hr/>";
            
                $selection=array();
                $selection[]=$altCle;
                require_once(ABS_START_PATH."/actions/renduEtapeMissionSoutenance_act.php");
            }
            return true;
        ?>
</div>
        </div>