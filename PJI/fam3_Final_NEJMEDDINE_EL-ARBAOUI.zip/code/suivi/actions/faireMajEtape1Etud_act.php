<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        <?php
        /*
         * To change this template, choose Tools | Templates
         * and open the template in the editor.
         */
        
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once (ABS_START_PATH."/html/dbutils.php");
        require_once (ABS_START_PATH."/html/escaping.php");
        require_once(ABS_START_PATH."/log/log.php");
        
        $altCle=getParam("altCle",null);
        if ($altCle==null) die("Demande de maj invalide!");
        

        $signEtud=(getParam("signEtud",null)==null?0:1);
        $rmqEtud=doDBEscape(getParam("rmqEtud",null));
        action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"faireMajEtape1Etud",array($altCle));

        
        
        ?>
        <h2>Mise à jour des informations concernant la rencontre avec l'étudiant <?php echo $et_pn ?></h2>
        <a onClick="javascript:history.go(-2)"><font style="color:blue;text-decoration: underline">Revenir à la page précédente</font></a><br/>
        
        <?php
            $conn=doConnection();
            $res=true;
            $queryString="set autocommit=0 ";
            $res=$res && !(!mysql_query($queryString,$conn));
            $queryString="begin ";
            $res=$res && !(!mysql_query($queryString,$conn));
            
            if ($res!=null)
            {
                
            
                $queryString="update etapeetudtut set signatureEtud='".$signEtud."', remarquesEtud='".$rmqEtud."' where alternanceRef='".$altCle."'";
            }
            //echo $queryString;
            if (!mysql_query($queryString,$conn))
            {
                mysql_query("rollback",$conn);
                error_log(mysql_error());
                die("pb updating information");
            }
            $queryString="commit ";
            $res=$res && !(!mysql_query($queryString,$conn));

            echo "Informations mise à jour!<hr/>";
            $selection=array();
            $selection[]=$altCle;
            require_once(ABS_START_PATH."/actions/renduEtape1_act.php");
            
            return true;
        ?>
</div>
        </div>