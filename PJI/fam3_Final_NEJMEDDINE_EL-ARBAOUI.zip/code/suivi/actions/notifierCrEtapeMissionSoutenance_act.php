<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/secure/auth.php");
require_once (ABS_START_PATH."/dbmngt/queriesEtapes.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/utils.php");


    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $alts=doQueryRenduEtapeMissionSoutenance($conn,$altRefs);
    $alt=mysql_fetch_row($alts);

    for ($i=0;$alt;$alt=mysql_fetch_row($alts),$i++)
    {
        $ref=$alt[18]." ".$alt[19];
        $etud=$alt[1]." ".$alt[2];
        $tuteur=$alt[20]." ".$alt[21];

        $mission=$alt[6];
        $environnement=$alt[7];
        $enjeux=$alt[8];

        $mailRef=$alt[17];
        $mailTut=$alt[16];
        $mailEtud=$alt[15];
        $mailRef2=$alt[22];
        $ref2=$alt[23]." ".$alt[24];

        $file=file("msgs/notifierCrEtapeMissionSoutenance_template.txt");
        $msgMail=str_replace("%REFERENT%",$ref,implode('',$file));
        $msgMail=str_replace("%ETUDIANT%",$etud,$msgMail);
        $msgMail=str_replace("%MISSION%",$mission,$msgMail);
        $msgMail=str_replace("%ENVIRONNEMENT%",$environnement,$msgMail);
        $msgMail=str_replace("%ENJEUX%",$enjeux,$msgMail);
        $msgMail=str_replace("%TUTEUR%",$tuteur,$msgMail);

        $headersMail  = 'MIME-Version: 1.0' . "\r\n";
        $headersMail .= 'Content-type: text/plain; charset=utf-8' . "\r\n";
        $headersMail .= "From: \"".$tuteur."\" <".$mailTut."> \r\n".

                    "Subject: [stalt] Mission retenue pour la soutenance de ".$etud."\r\n".
                    "To: \"".$ref."\"<".$mailRef.">".
                      (strlen($mailRef2)>0?",\"".$ref2."\"<".$mailRef2.">":"")." \r\n".
                    "Cc: \"".$etud."\"<".$mailEtud.">, ".
                    "\"".$tuteur."\" <".$mailTut."> \r\n";

        echo "
            <p>".
            to_html($headersMail)."<br/>".
            to_html($msgMail)."<br/>".
            "</p>
            <form method='post' action='".ABS_START_URL."/index.php'>
                <input type='hidden' name='page' value='interface/faireActionsEtudiants_act'/>
                <input type='hidden' name='action' value='faireNotifierCrEtapeMissionSoutenance_act'/>
                <input type='hidden' name='selection[]' value='".$alt[0]."'/>
                <input type='submit' value='Envoyer mail'/>
                <!--Envoi impossible pour le moment.-->
            </form>
        ";
       
    }

?>
