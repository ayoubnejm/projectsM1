<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once(ABS_START_PATH."/dbmngt/queries.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/ldap/updateStudMails.php");

    $conn=doConnection();

    $altRefs="'".$selection[0]."'";
    for ($i=1;$i<count($selection);$i++)
        $altRefs.=", "."'".$selection[$i]."'";

    $query="select etudRef from contrat where alternanceCle in ($altRefs)";
    error_log("majMailLille1 $query");
    $etudCles=mysql_query($query);
    $etudCle=mysql_fetch_row($etudCles);

    while ($etudCle) {
        updateMailFor($etudCle[0]);
        $etudCle=mysql_fetch_row($etudCles);
    }



?>
