<?php 
        require_once(ABS_START_PATH."/dbmngtPDO/connectPDO.php");
        require_once(ABS_START_PATH."/dbmngtPDO/queriesPDO.php");
		
        require_once(ABS_START_PATH."/html/dbutils.php");
        require_once(ABS_START_PATH."/log/log.php");


        $altRefs=str_replace("\\","",getParam("altRefs",null));

        if ($altRefs===FALSE) die("Demande d'activation invalide!");
        $etudNames=getParam("etudNames",null);
        $yearRef=$_SESSION[REF_YEAR];

        action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"faireSupprimerEtud",array($selection));
		?>
		<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
		<?php 
		echo "<br/><br/>";        
		echo "Activation de ".$etudNames." de l'application STALT en cours ... <br/> ";
		 echo "<br/><br/>";
        //echo "Vous pouvez re-inscrire des étudiants depuis le menu Re-Inscription ".$etudNames." de l'application STALT en cours ... <br/> ";





		$bdd=doConnectionPDO("stalt2");

    
        $etudCles=getEtudClesSecrListFromAlternanceCle($bdd,$altRefs);
      	

		$resultat = activerEtud_Secr($bdd, $etudCles);
		
		
        if ($resultat != null)
        {
            echo "<b>Activation réussie!</b>";
        } else {
            echo "Echec!";
        }
		  echo "<br/><br/>";	
		  echo "<input type='button' value='Precedent' onclick='javascript:history.go(-2);'/>";
		?>
		</div>
		</div>
