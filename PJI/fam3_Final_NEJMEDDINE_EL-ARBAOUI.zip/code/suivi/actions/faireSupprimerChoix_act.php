
<?php
    require_once ABS_START_PATH.'/secure/auth.php';

    if (!hasRole(PROF_ROLE))
        redirectAuth(null);

    require_once(ABS_START_PATH."/dbmngt/connect.php");
    require_once(ABS_START_PATH."/dbmngt/queriesTuteur.php");
    require_once(ABS_START_PATH."/rss/rss.php");
    require_once(ABS_START_PATH."/log/log.php");

    action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],"faireSupprimerChoix",array($selection));

    $conn=doConnection();
    doDeleteChoixTuteurPourEtudiant($conn,$_REQUEST["altCle"],$_REQUEST["tuteurRef"]);
    regenerateAllTuteursChoixRss();
    mysql_close($conn);
    require_once(ABS_START_PATH."/interface/choixEtudiantsParTuteur_act.php");
?>