function generateUpdateReferentForm() {
    document.write("<div id='updateReferent_div' style='visibility:hidden;position:absolute;width:100%;textalign:center;zIndex:1000;left:200;background-color:rgba(100,100,100,1);' >\n\
                <form id='updateReferent' action='#' method='POST'> "+
            "<input type='hidden' name='ref_cle' value='default'/>"+
            "<input type='hidden' name='ref_count' value='1'/>"+
            "<input type='hidden' name='entr_regie' value='entr'/>"+
            //"<input type='hidden' name='entr_nom' value='default'/>"+
            "<input type='hidden' name='main_form' value='form0'/>"+
            "<h2>Mis à jour référent : \n\
              <div id='nom_div_referent_update'>Default</div></h2> \n\
            <table witdh='500'>"+
                //"<tr><td>Nom *:</td><td><input type='text' name='ref_nom' value=''/></td></tr>"+
                //"<tr><td>Prenom *:</td><td><input type='text' name='ref_prenom' value=''/></td></tr>"+
                "<tr><td>Email *:</td><td><input type='text' name='ref_email' value=''/></td></tr>"+
                "<tr><td>Téléphone *:</td><td><input type='text' name='ref_tel' value=''/></td></tr>"+
                "<tr><td>Fonction *:</td><td><input type='text' name='ref_fonction' value=''/></td></tr>"+

                "<tr> \n\
                    <td>\n\
                        * Laisser vide si pas de modification \n\
                    </td> \n\
                    <td><table width='100%'> \n\
                        <td><input type='button' style='color:red' name='cancel' value='Annuler' onClick='javascript:showHideModal(\"updateReferent_div\")'/>\n\
                        </td><td><input type='button' style='color:orange' name='inscrire' \n\
                                onClick='javascript:\n\
                                            faireUpdateReferent(\"updateReferent\");' \n\
                                 value='Update'/> \n\
                        </td> \n\
                        </td></tr> \n\
                        </table> \n\
                    </td> \n\
                </tr> \n\
            </table> \n\
        </form></div>");
        doModal('updateReferent_div');
 }

 function faireUpdateReferent(form) {
   var xhr=getXMLHttpRequest();
   xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            readUpdateReferentData(xhr.responseXML,form);
        }
    };

    xhr.open("POST", "ajax/faireUpdateReferent.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
     params="";
    //alert("submit Data!");

    ref_cle=getFieldValue(form,'ref_cle');
    if (ref_cle.length>0)
        params="ref_cle=" + ref_cle;
    
    ref_email=getFieldValue(form,'ref_email');
    //alert(ref_email);
    if (ref_email.length>0)
      params+="&ref_email=" + ref_email;

    ref_tel=getFieldValue(form,'ref_tel');
    //alert(ref_tel);
    if (ref_tel.length>0)
      params+="&ref_tel=" + ref_tel;

    ref_fonction=getFieldValue(form,'ref_fonction');
    //alert(ref_fonction);
    if (ref_fonction.length>0)
      params+="&ref_fonction=" + ref_fonction;

    
    
    xhr.send(params);

 }

 function readUpdateReferentData(oData,form) {
  //alert("read Data!");
  var entrType=getFieldValue(form,"entr_regie");
  var entrForm=getFieldValue(form,"main_form");
  var refCount=getFieldValue(form,"ref_count");

  var nodes=oData.getElementsByTagName("item");
  var msg=nodes[0].getAttribute("msg").toString();
  if (nodes[0].getAttribute("code").toString()=="0") {
    var optsName="fa_"+((entrType=="regie")?"regie_":"")+"referent"+(refCount==2?2:"")+"_cle";

    opts=getElt(entrForm).elements.namedItem(optsName).options;
    var idx=opts.selectedIndex;
    opts[idx]=new Option(msg.substr(5),getFieldValue(form,'ref_cle'),true,true);

    optsName="fa_"+((entrType=="regie")?"regie_":"")+"referent"+(refCount==1?2:"")+"_cle";
    opts=getElt(entrForm).elements.namedItem(optsName).options;
    opts[idx]=new Option(msg.substr(5),getFieldValue(form,'ref_cle'),false,false);
    showHideModal('updateReferent_div');
    alert("Référent mis à jour avec succès!");
  } else {
    alert("Erreur : "+nodes[0].getAttribute("msg").toString());
    }
 }

 function updateReferent(formName,entr_regie,ref_count)
{
    //alert(entr_regie+' - regie - '+getOptionCle(formName,'fa_regie_bureau_cle'));
    //alert(entr_regie+' - entr - '+getOptionCle(formName,'fa_bureau_cle'));
    /*if((entr_regie=='regie' && getOptionCle(formName,'fa_regie_bureau_cle').length>0) ||
      (entr_regie=='entr' && getOptionCle(formName,'fa_bureau_cle').length>0))
    {*/

        selectEntr=(entr_regie=="regie")?
                ((ref_count==1)?getElt(formName).fa_regie_referent_cle:getElt(formName).fa_regie_referent2_cle):
                ((ref_count==1)?getElt(formName).fa_referent_cle:getElt(formName).fa_referent2_cle);
              
        getElt("nom_div_referent_update").innerHTML=selectEntr.options[selectEntr.selectedIndex].label;
        //alert("bureauCle");
        setFieldValue("updateReferent","ref_cle",selectEntr.options[selectEntr.selectedIndex].value);
        setFieldValue("updateReferent","main_form",formName);
        setFieldValue("updateReferent","entr_regie",entr_regie);
        setFieldValue("updateReferent","ref_count",ref_count);
        showHideModal('updateReferent_div');
        return "#";
    /*}
    else
    {
        alert("Veuillez sélectionner une entreprise!");
        return "#";
    }*/
}