<?php
// Ajout class de gestion des referents du 10/05/2012 JTA
header("Content-Type: text/xml");

require_once '../secure/auth.php';

if (!hasRole(PROF_ROLE) && !hasRole(STUD_ROLE))
    redirectAuth(null);


require_once '../html/utils.php';
require_once '../html/dbutils.php';
require_once '../dbmngt/inscrire.php';
echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";


$conn = doConnection();
$entreprise = trim(getParam("entr_cle", ""));
$entrepriseNom = trim(getParam("entr_nom", ""));
$bur_adresse = trim(getParam("bur_adresse", ""));
$bur_tel = trim(getParam("bur_tel", ""));
$bur_ville = trim(getParam("bur_ville", ""));
$bur_cp = trim(getParam("bur_cp", ""));
// Ajout de deux variables: ajouté par se et an
$latitude = trim(getParam("latitude", ""));
$longitude = trim(getParam("longitude", ""));
$distance = trim(getParam("bur_dist", ""));

$err_msg = $err_msg = faireInscrireBureau(
                                $bur_adresse, $bur_tel, $bur_ville, $bur_cp, $entreprise, $latitude, $longitude, $distance
                        );

echo "<list><item code=\"".($err_msg[0]=='N'?1:0)."\" msg=\"".$err_msg."\" ></item></list>";
error_log ("<list><item code=\"".($err_msg[0]=='N'?1:0)."\" msg=\"".$err_msg."\" ></item></list>");
?>
