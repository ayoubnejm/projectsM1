<?php
// Ajout class de gestion des referents du 10/05/2012 JTA
header("Content-Type: text/xml");

require_once '../secure/auth.php';

if (!hasRole(PROF_ROLE) && !hasRole(STUD_ROLE))
    redirectAuth(null);


require_once '../html/utils.php';
require_once '../html/dbutils.php';
require_once '../dbmngt/inscrire.php';
echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";


$conn = doConnection();
$fa_entr_nom=trim(getParam("entr_nom",""));
$fa_entr_adresse=(trim(getParam("entr_adresse","")));
$fa_entr_tel=(trim(getParam("entr_tel","")));
$fa_entr_ville=(trim(getParam("entr_ville","")));
$fa_entr_cp=(trim(getParam("entr_cp","")));
$fa_entr_opcaRef=getParam("entr_opcaRef","1"); 

$err_msg=faireInscrireentr(
                $fa_entr_nom,
                $fa_entr_adresse,
                $fa_entr_tel,
                $fa_entr_ville,
                $fa_entr_cp,
                $fa_entr_opcaRef
                );

echo "<list><item code=\"".($err_msg[0]=='N'?1:0)."\" msg=\"".$err_msg."\" ></item></list>";
error_log ("<list><item code=\"".($err_msg[0]=='N'?1:0)."\" msg=\"".$err_msg."\" ></item></list>");
?>
