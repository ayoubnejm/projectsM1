-- MySQL dump 10.13  Distrib 5.1.49, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: fi_stages11
-- ------------------------------------------------------
-- Server version	5.1.49-3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contrat`
--

DROP TABLE IF EXISTS `contrat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contrat` (
  `etudRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tuteurRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `referentRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `opcaRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT '__sans opca__',
  `typeContrat` varchar(5) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `debutContrat` date DEFAULT NULL,
  `finContrat` date DEFAULT NULL,
  `accordOPCA` date DEFAULT NULL,
  `signatureContrat` date DEFAULT NULL,
  `alternanceCle` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sudesRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `notifAttribTuteur` int(11) DEFAULT NULL,
  PRIMARY KEY (`alternanceCle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contrat`
--

LOCK TABLES `contrat` WRITE;
/*!40000 ALTER TABLE `contrat` DISABLE KEYS */;
INSERT INTO `contrat` VALUES ('a.da-costa-maia','lhoussai','a.da-costa-maiaR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','a.da-costa-maiaA',NULL,1),('a.el-idrissi','amir','a.el-idrissiR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','a.el-idrissiA',NULL,1),('a.ludunge-wendi','varre','a.ludunge-wendiR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','a.ludunge-wendiA',NULL,1),('abderezak.medjoudj','','abderezak.medjoudjR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'abderezak.medjoudjA',NULL,NULL),('adrien.burillon','olejnik','adrien.burillonR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','adrien.burillonA',NULL,1),('adrien.langlet','bilasco','adrien.langletR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','adrien.langletA',NULL,1),('alexandre.loywick','lhoussai','alexandre.loywickR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','alexandre.loywickA',NULL,1),('alexandre.raulin','fabien.delecroix','alexandre.raulinR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','alexandre.raulinA',NULL,1),('alexis.boutrouille','mailliet','alexis.boutrouilleR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','alexis.boutrouilleA',NULL,1),('alexis.rucar','olejnik','alexis.rucarR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','alexis.rucarA',NULL,1),('ali.hedjaz','noe','ali.hedjazR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','ali.hedjazA',NULL,1),('amara.timera','routier','amara.timeraR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','amara.timeraA',NULL,1),('amina.el-mekki','kuttler','amina.el-mekkiR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','amina.el-mekkiA',NULL,1),('amine.ouelhadj','grimaud','amine.ouelhadjR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','amine.ouelhadjA',NULL,NULL),('antoine.bertout','boulet','antoine.bertoutR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','antoine.bertoutA',NULL,NULL),('antoine.goubel','wegrzyno','antoine.goubelR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','antoine.goubelA',NULL,1),('arnaud.deville','grimaud','arnaud.devilleR','__sans opca__',NULL,'2004-04-12','2028-09-12','0000-00-00','0000-00-00','arnaud.devilleA',NULL,NULL),('arthur.aubrun','','arthur.aubrunR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'arthur.aubrunA',NULL,NULL),('aurore.castelain','olejnik','aurore.castelainR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','aurore.castelainA',NULL,1),('ayoub.nejmeddine','bilasco','ayoub.nejmeddineR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','ayoub.nejmeddineA',NULL,1),('b.van-ryseghem','rsilvest','b.van-ryseghemR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','b.van-ryseghemA',NULL,1),('benjamin.allaert','plenacos','benjamin.allaertR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','benjamin.allaertA',NULL,1),('benjamin.clermont','plenacos','benjamin.clermontR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','benjamin.clermontA',NULL,1),('benjamin.digeon','mailliet','benjamin.digeonR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','benjamin.digeonA',NULL,1),('benjamin.flahauw','nebut','benjamin.flahauwR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','benjamin.flahauwA',NULL,1),('benjamin.makusa','mailliet','benjamin.makusaR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','benjamin.makusaA',NULL,1),('benjamin.ruytoor','nebut','benjamin.ruytoorR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','benjamin.ruytoorA',NULL,1),('benoit.boutin','rsilvest','benoit.boutinR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','benoit.boutinA',NULL,1),('benoit.godissart','peter','benoit.godissartR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','benoit.godissartA',NULL,NULL),('benoit.mellinger','','benoit.mellingerR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'benoit.mellingerA',NULL,NULL),('camille.eurin','','camille.eurinR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'camille.eurinA',NULL,NULL),('camille.riquier','olejnik','camille.riquierR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','camille.riquierA',NULL,1),('camille.teruel','marvie','camille.teruelR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','camille.teruelA',NULL,NULL),('caroline.soyez','lebbe','caroline.soyezR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','caroline.soyezA',NULL,1),('cesar.splete','noe','cesar.spleteR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','cesar.spleteA',NULL,1),('charles.husquin','bilasco','charles.husquinR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','charles.husquinA',NULL,1),('clement.mondon','wegrzyno','clement.mondonR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','clement.mondonA',NULL,NULL),('clement.nicolet','','clement.nicoletR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'clement.nicoletA',NULL,NULL),('clement.vallerand','voge','clement.vallerandR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','clement.vallerandA',NULL,1),('clement1.lefevre','marmion','clement1.lefevreR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','clement1.lefevreA',NULL,1),('cyril.cordiez','mailliet','cyril.cordiezR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','cyril.cordiezA',NULL,1),('damien.leflon',NULL,'damien.leflonR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','damien.leflonA',NULL,2),('damien.walle','','damien.walleR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'damien.walleA',NULL,NULL),('darina.abderrahmane','','darina.abderrahmaneR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'darina.abderrahmaneA',NULL,NULL),('david.debehogne','decomite','david.debehogneR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','david.debehogneA',NULL,1),('david.lestaevel','','david.lestaevelR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'david.lestaevelA',NULL,NULL),('david.martel','jctarby','david.martelR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','david.martelA',NULL,NULL),('dimitri.descamps','marvie','dimitri.descampsR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','dimitri.descampsA',NULL,1),('donovan.watteau','liefooga','donovan.watteauR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','donovan.watteauA',NULL,1),('e.helluy-lafont','olejnik','e.helluy-lafontR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','e.helluy-lafontA',NULL,1),('edouard.berton','olejnik','edouard.bertonR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','edouard.bertonA',NULL,1),('eglantine.houdart','rsilvest','eglantine.houdartR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','eglantine.houdartA',NULL,1),('eh.ait-mahiddine','lepallec','eh.ait-mahiddineR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','eh.ait-mahiddineA',NULL,NULL),('el.foe-ongolo','','el.foe-ongoloR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'el.foe-ongoloA',NULL,NULL),('emeric.edmond','','emeric.edmondR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'emeric.edmondA',NULL,NULL),('emilien.hidden','boulet','emilien.hiddenR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','emilien.hiddenA',NULL,NULL),('emmeanuel.pede','olejnik','emmeanuel.pedeR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','emmeanuel.pedeA',NULL,1),('ewald.croxo','bilasco','ewald.croxoR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','ewald.croxoA',NULL,NULL),('fabien.duhamel','rouvoy','fabien.duhamelR','__sans opca__',NULL,'2012-03-19','2012-09-19','0000-00-00','2012-03-08','fabien.duhamelA',NULL,NULL),('fabien.piette','bilasco','fabien.pietteR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','fabien.pietteA',NULL,1),('farid.oussi','','farid.oussiR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'farid.oussiA',NULL,NULL),('florent.david','voge','florent.davidR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','florent.davidA',NULL,1),('florent.fouquet','boulet','florent.fouquetR','__sans opca__',NULL,'2012-04-16','2012-09-30','0000-00-00','0000-00-00','florent.fouquetA',NULL,NULL),('florent.guette','boulet','florent.guetteR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','florent.guetteA',NULL,NULL),('florian.bruffaert','beaufils','florian.bruffaertR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','florian.bruffaertA',NULL,1),('florian.carlier','caronc','florian.carlierR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','florian.carlierA',NULL,1),('florian.kauffmann','','florian.kauffmannR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'florian.kauffmannA',NULL,NULL),('florian.licour','sedoglav','florian.licourR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','florian.licourA',NULL,1),('florian.monsellier','seinturi','florian.monsellierR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','florian.monsellierA',NULL,NULL),('francois.dervaux','','francois.dervauxR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'francois.dervauxA',NULL,NULL),('francois.gruchala','','francois.gruchalaR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'francois.gruchalaA',NULL,NULL),('francois.lepan','marmion','francois.lepanR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','francois.lepanA',NULL,1),('francois.poulain','jctarby','francois.poulainR','__sans opca__',NULL,'2012-09-14','0000-00-00','0000-00-00','2012-03-19','francois.poulainA',NULL,NULL),('francois.roussel','','francois.rousselR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'francois.rousselA',NULL,NULL),('gauvain.marquet','routier','gauvain.marquetR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','gauvain.marquetA',NULL,1),('germain-de-montauzan','lhoussai','germain-de-montauzanR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','germain-de-montauzanA',NULL,1),('guillaume.barideau','grimaud','guillaume.barideauR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','guillaume.barideauA',NULL,NULL),('guillaume.dufosset','','guillaume.dufossetR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'guillaume.dufossetA',NULL,NULL),('hanae.rateau','','hanae.rateauR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'hanae.rateauA',NULL,NULL),('helene.weexsteen','','helene.weexsteenR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'helene.weexsteenA',NULL,NULL),('jason.toulotte','poteaux','jason.toulotteR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','jason.toulotteA',NULL,1),('jeremie.samson','varre','jeremie.samsonR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','jeremie.samsonA',NULL,1),('jeremie.segura','aubert','jeremie.seguraR','__sans opca__',NULL,'2012-08-31','0000-00-00','0000-00-00','2012-03-19','jeremie.seguraA',NULL,NULL),('jeremy.charlet','rouvoy','jeremy.charletR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','jeremy.charletA',NULL,NULL),('jeremy.diaz','mailliet','jeremy.diazR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','jeremy.diazA',NULL,1),('jerome.wyckaert','lebbe','jerome.wyckaertR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','jerome.wyckaertA',NULL,1),('jessy.lavorel','','jessy.lavorelR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'jessy.lavorelA',NULL,NULL),('jules.cissoko','decomite','jules.cissokoR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','jules.cissokoA',NULL,1),('jules.ivanic','plenacos','jules.ivanicR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','jules.ivanicA',NULL,1),('julia.grabkina','','julia.grabkinaR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'julia.grabkinaA',NULL,NULL),('julian.ronsse','sedoglav','julian.ronsseR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','julian.ronsseA',NULL,1),('julie.poulet','bogaert','julie.pouletR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','julie.pouletA',NULL,1),('julien.delavennat','decomite','julien.delavennatR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','julien.delavennatA',NULL,1),('julien.duquesnoy','','julien.duquesnoyR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'julien.duquesnoyA',NULL,NULL),('julien.duribreux','jmarti','julien.duribreuxR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','julien.duribreuxA',NULL,1),('julien.hazebroucq','olejnik','julien.hazebroucqR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','julien.hazebroucqA',NULL,1),('julien.lhomme','decomite','julien.lhommeR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','julien.lhommeA',NULL,1),('julien.weillaert','lebbe','julien.weillaertR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','julien.weillaertA',NULL,1),('justin.dufour','','justin.dufourR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'justin.dufourA',NULL,NULL),('kevin.mestdach','decomite','kevin.mestdachR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','kevin.mestdachA',NULL,1),('l3infofi,l3miagefi1BB22','','l3infofi,l3miagefi1BB22R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'l3infofi,l3miagefi1BB22A',NULL,NULL),('l3infofi,l3miagefi1RN24','','l3infofi,l3miagefi1RN24R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'l3infofi,l3miagefi1RN24A',NULL,NULL),('ryv.alapide','sedoglav','l3infofi1AR25R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi1AR25A',NULL,1),('em.benouiz','','l3infofi1BE35R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'l3infofi1BE35A',NULL,NULL),('laura.leclercq','bilasco','l3infofi1LL21R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi1LL21A',NULL,1),('matthieu1.lecomte','','l3infofi1LM40R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'l3infofi1LM40A',NULL,NULL),('antoine2.martin','rsilvest','l3infofi1MA33R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi1MA33A',NULL,1),('l3infofi1RN35','decomite','l3infofi1RN35R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3infofi1RN35A',NULL,1),('zakariae.azaroual','decomite','l3miagefi1AZ32R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefi1AZ32A',NULL,1),('l3miagefi1BB31','decomite','l3miagefi1BB31R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefi1BB31A',NULL,1),('boubacar-haby.bah','','l3miagefi1BB35R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'l3miagefi1BB35A',NULL,NULL),('pierre2.bailleul','bilasco','l3miagefi1BP25R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefi1BP25A',NULL,1),('remi.bailleul','sedoglav','l3miagefi1BR35R','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','l3miagefi1BR35A',NULL,1),('laurent.laplace','lebbe','laurent.laplaceR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','laurent.laplaceA',NULL,1),('lc.nsourou-ndong','sedoglav','lc.nsourou-ndongR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','lc.nsourou-ndongA',NULL,1),('ld.arenas-pimentel','nebut','ld.arenas-pimentelR','__sans opca__',NULL,'2012-02-16','2012-08-16','0000-00-00','2012-01-26','ld.arenas-pimentelA',NULL,NULL),('liuhua.gao','grimaud','liuhua.gaoR','__sans opca__',NULL,'2012-03-05','2012-09-07','0000-00-00','2012-01-20','liuhua.gaoA',NULL,NULL),('loic.allart','varre','loic.allartR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','loic.allartA',NULL,1),('lois.arens','bilasco','lois.arensR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','lois.arensA',NULL,2),('louis.billiet','yroos','louis.billietR','__sans opca__',NULL,'2012-04-16','2012-07-13','0000-00-00','0000-00-00','louis.billietA',NULL,1),('louis.motte',NULL,'louis.motteR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','louis.motteA',NULL,NULL),('louis.saint-maxent','salson','louis.saint-maxentR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','louis.saint-maxentA',NULL,1),('lucie.meresse','jmarti','lucie.meresseR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','lucie.meresseA',NULL,1),('lucille.dhaleine','oussous','lucille.dhaleineR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','lucille.dhaleineA',NULL,1),('m2eservfiBB30','','m2eservfiBB30R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2eservfiBB30A',NULL,NULL),('m2iaglfi1BI28','','m2iaglfi1BI28R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2iaglfi1BI28A',NULL,NULL),('m2iaglfi1BI32','','m2iaglfi1BI32R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2iaglfi1BI32A',NULL,NULL),('m2iaglfi1BI38','','m2iaglfi1BI38R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2iaglfi1BI38A',NULL,NULL),('m2iaglfiBB37','','m2iaglfiBB37R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2iaglfiBB37A',NULL,NULL),('m2iaglfiBI36','','m2iaglfiBI36R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2iaglfiBI36A',NULL,NULL),('antoine2.descamps','','m2miagefi1DA29R','__sans opca__',NULL,NULL,NULL,NULL,NULL,'m2miagefi1DA29A',NULL,NULL),('adrien.barreau','rouvoy','m2tiirfi1BA26R','__sans opca__',NULL,'2012-04-03','2012-09-28','0000-00-00','0000-00-00','m2tiirfi1BA26A',NULL,NULL),('ma.boutillier','komorows','ma.boutillierR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','ma.boutillierA',NULL,1),('mael.baekelandt','boulet','mael.baekelandtR','__sans opca__',NULL,'2012-03-19','2012-08-17','0000-00-00','0000-00-00','mael.baekelandtA',NULL,NULL),('malika.rakhaoui','plenacos','malika.rakhaouiR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','malika.rakhaouiA',NULL,1),('marine.becker','','marine.beckerR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'marine.beckerA',NULL,NULL),('martin.caby','sedoglav','martin.cabyR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','martin.cabyA',NULL,1),('mathieu.bon','lepallec','mathieu.bonR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','mathieu.bonA',NULL,NULL),('mathieu.dervaux','','mathieu.dervauxR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'mathieu.dervauxA',NULL,NULL),('mathilde.lagache','','mathilde.lagacheR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'mathilde.lagacheA',NULL,NULL),('matthieu.laurent','lebbe','matthieu.laurentR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','matthieu.laurentA',NULL,1),('matthieu.mastio','grimaud','matthieu.mastioR','__sans opca__',NULL,'2012-03-14','2012-08-17','0000-00-00','0000-00-00','matthieu.mastioA',NULL,NULL),('matthieu.poudroux','dekeyser','matthieu.poudrouxR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','matthieu.poudrouxA',NULL,NULL),('maxime.piquette','seinturi','maxime.piquetteR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','maxime.piquetteA',NULL,NULL),('maxime.vanpeene','sedoglav','maxime.vanpeeneR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','maxime.vanpeeneA',NULL,1),('melissa.blain','komorows','melissa.blainR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','melissa.blainA',NULL,1),('mengmeng.tang','pupin','mengmeng.tangR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','mengmeng.tangA',NULL,1),('mh.ouannane','bilasco','mh.ouannaneR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','mh.ouannaneA',NULL,1),('mickael.camier','salson','mickael.camierR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','mickael.camierA',NULL,1),('mickael.duruisseau','marvie','mickael.duruisseauR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','mickael.duruisseauA',NULL,1),('mina.elkhotfi','weinberl','mina.elkhotfiR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','mina.elkhotfiA',NULL,1),('nabil1.ech-charraq','liefooga','nabil1.ech-charraqR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','nabil1.ech-charraqA',NULL,1),('nassim.hassaine','amir','nassim.hassaineR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','nassim.hassaineA',NULL,1),('nathanael.martin','plenacos','nathanael.martinR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','nathanael.martinA',NULL,1),('navish.lallbeeharry','sedoglav','navish.lallbeeharryR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','navish.lallbeeharryA',NULL,1),('nicolas.colman','aubert','nicolas.colmanR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','nicolas.colmanA',NULL,1),('nicolas.coyard','marvie','nicolas.coyardR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','nicolas.coyardA',NULL,1),('nicolas.malassagne','lepallec','nicolas.malassagneR','__sans opca__',NULL,'2012-03-12','2012-09-12','0000-00-00','2011-12-01','nicolas.malassagneA',NULL,NULL),('nicolas.quequet','','nicolas.quequetR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'nicolas.quequetA',NULL,NULL),('olivier.debreu','plenacos','olivier.debreuR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','olivier.debreuA',NULL,1),('omar.chahbouni',NULL,'omar.chahbouniR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','omar.chahbouniA',NULL,NULL),('ouardia.ma-z','kuttler','ouardia.ma-zR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','ouardia.ma-zA',NULL,2),('oussama.mahmoudi','nebut','oussama.mahmoudiR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','oussama.mahmoudiA',NULL,NULL),('pauline.hache','wegrzyno','pauline.hacheR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','pauline.hacheA',NULL,1),('pierre.frayer','lebbe','pierre.frayerR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','pierre.frayerA',NULL,1),('pierre.ramelot','plenacos','pierre.ramelotR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','pierre.ramelotA',NULL,1),('pierrick.lesage','liefooga','pierrick.lesageR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','pierrick.lesageA',NULL,1),('quentin.petit','mailliet','quentin.petitR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','quentin.petitA',NULL,1),('rabab.bouziane','decomite','rabab.bouzianeR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','rabab.bouzianeA',NULL,1),('rachid.khelil','wegrzyno','rachid.khelilR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','rachid.khelilA',NULL,1),('remi.boens','poteaux','remi.boensR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','remi.boensA',NULL,1),('remi.houdelette','oussous','remi.houdeletteR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','remi.houdeletteA',NULL,1),('remi.kaczmarek','amir','remi.kaczmarekR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','remi.kaczmarekA',NULL,1),('remy.di-fant','','remy.di-fantR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'remy.di-fantA',NULL,NULL),('romain.belmonte','oussous','romain.belmonteR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','romain.belmonteA',NULL,1),('romain.blas','caronc','romain.blasR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','romain.blasA',NULL,1),('romain.bordone','sedoglav','romain.bordoneR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','romain.bordoneA',NULL,1),('romain.frangi','voge','romain.frangiR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','romain.frangiA',NULL,1),('romain.le-jeune','marvie','romain.le-jeuneR','__sans opca__',NULL,'2012-02-29','2012-08-31','0000-00-00','2012-01-27','romain.le-jeuneA',NULL,NULL),('romain.windels','rsilvest','romain.windelsR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','romain.windelsA',NULL,1),('ronan.dhellemmes','lemaire','ronan.dhellemmesR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','ronan.dhellemmesA',NULL,1),('s.doutreligne','oussous','s.doutreligneR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','s.doutreligneA',NULL,1),('sara.el-arbaoui','poteaux','sara.el-arbaouiR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','sara.el-arbaouiA',NULL,1),('sarah.aichaoui','grimaud','sarah.aichaouiR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','sarah.aichaouiA',NULL,NULL),('sebastien.rommelard','bilasco','sebastien.rommelardR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','sebastien.rommelardA',NULL,1),('sebastien2.leclercq','routier','sebastien2.leclercqR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','sebastien2.leclercqA',NULL,1),('shichen.zhao','rsilvest','shichen.zhaoR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','shichen.zhaoA',NULL,1),('sichen.qian','kuttler','sichen.qianR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','sichen.qianA',NULL,1),('simon.billiau','mailliet','simon.billiauR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','simon.billiauA',NULL,1),('sophie.mantel','komorows','sophie.mantelR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','sophie.mantelA',NULL,1),('soufiane.agadr','bogaert','soufiane.agadrR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','soufiane.agadrA',NULL,1),('stanislas.courouble','jmarti','stanislas.couroubleR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','stanislas.couroubleA',NULL,1),('stefan.dochez','oussous','stefan.dochezR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','stefan.dochezA',NULL,1),('sylvain.bialasik','','sylvain.bialasikR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'sylvain.bialasikA',NULL,NULL),('sylvain.depauw','dekeyser','sylvain.depauwR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','sylvain.depauwA',NULL,NULL),('sylvain.magnier','plenacos','sylvain.magnierR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','sylvain.magnierA',NULL,1),('sylvain.ruchot','jmarti','sylvain.ruchotR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','sylvain.ruchotA',NULL,1),('ta.sow','','ta.sowR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'ta.sowA',NULL,NULL),('thibaut.frain','plenacos','thibaut.frainR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thibaut.frainA',NULL,1),('thierry.ngando-ngwa','','thierry.ngando-ngwaR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'thierry.ngando-ngwaA',NULL,NULL),('thomas.aubry','voge','thomas.aubryR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thomas.aubryA',NULL,1),('thomas.baert','lemaire','thomas.baertR','__sans opca__',NULL,'2012-03-12','2012-09-09','0000-00-00','0000-00-00','thomas.baertA',NULL,NULL),('thomas.baguette','mailliet','thomas.baguetteR','__sans opca__',NULL,'2012-04-10','2012-09-28','0000-00-00','0000-00-00','thomas.baguetteA',NULL,NULL),('thomas.besset','weinberl','thomas.bessetR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thomas.bessetA',NULL,1),('thomas.buisine','decomite','thomas.buisineR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thomas.buisineA',NULL,1),('thomas.camberlin','bogaert','thomas.camberlinR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thomas.camberlinA',NULL,1),('thomas.chabin','rsilvest','thomas.chabinR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thomas.chabinA',NULL,1),('thomas.clement','rouvoy','thomas.clementR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thomas.clementA',NULL,NULL),('thomas.crepel-cardon','jmarti','thomas.crepel-cardonR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thomas.crepel-cardonA',NULL,1),('thomas.deblock','yroos','thomas.deblockR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thomas.deblockA',NULL,1),('thomas.maupain','duchien','thomas.maupainR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thomas.maupainA',NULL,NULL),('thomas.vanderheyden','decomite','thomas.vanderheydenR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','thomas.vanderheydenA',NULL,1),('thomas.zonca','','thomas.zoncaR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'thomas.zoncaA',NULL,NULL),('tianjun.lin','kuttler','tianjun.linR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','tianjun.linA',NULL,1),('titouan.compiegne','yroos','titouan.compiegneR','__sans opca__',NULL,'2012-03-19','2012-09-07','0000-00-00','0000-00-00','titouan.compiegneA',NULL,NULL),('tom.massol','plenacos','tom.massolR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','tom.massolA',NULL,1),('tony.tran','marvie','tony.tranR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','tony.tranA',NULL,1),('tristan.cavelier','oussous','tristan.cavelierR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','tristan.cavelierA',NULL,1),('tung-minh.pham','rouvoy','tung-minh.phamR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'tung-minh.phamA',NULL,NULL),('valentin.fix','decomite','valentin.fixR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','valentin.fixA',NULL,1),('victor.lefebvre','oussous','victor.lefebvreR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','victor.lefebvreA',NULL,1),('vincent.guichard','bogaert','vincent.guichardR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','vincent.guichardA',NULL,1),('vincent.knockaert','','vincent.knockaertR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'vincent.knockaertA',NULL,NULL),('vincent.voss','derbel','vincent.vossR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','vincent.vossA',NULL,NULL),('walid.trabelsi','','walid.trabelsiR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'walid.trabelsiA',NULL,NULL),('wissem.hadhri','amir','wissem.hadhriR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','wissem.hadhriA',NULL,1),('yannick.vanuxem','','yannick.vanuxemR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'yannick.vanuxemA',NULL,NULL),('yoann.bouquet','olejnik','yoann.bouquetR','__sans opca__',NULL,'0000-00-00','0000-00-00','0000-00-00','0000-00-00','yoann.bouquetA',NULL,1),('zouhair.makhout','','zouhair.makhoutR','__sans opca__',NULL,NULL,NULL,NULL,NULL,'zouhair.makhoutA',NULL,NULL);
/*!40000 ALTER TABLE `contrat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `fa_entreprise`
--

DROP TABLE IF EXISTS `fa_entreprise`;
/*!50001 DROP VIEW IF EXISTS `fa_entreprise`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_entreprise` (
  `nom` varchar(50),
  `adresse` text,
  `tel` varchar(20),
  `ville` text,
  `codePostal` varchar(5),
  `opcaRef` varchar(100),
  `entrepriseCle` varchar(100)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `infoetud`
--

DROP TABLE IF EXISTS `infoetud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `infoetud` (
  `alternanceRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dateSaisie` date DEFAULT NULL,
  `service` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `client` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `missions` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `environnementTechnique` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `motscles` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`alternanceRef`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `infoetud`
--

LOCK TABLES `infoetud` WRITE;
/*!40000 ALTER TABLE `infoetud` DISABLE KEYS */;
INSERT INTO `infoetud` VALUES ('eh.ait-mahiddineA','0000-00-00','','','Intégré dans une équipe de développement dédiée à l’offre e-Commerce, je participerai à la réalisation d’un ou plusieurs services fonctionnels prévus dans la roadmap de l’offre. \r\n\r\n\r\n','Les développements sont réalisés sous forme de service dans une architecture SOA en utilisant le container léger Spring. Les services seront exposés via une interface REST JAX-RS développés avec Jersey en utilisant le design pattern DTO. Le code métier du service sera réalisé en composants orchestrés par Apache Camel. La couche de persistance utilise le pattern DAO et s’appuie sur JPA (hibernate)',''),('ld.arenas-pimentelA','0000-00-00','Altum ERP','','• Développement d’outils en support au déploiement de l\'ERP Altum (Comarch). Mise en place de migrations automatiques des données complexes entre les différentes bases de données.\r\n• Pré-configuration automatique de l’environnement et mise en place de solutions de déploiement.\r\n• Développement de modules avancés compatibles avec l\'architecture ERP et développement de process. Création des interfaces homme-machine dans le système ERP.','• Langages orienté objet, notamment C++/C#\r\n• Programmation orientée objet\r\n• Plateformes Windows\r\n• Bases de données MS SQL Server\r\n• Langue: Anglais\r\n• Techniques d’ingénieurie de solutions: contrôle des versions, travail en équipe, processus\r\nd’ingenieurie en outils IT',''),('mathieu.bonA',NULL,'',NULL,'','',''),('jeremy.charletA','0000-00-00','projet GEFCO','','Travailler sur une application de gestion logistique (projet GEFCO) en J2EE (analyse, conception, développement, tests, intégration continue).\r\nJe bénéficierais d\'une formation sur les logiciels et frameworks utilisés (JBOSS et Log4j par exemple), avant de travailler sur des tâches de production en équipe.','JBOSS, Framework J2EE, Framework Obbisoft, Eclipse, Framework Log4j, Edition (Report Writer  / Fop), XML SPY, Toad, Oracle, PLSQL, JIRA, Clarity, SVN, Hudson, Maven, etc.',''),('ewald.croxoA','0000-00-00','Projets Web','','-Assurer et améliorer le reporting qualité des sites web\r\n- Collecter, mettre en forme, commenter et diffuser les indicateurs qualités hebdomadaires \r\n- Participer aux conférences téléphonique en anglais pour évoquer les problèmes techniques rencontrés\r\n- Suivre la résolution des problèmes / Assurer l’avancement des actions\r\n- Tester les nouveaux développements réalisés\r\n','',''),('fabien.duhamelA','0000-00-00','Skil Groupe ERP/Retail','','Participer à des phases de spécifications et de développement sur l\'ERP Oracle','Utilisation de PL/SQL, XML Publisher, OA Framework, affectation sur des vraies tâches de production, travail en équipe, coaching technique assuré par des ressources plus expérimentées, respect des charges et délais, respect des process et normes qualité du centre',''),('romain.le-jeuneA',NULL,'',NULL,'','',''),('nicolas.malassagneA','0000-00-00','Developpement d une solution d administration et supervision d une plateforme de jeux en ligne','equipes internes d Atos Worldline','- Analyser le besoin aupres des equipes internes d Atos Worldline\r\n- Concevoir et realiser ce produit interne\r\n- Fournir la documentation technique et operationnelle \r\n- Former les utilisateurs finaux','HTML5, PHP, MySQL, Java EE, script shell ',''),('thierry.ngando-ngwaA','0000-00-00','EDF - AGENCE INFORMATIQUE TÉLÉCOMMUNICATIONS SERVICES','','- Développement d\' un datawarehouse et des outils de requêtage associés par la réalisation d\'un module\r\nde supervision, permettant le suivi en temps réel d\'installations de système de téléphonie sans fil des sites nucléaires.\r\n\r\n- Participation à la conception, au développement et à la documentation du nouveau module.','Les outils utilisés sont : JDK 6 de Java, Tomcat 7, SGBD Postgres 8.4 et l\'un des IDE Eclipse ou Netbeans.\r\n\r\nLes apports pédagogiques escomptés :\r\n- développement des compétences techniques J2EE\r\n- intégration des cycles de développement logiciel : conception, réalisation, recette, documentation, mise en exploitation\r\n- acquisition des méthodologies projet\r\n- compréhension des enjeux métiers et opérateurs.',''),('camille.teruelA',NULL,'',NULL,'','',''),('sarah.aichaouiA',NULL,'',NULL,'','',''),('thomas.baertA','0000-00-00','Hebergement','','','OS Linux et Solaris administration systeme securite des systemes developpement perl bash et C monitoring et qualite de service',''),('thomas.baguetteA','0000-00-00','Organisation de la conaissance','','- travailler au sein de l\'équipe système du service KEDB (known error data base), une\r\nbase de données qui recense la plupart des erreurs système survenue au sein de\r\nl\'entreprise. \r\n\r\n- gestion de projet orientée étude et mise en place d\'outils open source pour la gestion\r\nde projet et de l\'information.\r\n\r\n- Build construction de plateforme.','',''),('guillaume.barideauA',NULL,'',NULL,'','',''),('m2tiirfi1BA26A','0000-00-00','Service R&D','','Améliorer la gestion des failovers sur le système d’accès des sas physique, ainsi que la remonté d\'alertes.','linux, perl, inittab, svc , mysql , http(s), object, strace , iptables',''),('arnaud.devilleA','0000-00-00','Ecommerce','','1- Intégrer une équipe de développement web\r\n2- Participation aux différentes phases de projet (analyse, développement, recette) afin d\'apprendre les méthode de travail\r\n3- Concevoir, développer, tester, participer à la recette client et la mise en production d’un module complet du projet d’évolution de la plate-forme internet','Java, J2EE, JSP, Flash, UML, Tapestry, Unix, SQL, Mysql et Oracle.\r\nÉventuellement de la sécurité informatique si je suis amené à travailler pour les systèmes de paiements',''),('florent.fouquetA','0000-00-00','DSI - La Poste','','- Thème du stage : refonte de l\'alimentation de l\'application Fannie (consultation des résultats de paie),\r\n- Activités prévues : étude de l\'existant, conception, développement et tests, aide à la recette fonctionnelle et mise en production.','Développement Java.\r\nEnvironnement ORACLE sous Unix.',''),('liuhua.gaoA','0000-00-00','P2P, web et temps reel','','Dans le cadre de ce projet, vous devrez étudier l’utilisation des technologies peer-to-peer utilisables par l’intermédiaire de services web afin de permettre aux utilisateurs de ces services de communiquer en temps réel avec une autre personne ou au sein d’un groupe. Vous déterminerez dans quel cadre ces technologies sont utilisables en complément de l’approche classique utilisé par Atos Worldline. Vous appliquerez vos résultats à un exemple concret à déterminer.','Flash, HTML5, Javascript, Java, C/C++, Développement serveur, algorithmes P2P',''),('benoit.godissartA',NULL,'',NULL,'','',''),('florent.guetteA','0000-00-00','Orion','Kiabi','Refonte de la l’application « VEGA » permettant de gérer graphiquement les plans de Collection du groupe KIABI\r\n\r\n- Analyser le besoin utilisateur.\r\n- Proposer une ou des solutions à l\'utilisateur.\r\n- Modéliser les impacts sur l’application (UML).\r\n- Définir les impacts sur le modèles de données.\r\n- Estimer la charge de développement (IHM et serveur d\'application).\r\n- Réaliser les développements (IHM et serveur d\'application).\r\n- Qualifier le processus terminé.','Application Eclipse RCP (eclipse 3.7).\r\n\r\nServeur d\'application TomCat sous Unix.\r\n\r\nBase de données Oracle 10g sous Unix (SQL et PL/SQL).',''),('emilien.hiddenA','0000-00-00','Pole conseil et expertise','','L’offre de stage a pour but d’assister les consultants dans le maintient et le développement des outils et méthodologies d’intrusion.\r\n\r\nParticipation aux tâches de veille technologique et rédaction d’articles techniques\r\n\r\nEvaluation de nouveaux outils d’intrusion\r\n\r\nMaintenance et évolution des procédures de tests techniques (essentiellement les méthodologies de tests d’intrusion)','Les moyens :\r\n\r\nLe stagiaire est en binôme avec un consultant sénior de référence\r\n\r\nLes outils et méthodologies de réalisation des missions du pôles C&E\r\n\r\nToute la base de connaissance du pôle\r\n\r\nUn ordinateur portable personnel',''),('oussama.mahmoudiA','0000-00-00','Conception et développement de modules Gravity','','Intégré au sein de l’équipe R&D, le stage permettra de participer à la conception et au développement de modules fonctionnels et techniques à destination de la plateforme de réseau social appelée Gravity. \r\nActivités :\r\nRecherche, conception, maquettage, prototypage, développement test.\r\n','EJB3, JSF2, JPA, eclipse, JBoss, maven.',''),('matthieu.mastioA','0000-00-00','','','Analyse de log','Windows (station de\r\ntravail, développement), Unix(serveurs), Java (+Weka, Mahout), Outils\r\nd’analyse de données (R, Python/SciPy).',''),('clement.mondonA','0000-00-00','équipe ESTAS','','L’objectif du travail proposé est de réaliser un logiciel, externe à la plate-forme ERTMS,\r\npermettant d’évaluer les capacités d’interaction avec celle-ci en utilisant le bus CORBA.\r\nLes besoins à couvrir par ce type de logiciel sont variés. Cela va de la simple surveillance\r\npassive des données / messages échangés («monitoring»), au pilotage à distance de fonctions\r\nspécifiques, voire même à l’injection de données erronées afin de tester la robustesse du système.\r\n','La plateforme de simulation ERTMS est principalement utilisée pour :\r\n– dérouler des jeux de tests systèmes pour valider les équipements ERTMS\r\n– mener des expérimentations sur le comportement des opérateurs humains\r\nL’architecture logicielle de cette plate-forme est articulée autour d’un bus logiciel CORBA.\r\nL’éditeur de la plate-forme, ERSA, communique un ensemble de fichiers IDL définissant\r\nles capacités d’interfaçage pour un composant logiciel externe avec la plate-forme.\r\n\r\nLe stage se déroulera dans les locaux IFSTTAR-Villeneuve d’Ascq.\r\n',''),('amine.ouelhadjA',NULL,'',NULL,'','',''),('tung-minh.phamA',NULL,'',NULL,'','',''),('l3miagefi1BB31A',NULL,'',NULL,'','',''),('vincent.vossA',NULL,'',NULL,'','',''),('sylvain.bialasikA',NULL,'',NULL,'','',''),('m2miagefi1DA29A',NULL,'',NULL,'','',''),('emeric.edmondA',NULL,'',NULL,'','',''),('el.foe-ongoloA',NULL,'',NULL,'','',''),('florian.kauffmannA',NULL,'',NULL,'','',''),('vincent.knockaertA',NULL,'',NULL,'','',''),('mathilde.lagacheA',NULL,'',NULL,'','',''),('david.lestaevelA',NULL,'',NULL,'','',''),('abderezak.medjoudjA',NULL,'',NULL,'','',''),('benoit.mellingerA',NULL,'',NULL,'','',''),('farid.oussiA',NULL,'',NULL,'','',''),('francois.rousselA',NULL,'',NULL,'','',''),('ta.sowA',NULL,'',NULL,'','',''),('helene.weexsteenA',NULL,'',NULL,'','',''),('darina.abderrahmaneA',NULL,'',NULL,'','',''),('francois.dervauxA',NULL,'',NULL,'','',''),('mathieu.dervauxA',NULL,'',NULL,'','',''),('remy.di-fantA',NULL,'',NULL,'','',''),('camille.eurinA',NULL,'',NULL,'','',''),('nicolas.quequetA',NULL,'',NULL,'','',''),('hanae.rateauA',NULL,'',NULL,'','',''),('walid.trabelsiA',NULL,'',NULL,'','',''),('damien.walleA',NULL,'',NULL,'','',''),('thomas.zoncaA',NULL,'',NULL,'','',''),('marine.beckerA',NULL,'',NULL,'','',''),('antoine.bertoutA',NULL,'',NULL,'','',''),('thomas.clementA',NULL,'',NULL,'','',''),('titouan.compiegneA',NULL,'',NULL,'','',''),('guillaume.dufossetA',NULL,'',NULL,'','',''),('julia.grabkinaA',NULL,'',NULL,'','',''),('francois.gruchalaA',NULL,'',NULL,'','',''),('jessy.lavorelA',NULL,'',NULL,'','',''),('david.martelA',NULL,'',NULL,'','',''),('thomas.maupainA',NULL,'',NULL,'','',''),('florian.monsellierA',NULL,'',NULL,'','',''),('clement.nicoletA',NULL,'',NULL,'','',''),('maxime.piquetteA',NULL,'',NULL,'','',''),('francois.poulainA',NULL,'',NULL,'','',''),('jeremie.seguraA',NULL,'',NULL,'','',''),('soufiane.agadrA',NULL,'',NULL,'','',''),('thomas.aubryA',NULL,'',NULL,'','',''),('l3miagefi1AZ32A',NULL,'',NULL,'','',''),('l3miagefi1BB35A',NULL,'',NULL,'','',''),('omar.chahbouniA',NULL,'',NULL,'','',''),('l3miagefi1BP25A',NULL,'',NULL,'','',''),('simon.billiauA',NULL,'',NULL,'','',''),('melissa.blainA',NULL,'',NULL,'','',''),('romain.blasA',NULL,'',NULL,'','',''),('romain.bordoneA',NULL,'',NULL,'','',''),('ma.boutillierA',NULL,'',NULL,'','',''),('alexis.boutrouilleA',NULL,'',NULL,'','',''),('florian.bruffaertA',NULL,'',NULL,'','',''),('martin.cabyA',NULL,'',NULL,'','',''),('florian.carlierA',NULL,'',NULL,'','',''),('aurore.castelainA',NULL,'',NULL,'','',''),('jules.cissokoA',NULL,'',NULL,'','',''),('benjamin.clermontA',NULL,'',NULL,'','',''),('cyril.cordiezA',NULL,'',NULL,'','',''),('stanislas.couroubleA',NULL,'',NULL,'','',''),('a.da-costa-maiaA',NULL,'',NULL,'','',''),('thomas.deblockA',NULL,'',NULL,'','',''),('dimitri.descampsA',NULL,'',NULL,'','',''),('julien.duquesnoyA',NULL,'',NULL,'','',''),('romain.frangiA',NULL,'',NULL,'','',''),('pierre.frayerA',NULL,'',NULL,'','',''),('germain-de-montauzanA',NULL,'',NULL,'','',''),('pauline.hacheA',NULL,'',NULL,'','',''),('wissem.hadhriA',NULL,'',NULL,'','',''),('nassim.hassaineA',NULL,'',NULL,'','',''),('remi.kaczmarekA',NULL,'',NULL,'','',''),('laurent.laplaceA',NULL,'',NULL,'','',''),('matthieu.laurentA',NULL,'',NULL,'','',''),('pierrick.lesageA',NULL,'',NULL,'','',''),('florian.licourA',NULL,'',NULL,'','',''),('sylvain.magnierA',NULL,'',NULL,'','',''),('zouhair.makhoutA',NULL,'',NULL,'','',''),('sophie.mantelA',NULL,'',NULL,'','',''),('lucie.meresseA',NULL,'',NULL,'','',''),('louis.motteA',NULL,'',NULL,'','',''),('lc.nsourou-ndongA',NULL,'',NULL,'','',''),('quentin.petitA',NULL,'',NULL,'','',''),('julian.ronsseA',NULL,'',NULL,'','',''),('sylvain.ruchotA',NULL,'',NULL,'','',''),('caroline.soyezA',NULL,'',NULL,'','',''),('maxime.vanpeeneA',NULL,'',NULL,'','',''),('julien.weillaertA',NULL,'',NULL,'','',''),('jerome.wyckaertA',NULL,'',NULL,'','',''),('benjamin.allaertA',NULL,'',NULL,'','',''),('loic.allartA',NULL,'',NULL,'','',''),('lois.arensA',NULL,'',NULL,'','',''),('arthur.aubrunA',NULL,'',NULL,'','',''),('romain.belmonteA',NULL,'',NULL,'','',''),('l3infofi1BE35A',NULL,'',NULL,'','',''),('thomas.bessetA',NULL,'',NULL,'','',''),('louis.billietA',NULL,'',NULL,'','',''),('remi.boensA',NULL,'',NULL,'','',''),('yoann.bouquetA',NULL,'',NULL,'','',''),('benoit.boutinA',NULL,'',NULL,'','',''),('rabab.bouzianeA',NULL,'',NULL,'','',''),('thomas.buisineA',NULL,'',NULL,'','',''),('adrien.burillonA',NULL,'',NULL,'','',''),('thomas.camberlinA',NULL,'',NULL,'','',''),('mickael.camierA',NULL,'',NULL,'','',''),('tristan.cavelierA',NULL,'',NULL,'','',''),('thomas.chabinA',NULL,'',NULL,'','',''),('nicolas.colmanA',NULL,'',NULL,'','',''),('nicolas.coyardA',NULL,'',NULL,'','',''),('thomas.crepel-cardonA',NULL,'',NULL,'','',''),('florent.davidA',NULL,'',NULL,'','',''),('david.debehogneA',NULL,'',NULL,'','',''),('olivier.debreuA',NULL,'',NULL,'','',''),('l3infofi,l3miagefi1BB22A',NULL,'',NULL,'','',''),('julien.delavennatA',NULL,'',NULL,'','',''),('sylvain.depauwA',NULL,'',NULL,'','',''),('lucille.dhaleineA',NULL,'',NULL,'','',''),('ronan.dhellemmesA',NULL,'',NULL,'','',''),('jeremy.diazA',NULL,'',NULL,'','',''),('benjamin.digeonA',NULL,'',NULL,'','',''),('stefan.dochezA',NULL,'',NULL,'','',''),('s.doutreligneA',NULL,'',NULL,'','',''),('justin.dufourA',NULL,'',NULL,'','',''),('julien.duribreuxA',NULL,'',NULL,'','',''),('mickael.duruisseauA',NULL,'',NULL,'','',''),('sara.el-arbaouiA',NULL,'',NULL,'','',''),('a.el-idrissiA',NULL,'',NULL,'','',''),('amina.el-mekkiA',NULL,'',NULL,'','',''),('mina.elkhotfiA',NULL,'',NULL,'','',''),('valentin.fixA',NULL,'',NULL,'','',''),('benjamin.flahauwA',NULL,'',NULL,'','',''),('thibaut.frainA',NULL,'',NULL,'','',''),('julien.hazebroucqA',NULL,'',NULL,'','',''),('ali.hedjazA',NULL,'',NULL,'','',''),('e.helluy-lafontA',NULL,'',NULL,'','',''),('remi.houdeletteA',NULL,'',NULL,'','',''),('charles.husquinA',NULL,'',NULL,'','',''),('rachid.khelilA',NULL,'',NULL,'','',''),('navish.lallbeeharryA',NULL,'',NULL,'','',''),('adrien.langletA',NULL,'',NULL,'','',''),('l3infofi1LL21A',NULL,'',NULL,'','',''),('sebastien2.leclercqA',NULL,'',NULL,'','',''),('l3infofi1LM40A',NULL,'',NULL,'','',''),('victor.lefebvreA',NULL,'',NULL,'','',''),('clement1.lefevreA',NULL,'',NULL,'','',''),('damien.leflonA',NULL,'',NULL,'','',''),('francois.lepanA',NULL,'',NULL,'','',''),('tianjun.linA',NULL,'',NULL,'','',''),('alexandre.loywickA',NULL,'',NULL,'','',''),('a.ludunge-wendiA',NULL,'',NULL,'','',''),('ouardia.ma-zA',NULL,'',NULL,'','',''),('benjamin.makusaA',NULL,'',NULL,'','',''),('gauvain.marquetA',NULL,'',NULL,'','',''),('nathanael.martinA',NULL,'',NULL,'','',''),('tom.massolA',NULL,'',NULL,'','',''),('kevin.mestdachA',NULL,'',NULL,'','',''),('ayoub.nejmeddineA',NULL,'',NULL,'','',''),('mh.ouannaneA',NULL,'',NULL,'','',''),('emmeanuel.pedeA',NULL,'',NULL,'','',''),('fabien.pietteA',NULL,'',NULL,'','',''),('matthieu.poudrouxA',NULL,'',NULL,'','',''),('julie.pouletA',NULL,'',NULL,'','',''),('sichen.qianA',NULL,'',NULL,'','',''),('malika.rakhaouiA',NULL,'',NULL,'','',''),('pierre.ramelotA',NULL,'',NULL,'','',''),('alexandre.raulinA',NULL,'',NULL,'','',''),('camille.riquierA',NULL,'',NULL,'','',''),('sebastien.rommelardA',NULL,'',NULL,'','',''),('alexis.rucarA',NULL,'',NULL,'','',''),('benjamin.ruytoorA',NULL,'',NULL,'','',''),('louis.saint-maxentA',NULL,'',NULL,'','',''),('jeremie.samsonA',NULL,'',NULL,'','',''),('cesar.spleteA',NULL,'',NULL,'','',''),('mengmeng.tangA',NULL,'',NULL,'','',''),('amara.timeraA',NULL,'',NULL,'','',''),('jason.toulotteA',NULL,'',NULL,'','',''),('tony.tranA',NULL,'',NULL,'','',''),('clement.vallerandA',NULL,'',NULL,'','',''),('b.van-ryseghemA',NULL,'',NULL,'','',''),('thomas.vanderheydenA',NULL,'',NULL,'','',''),('yannick.vanuxemA',NULL,'',NULL,'','',''),('donovan.watteauA',NULL,'',NULL,'','',''),('romain.windelsA',NULL,'',NULL,'','',''),('shichen.zhaoA',NULL,'',NULL,'','',''),('m2iaglfiBB37A',NULL,'',NULL,'','',''),('m2eservfiBB30A',NULL,'',NULL,'','',''),('m2iaglfiBI36A',NULL,'',NULL,'','',''),('m2iaglfi1BI38A',NULL,'',NULL,'','',''),('m2iaglfi1BI32A',NULL,'',NULL,'','',''),('m2iaglfi1BI28A',NULL,'',NULL,'','',''),('jules.ivanicA',NULL,'',NULL,'','',''),('eglantine.houdartA',NULL,'',NULL,'','',''),('l3infofi,l3miagefi1RN24A',NULL,'',NULL,'','',''),('l3infofi1RN35A',NULL,'',NULL,'','',''),('mael.baekelandtA','0000-00-00','Accompagnement de la fonction sécurité','ADVENS','L’objectif du stage est d’accompagner la fonction sécurité dans la mise en œuvre d’un système de management de la sécurité (norme ISO 27001) et des différents chantiers de sécurité :\r\n* Mettre à jour l’analyse de risques du système d’information de l’entreprise.\r\n* Définir la politique de sécurité.\r\n* Mettre en œuvre un plan de traitement des risques.\r\n* Participer à des projets de sécurisation du SI : sécurité physique, sécurité logique, sensibilisation du personnel, intégration de la sécurité dans les contrats, etc.\r\n* Définir et mettre en œuvre des tableaux de bord de sécurité.','',''),('julien.lhommeA',NULL,'',NULL,'','',''),('l3infofi1AR25A',NULL,'',NULL,'','',''),('l3miagefi1BR35A',NULL,'',NULL,'','',''),('vincent.guichardA',NULL,'',NULL,'','',''),('l3infofi1MA33A',NULL,'',NULL,'','',''),('antoine.goubelA',NULL,'',NULL,'','',''),('nabil1.ech-charraqA',NULL,'',NULL,'','',''),('edouard.bertonA',NULL,'',NULL,'','','');
/*!40000 ALTER TABLE `infoetud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_etapeet`
--

DROP TABLE IF EXISTS `fa_etapeet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_etapeet` (
  `alternanceRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dateRencontre` date DEFAULT NULL,
  `service` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `client` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `missions` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `environnementTechnique` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `integrationEntreprise` text CHARACTER SET utf8 COLLATE utf8_bin,
  `signatureEtud` tinyint(1) DEFAULT NULL,
  `signatureTuteur` tinyint(1) DEFAULT NULL,
  `remarquesEtud` text CHARACTER SET utf8 COLLATE utf8_bin,
  `remarquesTuteur` text CHARACTER SET utf8 COLLATE utf8_bin,
  `motscles` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`alternanceRef`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_etapeet`
--

LOCK TABLES `fa_etapeet` WRITE;
/*!40000 ALTER TABLE `fa_etapeet` DISABLE KEYS */;
INSERT INTO `fa_etapeet` VALUES ('julien.duribreuxA','0000-00-00','','','Integration developpement Web','php mysql js html','',NULL,0,NULL,'','--Integration developpement Web'),('damien.leflonA','0000-00-00','','','Developpement Perl,analyse reseau, VoIP','','',NULL,0,NULL,'','--Developpement Perl,analyse reseau, VoIP'),('gauvain.marquetA','0000-00-00','','','developpement d une application de navigation en environnement 3D','OpenGL, QT, C++','',NULL,0,NULL,'','--developpement d une application de navigation en environnement 3D'),('cesar.spleteA','0000-00-00','','','developpement d applications web bassees sur des CMS open source (E2Publish, Drupal)\r\nAnalyse sur des nouvelles fonctionnalites','php, mysql, E2Publish, Drupal','',NULL,0,NULL,'','--developpement d applications web bassees sur des CMS open source (E2Publish, Drupal)\r\nAnalyse sur des nouvelles fonctionnalites'),('martin.cabyA','0000-00-00','','','Analyse conception test au sein des projets INES et NOSTRA','JBOSS, J2EE Obbisoft eclipse xmlspy toad,oracle pl/sql JIRA Clarity Hudson MAven','',NULL,0,NULL,'','--Analyse conception test au sein des projets INES et NOSTRA'),('pauline.hacheA','0000-00-00','','','developpement Web','html, css, php5','',NULL,0,NULL,'','--developpement Web'),('remi.kaczmarekA','0000-00-00','','','developpement informatique\r\n- developpement de fonctionnalites sociales\r\n- amelioration de l\'espace utilisateur\r\n- developpement d\'une API\r\n-developpement d\'une interface mobile dediée\r\n- moteur de recherche integré','php5 Ajax MySQL XML','',NULL,0,NULL,'','--developpement informatique\r\n- developpement de fonctionnalites sociales\r\n- amelioration de l\'espace utilisateur\r\n- developpement d\'une API\r\n-developpement d\'une interface mobile dediée\r\n- moteur de recherche integré'),('lucie.meresseA','0000-00-00','','','Implementation d un ETL a bas cout','','',NULL,0,NULL,'','--Implementation d un ETL a bas cout'),('quentin.petitA','0000-00-00','','','Centre de services J2EE\r\nIntegrer l equipe en place et participer a la conception technique et au developpement applicatif. \r\n','java J2EE maven Glut Play Struts Eclipse','',NULL,0,NULL,'','--Centre de services J2EE\r\nIntegrer l equipe en place et participer a la conception technique et au developpement applicatif. \r\n'),('alexis.boutrouilleA','0000-00-00','','','externaliser un service woindows d alimentation de Mate Analysis sous forme d un agent distant via des web services','oracle sqlserver wpf visual studio .NET','',NULL,0,NULL,'','externaliser un service woindows d alimentation de Mate Analysis sous forme d un agent distant via des web services'),('cyril.cordiezA','0000-00-00','centre de services J2EE','','conception technique, developpement applicatif','java j2EE MAven GLut Play Struts Eclipse','',NULL,0,NULL,'','--conception technique, developpement applicatif'),('benjamin.clermontA','0000-00-00','','','developpement PHP5 sites E-Commerce','magenta ou drupal','',NULL,0,NULL,'','--developpement PHP5 sites E-Commerce'),('l3infofi1LL21A','0000-00-00','','','Conceptions applications mobiles multi plateformes','php mySql JQuery Mobile, java','',NULL,0,NULL,'','--Conceptions applications mobiles multi plateformes'),('ali.hedjazA','0000-00-00','','','Maintenance des outils de pricing, developpement d\'un outil de gestion des grossistes. Participation a la realisation d\'une webapp J2EE','php j2EE','',NULL,0,NULL,'','--Maintenance des outils de pricing, developpement d\'un outil de gestion des grossistes. Participation a la realisation d\'une webapp J2EE'),('romain.windelsA','0000-00-00','Mostrare','','etude des equivalences des requetes en sql et algorithmes d\'optimisation. ','sql','',NULL,0,NULL,'','--etude des equivalences des requetes en sql et algorithmes d\'optimisation. '),('clement.vallerandA','0000-00-00','','','Evolution plateforme SAAS\r\nmise en oevre des actions de securite','php java sql html','',NULL,0,NULL,'','--Evolution plateforme SAAS\r\nmise en oevre des actions de securite'),('julian.ronsseA','0000-00-00','','','mise en place de suivi de bug','java, flex\r\n','',NULL,0,NULL,'','--mise en place de suivi de bug'),('matthieu.laurentA','0000-00-00','','','Mise en place d\'une solution decisionnelle avec l\'outil PentahoBi. \r\nModelistation, creation des flux, reporting','Pentahobi, sql','',NULL,0,NULL,'','--Mise en place d\'une solution decisionnelle avec l\'outil PentahoBi. \r\nModelistation, creation des flux, reporting'),('jerome.wyckaertA','0000-00-00','','','methodologie de test, maintenance corrective et evolutive. ','unix, cobol/Pacbase, erp HR access V3 et HP/QC','',NULL,0,NULL,'','--methodologie de test, maintenance corrective et evolutive. '),('simon.billiauA','0000-00-00','centre de services J2EE','','Conception technique developpement applicatif','java j2EE maven glut play struts eclipse','',NULL,0,NULL,'','--Conception technique developpement applicatif'),('lc.nsourou-ndongA','0000-00-00','','','developpement web, applis mobiles','web, os mobiles','',NULL,0,NULL,'','--developpement web, applis mobiles'),('romain.blasA','0000-00-00','','','Migration d\'une application de consultation de rapports décisionnels en nouvelles technologies','html css jquery java spring hibernate','',NULL,0,NULL,'','--Migration d\'une application de consultation de rapports décisionnels en nouvelles technologies'),('thomas.bessetA','0000-00-00','','','deloppement','j2EE ou .Net','',NULL,0,NULL,'','--deloppement'),('s.doutreligneA','0000-00-00','','','developpement web de l\'appli de gestin interne','php mysql','',NULL,0,NULL,'','--developpement web de l\'appli de gestin interne'),('eglantine.houdartA','0000-00-00','','','API java card','javacard','',NULL,0,NULL,'','--API java card'),('adrien.langletA','0000-00-00','','','developpement','asp .net ms sql server','',NULL,0,NULL,'','--developpement'),('maxime.vanpeeneA','0000-00-00','','','Realisation d\'un plug-in Air pour réseau social ','Adobe Air Lamp PHP AS3 MXML SQL','',NULL,0,NULL,'','--Realisation d\'un plug-in Air pour réseau social '),('soufiane.agadrA','0000-00-00','','','Conception applications mobiles','android ios\r\njava eclipse objective C','',NULL,0,NULL,'','--Conception applications mobiles'),('lucille.dhaleineA','0000-00-00','','','developpement web','php mysql','',NULL,0,NULL,'','--developpement web'),('romain.frangiA','0000-00-00','','','Developpement','java .NET','',NULL,0,NULL,'','--Developpement'),('nathanael.martinA','0000-00-00','','','developpement','J2EE Java Html CSS','',NULL,0,NULL,'','--developpement'),('thomas.deblockA','0000-00-00','','','Enrichissement d une solution de tests automatisee','java maven junit xml jenkins testlink eclipse osgi','',NULL,0,NULL,'','--Enrichissement d une solution de tests automatisee'),('germain-de-montauzanA','0000-00-00','','','genie logiciel : transformation de bytecode','java eclipse','',NULL,0,NULL,'','--genie logiciel : transformation de bytecode'),('l3miagefi1BP25A','0000-00-00','','','Developpement mobile','android java eclipse','',NULL,0,NULL,'','Developpement mobile'),('alexandre.loywickA','0000-00-00','','','reecriture de requetes de mises a jour XQUF','java','',NULL,0,NULL,'','--reecriture de requetes de mises a jour XQUF'),('florian.carlierA','0000-00-00','','','developpement d un intranet \r\n','joomla mysql','',NULL,0,NULL,'','--developpement d un intranet \r\n'),('remi.boensA','0000-00-00','','','developpement C#','uml c#','',NULL,0,NULL,'','--developpement C#'),('amina.el-mekkiA','2012-05-22','','','refonte de site wab+systeme de paiement','joomla jquery php javascript','',NULL,0,NULL,'','refonte de site wab+systeme de paiement'),('florent.davidA','0000-00-00','','','developpement java','java J2EE','',NULL,0,NULL,'','--developpement java'),('julien.delavennatA','0000-00-00','','','Optimization and extended interaction functionality of water interaction simulation','c++ intrinsics VC++ ps3 profiler, xbox profiler','',NULL,0,NULL,'','--Optimization and extended interaction functionality of water interaction simulation'),('olivier.debreuA','0000-00-00','','','Evolution d\'un systeme de communication sans contact (NFC)','webservice WCF, Microsoft SQLServer200BR2, ASp.net Windows mobile 2006 C# SQL ASP','',NULL,0,NULL,'','--Evolution d\'un systeme de communication sans contact (NFC)'),('julien.hazebroucqA','0000-00-00','','','developpement d applications metier','php mysql vba','',NULL,0,NULL,'','--developpement d applications metier'),('l3infofi1RN35A','0000-00-00','','','developpement web','php mysql drupal javascript jquery','',NULL,0,NULL,'','--developpement web'),('pierrick.lesageA','2012-04-18','(groupe ASTREA Management, partie décisionnelle, projet \"QlikView\")','(à venir)','- Développement et mise en production d\'applications décisionnelles (recueil des besoins, alimentation des données, modélisation, restitution)\r\n- Support client, prestation (court/long terme), aide à la maintenance, tableaux de bord, intervention clientèle\r\n','QlikView (outil décisionnel de QlikTech, donc ACSSI est partenaire \"Elite\")\r\nhttp://us.demo.qlikview.com/','- Suivi de formations en groupe : développeur (2 jours), designer (2 jours)\r\n- Tuteur de stage sur le lieux de travail\r\n- Dans un bureau de 3/4 consultants du même service\r\n- Objectif de l\'entreprise : mise en place d\'un contrat d\'alternance',NULL,0,NULL,'','Applications décisionnelles, business intelligence, modèle de données, bases de données transactionnelles, vectorielles'),('a.el-idrissiA','0000-00-00','','','developpement d un moteur de recherche des formations','php javascript','',NULL,0,NULL,'','--developpement d un moteur de recherche des formations'),('sylvain.magnierA','0000-00-00','','','realisation de reporting graphiques','java C++ html javascript','',NULL,0,NULL,'','--realisation de reporting graphiques'),('loic.allartA','0000-00-00','','','developpement java','java j2EE','',NULL,0,NULL,'','--developpement java'),('thomas.chabinA','0000-00-00','','','audit et amelioration du code de Wopal Wobbit','C++','',NULL,0,NULL,'','--audit et amelioration du code de Wopal Wobbit'),('shichen.zhaoA','0000-00-00','','','developpement / Mostrare','C++','',NULL,0,NULL,'','--developpement / Mostrare'),('clement1.lefevreA','0000-00-00','','','Remontee d information applicative et automatisation du deploiement','python linux','',NULL,0,NULL,'','--Remontee d information applicative et automatisation du deploiement'),('benjamin.allaertA','0000-00-00','','','developpement site web','php javascript sql','',NULL,0,NULL,'','--developpement site web'),('a.da-costa-maiaA','0000-00-00','','','developpement d un outil de reparation automatique de bug','java javascript ajax','',NULL,0,NULL,'','--developpement d un outil de reparation automatique de bug'),('remi.houdeletteA','0000-00-00','','','application permettant l automatisation de creation de fonctionnalites lors du developpement d autres applications pour les clients','php javascript ajax xhtml api facebook','',NULL,0,NULL,'','--application permettant l automatisation de creation de fonctionnalites lors du developpement d autres applications pour les clients'),('donovan.watteauA','2012-04-19','Système','','Cerise Media = Portails web avec gros contenus (serveurs BD, mySQL)\r\n- automatisation de la re-synchronisation des serveurs\r\n- développement d\'outils de monitoring\r\n- notices d\'utilisation','mySQL, scripts shell, linux Debian, Percona','- Tuteur de stage et directeur sur le lieux de travail\r\n- Service de 10 personnes (dont 4 autres stagiaires)\r\n',NULL,0,NULL,'','serveur, monitoring'),('tom.massolA','0000-00-00','','','developpement web','j2E6 Oracle','',NULL,0,NULL,'','--developpement web'),('dimitri.descampsA','0000-00-00','','','developper un outil de suivi d achats','access oracle','',NULL,0,NULL,'','--developper un outil de suivi d achats'),('sylvain.ruchotA','0000-00-00','','','developpement d un site web','php mysql lamp','',NULL,0,NULL,'','--developpement d un site web'),('rabab.bouzianeA','0000-00-00','','','design and implementation of a robotic surveillance application','java c c++','',NULL,0,NULL,'','--design and implementation of a robotic surveillance application'),('thomas.aubryA','0000-00-00','','','creation de plateforme metier/ developpement web','php, javascript, html, ajax','',NULL,0,NULL,'','--creation de plateforme metier/ developpement web'),('caroline.soyezA','0000-00-00','','','developpement sur l erp d oracle','pl/sql xml publisher OA framework','',NULL,0,NULL,'','--developpement sur l erp d oracle'),('louis.saint-maxentA','0000-00-00','','','conception developpement java j2EE sur les produits Vekia','Java J2EE GWT ','',NULL,0,NULL,'','--conception developpement java j2EE sur les produits Vekia'),('florian.bruffaertA','0000-00-00','','','creation d elements d intervention entre les applications internes','php mysql xml html css','',NULL,0,NULL,'','--creation d elements d intervention entre les applications internes'),('melissa.blainA','2012-05-23','','','realisation d un socle CMS Logica','php','tres bien ',NULL,1,NULL,'','--realisation d un socle CMS Logica'),('nicolas.colmanA','0000-00-00','','','Intervention dans la creation d un jeu video','c# c++ php directX','',NULL,0,NULL,'','--Intervention dans la creation d un jeu video'),('mickael.camierA','0000-00-00','','','conception d outils javascript pour livres numeriques','javascript html5 cSS3','',NULL,0,NULL,'','--conception d outils javascript pour livres numeriques'),('stanislas.couroubleA','0000-00-00','','','etude et developpement d une supervision qualitative','java ou php, mysql ou Oracle','',NULL,0,NULL,'','--etude et developpement d une supervision qualitative'),('sichen.qianA','0000-00-00','','','development of software product','','',NULL,0,NULL,'','--development of software product'),('thomas.crepel-cardonA','0000-00-00','','','environnement de developpement et de test des applications vocales','c c++ java vxml','',NULL,0,NULL,'','--environnement de developpement et de test des applications vocales'),('julien.weillaertA','0000-00-00','','','customiser un progiciel pour Leroy Merlin pour creer des outils d aide a la vente permettant d automatiser les processus de vente en magasin','cameleon V6, java javascript jsp pgAdmin','',NULL,0,NULL,'','--customiser un progiciel pour Leroy Merlin pour creer des outils d aide a la vente permettant d automatiser les processus de vente en magasin'),('matthieu.poudrouxA','0000-00-00','','','developpement d un proxy de communication entre deux systemes','microsoft webservice, TCP, IPV6 C# html SQL','',NULL,0,NULL,'','--developpement d un proxy de communication entre deux systemes'),('ma.boutillierA','2012-05-23','','','realisation d un outil de reservation de ressources avec un module de validation','c# silverlight asp .net','',NULL,1,NULL,'','--realisation d un outil de reservation de ressources avec un module de validation'),('tristan.cavelierA','0000-00-00','','','participation au prototype d un demonstrateur safeDOC sous licence  open-source','javascript html5','',NULL,0,NULL,'','--participation au prototype d un demonstrateur safeDOC sous licence  open-source'),('jeremy.diazA','0000-00-00','','','dveloppement d une application de demandes internes','php html mysql oracle\r\n','',NULL,0,NULL,'','--dveloppement d une application de demandes internes'),('thomas.camberlinA','0000-00-00','','','deveolppement d un module logistique dans un ERP','','',NULL,0,NULL,'','--deveolppement d un module logistique dans un ERP'),('julien.lhommeA','0000-00-00','','','developpement web (gestion de la cantine)','sql php','',NULL,0,NULL,'','--developpement web (gestion de la cantine)'),('florian.licourA','0000-00-00','','','developpement java','java et compagnie','',NULL,0,NULL,'','--developpement java'),('julie.pouletA','0000-00-00','','','Developpement Web','php html5 javascript','',NULL,0,NULL,'','--Developpement Web'),('wissem.hadhriA','0000-00-00','','','mise a jour moteur javascript du CMS. Developpement de modules. ','javascript CMS','',NULL,0,NULL,'','--mise a jour moteur javascript du CMS. Developpement de modules. '),('tony.tranA','0000-00-00','','','developpement web de la nouvelle plateform Tombapik','php symphony2','',NULL,0,NULL,'','--developpement web de la nouvelle plateform Tombapik'),('yoann.bouquetA','0000-00-00','','','Participation a l activite du centre de services','j2EE gwt flex struts hibernate','',NULL,0,NULL,'','--Participation a l activite du centre de services'),('ayoub.nejmeddineA','0000-00-00','','','Module interfacage Facebook','php dotnet mysql sqlserver','',NULL,0,NULL,'','--Module interfacage Facebook'),('l3infofi1AR25A','0000-00-00','','','developpement application mobile','android java','',NULL,0,NULL,'','--developpement application mobile'),('mengmeng.tangA','0000-00-00','','','Propagation de contraintes en Scala','Scala','',NULL,0,NULL,'','--Propagation de contraintes en Scala'),('nicolas.coyardA','0000-00-00','','','developpement web','php javasccript jquery html','',NULL,0,NULL,'','--developpement web'),('amara.timeraA','0000-00-00','','','developpement de diverses applications en fonction des demandes des clients. ','java','',NULL,0,NULL,'','--developpement de diverses applications en fonction des demandes des clients. '),('jason.toulotteA','0000-00-00','','','optimisation dalgorithmes','java J2EE XML','',NULL,0,NULL,'','--optimisation dalgorithmes'),('thibaut.frainA','0000-00-00','','','developpement web','rails, jQuery php5 html5 sql','',NULL,0,NULL,'','--developpement web'),('benoit.boutinA','0000-00-00','','','developpement PHP','php mysql (vb .NET javascript)','',NULL,0,NULL,'','--developpement PHP'),('stefan.dochezA','0000-00-00','','','moteur d exercices bureautique','VB','',NULL,0,NULL,'','--moteur d exercices bureautique'),('benjamin.ruytoorA','0000-00-00','','','developpement interface graphique','C','',NULL,0,NULL,'','--developpement interface graphique'),('mickael.duruisseauA','0000-00-00','','','developpement web : formulaire de gestion evenementiel sur le site de la branche gares et connexions','php','',NULL,0,NULL,'','--developpement web : formulaire de gestion evenementiel sur le site de la branche gares et connexions'),('malika.rakhaouiA','0000-00-00','','','Application Iphone anti-stress','objective C cocoa','',NULL,0,NULL,'','--Application Iphone anti-stress'),('ronan.dhellemmesA','0000-00-00','','','developpement logiciel embarque','C','',NULL,0,NULL,'','--developpement logiciel embarque'),('pierre.ramelotA','0000-00-00','','','interpretation de donnees','vb','',NULL,0,NULL,'','--interpretation de donnees'),('francois.lepanA','0000-00-00','','','interface graphique de visualisation de donnees. ','java','',NULL,0,NULL,'','--interface graphique de visualisation de donnees. '),('tianjun.linA','0000-00-00','','','creation d un site web reserve aux clients','javascript html php bdd css','',NULL,0,NULL,'','--creation d un site web reserve aux clients'),('fabien.pietteA','0000-00-00','','','conception applications mobiles','os mobiles, objective-C java html css xml','',NULL,0,NULL,'','--conception applications mobiles'),('pierre.frayerA','0000-00-00','','','developpement web ','php mysql','',NULL,0,NULL,'','--developpement web '),('sebastien2.leclercqA','0000-00-00','','','developpement java','java','',NULL,0,NULL,'','--developpement java'),('l3miagefi1BR35A','0000-00-00','','','developpement e-commerce','php 5 ou J2EE','',NULL,0,NULL,'','--developpement e-commerce'),('vincent.guichardA','0000-00-00','','','developpement intranet','php mysql uml\r\n','',NULL,0,NULL,'','--developpement intranet'),('benjamin.digeonA','0000-00-00','','','developpement java','j2EE postgresql birt spring','',NULL,0,NULL,'','--developpement java'),('l3infofi1MA33A','0000-00-00','','','developpement web','php','',NULL,0,NULL,'','--developpement web'),('camille.riquierA','0000-00-00','','','evolution des outils de BDD editoriales','php mysql oracle xml','',NULL,0,NULL,'','--evolution des outils de BDD editoriales'),('laurent.laplaceA','0000-00-00','','','migration des sites d un CMS maison','sql server java css xhtml','',NULL,0,NULL,'','--migration des sites d un CMS maison'),('sara.el-arbaouiA','0000-00-00','','','analyse et reponse a une demande MOA','Lotus java xpages','',NULL,0,NULL,'','analyse et reponse a une demande MOA'),('jeremie.samsonA','0000-00-00','','','developpement applications mobiles android iphone','','',NULL,0,NULL,'','--developpement applications mobiles android iphone'),('valentin.fixA','0000-00-00','','','administration systeme reseau','outil reseau','',NULL,0,NULL,'','--administration systeme reseau'),('mh.ouannaneA','0000-00-00','','','developpement de requete, reporting, outils de pilotage sur un crm','sql C# PL/SQL PHP/sql','',NULL,0,NULL,'','--developpement de requete, reporting, outils de pilotage sur un crm'),('antoine.goubelA','0000-00-00','','','refonte et amelioration d un produit de generation de publipostage','SOAP .NET BDD C#','',NULL,0,NULL,'','--refonte et amelioration d un produit de generation de publipostage'),('romain.belmonteA','0000-00-00','','','developper une application web d administration et de configuration de contenus audios geolocalises','php javascript','',NULL,0,NULL,'','--developper une application web d administration et de configuration de contenus audios geolocalises'),('nabil1.ech-charraqA','2012-05-25','Unité de Recherche LEOST','','La mission concerne le développement d\'interfaces graphiques pour la classification de données en environnements électromagnétiques, dans le cadre de compatibilité électromagnétique pour les transports terrestres (variables liées au matériel GSM embarqué sur TGV-SNCF)\r\n- Interfaces graphiques\r\n- Traitements et calculs couteux en fonction des données d\'entrée\r\n- Système de fichiers (format Matlab) : sauvegarde et chargement de calculs effectués par le passé. \r\n','- MATLAB principalement\r\n- Java/C par la suite pour interfaces graphiques avancées','- Référent entreprise sur le lieux de travail\r\n- Points journaliers',NULL,1,NULL,'',''),('sophie.mantelA','2012-06-04','','','developpement d un applicatif de commandes sur l entrepot','c# .NET','',NULL,0,NULL,'','--developpement d un applicatif de commandes sur l entrepot'),('a.ludunge-wendiA','0000-00-00','','','developpemnt de fonctions complementaires de progiciels','visual Studio .NET','',NULL,0,NULL,'','--developpemnt de fonctions complementaires de progiciels'),('romain.bordoneA','0000-00-00','','','Etude et initialisation du passage en trois tiers des applications SNEG','','',NULL,0,NULL,'','--Etude et initialisation du passage en trois tiers des applications SNEG'),('kevin.mestdachA','0000-00-00','','','creation d applications tactiles culturelles','android','',NULL,0,NULL,'','--creation d applications tactiles culturelles'),('louis.billietA','2012-04-05','MRH','','developpement SaaS remaniement base de donnees.\r\nGestion de messagerie\r\nOptimisation de traitements (SQL , sauvegardes , réplication)','java javascript postgresql php\r\nJ2EE STRUTS RoundCube\r\n','Très petite structure. SI = 2 permanents. ',NULL,0,NULL,'','--developpement SaaS remaniement base de donnees'),('thomas.buisineA','0000-00-00','','','procedures GPAO','windows SQL','',NULL,0,NULL,'','--procedures GPAO'),('adrien.burillonA','0000-00-00','','','realiser des rapports de suivi d activites commerciales via Jasper et des executables java','java j2EE jasper osb ','',NULL,0,NULL,'','--realiser des rapports de suivi d activites commerciales via Jasper et des executables java'),('lois.arensA','0000-00-00','','','portage de code calcul en grille EGI a l aide du logiciel DIRAC','linux HPC grid','python C bash',NULL,0,NULL,'','portage de code calcul en grille EGI a l aide du logiciel DIRAC'),('e.helluy-lafontA','0000-00-00','','','developpement d un firewall applicatif (Vulture)','vulture','',NULL,0,NULL,'','--developpement d un firewall applicatif (Vulture)'),('mina.elkhotfiA','0000-00-00','','','developpement dun site e-commerce','php sql','',NULL,0,NULL,'','developpement dun site e-commerce'),('sylvain.depauwA','0000-00-00','','','','php javascript jquery ajax','',NULL,0,NULL,'','developpement web'),('emmeanuel.pedeA','0000-00-00','','','creation d un site web. Mise a jour d applications web','php css html joomla wordpress','',NULL,0,NULL,'','creation d un site web. Mise a jour d applications web'),('aurore.castelainA','0000-00-00','','','developpement web','joomla wordpress symfony drupal prestashop','',NULL,0,NULL,'','developpement web'),('charles.husquinA','0000-00-00','','','application graphique de simulation de conduite de train','java','',NULL,0,NULL,'','application graphique de simulation de conduite de train'),('rachid.khelilA','0000-00-00','','','developpement web ','mysql javascript','',NULL,0,NULL,'','developpement web '),('edouard.bertonA','0000-00-00','','','optimisation de tableaux de bord excel via automatisation sous VBA','VBA','',NULL,0,NULL,'','optimisation de tableaux de bord excel via automatisation sous VBA'),('navish.lallbeeharryA','0000-00-00','','','portage d application sur supercaluclateur','linux HPC C MPI ','',NULL,0,NULL,'','portage d application sur supercaluclateur'),('thomas.vanderheydenA','0000-00-00','','','informatisation des circuits de collecte','java web client serveur oracle','',NULL,0,NULL,'','informatisation des circuits de collecte'),('david.debehogneA','0000-00-00','','','creation site web (travail a domicile)','','',NULL,0,NULL,'','creation site web (travail a domicile)'),('victor.lefebvreA','0000-00-00','','','developpement d application Iphone. Gestion de donnees GPS dans du contenu sonore','','',NULL,0,NULL,'','developpement d application Iphone. Gestion de donnees GPS dans du contenu sonore'),('benjamin.makusaA','0000-00-00','','','developpement d un outil de pilotage decisionnel','java apache javascript\r\n','',NULL,0,NULL,'',''),('l3miagefi1AZ32A','0000-00-00','','','developpement et optimisation de methodes de suivi capacitaire et projectif','vba','',NULL,0,NULL,'','developpement et optimisation de methodes de suivi capacitaire et projectif'),('ouardia.ma-zA','0000-00-00','','','refonte du site web E-commerce','','',NULL,0,NULL,'','refonte du site web E-commerce'),('jules.cissokoA','0000-00-00','','','developpement web','php mysql html js','',NULL,0,NULL,'','developpement web'),('alexis.rucarA','0000-00-00','','','Application Android','java mysql','',NULL,0,NULL,'','--Application Android'),('l3miagefi1BB31A','0000-00-00','','','developpement d un outil d analyse en relation avec une base de donnees de tracabilite ','','',NULL,0,NULL,'','developpement d un outil d analyse en relation avec une base de donnees de tracabilite '),('sebastien.rommelardA','0000-00-00','','','integration developpement web','css html php jquery','',NULL,0,NULL,'','integration developpement web'),('omar.chahbouniA','0000-00-00','','','consolidation dans illisible','linux apache php tomcat','',NULL,0,NULL,'','consolidation dans illisible'),('louis.motteA','0000-00-00','','','migration format monetaire','windev','',NULL,0,NULL,'','migration format monetaire');
/*!40000 ALTER TABLE `fa_etapeet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapevisite1`
--

DROP TABLE IF EXISTS `etapevisite1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapevisite1` (
  `alternanceRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dateRencontre` date DEFAULT NULL,
  `adequationMission` text CHARACTER SET utf8 COLLATE utf8_bin,
  `integrationEtudiant` text CHARACTER SET utf8 COLLATE utf8_bin,
  `signatureEtud` tinyint(1) DEFAULT NULL,
  `remarquesEtud` text CHARACTER SET utf8 COLLATE utf8_bin,
  `signatureReferent` tinyint(1) DEFAULT NULL,
  `remarquesReferent` text CHARACTER SET utf8 COLLATE utf8_bin,
  `signatureTuteur` tinyint(1) DEFAULT NULL,
  `remarquesTuteur` text CHARACTER SET utf8 COLLATE utf8_bin,
  `typeRencontre` text CHARACTER SET utf8 COLLATE utf8_bin,
  PRIMARY KEY (`alternanceRef`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapevisite1`
--

LOCK TABLES `etapevisite1` WRITE;
/*!40000 ALTER TABLE `etapevisite1` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapevisite1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapeechanges`
--

DROP TABLE IF EXISTS `etapeechanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapeechanges` (
  `alternanceRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `participants` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `typeRencontre` int(11) NOT NULL,
  `dateRencontre` date NOT NULL,
  `resume` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sujet` int(11) NOT NULL,
  PRIMARY KEY (`alternanceRef`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapeechanges`
--

LOCK TABLES `etapeechanges` WRITE;
/*!40000 ALTER TABLE `etapeechanges` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapeechanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapeSout`
--

DROP TABLE IF EXISTS `etapeSout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapeSout` (
  `alternanceRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `titreStage` tinytext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `comprehension` tinyint(4) NOT NULL,
  `efficaciteAnalyse` tinyint(4) NOT NULL,
  `rigueur` tinyint(4) NOT NULL,
  `interet` tinyint(4) NOT NULL,
  `communication` tinyint(4) NOT NULL,
  `autonomie` tinyint(4) NOT NULL,
  `receptivite` tinyint(4) NOT NULL,
  `serieux` tinyint(4) NOT NULL,
  `pourcentageObjectifs` float NOT NULL,
  `difficulteMission` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `visaReferent` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dateVisaReferent` date NOT NULL,
  `dateSoutenance` date NOT NULL,
  `noteTravail` float NOT NULL,
  `noteRapport` float NOT NULL,
  `noteSoutenance` float NOT NULL,
  `avisJury` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `salle` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `heure` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`alternanceRef`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapeSout`
--

LOCK TABLES `etapeSout` WRITE;
/*!40000 ALTER TABLE `etapeSout` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapeSout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapemissionsout`
--

DROP TABLE IF EXISTS `etapemissionsout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapemissionsout` (
  `alternanceRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dateRencontre` date NOT NULL,
  `typeRencontre` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dateValidation` date NOT NULL,
  `missions` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `environnementTechnique` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `enjeux` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `signatureEtud` tinyint(1) NOT NULL,
  `signatureTuteur` tinyint(1) NOT NULL,
  `signatureReferent` tinyint(1) NOT NULL,
  `remarquesEtud` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `remarquesTuteur` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `remarquesReferent` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`alternanceRef`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapemissionsout`
--

LOCK TABLES `etapemissionsout` WRITE;
/*!40000 ALTER TABLE `etapemissionsout` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapemissionsout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapevisite2`
--

DROP TABLE IF EXISTS `etapevisite2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapevisite2` (
  `alternanceRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dateRencontre` date NOT NULL,
  `pointsPositifs` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `pointsProgres` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `avancementProjet` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dateProbableSoutenance` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `signatureEtud` tinyint(1) NOT NULL,
  `signatureTuteur` tinyint(1) NOT NULL,
  `signatureReferent` tinyint(1) NOT NULL,
  `remarquesEtud` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `remarquesTuteur` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `remarquesReferent` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`alternanceRef`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapevisite2`
--

LOCK TABLES `etapevisite2` WRITE;
/*!40000 ALTER TABLE `etapevisite2` DISABLE KEYS */;
/*!40000 ALTER TABLE `etapevisite2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `fa_etudiant`
--

DROP TABLE IF EXISTS `fa_etudiant`;
/*!50001 DROP VIEW IF EXISTS `fa_etudiant`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_etudiant` (
  `nom` varchar(50),
  `prenom` varchar(30),
  `tel` char(20),
  `mail` varchar(200),
  `mailLille1` varchar(200),
  `etudCle` varchar(50),
  `groupeRef` varchar(20)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `fa_formation`
--

DROP TABLE IF EXISTS `fa_formation`;
/*!50001 DROP VIEW IF EXISTS `fa_formation`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_formation` (
  `anneeReference` int(4),
  `obsolete` int(1),
  `formationCle` varchar(10),
  `nom` varchar(50),
  `responsableRef` varchar(20),
  `responsableRef2` varchar(20)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `fa_groupe`
--

DROP TABLE IF EXISTS `fa_groupe`;
/*!50001 DROP VIEW IF EXISTS `fa_groupe`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_groupe` (
  `anneeReference` int(4),
  `obsolete` int(1),
  `groupeCle` varchar(20),
  `formationRef` varchar(20),
  `responsableRef` varchar(20)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `fa_opca`
--

DROP TABLE IF EXISTS `fa_opca`;
/*!50001 DROP VIEW IF EXISTS `fa_opca`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_opca` (
  `nom` varchar(50),
  `commentaires` text,
  `anneesFinancees` int(11),
  `representant` varchar(50),
  `tel` varchar(10),
  `mail` varchar(50),
  `opcaCle` varchar(50),
  `url` varchar(200)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `fa_prof`
--

DROP TABLE IF EXISTS `fa_prof`;
/*!50001 DROP VIEW IF EXISTS `fa_prof`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_prof` (
  `anneeReference` int(4),
  `obsolete` int(1),
  `nom` varchar(50),
  `prenom` varchar(30),
  `tel` varchar(20),
  `mail` varchar(50),
  `bureau` text,
  `profCle` varchar(50)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `fa_referent`
--

DROP TABLE IF EXISTS `fa_referent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_referent` (
  `nom` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `prenom` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `tel` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `mail` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `referentCle` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `entrepriseRef` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ville` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `fonction` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`referentCle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_referent`
--

LOCK TABLES `fa_referent` WRITE;
/*!40000 ALTER TABLE `fa_referent` DISABLE KEYS */;
INSERT INTO `fa_referent` VALUES ('Monperrus','Martin','0359577875','martin.monperrus@univ-lille1.fr','a.da-costa-maiaR','inria','Villeneuve d Ascq','Maitre de COnferences'),('Parent','Guillaume','0980082818','gparent@formaeva.com','a.el-idrissiR','formaeva','Lille','responsable du developpement informatique'),('Lucas','Sebastien','0320919619','sebastien.lucas@quadra-diffusion.fr','a.ludunge-wendiR','quadra ','Villeneuve d ascq','responsable du bureau d etudes'),('',NULL,NULL,'','abderezak.medjoudjR','__sans entreprise__',NULL,NULL),('Carpentier','Hanh','0320202029','hcarpentier@commerce-btoc.com','adrien.burillonR','commerce_btoc','Villeneuve d ascq','chef de projet d etudes '),('Fourcroy','Sebastien','0328044046','sebastien.fourcroy@openresources.fr','adrien.langletR','open_resources','Marcq en Baroeul',''),('Roos','Yves','0359577855','yves.roos@univ-lille1.fr','alexandre.loywickR','inria','Villeneuve d Ascq','maitre de conferences'),('Delcant','Nicolas','0362648131','ndelcant@keyneosoft.fr','alexandre.raulinR','keyneosoft','Tourcoing','Directeur associe '),('Bernhard','M','0320672269','mbernhard@synergy.fr','alexis.boutrouilleR','synergy','Lezennes','Responsabel R et D'),('Deplanque','Jerome','0320607967','jerome.deplanque@atos.net','alexis.rucarR','atos_worldline','Seclin','Chef de projet'),('Titrent','Marc','0616723728','mtitrent@oxyo-pneus.fr','ali.hedjazR','constellation','Sainghin en Melantois','Directeur des operations'),('Rodrigues','Bertrand','+33660851166','b.rodrigues@sacapus.com','amara.timeraR','sacapus','Croix','Gerant'),('Feddal','Mortal','0320554209','mfe@geolatys.com','amina.el-mekkiR','geolatys','Lille','Directeur General'),('','','','','amine.ouelhadjR','atos','Seclin',''),('Forget','Julien','','julien.forget@lifl.fr','antoine.bertoutR','lifl','Villeneuve d Ascq','Maître de conférences'),('Renard','Franck','0320659665','franck.renard@sa-cim.fr','antoine.goubelR','cim_informatique','Roubaix','responsable service web'),('Sottiau',' Alexandra ','03-20-60-93-74','Alexandra.Sottiau@atos.net','arnaud.devilleR','atos_worldline','Seclin','Responsable d'),('',NULL,NULL,'','arthur.aubrunR','__sans entreprise__',NULL,NULL),('Atticot','Frederick ','0320459584','f.atticot@lemon-interactive.fr','aurore.castelainR','lemon_interactive','Roubaix','Responsable technique'),('Duhamel','Renald','0698704525','renald.duhamel@addicta.net','ayoub.nejmeddineR','addicta','Tourcoing','Directeur General'),('Ducasse','Stephane','','stephane.ducasse@inria.fr','b.van-ryseghemR','inria','Villeneuve d Ascq',''),('Govin','Sandra','0680742254','','benjamin.allaertR','ms_design','Lille','Graphiste Designer'),('Pesez','Christelle','0675887793','christelle.pesez@logica.com','benjamin.clermontR','logica','Lille','Manager E-commerce'),('taillard','Julien ','0328559250','julien.taillard@alicante.fr','benjamin.digeonR','alicante','Seclin','chef de projet'),('Denneulin','Alain','0608181323','alain.denneulin@gmail.com','benjamin.flahauwR','esinor','Villeneuve d Ascq','Directeur de developpement'),('Deloffre','Antoine','0320609224','antoine.deloffre@atos.net','benjamin.makusaR','atos_worldline','Seclin','Responsable d equipe'),('Ambellouis','Sebastien','0320438493','sebastien.ambellouis@ifsttar.fr','benjamin.ruytoorR','ifsttar','Villeneuve d Ascq','Charge de recherche'),('Legrand','Fabienne ','0321637473','flegrand@atpc.asso.fr','benoit.boutinR','atpc','Bethune','developpeuse'),('Schauwers','Gert','+32 (0)2 745 04 45','gert.schauwers@dimensiondata.com','benoit.godissartR','dimension_data','Bruxelles','Team Leader Core'),('',NULL,NULL,'','benoit.mellingerR','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','camille.eurinR','__sans entreprise__',NULL,NULL),('Maquet','Julien','0320414042','jmaquet@nordsoft.fr','camille.riquierR','nordsoft','Villeneuve dAscq','ingenieur developpement'),('Ducasse','Stephane','03 20 43 42 56','stephane.ducasse@inria.fr','camille.teruelR','inria','Villeneuve','Directeur de recherche (RMod)'),('Claussmann','Thierry ','0320653434','thierry.claussmann@capgemini.com','caroline.soyezR','cap_gemini','Lille','responsable erp'),('Cordonnier','Vincent','0320638888','vco@audaxis.com','cesar.spleteR','audaxis','Marcq en Baroeul',''),('Lemaire','Steeve','0328558387','steeve.lemaire@sncf.fr','charles.husquinR','sncf','Lezennes',''),('Mariano','George','03 20 43 84 06','georges.mariano@ifsttar.fr','clement.mondonR','ifsttar','Villeneuve d ascq','Chargé de Recherche '),('',NULL,NULL,'','clement.nicoletR','__sans entreprise__',NULL,NULL),('Creton','Olivier','0366728324','ocreton@numsoft.fr','clement.vallerandR','numsoft','lILLE','PDG'),('Servais','Nabil','0366720597','contact@9h37.fr','clement1.lefevreR','9h37','La madeleine','Ingenieur R et D'),('Empis','Jean-Loup','0328765666','jlempis@norsys.fr','cyril.cordiezR','norsys','Ennevelin','Directeur des operations'),('Demuynck','Florent','0320827332','florent.demuynck@ovh.net','damien.leflonR','ovh_gs_sas','Roubaix',''),('',NULL,NULL,'','damien.walleR','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','darina.abderrahmaneR','__sans entreprise__',NULL,NULL),('Mantel','Bruno','0608001760','bruno.mantel@yahoo.fr','david.debehogneR','api_aire','Rousies','Artisan'),('',NULL,NULL,'','david.lestaevelR','__sans entreprise__',NULL,NULL),('','','','','david.martelR','mobilis_digital','',''),('Dellacherie','Philippe ','0327512301','','dimitri.descampsR','toyota_motor_manufacturing','Onnaing','responsable achats'),('Dequidt','Gauthier','0320234040','g.dequidt@news-de-stars.com','donovan.watteauR','cerise_media','Tourcoing','Chef de projet'),('Jourdin','Jeremie','0677102202','jeremie.jourdin@advens.fr','e.helluy-lafontR','advens','Lille',''),('Baudoux','Didier','0320666734','didier.baudoux@cenfe.caisse-epargne.fr','edouard.bertonR','caisse_d\'epargne_nord_france_europe','Lille','directeur contentieux'),('Grimaud','Gilles','0362531555','gilles.grimaud@lifl.fr','eglantine.houdartR','inria','Villeneuve d Ascq',''),('Beghin','Richard','','richard.beghin@atos.net','eh.ait-mahiddineR','atos_worldline','Seclin','Ingenieur detudes et developpement'),('',NULL,NULL,'','el.foe-ongoloR','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','emeric.edmondR','__sans entreprise__',NULL,NULL),('jourdin','Jérémie','0320684181','jeremie.jourdin@advens.fr','emilien.hiddenR','advens','LILLE','responsable des pôles conseil & expertises et R&D'),('Bard','Jerome','0320575963','jerome.bard@viagolf.fr','emmeanuel.pedeR','viagolf','Villeneuve dAscq','directeur'),('Dumetz','Patrick','03 20 69 60 00','pdumetz@redoute.fr','ewald.croxoR','la_redoute','Roubaix','Chef de projets Web'),('CLAUSSMANN','Thierry','0320653434','thierry.claussmann@capgemini.com','fabien.duhamelR','cap_gemini','LILLE','Responsable ERP'),('Marez','Pierre-Eric','0320414074','pemarez@odysys.fr','fabien.pietteR','odysys','Villeneuve d Ascq','Mobile Project Manager'),('',NULL,NULL,'','farid.oussiR','__sans entreprise__',NULL,NULL),('Duee','Herve','0328531000','herve.duee@gfi.fr','florent.davidR','gfi','Lille','Directeur de developpement'),('Diouron','Maryvonne','+33 (0)1 58 35 36 63','maryvonne.diouron@laposte.fr ','florent.fouquetR','la_poste','PARIS CEDEX 14','Chef de projet informatique'),('Luczak','Olivier','+33 (0)3 28 38 76 79','oluczak@sopragroup.com','florent.guetteR','sopragroup','Hem','DIRECTEUR DE MARCHÉ'),('Duquesne','Adrien','0328552130','a.duquesne@urbilog.fr','florian.bruffaertR','urbilog','Roubaix','Chef de Projet'),('Bouquet','Bruno','0320637349','bruno.bouquet@sathys.com','florian.carlierR','sathys','La madeleine',''),('',NULL,NULL,'','florian.kauffmannR','__sans entreprise__',NULL,NULL),('Wauters','Vincent','0658297793','vwauters@vekia.fr','florian.licourR','vekia','Lille','Directeur technique'),('','','','','florian.monsellierR','atos','Blois',''),('',NULL,NULL,'','francois.dervauxR','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','francois.gruchalaR','__sans entreprise__',NULL,NULL),('Rioult','Jean','0320438312','','francois.lepanR','ifsttar','Villeneuve d Ascq','Ingenieur de recherche'),('Dassonneville','Matthieu','0320608274','matthieu.dassonneville@atos.net','francois.poulainR','atos_worldline','Noyelles les Seclin',''),('',NULL,NULL,'','francois.rousselR','__sans entreprise__',NULL,NULL),('Casiez','Gery','','gery.casiez@lifl.fr','gauvain.marquetR','ircica','Villeneuve d Ascq','Maitre de Conferences'),('Monperrus','Martin','0359577875','martin.monperrus@unic-lille1.fr','germain-de-montauzanR','inria','Villeneuve d Ascq','maitre de conferences'),('Wang','Quang','13701083592','wangquan@chinamobile.com','guillaume.barideauR','china_mobile','Beijing','Senior Researcher'),('',NULL,NULL,'','guillaume.dufossetR','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','hanae.rateauR','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','helene.weexsteenR','__sans entreprise__',NULL,NULL),('Cloarec','Xavier','0362648131','xcloarec@keyenosoft.fr','jason.toulotteR','keyneosoft','Tourcoing',''),('Ferray','Jean-Baptiste ','0320646363','jbf@proges.com','jeremie.samsonR','proges_plus','Willems',''),('Palamin','Guillaume','','gpalamin@idees-3com.com','jeremie.seguraR','idees3com','Roubaix',''),('BELLENGUEZ','Franck','','franck.bellenguez@capgemini.com','jeremy.charletR','cap_gemini','LILLE','Chef de projet'),('Hubert','Fabien','0320058254','fhubert@tifany.com','jeremy.diazR','tifany_industries','Phalempin','responsable SI'),('Faidherbe','Denis','0320653434','denis.faidherbe@capgemini.com','jerome.wyckaertR','cap_gemini','Lille','Chef de projet'),('',NULL,NULL,'','jessy.lavorelR','__sans entreprise__',NULL,NULL),('Depaul','Celine','0698340312','c.depaul@portailpro.net','jules.cissokoR','poratil_pro','Attiches','chef de projet'),('Duee','Hervé ','0328581002','herve;duee@gfi.fr','jules.ivanicR','gfi','Lille','Directeur de projet'),('',NULL,NULL,'','julia.grabkinaR','__sans entreprise__',NULL,NULL),('Marechal','L','0320560194','l.marechal@wizeoo.fr','julian.ronsseR','wizeoo','Marcq en Baroeul','Directeur technique'),('Desmons','Laurent','0951163260','laurent.desmons@excellance.fr','julie.pouletR','excellance','Douai','Gerant'),('','','','','julien.delavennatR','ea_digital_illusions','Stockholm',''),('',NULL,NULL,'','julien.duquesnoyR','__sans entreprise__',NULL,NULL),('Kaddiri','Jamal','0320024474','studio@kreatic.com','julien.duribreuxR','kreatic','Roubaix','Responsable Production'),('Poillion','Jean','0629736708','jean.poillion@codeps.fr','julien.hazebroucqR','codeps','Lille Hellemmes','President'),('Audren','Jerome','0320845708','j.audren@institutdegenech.fr','julien.lhommeR','institut_de_genech','Genech','Responsable informatique'),('Ghesquiere','Gregory','0362599352','gregory.ghesquiere@logica.com','julien.weillaertR','logica','Lille','charge de projet ADEO leroy Merlin'),('',NULL,NULL,'','justin.dufourR','__sans entreprise__',NULL,NULL),('Beugin','Emmanuel','0321048265','auchyleshesdin@wanadoo.fr','kevin.mestdachR','commune_d_auchy_les_hesdin','Auchy les Hesdin','DGS'),('',NULL,NULL,'','l3infofi,l3miagefi1BB22R','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','l3infofi,l3miagefi1RN24R','__sans entreprise__',NULL,NULL),('Le Pallec','Xavier ','5943','xavier.le-pallec@univ-lille1.fr','l3infofi1AR25R','lifl','Villeneuve d Ascq','MDC'),('',NULL,NULL,'','l3infofi1BE35R','__sans entreprise__',NULL,NULL),('Marez','Pierre-Eric','0320414074','pemarez@odysys.fr','l3infofi1LL21R','odysys','Villeneuve d Ascq','Mobile Project Manager'),('',NULL,NULL,'','l3infofi1LM40R','__sans entreprise__',NULL,NULL),('Delaporte','Sandra ','0328769333','sdelaporte@vivelavie.fr','l3infofi1MA33R','vive_la_vie','Mons en Baroeul',''),('Capra','Olivier','0320283815','ocapra@lefresnoy.net','l3infofi1RN35R','le_fresnoy','Tourcoing','web designer'),('Gauthier','Jean-Jacques','0327253950','jean-jacques.gauthier@fr.transport.bombardier.com','l3miagefi1AZ32R','bombardier_transport_france','Crespin','controle de production'),('Bolet','Cedric','0327958877','cedric.bolet@avenir-group.fr','l3miagefi1BB31R','avenir_process','Cuincy',''),('',NULL,NULL,'','l3miagefi1BB35R','__sans entreprise__',NULL,NULL),('Pessemier','Nicolas','0623783560','nicolas@ergonotics.com','l3miagefi1BP25R','ergonotics','Villeneuve d\'Ascq','Directeur technique'),('Pesez','Christelle','','christelle.pesez@logica.com','l3miagefi1BR35R','logica','Lille','Directeur de projet'),('Menu','Francois','0320679682','francois.menu@ag2rlamondiale.fr','laurent.laplaceR','ag2r_la_mondiale','Mons en Baroeul','webmaster technique'),('Lefebvre','Pierre','0320874130','plefebvre@view-on.fr','lc.nsourou-ndongR','mcm_groupe_view-on','Roubaix','Chef de projet'),('Tenerowicz ','Andrzej ','+48 694 464 877','Andrzej.Tenerowicz@comarch.pl','ld.arenas-pimentelR','comarch','Wroclaw','Engineer at EDC'),('PTAK','Eric','','eric.ptak@atos.net','liuhua.gaoR','atos','Seclin,Nord-Pas-de-Calais','ingenieur R&D'),('Wauters','Vincent','0658297793','vwauters@vekia.fr','loic.allartR','vekia','Lille','directeur technique'),('Bonamy','Cyrille ','0320436750','cyrille.bonamy@univ-lille1.fr','lois.arensR','cri_(centre_ressources_informatiques)','Villeneuve d\'Ascq','IR Calcul'),('Brunet','Franck','0954841760','fb@addcom.fr','louis.billietR','addcom','Roubaix','Directeur'),('Daireaux','Jean-Baptiste','0320761176','jb.daireaux@sneg.fr','louis.motteR','sneg','Roubaix','chef de projet'),('Wauters','Vincent','0658297793','vwauters@vekia.fr','louis.saint-maxentR','vekia','Lille','Directeur technique'),('Duchenne','Aurelia','0359304145','aurelia.duchenne@oxylane.com','lucie.meresseR','decathlon','Villeneuve d Ascq','Ingenieur Systeme d Information'),('','','','','lucille.dhaleineR','constellation','Villeneuve d Ascq',''),('',NULL,NULL,'','m2eservfiBB30R','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','m2iaglfi1BI28R','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','m2iaglfi1BI32R','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','m2iaglfi1BI38R','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','m2iaglfiBB37R','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','m2iaglfiBI36R','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','m2miagefi1DA29R','__sans entreprise__',NULL,NULL),('Hudzia','Bertrand','0320827332','','m2tiirfi1BA26R','ovh_gs_sas','Roubaix','Responsable R&D'),('Notebaert','Frederick','0612095835','frederick.notebaert@logica.com','ma.boutillierR','logica','Lille','architecte technique'),('LANCRY','Julien','0320684181','julien.lancry@advens.fr','mael.baekelandtR','advens','Lille','Consultant Sécurité'),('Ibarissene','Idir','','idir.ibarissene@chru-lille.fr','malika.rakhaouiR','chru_lille_(cic_it_807)','Loos','Informaticien'),('',NULL,NULL,'','marine.beckerR','__sans entreprise__',NULL,NULL),('Bellenguez','Franck','0320653434','franck.bellenguez@capgemini.com','martin.cabyR','cap_gemini','Lille','Chef de projet'),('Pelsener','Aurélien','0320609359','aurelien.pelsener@atos.net','mathieu.bonR','atos_worldline','seclin','Ingénieur études et développement'),('',NULL,NULL,'','mathieu.dervauxR','__sans entreprise__',NULL,NULL),('',NULL,NULL,'','mathilde.lagacheR','__sans entreprise__',NULL,NULL),('Verguet','Jean-Alexis','0786968886','','matthieu.laurentR','logica','Lille','consultant solution'),('Carme','Julien','0320609435','julien.carme@atos.net','matthieu.mastioR','atos_worldline','seuclin','Ingénieur R&D'),('Deceuninck','Sylvain','0366720247','sylvain.deceuninck@noolitic.biz','matthieu.poudrouxR','noolitic','Lille','Directeur Technique'),('Piquette','Maxime','','maxime.piquette@gmail.com','maxime.piquetteR','icreo','','PDG'),('Lefebvre','Pierre','0320860200','plefebvre@view-on.fr','maxime.vanpeeneR','mcm_groupe_view-on','Roubaix','Chef de projet'),('Schillewaert','Loic','0674959353','loic;schillewaert@gmail.com','melissa.blainR','logica','Lille','ingenieur en technologie de l information'),('John','Mathias','','mattis23@gmail.com','mengmeng.tangR','lifl','Villeneuve d Ascq','postdoc'),('Gradel','Olivier','0629852077','gredel-ol@bdom.fr','mh.ouannaneR','bdom','Wasquehal','Directeur finance,organisation et process'),('Opigez','Mickael','0359314232','mopigez@nordcompo.fr','mickael.camierR','nordcompo','Villeneuve d Ascq','Manager RetD et methodes'),('Lombart','Anthony','0351164603','anthony.lombart@sncf.fr','mickael.duruisseauR','sncf','Charleville-Mezieres','chef de section'),('Wahabi','Rachid','00212661197939','wahadi.rachid@gmail.com','mina.elkhotfiR','wgi','Casablanca','DG'),('Deniau','Virginie ','0320438992','virginie.deniau@ifsttar.fr','nabil1.ech-charraqR','ifsttar','Villeneuve d Ascq','chargee de recherche'),('Djeraba','Chabane','0362531552','chabane.djeraba@lifl.fr','nassim.hassaineR','ircica','Villeneuve d Ascq','Professeur'),('Deboeuf','Samuel','0362599367','samuel.deboeuf@logica.com','nathanael.martinR','logica','Lille',''),('Tinel','Yvon','0320436750','yvon.tinel@univ-lille1.fr','navish.lallbeeharryR','cri_(centre_ressources_informatiques)','Villeneuve d Ascq','IR Calcul'),('Baudhuin','Guillaume ','0320464849','g;baudhuin@peoleo.com','nicolas.colmanR','peoleo','Tourcoing','responsable technique'),('Jamin','Stephane','0324584464','stephane.jamin@erdf-grdf.fr','nicolas.coyardR','erdf-grdf','Charleville-Mezieres','hyperviseur pilotage centralise'),('Rousseaux','Jeremy','0320609309','jeremy.Rousseaux@atos.net','nicolas.malassagneR','atos_worldline','Seclin','Chef de projet'),('',NULL,NULL,'','nicolas.quequetR','__sans entreprise__',NULL,NULL),('Deceuninck','Sylvain','0699426271','','olivier.debreuR','noolitic','Lille','Directeur Technique'),('Mokhtari','Said','','said.elharchi@tgr.gov.ma','omar.chahbouniR','tgr','Rabat',''),('Mortar','Feddal','0320554209','mfe@geolatys.com','ouardia.ma-zR','geolatys','Lille','gerant'),('VIRY','Matthias','06 23 11 01 43','matthias@3e-monde.com','oussama.mahmoudiR','sas_3e_monde','Lille','Directeur Associé'),('Tuminello','Cedric','0320688090','cedric@oxygem.tv','pauline.hacheR','dynamic web','Roubaix',''),('Buisine','Stephane','0320638240','sbuisine@sumhit.com','pierre.frayerR','sumhit','Lille','directeur technique'),('Haddad','','0320549699','contact@kalysse.fr','pierre.ramelotR','kalysse','Lomme','gerant'),('Behin','olivier','0320910391','obehin@acss.fr','pierrick.lesageR','acssi','Villeneuve d Ascq','Responsable BI'),('Empis','Jean-Loup','0328765666','jlempis@norsys.fr','quentin.petitR','norsys','Ennevelin','Directeur des operations'),('Koubaa','Anis','966508612974','','rabab.bouzianeR','coins_lab','Riyadh','associate professor'),('Tuminello','Cedric','0320689080','cedric@oxygem.tv','rachid.khelilR','dynamic web','Roubaix','Directeur technique'),('Charpentier','Fabienne','','cCharpentier@carter-cash.com','remi.boensR','carter-cash','Villeneuve d Ascq',''),('Ruffelaere','David','0320692069','druffelaere@like-interactive.com','remi.houdeletteR','like_interactive','Roubaix','Directeur developpement'),('Parents','Guillaume','0980082818','','remi.kaczmarekR','formaeva','Lille','Responsable developpement Informatique'),('',NULL,NULL,'','remy.di-fantR','__sans entreprise__',NULL,NULL),('Pupponi','Jacques','0359086926','j;pupponi@intuitive.travel.fr','romain.belmonteR','intuitive_travel','Villeneuve d ascq',''),('Bouquet','Bruno','0320637349','bruno.bouquet@sathys.com','romain.blasR','sathys','La madeleine',''),('Daireaux','Jean-Baptiste','0320761176','jb.daireaux@sneg.fr','romain.bordoneR','sneg','Roubaix','chef de projet'),('Duee','Herve','0328531002','herve.duez@gfi.fr','romain.frangiR','gfi','Lille','Directeur de projet'),('APPELL','Didier','04 76 52 65 35 ','didier.appell@sogeti.com','romain.le-jeuneR','sogeti_high_tech','Montbonnot','Directeur d’Agence'),('Bonifati','Angela','0328778518','','romain.windelsR','inria','Villeneuve d Ascq','Professeur'),('Vantroys','Thomas','','thomas;vantroys@univ-lille1.fr','ronan.dhellemmesR','ircica','Villeneuve d Ascq','Maitre de conferences'),('Lefebvre','Pierre-Emmanuel','','pierre-emmanuel@infhor.com','s.doutreligneR','infhor','Tourcoing',''),('Jean-Francois','Bocourt','0328331113','jf.bocourt@blm-technologies.fr','sara.el-arbaouiR','blm_technologies','Marcq en Baroeul','Direction de la production'),('Nebut','Mirabelle','03 20 43 47 17','mirabelle.nebut@lifl.fr','sarah.aichaouiR','capgemini_id','Euratechnologies - Bâtiment Leblan Lafont 165 avenue de Bretagne  BP 60404  59 020 LILLE CEDEX','Maître de conférences'),('Lecocq','Cyril','0622171753','clecocq@ntmy.fr','sebastien.rommelardR','nicetomeetyou','Hellemmes','Gerant'),('Fourmeaux','Herve','0320842710','herve@lifedomus.com','sebastien2.leclercqR','lifedomus','Villeneuve d Ascq','Chef de projets'),('Groz','Benoit','0359577988','benoit.groz@inria.fr','shichen.zhaoR','inria','Villeneuve d Ascq',''),('Zheng','Yun','00862161821818','zhengy@spsp.com.cn','sichen.qianR','shanghai_pudong_software_park','Shanghai',''),('Empis','Jean-Loup','0328765600','jlempis@norsys.fr','simon.billiauR','norsys','Ennevelin','Directeur des operations'),('Charpentier','Fabienne','0320399208','fcharpentier@carte-cash.com','sophie.mantelR','carter-cash','Villeneuve dAscq','responsable informatique'),('Marez','Pierre-Eric','0320414074','pemarez@odysys.fr','soufiane.agadrR','odysys','Villeneuve d Ascq','Mobile Project Manager'),('Dequeker','Guillaume','0616973091','guillaume.dequeker@oxylane.fr','stanislas.couroubleR','decathlon','Villeneuve d Ascq','ingenieur informatique support e-commerce'),('Digeon','J.','0320415533','jdigeon@alternative-formation.fr','stefan.dochezR','alternative','Villeneuve d Ascq','Gerant'),('',NULL,NULL,'','sylvain.bialasikR','__sans entreprise__',NULL,NULL),('Mahe','David','0320734776','dmahe@saveur-biere.com','sylvain.depauwR','saveur_biere','Lille','developpeur Web'),('Harsze','Lucas','0359301384','harsze@cap-rh.fr','sylvain.magnierR','cap_rh','Lille','chef de projet'),('Biencourt','Cedric','0320689080','cbiencourt@oxygem.tv','sylvain.ruchotR','meteo_city','Roubaix','Directeur technique'),('',NULL,NULL,'','ta.sowR','__sans entreprise__',NULL,NULL),('Limon Duparcmeur','Ronan','0320163861','ronan.limon-duparcmeur@hosipmedia.fr','thibaut.frainR','hospimedia','Lille','Responsable technique'),('',NULL,NULL,'','thierry.ngando-ngwaR','__sans entreprise__',NULL,NULL),('Creton','Olivier','0612184649','rh@numsoft.fr','thomas.aubryR','numsoft','Lille','directeur'),('DE TEMMERMANN','Tony','0320827332','anthony.de-temmerman@corp.ovh.com','thomas.baertR','ovh_gs_sas','Roubaix','Responsable service hébergement mutualisé'),('Leriche','Vincent','0320609408','Vincent.Leriche@atos.net','thomas.baguetteR','atos_worldline','Seclin','Chef d\'équipe admin système'),('Duee','Herve','0328531002','herve.duez@gfi.fr','thomas.bessetR','gfi','Lille','Directeur de projet'),('Van Agt','Kevin','0328682030','contact@a-technic.com','thomas.buisineR','ad_coup_littoral','Bierne','Responsable Informatique'),('Chokote','Charles ','0320494895','cchokote@yob.fr','thomas.camberlinR','yob_doublet','Avelin','Responsable agence'),('mary','Jeremie','','jeremie.mary@inria.fr','thomas.chabinR','inria','Villeneuve d Ascq',''),('','','','','thomas.clementR','unis','',''),('Vanderbeke','Frederick','0320606886','frederick.vanderbeke@atos.net','thomas.crepel-cardonR','atos_worldline','Seclin','Chef de Projet'),('Crespel','Fabien','0682891737','fabien.crespel@logica.com','thomas.deblockR','logica','Lille','Ingenieur technologies de l information'),('','','','','thomas.maupainR','sopragroup','',''),('Dissaux','Jean Luc','0321576984','jeanluc.dissaux@artoiscomm.fr','thomas.vanderheydenR','communaute_d_agglomerations_de_l_artois','Ruitz (62)','responsable collecte et traitement des dechets'),('',NULL,NULL,'','thomas.zoncaR','__sans entreprise__',NULL,NULL),('Zhang','Simon','0491023265','mcta@wanadoo.fr','tianjun.linR','mcta','Marseille','Gerant'),('Marescaux','Jean-Christophe','0328808496','jean-christophe.marescaux@leroymerlin.fr','titouan.compiegneR','leroy_merlin','Lezennes',''),('Herment','Jeremy','0675486760','jeremie.herment@logica.com','tom.massolR','logica','Lille','charge de projet'),('Fourdinier','Guillaume ','0650443560','guillaume@tombapik.com','tony.tranR','tombapik','Lille Hellemmes','Cogerant'),('Robin','Sebastien','0667117817','seb@nexedi.com','tristan.cavelierR','nexedi','Marcq en Baroeul','Chef de Projet'),('',NULL,NULL,'','tung-minh.phamR','__sans entreprise__',NULL,NULL),('Saveant','Guillaume','0359703219','gsaveant@clinopale.com','valentin.fixR','financiere_verriez','Saint Martin Les Boulogne',''),('Pupponi','Jacques','0359086926','j.pupponi@intuitivetravel.fr','victor.lefebvreR','intuitive_travel','Villeneuve d ascq','Gerant'),('Sion','Herve','0320435050','hsion@villeneuve-d-ascq.fr','vincent.guichardR','mairie_villeneuve_d_ascq','Villeneuve d Ascq','responsable des applications'),('',NULL,NULL,'','vincent.knockaertR','__sans entreprise__',NULL,NULL),('','','','','vincent.vossR','__sans entreprise__','',''),('',NULL,NULL,'','walid.trabelsiR','__sans entreprise__',NULL,NULL),('Poulain','Damien','0811851376','contact@ki-mura.com','wissem.hadhriR','ki_mura','Villeneuve d Ascq','Gerant'),('',NULL,NULL,'','yannick.vanuxemR','__sans entreprise__',NULL,NULL),('Desmarest','Xavier','0682997732','xavier.desmarest@infotel.com','yoann.bouquetR','empeiria','Villeneuve d Ascq','Consultant senior'),('',NULL,NULL,'','zouhair.makhoutR','__sans entreprise__',NULL,NULL);
/*!40000 ALTER TABLE `fa_referent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `fa_sec_roles`
--

DROP TABLE IF EXISTS `fa_sec_roles`;
/*!50001 DROP VIEW IF EXISTS `fa_sec_roles`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_sec_roles` (
  `anneeReference` int(4),
  `obsolete` int(1),
  `roleDesc` text,
  `roleCle` varchar(20)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `fa_sec_user_roles`
--

DROP TABLE IF EXISTS `fa_sec_user_roles`;
/*!50001 DROP VIEW IF EXISTS `fa_sec_user_roles`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_sec_user_roles` (
  `anneeReference` int(4),
  `obsolete` int(1),
  `userRef` varchar(20),
  `roleRef` varchar(20)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `fa_soutenance`
--

DROP TABLE IF EXISTS `fa_soutenance`;
/*!50001 DROP VIEW IF EXISTS `fa_soutenance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fa_soutenance` (
  `formationRef` varchar(10),
  `dateRemise` text,
  `datesSoutenances` text,
  `longueurRapport` text,
  `duréeSoutenance` text,
  `observationsTous` text,
  `observationsTuteurs` text
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `fa_temp_tuteurs`
--

DROP TABLE IF EXISTS `fa_temp_tuteurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_temp_tuteurs` (
  `etat` int(11) NOT NULL,
  `tuteurRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `alternanceRef` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `nom_tuteur` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `prenom_tuteur` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mail_tuteur` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `formationRef` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_temp_tuteurs`
--

LOCK TABLES `fa_temp_tuteurs` WRITE;
/*!40000 ALTER TABLE `fa_temp_tuteurs` DISABLE KEYS */;
INSERT INTO `fa_temp_tuteurs` VALUES (0,'plenacos','clement.vallerandA','','','','L3INFOFI'),(0,'imen.chakroun','liuhua.gaoA','','','','M2TIIRFI'),(0,'imen.chakroun','arnaud.devilleA','','','','M2TIIRFI'),(0,'beaufils','damien.leflonA','','','','L3INFOFI'),(0,'olejnik','damien.leflonA','','','','L3INFOFI');
/*!40000 ALTER TABLE `fa_temp_tuteurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `fa_entreprise`
--

/*!50001 DROP TABLE IF EXISTS `fa_entreprise`*/;
/*!50001 DROP VIEW IF EXISTS `fa_entreprise`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`manneken.lifl.fr` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_entreprise` AS (select `fil_entr`.`entreprise`.`nom` AS `nom`,`fil_entr`.`entreprise`.`adresse` AS `adresse`,`fil_entr`.`entreprise`.`tel` AS `tel`,`fil_entr`.`entreprise`.`ville` AS `ville`,`fil_entr`.`entreprise`.`codePostal` AS `codePostal`,`fil_entr`.`entreprise`.`opcaRef` AS `opcaRef`,`fil_entr`.`entreprise`.`entrepriseCle` AS `entrepriseCle` from `fil_entr`.`entreprise`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fa_etudiant`
--

/*!50001 DROP TABLE IF EXISTS `fa_etudiant`*/;
/*!50001 DROP VIEW IF EXISTS `fa_etudiant`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`manneken.lifl.fr` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_etudiant` AS (select `fil_dept`.`etudiant`.`nom` AS `nom`,`fil_dept`.`etudiant`.`prenom` AS `prenom`,`fil_dept`.`etudiant`.`tel` AS `tel`,`fil_dept`.`etudiant`.`mail` AS `mail`,`fil_dept`.`etudiant`.`mailLille1` AS `mailLille1`,`fil_dept`.`etudiant`.`etudCle` AS `etudCle`,`fil_dept`.`etudiant_groupe`.`groupeRef` AS `groupeRef` from (`fil_dept`.`etudiant` join `fil_dept`.`etudiant_groupe` on((`fil_dept`.`etudiant_groupe`.`etudRef` = `fil_dept`.`etudiant`.`etudCle`))) where ((`fil_dept`.`etudiant_groupe`.`groupeRef` like '%FI%') and (2011 = `fil_dept`.`etudiant_groupe`.`annee`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fa_formation`
--

/*!50001 DROP TABLE IF EXISTS `fa_formation`*/;
/*!50001 DROP VIEW IF EXISTS `fa_formation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`manneken.lifl.fr` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_formation` AS (select `fil_dept`.`formation`.`anneeReference` AS `anneeReference`,`fil_dept`.`formation`.`obsolete` AS `obsolete`,`fil_dept`.`formation`.`formationCle` AS `formationCle`,`fil_dept`.`formation`.`nom` AS `nom`,`fil_dept`.`formation`.`responsableRef` AS `responsableRef`,`fil_dept`.`formation`.`responsableRef2` AS `responsableRef2` from `fil_dept`.`formation` where ((2010 <= `fil_dept`.`formation`.`anneeReference`) and (`fil_dept`.`formation`.`obsolete` = 0) and (`fil_dept`.`formation`.`formationCle` like '%FI%'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fa_groupe`
--

/*!50001 DROP TABLE IF EXISTS `fa_groupe`*/;
/*!50001 DROP VIEW IF EXISTS `fa_groupe`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`manneken.lifl.fr` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_groupe` AS (select `fil_dept`.`groupe`.`anneeReference` AS `anneeReference`,`fil_dept`.`groupe`.`obsolete` AS `obsolete`,`fil_dept`.`groupe`.`groupeCle` AS `groupeCle`,`fil_dept`.`groupe`.`formationRef` AS `formationRef`,`fil_dept`.`groupe`.`responsableRef` AS `responsableRef` from `fil_dept`.`groupe` where ((2010 <= `fil_dept`.`groupe`.`anneeReference`) and (`fil_dept`.`groupe`.`obsolete` = 0) and (`fil_dept`.`groupe`.`groupeCle` like '%FI%'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fa_opca`
--

/*!50001 DROP TABLE IF EXISTS `fa_opca`*/;
/*!50001 DROP VIEW IF EXISTS `fa_opca`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`manneken.lifl.fr` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_opca` AS (select `fil_entr`.`opca`.`nom` AS `nom`,`fil_entr`.`opca`.`commentaires` AS `commentaires`,`fil_entr`.`opca`.`anneesFinancees` AS `anneesFinancees`,`fil_entr`.`opca`.`representant` AS `representant`,`fil_entr`.`opca`.`tel` AS `tel`,`fil_entr`.`opca`.`mail` AS `mail`,`fil_entr`.`opca`.`opcaCle` AS `opcaCle`,`fil_entr`.`opca`.`url` AS `url` from `fil_entr`.`opca`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fa_prof`
--

/*!50001 DROP TABLE IF EXISTS `fa_prof`*/;
/*!50001 DROP VIEW IF EXISTS `fa_prof`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`manneken.lifl.fr` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_prof` AS (select `fil_dept`.`membre`.`anneeReference` AS `anneeReference`,`fil_dept`.`membre`.`obsolete` AS `obsolete`,`fil_dept`.`membre`.`nom` AS `nom`,`fil_dept`.`membre`.`prenom` AS `prenom`,`fil_dept`.`membre`.`tel` AS `tel`,`fil_dept`.`membre`.`mail` AS `mail`,`fil_dept`.`membre`.`bureau` AS `bureau`,`fil_dept`.`membre`.`profCle` AS `profCle` from `fil_dept`.`membre` where ((2010 <= `fil_dept`.`membre`.`anneeReference`) and (`fil_dept`.`membre`.`obsolete` = 0))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fa_sec_roles`
--

/*!50001 DROP TABLE IF EXISTS `fa_sec_roles`*/;
/*!50001 DROP VIEW IF EXISTS `fa_sec_roles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`manneken.lifl.fr` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_sec_roles` AS (select `fil_dept`.`roles`.`anneeReference` AS `anneeReference`,`fil_dept`.`roles`.`obsolete` AS `obsolete`,`fil_dept`.`roles`.`roleDesc` AS `roleDesc`,`fil_dept`.`roles`.`roleCle` AS `roleCle` from `fil_dept`.`roles` where ((2010 <= `fil_dept`.`roles`.`anneeReference`) and (`fil_dept`.`roles`.`obsolete` = 0) and ((`fil_dept`.`roles`.`roleCle` like '%FI%') or (`fil_dept`.`roles`.`roleCle` like 'ALL_RESP')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fa_sec_user_roles`
--

/*!50001 DROP TABLE IF EXISTS `fa_sec_user_roles`*/;
/*!50001 DROP VIEW IF EXISTS `fa_sec_user_roles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`manneken.lifl.fr` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_sec_user_roles` AS (select `fil_dept`.`roles_membres`.`anneeReference` AS `anneeReference`,`fil_dept`.`roles_membres`.`obsolete` AS `obsolete`,`fil_dept`.`roles_membres`.`userRef` AS `userRef`,`fil_dept`.`roles_membres`.`roleRef` AS `roleRef` from `fil_dept`.`roles_membres` where ((2010 <= `fil_dept`.`roles_membres`.`anneeReference`) and (`fil_dept`.`roles_membres`.`obsolete` = 0) and ((`fil_dept`.`roles_membres`.`roleRef` like '%FI%') or (`fil_dept`.`roles_membres`.`roleRef` like '%ALL%') or (`fil_dept`.`roles_membres`.`roleRef` like 'INFO_%') or (`fil_dept`.`roles_membres`.`roleRef` like 'MIAGE_%')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fa_soutenance`
--

/*!50001 DROP TABLE IF EXISTS `fa_soutenance`*/;
/*!50001 DROP VIEW IF EXISTS `fa_soutenance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`manneken.lifl.fr` SQL SECURITY DEFINER */
/*!50001 VIEW `fa_soutenance` AS (select `fil_dept`.`soutenance`.`formationRef` AS `formationRef`,`fil_dept`.`soutenance`.`dateRemise` AS `dateRemise`,`fil_dept`.`soutenance`.`datesSoutenances` AS `datesSoutenances`,`fil_dept`.`soutenance`.`longueurRapport` AS `longueurRapport`,`fil_dept`.`soutenance`.`duréeSoutenance` AS `duréeSoutenance`,`fil_dept`.`soutenance`.`observationsTous` AS `observationsTous`,`fil_dept`.`soutenance`.`observationsTuteurs` AS `observationsTuteurs` from `fil_dept`.`soutenance` where ((`fil_dept`.`soutenance`.`anneeReference` <= 2010) and (`fil_dept`.`soutenance`.`obsolete` = 0))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-06-08 23:17:01
