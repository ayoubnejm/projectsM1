<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
 require_once (ABS_START_PATH."/secure/auth.php");


 if (hasRole(RESP_ROLE)) {
   require_once (ABS_START_PATH."/interface/welcomeResponsable_act.php");
 }
 else
 if (hasRole(PROF_ROLE)) require_once (ABS_START_PATH."/interface/welcomeTuteur_act.php");
 else
 if (hasRole(STUD_ROLE)) require_once (ABS_START_PATH."/interface/welcomeEtudiant_act.php");
// Ajouté par an et se 2013 
else
 if (hasRole(SECR_ROLE)) require_once (ABS_START_PATH."/interface/welcomeSecretaire_act.php");
?>
