<?php
    require '../secure/auth.php';

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <TITLE>Enregistrement régularisation tuteurs </TITLE>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
    </head>
    <body>
        <?php

        function inscrire($conn, $nom,$prenom,$mail,$cle)
        {
            $insertQuery="insert into fa_prof (`profCle`, `nom`,`prenom`,`mail`) VALUES ";
            $insertQuery.="('".$cle."','".$nom."','".$prenom."','".$mail."')";
            if (!mysql_query($insertQuery,$conn))
            {
                echo "pb inserting prof";
                return false;
            }

            return true;
        }
        
        function replace($conn,$nom,$prenom,$mail,$cle)
        {
            

            $updateQuery="update fa_temp_tuteurs set ";
            $updateQuery.=" tuteurRef='".$cle."' , ";
            $updateQuery.=" nom_tuteur='', ";
            $updateQuery.=" prenom_tuteur='', ";
            $updateQuery.=" mail_tuteur='' ";
            $updateQuery.="where nom_tuteur like '".$nom."' ";
            $updateQuery.="and prenom_tuteur like '".$prenom."' ";
            $updateQuery.="and mail_tuteur like '".$mail."' ";

            if (!mysql_query($updateQuery,$conn))
            {
                echo "pb updating tuteurs";
                //deleting prof
                return false;
            }

            return true;
        }
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/dbmngt/queries.php");
        require_once(ABS_START_PATH."/html/utils.php");

        ?>

        <h2>Etat de la régularisation</h2>
        

        <table border="1">
            <thead>
                <tr>
                    <td>Nom</td>
                    <td>Prenom</td>
                    <td>Mail</td>
                    <td>IdentifiantTuteur</td>
                    <td>Etat</td>
            </thead>
            <tbody>
        <?php


        if (!array_key_exists("nbNvxTuteurs",$_REQUEST))
        {
            echo 'Rien à faire ici! Comment etes-vous rentré?';
            exit();
        }

        
        $nbNvxTuteurs=$_REQUEST["nbNvxTuteurs"];
        $conn=doConnection();
        $tuteursClesEnregistres=doQueryListTuteurs($conn);
        $row=mysql_fetch_row($tuteursClesEnregistres);
        $nbCles=0;
        while ($row)
        {
            $clesExistantes[$nbCles++]=$row[0];
            $row=mysql_fetch_row($tuteursClesEnregistres);
        }

        echo "Currently ",$nbCles, " prof enregistrés";

        
        $noms=$_REQUEST["nom"];
        $prenoms=$_REQUEST["prenom"];
        $mails=$_REQUEST["mail"];
        $nvTuteursCles=$_REQUEST["nvTuteurCle"];
        $existantTuteurCles=$_REQUEST["existantTuteurCle"];
        
        
        $countPB=0;
        $count=0;
        while ($count<$nbNvxTuteurs)
        {
            echo "<tr>";
            echo "<td><input type=\"hidden\" name=\"nom\"/>",$noms[$count],"</td>";
            echo "<td><input type=\"hidden\" name=\"prenom\"/>",$prenoms[$count],"</td>";
            echo "<td><input type=\"hidden\" name=\"mail\"/>",$mails[$count],"</td>";
            echo "<td>";
            $ok=true;
            if ($nvTuteursCles[$count]=="nouveau")
            {
                echo "nouveau - n'est pas un identifiant valide";
                $ok=false;
            }
            else {
                   
                    if ($existantTuteurCles[$count]!="nouveau")
                        $cle=$existantTuteurCles[$count];
                    else
                    {
                   
                        $cle=$nvTuteursCles[$count];
                   
                        for ($i=0;$i<$nbCles && $clesExistantes[$i]!=$cle;$i++)
                        {
                   
                        }
                        if ($i<$nbCles)
                            {
                                echo "id déjà existant";
                                $ok=false;
                            }
                        else
                            $ok=inscrire($conn, $noms[$count],$prenoms[$count],$mails[$count],$cle);
                    }
                   
                    if ($ok)
                        $ok=replace($conn, $noms[$count],$prenoms[$count],$mails[$count],$cle);
                    if ($ok)
                        echo $cle;
                }
            echo "</td>";
            echo "<td>".($ok?"enregistré":"problème")."</td>";
            echo "</tr>";
            if ($ok==false)
                $countPB++;
            $count++;
        }
       ?>
            </tbody>
        </table>
        <br>
        
        <?php
        if ($countPB>0)
        {
            echo "Quelques problèmes pour l'enregistrement des tuteurs.";
            echo "Revenez à l'<a href=\"regularisationTuteurs.php\">étape précedente</a>";
        }
        ?>
        <br/>
        <a href="attributionTuteurs.php">Page attribution tuteurs</a>
     </body>
</html>