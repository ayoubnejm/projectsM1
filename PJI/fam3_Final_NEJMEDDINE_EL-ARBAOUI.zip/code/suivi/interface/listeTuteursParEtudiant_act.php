<?php
    require_once(ABS_START_PATH."/secure/auth.php");


    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
    require_once(ABS_START_PATH."/dbmngt/connect.php");
    require_once(ABS_START_PATH."/dbmngt/queries.php");
    require_once(ABS_START_PATH."/html/utils.php");
    require_once(ABS_START_PATH."/html/dbutils.php");
?>

        <!--SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT-->
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
 
        <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 5 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Tableau de situation des étudiants</a></div>
<div class="menuitem2" id="item_1"><a href="#" onclick="changeClass(this)">Emails étudiants ULille1</a></div>
<div class="menuitem2" id="item_2"><a href="#" onclick="changeClass(this)">Emails étudiants ULille1 + perso</a></div>
<div class="menuitem2" id="item_3"><a href="#" onclick="changeClass(this)">Emails étudinats perso</a></div>
<div class="menuitem2" id="item_4"><a href="#" onclick="changeClass(this)">Légende couleurs</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
<!-- FIN MENU -->
<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        <?php
           
            $conn=doConnection();
            $emails="";

            $formation=getParam("formation","%MIAGE%");
            $_SESSION["formation"]=$formation;

            ?>
            <h1></h1>
            <?php
              $keysValues=constructGrantedGroupesKeys();
            ?>
            <?php
              $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");
            ?>
            
         <table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1">
                <thead><tr>
                        <!--td></td-->
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Formation</th>
                        <th>Ville</th>
                        <th>Entreprise</th>
                       <th>Tuteurs potentiels</th>
                       <th><div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">details</a--></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i=0;
                    $divs="'head'";
                    $etudiants=doQueryListEtudiantsParFormation($conn,$formation);
                    $emails=""; $emailsMix=""; $emailsULille1="";
                    $missing=""; $missingMix=""; $missingULille1="";
                    
                    $row=mysql_fetch_row($etudiants);
                    while ($row)
                    {
                        $et_pn=$row[2]." ".$row[1];
                        
                        $etud=$row[14];
                        
                        if ($row[19])
                        {
                            $emails=$emails.", ".$row[19];
                        }
                        else
                        {
                            $missing.=", ".$et_pn;
                        }

                        if ($row[22]) {
                          $emailsULille1.=", ".$row[22];
                        } else
                          $missingULille1.=", ".$et_pn;

                        if ($row[22])
                          $emailsMix.=", ".$row[22];
                        else
                          if ($row[19])
                            $emailsMix.=", ".$row[19];
                          else
                            $missingMix.=", ".$et_pn;

                        $nbTuteurs=0;
                        $tuteurSelectionne=-1;
                        $clesTuteurs=array();$nomsTuteurs=array();

                        $tuteurEtabli=mysql_fetch_row(doQueryTuteurEtudiant($conn,$etud));
                        if ($tuteurEtabli)
                        {
                            $clesTuteurs[$nbTuteurs]=$tuteurEtabli[0];
                            $nomsTuteurs[$nbTuteurs++]=$tuteurEtabli[1]." ".$tuteurEtabli[2];
                            $tuteurSelectionne=0;
                        }

                        $tuteurs=doQueryTuteursPotentiels($conn,$formation,$row[0]);

                        if ($tuteurSelectionne==0)
                        { echo "<tr bgcolor='gray'>";}
                        else
                        {  
                            if (mysql_num_rows($tuteurs)>0)
                                echo "<tr >";
                            else
                               echo "<tr bgcolor='red'>";
                        }
                        
                        echo "<td>",$row[1],"</td>";
                        echo "<td>",$row[2],"</td>";
                        echo "<td>",$row[3],"</td>";

                        echo "<td>",$row[6],"</td>";
                        echo "<td>",substr($row[9],0,20),"</td>";
                        echo "<td>&nbsp;";
                        if ($tuteurSelectionne == 0) {
                            echo "<b>".$row[15]."</b> ";
                        }
                            
                            $tuteur=null;
                            if ($tuteurs)
                                $tuteur=mysql_fetch_row($tuteurs);
                            while ($tuteur) {
                                if (strcmp($tuteur[0],"nouveau")!=0)
                                    echo $tuteur[0];
                                else
                                    echo $tuteur[1]."_".$tuteur[2];
                                echo "<br/>";
                                $tuteur=mysql_fetch_row($tuteurs);
                            }
                        echo "</td>";
                        echo "<td> ".$row[16]." <div id='td",$i,"' style='visibility:hidden'><a name='td",$i,"'/><table bgcolor='orange' border='1'>
             <tr>
             <td>Referent</td>
             <td>Missions</td>
             <td>Services</td>
             <td>Clients</td>
             <td>Envirnmnt Tech.</td>
             </tr><tr>";
                        echo "<td>",$row[7] ,"</td>";
                        echo "<td>",$row[10] ,"</td>";
                        echo "<td>",$row[11] ,"</td>";
                        echo "<td>",$row[12] ,"</td>";
                        echo "<td>",$row[13] ,"</td>";
                        echo "</tr><tr><td colspan='5' align='right'><a href='#td",$i,"' onClick='javascript:showHideModal(\"td",$i,"\");'>Cacher</a></td></tr></table></div><a href='#td",$i,"' onClick='javascript:showHideModal(\"td",$i,"\");'>details</a></td>";
                        echo "</tr>";
                        $divs=$divs.",'td".$i."'";
                        $row=mysql_fetch_row($etudiants);
                        $i=$i+1;
                    }
                    $nbDivs=$i;
                    
                    ?>
                </tbody>
            </table>
        </div>
        <div id="cadre_1" class="contenu-item2 off">
            <br/>
            <?php
              $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");
            ?>
            <ul><li>
                <b>Emails</b> : <?php if (strlen($emailsULille1)>2) echo substr($emailsULille1,2); ?> <br/>
              </li><li>
                <b style="color:red">Manquants</b> : <?php if (strlen($missingULille1)>2) echo substr($missingULille1,2); ?>
            </li></ul>
            
         </div>
        <div id="cadre_2" class="contenu-item2 off">
          <br/>
          <?php
              $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");
            ?>
          <ul><li>
                <b>Emails</b> : <?php if (strlen($emailsMix)>2) echo substr($emailsMix,2); ?> <br/>
            </li><li>
                <b style="color:red">Manquants</b> : <?php if (strlen($missingMix)>2) echo substr($missingMix,2); ?>
            </li></ul>

        </div>
        <div id="cadre_3" class="contenu-item2 off">
            <br/>
            <?php
              $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");
            ?>
            <ul><li>
              <b>Emails</b> : <?php if (strlen($emails)>2) echo substr($emails,2); ?> 
            </li><li>
              <b style="color:red">Manquants</b> : <?php if (strlen($missing)>2) echo substr($missing,2); ?>
            </li></ul>

    </div>
  <div id="cadre_4" class="contenu-item2 off">
    <br/>
    <ul>
      <li>Lignes <font style="background-color:red">rouges</font> - étudiants sans tuteur
      </li>
      <li>Lignes <font style="background-color:darkgray">grises</font> - étudiants avec tuteur</li>
    </ul>
  </div>
</div>
         <script type="text/javascript">
<?php
echo "var layer = new Array(",$divs,");";
echo "doModalAll(layer);";
?>
            </script>
