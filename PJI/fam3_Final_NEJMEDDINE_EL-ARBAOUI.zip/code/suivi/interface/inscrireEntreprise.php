<?php
    require_once '../secure/auth.php';

    //error_log("accueilTuteur for ".getParam(CK_USER,"UNKOWNN"));

    if (!hasRole(PROF_ROLE) && !hasRole(STUD_ROLE))
        redirectAuth(null);


    require_once '../html/utils.php';
    require_once '../html/dbutils.php';
    require_once '../dbmngt/inscrire.php';

?>
<html>
     <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Nouvelle Entreprise</title>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <form id="inscrireentr" action="inscrireEntreprise.php" method="POST">
          <h2>Inscrire une nouvelle entreprise</h2>
            <table witdh="500">

        <?php
          $inscrire=getParam("inscrire","");
          $fa_entr_nom=getParam("fa_entr_nom","");
          $fa_entr_adresse=getParam("fa_entr_adresse","");
          $fa_entr_tel=getParam("fa_entr_tel","");
          $fa_entr_ville=getParam("fa_entr_ville","");
          $fa_entr_cp=getParam("fa_entr_cp","");
          $fa_entr_opcaRef=getParam("fa_entr_opcaRef","1");          
          if (strlen($inscrire)>0) 
          {
              $err_msg=faireInscrireentr(
                $fa_entr_nom,
                $fa_entr_adresse,
                $fa_entr_tel,
                $fa_entr_ville,
                $fa_entr_cp,
                $fa_entr_opcaRef
                );
              if (strlen($err_msg)) {
                echo "<h4 style='color:red'>$err_msg</h4>";
              } else {
                echo "$fa_entr_nom inscrite avec succes!<br/>";
                echo "<a href='javascript:history.go(-2);'>Retour</a>";
                exit();
              }
          }
          
          
        ?>
                <tr>
                    <td width="250">
            Nom entreprise : </td><td><input type="text" name="fa_entr_nom" value="<?php echo $fa_entr_nom;?>"/>
                    </td></tr><tr><td>
            Adresse : </td><td><input type="text" name="fa_entr_adresse" value="<?php echo $fa_entr_adresse;?>"/>
            </td></tr><tr><td>
                        Ville :</td><td><input type="text" name="fa_entr_ville" value="<?php echo $fa_entr_ville;?>"/>
            </td></tr><tr><td>
                        Code Postal :</td><td><input type="text" name="fa_entr_cp" value="<?php echo $fa_entr_cp;?>"/>
            </td></tr><tr><td>
                        Téléphone :</td><td><input type="text" name="fa_entr_tel" value="<?php echo $fa_entr_tel;?>"/>
            </td></tr><tr><td>OPCA</td><td>
                        <?php
                        createOPCASelect(doConnection(),"fa_entr_opcaRef",$fa_entr_opcaRef);
                        echo "<br/><a target='main' href='../interface/inscrireOPCA.php'/>saisir OPCA</a>";
                        ?>
                </td>
                </tr>
                <tr><td colspan="2" align="center"><input type="submit" style="color:orange" name="inscrire" value="Inscrire"/></td></tr>
            </table>

        </form>

    </body>
</html>