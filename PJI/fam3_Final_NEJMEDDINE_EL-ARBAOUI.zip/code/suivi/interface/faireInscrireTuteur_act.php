<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queries.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/dbutils.php");
      require_once (ABS_START_PATH."/dbmngt/inscrire.php");

      $conn=doConnection();

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Inscrire Tuteur</a>
  | <a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/gestionTuteurs_act">Liste des tuteurs universitaires</a>
</div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>

        <?php 
      

        $prenom = trim(getParam("fa_tuteur_prenom", null));
        $nom = trim(strtoupper(getParam("fa_tuteur_nom", null)));
        $mail = trim(getParam("fa_tuteur_mail", null));
        $tel = trim(getParam("fa_tuteur_tel", null));
        $profCle = trim(getParam("fa_tuteur_profCle", null));
        $bureau=trim(getParam("fa_tuteur_bureau", null));

        

        if ($prenom != null && $nom != null)
            echo "<b>", $prenom, " ", $nom, "</b> <br/>";
        else
            die("<h2>Problème</h2>Vous devez renseigner le nom, le prenom  de tuteur! <br/><a href='#' onclick='javascript:history.go(-1);'>Revenir</a>");


        /*
         * Ajout JTA le 06/02/2012 recuperation du bureau de l'etudiant et du referent 
         */

      

        $res = faireInscrireTuteur($nom, $prenom, $tel, $mail, $profCle,$bureau, $_SESSION[REF_YEAR]);

        if (strcmp($res,"Echec")==0)
          echo "<b>Echec d'insertion de $nom $prenom pour l'année ".$_SESSION[REF_YEAR]."</b>";
        else if (strcmp($res,"En attente")==0)
            echo "<b>En attente</b>";
        else
            echo "<b>Insertion réussie de $nom $prenom  pour l'année ".$_SESSION[REF_YEAR]."</b>";
               ?>
    </div>
</div>