<?php
// Ajout class de gestion des referents du 10/05/2012 JTA 

require_once '../secure/auth.php';

if (!hasRole(PROF_ROLE) && !hasRole(STUD_ROLE))
    redirectAuth(null);


require_once '../html/utils.php';
require_once '../html/dbutils.php';
require_once '../dbmngt/inscrire.php';

$conn = doConnection();
?>
<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Nouveau Referent</title>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <form id="inscrireReferent" action="inscrireReferent.php" method="POST">
            <?php
            $entreprise = getParam("entr_cle", "");
            $entrepriseNom = getParam("entr_nom", "");
            ?>
            <input type="hidden" name="entr_cle" value="<?php echo $entreprise; ?>"/>
            <input type="hidden" name="entr_nom" value="<?php echo $entrepriseNom; ?>"/>
            <h2>Inscrire un nouveau référent pour l'entreprise : <?php echo $entrepriseNom ?> </h2>
            <table witdh="500">

                <?php
                $inscrire = getParam("inscrire", "");
                $fa_ref_nom = getParam("fa_ref_nom", "");
                $fa_ref_prenom = getParam("fa_ref_prenom", "");
                $fa_ref_email = getParam("fa_ref_email", "");
                $fa_ref_tel = getParam("fa_ref_tel", "");
                $fa_ref_fonction = getParam("fa_ref_fonction", "");
                $fa_ref_bureau = getParam("fa_ref_bureau", "");

                if (strlen($inscrire) > 0) {
                    $err_msg = faireInscrireReferent(
                            $fa_ref_nom, $fa_ref_prenom, $fa_ref_email, $fa_ref_tel, $fa_ref_fonction, $fa_ref_bureau, $entreprise
                    );
                    if (strlen($err_msg)) {
                        echo "<h4 style='color:red'>$err_msg</h4>";
                    } else {
                        echo "Inscription reussie!<br/>";
                        echo "<a href='javascript:history.go(-2);'>Retour</a>";
                        exit();
                    }
                }
                ?>
                <tr>
                    <td>
                        Nom *: 
                    </td>
                    <td>
                        <input type="text" name="fa_ref_nom" value="<?php echo $fa_ref_nom; ?>"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Prenom *:
                    </td>
                    <td>
                        <input type="text" name="fa_ref_prenom" value="<?php echo $fa_ref_prenom; ?>"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Email *:
                    </td>
                    <td>
                        <input type="text" name="fa_ref_email" value="<?php echo $fa_ref_email; ?>"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Téléphone :
                    </td>
                    <td>
                        <input type="text" name="fa_ref_tel" value="<?php echo $fa_ref_tel; ?>"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Fonction :
                    </td>
                    <td>
                        <input type="text" name="fa_ref_fonction" value="<?php echo $fa_ref_fonction; ?>"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Bureau :
                    </td>
                    <td>
                        <?php
                        createBureauSelect($conn, "fa_ref_bureau", $entreprise, "", "");
                        echo "<br/><a target='main' href='../interface/inscrireBureau.php?entr_cle=" . $entreprise . ".&entr_nom=" . $entrepriseNom . "'/>saisir Bureau</a>";
                        ?>                        
                    </td>
                </tr>
                <tr>
                    <td>
                        * Champ obligatoire
                    </td>
                    <td>
                        <input type="submit" style="color:orange" name="inscrire" value="Inscrire"/>
                    </td>
                </tr>
            </table>

        </form>

    </body>
</html>