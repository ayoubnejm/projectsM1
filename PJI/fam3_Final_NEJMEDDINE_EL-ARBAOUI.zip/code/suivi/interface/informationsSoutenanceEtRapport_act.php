<?php

    require_once(ABS_START_PATH."/secure/auth.php");
    if (!hasRole(STUD_ROLE))
      redirectAuth(null);
    
?>
<?php
        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/dbmngt/queriesSout.php");
        require_once(ABS_START_PATH."/html/utils.php");

        $conn=doConnection();
        $req=doQueryDetailsSoutenanceRapportByEtud($conn,$_SESSION[CK_USER]);
        $res=mysql_fetch_row($req);

?>
<div class="menuitem2" id="item_0">Informations concernant le rapport et la soutenance</a></div>

 <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        
     
      <table style="font-size:9pt">
        <tr>
          <td>
            <b>Date de remise du rapport</b>
          </td>
          <td>
            <?php echo to_html($res[1]) ; ?>
          </td>
        </tr>

      <tr><td><b>Dates de soutenances</b></td><td>
      <?php echo to_html($res[2]); ?></td></tr>
      

      <tr><td><b>Longueur du rapport</b></td><td><?php echo to_html($res[3]); ?></td></tr>


      <tr><td><b>Durée de la soutenance</b></td><td><?php echo to_html($res[4]); ?></td></tr>
      

      <tr><td><b>Observation</b></td><td><?php echo to_html($res[5]); ?></td></tr>
      </table>

      <br/>
      <!--a href="../interface/accueilEtudiant.php" style="color:white">Revenir à la page d'accueil</a-->

        </div>
 </div>
