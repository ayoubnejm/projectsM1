<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE) or !hasRole(SECR_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queries.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/dbutils.php");
      require_once(ABS_START_PATH."/dbmngt/inscrire.php");

      $conn=doConnection();

      $formation=getParam("formation","L3MIAGEFA");
      $_SESSION["formation"]=$formation;

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Inscrire Etudiants</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
  
  

</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>
          <h1>A NE PAS UTILISER ! A READAPTER l'appel pour inscrire un par 1 les étudiants </h1>
        <?php
          if (getCurrYear()>$_SESSION[REF_YEAR]) {
            die("<b>Impossible d'inscrire d'étudiants pour l'année courante $_SESSION[REF_YEAR] !</b> </div></div>");
          }
        ?>

      <?php
      if( isset($_POST['uploaded']) ) // si formulaire soumis
      {

        $tmp_file = $_FILES['fichier']['tmp_name'];

        if( !is_uploaded_file($tmp_file) )
        {
            exit("Le fichier est introuvable");
        }

        $type_file = $_FILES['fichier']['type'];
        if( !strstr($type_file, 'plain') &&!strstr($type_file, 'csv'))
        {
            exit("Le fichier n'est pas un fichier csv");
        }

        $conn=doConnection();
        date_default_timezone_set('Europe/Paris');
        
        //$annee=date("n")>9?date("Y"):(date("Y")-1);


        echo "<table border='1'>";
        $handle= fopen($tmp_file, "r");
        $ignoredHeaderLine=fgetcsv($handle,0,';');
        while ($data=fgetcsv($handle,0,';')) {
          $nom=trim($data[0]);
          $prenom=trim($data[1]);
          $status=trim($data[2]);
          $mail=trim($data[3]);
          $et_entrCle=strlen(trim($data[4])>0)?trim($data[4]):"__sans entreprise__";
          $ville=trim($data[5]);
          if (substr($data[6],strlen($data[6])-1)=="1")
            $groupeRef=trim($data[6]);
          else
            $groupeRef=trim($data[6])."1";
          $motsCles=trim($data[7]);
          $tuteurRef=NULL;

          echo "<tr><td>$nom</td><td>$prenom</td><td>$groupeRef</td><td>";
          if (strtoupper($status)=="FA") {
            echo "<i>ignoré</i>";
          } else {
            $res=faireInscrireEtudiant(
              $groupeRef,
              $nom,
              $prenom,
              $tel,
              $mail,
              $et_entrCle,
              $tuteurRef,
              $motsCles,
              $_SESSION[REF_YEAR],
              $et_entrCle."_siege",
              "__sans referent___".str_upper($et_entrCle)
            );

            echo $res;
          }
          echo "</td></tr>";
        }
        echo "</table>";
        die();
      }
      ?>
          <form id="inscrireEtudiants" enctype="multipart/form-data"
                action="<?php echo ABS_START_URL;?>/index.php"  method="POST"/>
          <input type="hidden" name="page" value="interface/inscrireEtudiants_act">

          <?php
            $keysValues=constructGrantedGroupesKeys();
            $keys=$keysValues["keys"];
            $values=$keysValues["values"];
            $conn=doConnection();
            $groupes=getGroupesArrayPourFormationsLike($conn,$keys[0]);
          ?>

           <p>Le fichier d'importation (.csv) doit comporter les colonnes suivantes séparées par des <b>";"</b>. <br/>
             Vous pouvez téléchager un exemple <a href="../files/etudiants.csv">ici</a> </p>
           <table style="margin-left:40px; font-size:9pt" border="1">
             <tr><td>colonne 1</td><td>nom</td></tr>
             <tr><td>colonne 2</td><td>prenom</td></tr>
             <tr><td>colonne 3</td><td>statut (FI, FA ou FC)</td></tr>
             <tr><td>colonne 4</td><td>email</td></tr>
             <tr><td>colonne 5</td><td>entreprise (ignorée pour l'instant) </td></tr>
             <tr><td>colonne 6</td><td>ville (ignorée pour l'instant) </td></tr>
             <tr><td>colonne 7</td><td>groupe (<?php echo implode($groupes,",") ; ?>)</td></tr>
             <tr><td>colonne 8</td><td>mots cles décrivant la mission</td></tr>
           </table><br/>
             Choisissez le fichier :
                  <input type="file" name="fichier" size="40"/><br/>
             <p style="margin-left:40px"><input type="submit" name="uploaded" style="color:orange" value="Inscrire"/></p>
             
        </form>

    </div>
</div>
