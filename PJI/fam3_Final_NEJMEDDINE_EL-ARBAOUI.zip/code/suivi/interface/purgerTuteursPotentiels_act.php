<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
?>
<div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 1 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Etat de la table temporaire</a></div>


<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
<!-- FIN MENU -->
  <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
        <?php
            require_once(ABS_START_PATH."/dbmngt/connect.php");
            require_once(ABS_START_PATH."/dbmngt/queries.php");

            
            $conn=doConnection();
            $forms=getParam("formation");
            //$results = doQueryListAlternancesAvecTuteurEnTableTemp($conn);
            $results = doQueryListAlternancesAvecTuteurEnTableTempParFormation($conn,$forms);
            if (mysql_num_rows($results)==0)
            {
                echo "Aucune purge est nécessaire!<br/>";
                //echo "<a href='attributionTuteurs.php'>Revenir à la page d'attribution de tuteurs!</a>";
                die();
            }
            $count=getCountEntreesTuteursPotentiels($conn);
            echo "Nombre d'entrées dans la table de tuteurs potentiels avant netoyage : ",$count;

            

            echo "<h3>Etudiants affectés</h3>";
            echo "<ul>";
            for ($row=mysql_fetch_row($results);$row;$row=mysql_fetch_row($results))
            {
                if (doDeleteTuteursPotentielsPourEtudiant($conn,$row[0]))
                    echo "<li>Tuteurs potentiels pour <b>",$row[1]," ",$row[2],"</b> purgés!</li>";
            }
            echo "</ul>";

            $count=getCountEntreesTuteursPotentiels($conn);
            echo "Nombre d'entrées dans la table de tuteurs potentiels après netoyage : ",$count;
       ?>
         <?php
            regenerateAllTuteursChoixRss();
        ?>
        </div>
  </div>