
<?php

    require_once(ABS_START_PATH."/secure/auth.php");
    
    if (!hasRole(SECR_ROLE))
        redirectAuth(null);


        require_once(ABS_START_PATH."/dbmngtPDO/connectPDO.php");
        require_once(ABS_START_PATH."/dbmngtPDO/queriesPDO.php");
        require_once(ABS_START_PATH."/html/utils.php");
        require_once(ABS_START_PATH."/html/dbutils.php");
 		
 		$selectString = generateSelectOption(
            array("aucune","majEtudiantSecr_act","desactiverEtudSecr_act","supprimerEtud_act","migrerEtud_act"),
                    array("aucune","Maj fiche étudiant","Desactiver etudiant","Supprimer etudiant et son historique",
                    		"Migrer/Changer formation étud."),0);

        $formation=getParam("formation","%");
        $_SESSION["formation"]=$formation;
        
 
        

        $bdd=doConnectionPDO("stalt2");
		?>

		<SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
        <script type="text/javascript">
		<!--
		var dernierItem = 5 ;
		-->
		</script>
		<script type="text/javascript">
		<!--
		  document.getElementById("item_"+0).className = 'menuitem2-current';
		-->
		</script>
       <div id="contenu">
       	<div class="menuitem2" id="item_0">
       	<a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/inscrireEtudiant_act">Inscrire etudiant</a> |
       	<a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/listeEtudiantsParFormationParSecr_act">Liste des etudiants actifs </a>
		| <a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/listeEtudiantsParFormationParSecrInnactifs_act">Liste des etudiants innactifs</a>

		
		</div>
        <div id="cadre_0" class="contenu-item2 on">
         
            <?php

					echo "<br/>";
					
                 $keysValues=constructGrantedGroupesKeys();             
            	 $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation : ");
				 $resultat=doQuerieListEtudiantParFormation($bdd,$formation,$_SESSION[CK_USER]);
				    
				 	   ?>
		            <form action="<?php echo ABS_START_URL;?>/index.php" method="post" id="actionForm">
		            <input type="hidden" name="page" value="interface/faireActionsEtudiantsSecr_act"/>
		            <?php
				    $i = 0;
            		$divs = "'head'";
            ?>

            
            <a onClick="javascript:checkAll('actionForm','selection[]',true);"><font style="color:blue; text-decoration:underline;">Tous</font></a>
            <a onClick="javascript:checkAll('actionForm','selection[]',false);"><font style="color:blue; text-decoration:underline;">Aucun</font></a>
			<?php
			//Now that we've created such a nice heading for our html table, lets create a heading for our csv table
			$csv_hdr = "Nom; Prenom; Email; Ville; Entreprise";
			//Quickly create a variable for our output that'll go into the CSV file (we'll make it blank to start).
			$csv_output="";
			?>
     <table id="tableau_triable" class="tablesorter" border="0" cellpadding="1" cellspacing="1">
		<thead>
			<tr>
				<th></th>
				<th>Nom</th>
				<th>Prenom</th>
				<th>Mail</th> 
				<th>Ville</th>  
				<th>Entreprise</th> 
				 <th width="200pt">Actions<div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">details</a--></th> 
			</tr>
		</thead>
		<tbody><?php 

					while ($donnees = $resultat->fetch())
			{ 
				//if (strlen($donnees['mail'])>0) {$mail= $donnees['mail'];} else{ $mail= "_";}
				echo "
				<tr>
					<td><input type='checkbox' id=\"chbox_$i\" name='selection[]' value='".$donnees['cleAlt']. "' /> </td>
					<td>".$donnees['nom_etud']."</td>
					<td>".$donnees['nom_prenom']."</td>
					<td>".$donnees['mailEtud']."</td> 
					<td>".$donnees['ville']."</td>  
					<td>".$donnees['entreprise']."</td>  
					<td><select name=\"a_".str_replace('.', '_', $donnees['cleAlt']) ."\" 
					 onChange=\"javascript:checkAll('actionForm','selection[]',false);
                                          getElt('chbox_" . $i . "').checked=true;
                                          submit();\">".$selectString."</select></td>
				</tr>";
				  $i = $i + 1;
				  $csv_output .= $donnees['nom_etud'] . ";" . $donnees['nom_prenom'] . ";" . $donnees['mailEtud']. ";" .$donnees['ville']. ";" . $donnees['entreprise'] . "\n";
				  

			}

 		
			$resultat->closeCursor(); // Termine le traitement de la requête
		?>
		</tbody>
	</table>
	<a onClick="javascript:checkAll('actionForm','selection[]',true);"><font style="color:blue; text-decoration:underline;">Tous</font></a>
    <a onClick="javascript:checkAll('actionForm','selection[]',false);"><font style="color:blue; text-decoration:underline;">Aucun</font></a>
    <br/>
       <?php
            echo "<select name='action'>";
            echo $selectString;
            echo "</select>";


            ?>
            <input type="submit" value="Effectuer actions"/>
            </form>

            <form action="<?php echo ABS_START_URL;?>/actions/export_csv.php" method="post" >
		    <input type="submit" value="Export table to CSV">
		    <input type="hidden" value="<? echo $csv_hdr; ?>" name="csv_hdr">
		    <input type="hidden" value="<? echo $csv_output; ?>" name="csv_output">
</form>
</div>
</div>
