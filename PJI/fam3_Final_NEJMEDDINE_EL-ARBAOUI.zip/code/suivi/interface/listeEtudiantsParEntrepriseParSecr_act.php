<?php

    require_once(ABS_START_PATH."/secure/auth.php");
    
    if (!hasRole(SECR_ROLE))
        redirectAuth(null);

        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/dbmngt/queries.php");
	
        require_once(ABS_START_PATH."/dbmngtPDO/connectPDO.php");
        require_once(ABS_START_PATH."/dbmngtPDO/queriesPDO.php");

        require_once(ABS_START_PATH."/html/utils.php");
        require_once(ABS_START_PATH."/html/dbutils.php");

        $formation=getParam("formation","%");
        $tuteurParam=getParam("tuteurParam","%");

        $_SESSION["tuteurParam"]=$tuteurParam;
        
        $_SESSION["formation"]=$formation;
        
        $bdd=doConnectionPDO("stalt2");

        $conn=doConnection();

?>

        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
    <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 5 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Tableau de situation des étudiants</a></div>
<div class="menuitem2" id="item_1"><a href="#" onclick="changeClass(this)">Emails tuteurs Lille 1</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

</div>        
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>

       		<?php

		     $keysValues=constructGrantedGroupesKeys();             
			 $formation=createSelectFormKeyValuesAndTargetPage("formForm","formation",$keysValues,$formation,getParam("page"),"Choisissez la formation :&nbsp; &nbsp; &nbsp; ");
		?>

         	<form id="gestionbureau" method="post" action="<?php echo ABS_START_URL;?>/index.php">
		  <input type="hidden" name="page" value="interface/listeEtudiantsParEntrepriseParSecr_act"/>
		   <?php
		   $entr=$_REQUEST["entr"];
		   $conn=doConnection();
		   echo " Choisissez une entreprise  : ";
		   createEntrepriseSelect($conn,"entr", $entr,"submit();");

        
		   ?>
		</form>
         
        

        <?php
            $i=0;
            $divs="'head'";
            $entreprise = getParam("entr", "");
            $bureaux=doQueryListBureau($conn, $entreprise);
      	 
			
	   while ($bureau=mysql_fetch_row($bureaux)) 
            {
			  $etudiants=doQuerieListEtudiantParEntreprise($bdd,$bureau[0],$formation,$_SESSION[CK_USER]);
	    
			echo "<h3>".$bureau[0]."</h3>";    
	 
 
			echo "<form  method='post' action='".ABS_START_URL."/index.php'>
					      <input type='hidden' name='page' value='interface/modifAdresseEntreprise_act'/>
					      <input type='hidden' value='".$bureau[0]."' name='lebureau'>
					      <input type='submit' name='modifier' value='Modifier l adresse de ce bureau'/></form></td>
			</form>";

			$outputString="<table id='tableau_triable' class='tablesorter' border='0' cellpadding='1' cellspacing='1'>
					<thead>
							<tr>
						
								<th>Adresse</th>  
								<th>code postal</th>
								<th>Nom Etudiant</th>
								<th>Prenom Etudiant</th>
							  	<th>Mail Etudiant</th>
							</tr>
						</thead>
					<tbody>";

		 while ($donnees = $etudiants->fetch())
			{ 
				 $outputString.="<tr>
					<td>".$donnees['adresse']."</td>  
					<td>".$donnees['codePostal']."</td>
					<td>".$donnees['nom_etud']."</td>
					<td>".$donnees['nom_prenom']."</td>
					<td>".$donnees['mail_etud']."</td>
				</tr>";
			}

	
		$etudiants->closeCursor(); // Termine le traitement de la requête

                   
               $outputString.= " </tbody>
		         </table>";

             	 echo $outputString; 
             }

            
          
        ?>
                
        </div>

      </div>

<script type="text/javascript">

</script>

