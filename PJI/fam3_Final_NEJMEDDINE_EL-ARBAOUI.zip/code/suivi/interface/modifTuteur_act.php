<?php
// Auteur VIJ
require_once(ABS_START_PATH."/secure/auth.php");


    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
require_once(ABS_START_PATH."/dbmngt/queries.php");
require_once(ABS_START_PATH."/html/utils.php");
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/html/dbutils.php");
?>

<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Accès aux pages d'administration</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />




    </head>
    <body>
    
<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">


<br/><br/>	

 <?php



 $tuteurNom = getParam("tuteurNom", "");
 $tuteurPrenom = getParam("tuteurPrenom", "");
 $conn = doConnection();
 $res = doQueryAvoirLeTuteur($conn, $tuteurNom, $tuteurPrenom);
   
     
   
       while ( $tuteur = mysql_fetch_row($res)) {
               echo "<form  method='post' action=".ABS_START_URL."/index.php >
                     <input type='hidden' name='page' value='interface/gestionTuteurs_act'/>
                     <input type='hidden' value='1' name='modifierTut'>
                      <table witdh='500'>
                      <tr>
                      <td width='250'>
                      Clé du Prof : </td><td><input type='text' name='profCle' value='".$tuteur[0]."'/>
                      </td></tr><tr><td>
                      Nom : </td><td><input type='text' name='nom' value='".$tuteur[1]."'/>
                      </td></tr><tr><td>
                      Prenom : </td><td><input type='text' name='prenom' value='".$tuteur[2]."'/>
                      </td></tr><tr><td>
                      Tel : </td><td><input type='text' name='tel' value='".$tuteur[3]."'/>
                      </td></tr><tr><td>
                      Mail : </td><td><input type='text' name='mail' value='".$tuteur[4]."'/>
                      </td></tr><tr><td>
                      Année Référence : </td><td><input type='text' name='anneeReference' value='".$tuteur[5]."'/>
                      </td></tr><tr><td>
                      Bureau  : </td><td><input type='text' name='bureau' value='".$tuteur[6]."'/>
                      </td></tr><tr><td>
                       </br>
                      <tr><td colspan='2' align='center'><input type='submit' style='color:orange'  name = 'modifier' value='Modifier' onclick=\"return confirm('Etes-vous sur de modifier ces informations ?')\"/> </td>
                  </form>

                  <form  method='post' action=".ABS_START_URL."/index.php >
                  <input type='hidden' name='page' value='interface/gestionTuteurs_act'/>
                  <td colspan='2' align='center'><input type='submit' style='color:orange'  value=' Précédent '/></td></tr>
                     </table>  </form>";



       }
      
 
 // Ajout d'un petit formulaire permettant de ressaisir les informations relatives au référents
 

?>
</div>
</div>
</body>
</html>
