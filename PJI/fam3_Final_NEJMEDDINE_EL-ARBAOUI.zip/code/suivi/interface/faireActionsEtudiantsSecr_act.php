<?php
    require_once ABS_START_PATH.'/secure/auth.php';
    require_once(ABS_START_PATH."/log/log.php");

    if (!hasRole(SECR_ROLE))
        redirectAuth(null);
?>

    <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 1 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Etat de l'opération</a></div>
<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
<!-- FIN MENU -->
<div id="contenu">
        

       
        <?php

            $action=$_REQUEST["action"];
 			
            error_log("action : ".$action);
            
            if ($action=="aucune") {
              
              $altCle=$_REQUEST["selection"][0];
              $action=$_REQUEST["a_".str_replace('.','_',$altCle)];
 
            }

            action_log($_SESSION[CK_ROLES],$_SESSION[CK_USER],$action,$_REQUEST["selection"]);

            error_log("action : ".$action);
            $selection=$_REQUEST[	"selection"];
            require_once(ABS_START_PATH."/actions/".$action.".php");
            
            

        ?>
      
        
        
</div>
