<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queries.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/dbutils.php");
      require_once (ABS_START_PATH."/dbmngt/inscrire.php");

      $conn=doConnection();

      $formation=getParam("formation","L3MIAGEFA");

      $_SESSION["formation"]=$formation;

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0">
  <a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/inscrireTuteur_act">Inscrire un tuteur universitaire</a> 
   | <a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/gestionTuteurs_act">Liste des tuteurs universitaires actifs</a>
   | <a href="<?php echo ABS_START_URL; ?>/index.php?page=interface/gestionTuteursInactifs_act">Liste des tuteurs universitaires Inactifs</a>
</div>


<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>

  <SCRIPT src='<?php echo ABS_START_URL; ?>/ajax/inscrireEntreprise_modal.js' lang='javascript'></SCRIPT>
  <script type='text/javascript'>generateInscrireEntrepriseForm();</script>

  <SCRIPT src='<?php echo ABS_START_URL; ?>/ajax/inscrireBureau_modal.js' lang='javascript'></SCRIPT>
  <script type='text/javascript'>generateInscrireBureauForm();</script>

  <SCRIPT src='<?php echo ABS_START_URL; ?>/ajax/inscrireReferent_modal.js' lang='javascript'></SCRIPT>
  <script type='text/javascript'>generateInscrireReferentForm();</script>

<?php
         $inscription = trim(getParam("inscription", null));

         if($inscription==1){

        $prenom = trim(getParam("fa_tuteur_prenom", null));
        $nom = trim(strtoupper(getParam("fa_tuteur_nom", null)));
        $mail = trim(getParam("fa_tuteur_mail", null));
        $tel = trim(getParam("fa_tuteur_tel", null));
        $profCle = trim(getParam("fa_tuteur_profCle", null));
        $bureau=trim(getParam("fa_tuteur_bureau", null));

            if ($prenom == null && $nom == null){
                 die("<h2>Problème</h2>Vous devez renseigner le nom, le prenom  de tuteur! <br/> 
                   <a href=".ABS_START_URL."/index.php?page=interface/gestionTuteurs_act>Revenir</a>
                 "); 
            }
            
        $res = faireInscrireTuteur($nom, $prenom, $tel, $mail, $profCle,$bureau, $_SESSION[REF_YEAR]);

                if($res ){ ?>
                              <script type="text/javascript">
                             window.alert(" L'inscription est faite avec succes ");
                            </script>
                        <?php }else{ ?>
                           <script type="text/javascript">
                             window.alert(" erreur : Impossible d'inscrire ce tuteur  ");
                            </script>

                       <?php }
            }
?>
</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>

        <?php
          if (getCurrYear()>$_SESSION[REF_YEAR]) {
            die("<b>Impossible d'inscrire des tuteurs pour l'année ".$_SESSION[REF_YEAR]." !</b> </div></div>");
          }
        ?>
        <form id="form0" method="post" action="<?php echo ABS_START_URL; ?>/index.php" >
          <input type="hidden" name="page" value="interface/inscrireTuteur_act"/>
          <input type="hidden" name="inscription" value="1"/>
            
            <h1>Inscription pour l'année : <?php echo $_SESSION[REF_YEAR]; ?></h1>
            <table witdh="500">
              

                <tr>
                    <td width="250">
                        Nom : </td><td><input type="text" name="fa_tuteur_nom" value=""/>
                    </td></tr><tr><td>
                        Prenom : </td><td><input type="text" name="fa_tuteur_prenom" value=""/>
                    </td></tr><tr><td>
                        Email :</td><td><input type="text" name="fa_tuteur_mail" value=""/>
                    </td></tr><tr><td>
                        Téléphone :</td><td><input type="text" name="fa_tuteur_tel" value=""/>
                    </td></tr>
       
                <tr><td>
                        Bureau :</td><td><input type="text" name="fa_tuteur_bureau" value=""/>
                    </td></tr>
                <tr><td>
                        profCle :</td><td><input type="text" name="fa_tuteur_profCle" value=""/>
                    </td></tr>
        
                  <tr><td colspan="2" align="center"><input type="submit" style="color:orange" value="Inscrire"/></td>
            
        </form>

                 <form  method='post' action= "<?php echo ABS_START_URL; ?>/index.php" >
                  <input type='hidden' name='page' value='interface/gestionTuteurs_act'/>
                  <td colspan='2' align='center'><input type='submit' style='color:orange'  value=' Précédent '/></td></tr>
                     </table>  </form>

      
            
          
        </div>

</div>
<script type="text/javascript">choix(form0)</script>