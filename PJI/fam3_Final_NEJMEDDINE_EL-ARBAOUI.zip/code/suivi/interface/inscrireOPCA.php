<?php
    require_once '../secure/auth.php';

    //error_log("accueilTuteur for ".getParam(CK_USER,"UNKOWNN"));

    if (!hasRole(PROF_ROLE) && !hasRole(STUD_ROLE))
        redirectAuth(null);


    require_once '../html/utils.php';
    require_once '../dbmngt/inscrire.php';

?>
<html>
     <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Nouvelle OPCA</title>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <form id="inscrireOPCA" action="inscrireOPCA.php" method="POST">
          <h2>Inscrire une nouvelle OPCA</h2>
            <table witdh="500">

        <?php
          //error_log("retrieving vars!");
          
          $inscrire=getParam("inscrire","");
          $fa_opca_nom=getParam("fa_opca_nom","");
          $fa_opca_url=getParam("fa_opca_url","");
          $fa_opca_representant=getParam("fa_opca_representant","");
          $fa_opca_mail=getParam("fa_opca_mail","");
          $fa_opca_tel=getParam("fa_opca_tel","");
          $fa_opca_annees=getParam("fa_opca_annees","1");
          $fa_opca_commentaires=getParam("fa_opca_commentaires","");
          if (strlen($inscrire)>0) 
          {
              $err_msg=faireInscrireOPCA(
                $fa_opca_nom,
                $fa_opca_url,
                $fa_opca_representant,
                $fa_opca_mail,
                $fa_opca_tel,
                $fa_opca_annees,
                $fa_opca_commentaires);
              if (strlen($err_msg)) {
                echo "<h4 style='color:red'>$err_msg</h4>";
              } else {
                echo "$fa_opca_nom inscrite avec succes!<br/>";
                echo "<a href='javascript:history.go(-2);'>Retour</a>";
                exit();
              }
          }
          
          
        ?>
                <tr>
                    <td width="250">
            OPCA : </td><td><input type="text" name="fa_opca_nom" value="<?php echo $fa_opca_nom;?>"/>
                    </td></tr><tr><td>
            Point de contact : </td><td><input type="text" name="fa_opca_representant" value="<?php echo $fa_opca_representant;?>"/>
            </td></tr><tr><td>
                        Mail :</td><td><input type="text" name="fa_opca_mail" value="<?php echo $fa_opca_mail;?>"/>
            </td></tr><tr><td>
                        Téléphone :</td><td><input type="text" name="fa_opca_tel" value="<?php echo $fa_opca_tel;?>"/>
            </td></tr><tr><td>
                        URL :</td><td><input type="text" name="fa_opca_url" value="<?php echo $fa_opca_url;?>"/>
                </td>
                </tr>
            <tr><td>
                        Années financées :</td><td><input type="text" name="fa_opca_annees" value="<?php echo $fa_opca_annees;?>"/>
            </td></tr>
            <tr><td colspan="2">
                        Commentaires :<br/><textarea cols="50" rows="5" type="text" name="fa_opca_commentaires"><?php echo $fa_opca_commentaires;?></textarea>
            </td></tr>
                <tr><td colspan="2" align="center"><input type="submit" style="color:orange" name="inscrire" value="Inscrire"/></td></tr>
            </table>

        </form>

    </body>
</html>