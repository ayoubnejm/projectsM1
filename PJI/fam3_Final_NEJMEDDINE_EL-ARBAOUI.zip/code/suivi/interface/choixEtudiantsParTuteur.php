<?php
require_once(ABS_START_PATH."/secure/auth.php");

if (!hasRole(PROF_ROLE))
    redirectAuth(null);
?>
<?php
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/dbmngt/queriesTuteur.php");
require_once(ABS_START_PATH."/html/utils.php");
//Ajout JTA 
require_once(ABS_START_PATH."/distance/calculDistance.php");
// Fin ajout 

$formation = getParam("formation", "%");
$_SESSION["formation"] = $formation;

$tuteurParam = getParam(CK_USER, $_SESSION[CK_USER]);
$_SESSION["tuteurParam"] = $tuteurParam;


$conn = doConnection();
?>
<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Choix d'encadrement en attente</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
    </head>
    <body>
        <h1>Vos étudiants</h1>


        <form id="formationForm" action="listeEtudiantsParTuteur.php" method="POST">

            <?php
            $formations = doTuteurQueryChoosedFormations($conn, $tuteurParam);
            if (!mysql_num_rows($formations)) {
                echo "</form><br/>Pour l'instant vous n'avez demandé de suivre d'étudiant!";
                exit(1);
            }

            $keys = Array();
            $values = Array();

            for ($k = 0, $formation = mysql_fetch_row($formations); $formation; $formation = mysql_fetch_row($formations), $k = $k + 1) {
                //echo "processing ".$formation[1]." ".$formation[0]."<br/>";
                $keys[$k] = $formation[1];
                $values[$k] = $formation[0];
                //echo "processing ".$keys[$k]." ".$values[$k]."<br/>";
            }

            $i = 0;
            for (; ($i < count($keys)) AND ($keys[$i] !== $formation); $i++)
                ;
            if ($i == count($keys)) {
                $i = 0;
                $formation = $keys[$i];
            }

            echo "Choisissez la formation : ";
            createSelectWithOnChange("formation", $keys, $values, $i, "javascript:submit();");
            ?>
        </form>

        <?php
        $i = 0;
        $divs = "'head'";

        $etudiants = doTuteurQueryListChoices($conn, $tuteurParam);

        if (!mysql_num_rows($etudiants)) {
            echo "<h4 style='color:red'>Aucun étudiant</h4>";
            $tuteur = mysql_fetch_row($tuteurs2);
        }
        if (!mysql_num_rows($etudiants))
            die();
        ?>

        <table border="1">
            <thead><tr>
                    <td>Nom</td>
                    <td>Prenom</td>
                    <td>Formation</td>
                    <td>Ville/Kilométrage</td>
                    <td>Entreprise</td>
                    <td><div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">details</a--></td>
                </tr>
            </thead>
            <tbody>
                <?php
                $Distance = new calculDistance();
                $row = mysql_fetch_row($etudiants);
                while ($row) {
                    //if ($row[16]===NULL)
                    echo "<tr>";
//                        else
//                            echo "<tr style='color:yellow'>";
//                      
                    echo "<td>", $row[1], " </td>";
                    echo "<td>", $row[2], " </td>";

                    echo "<td>", $row[3], " </td>";
                    if ($row[4]) {
                        echo "<td>", $row[4], "/", $row[6], "Km"
                        , "<a href='" . $Distance->getLien($row[7] . " " . $row[8] . " " . $row[4]) . "' target='_blank'>Itineraire</a ></td>";
                        echo "<td>", $row[5], "</td>";
                    }                    
                    echo "<td><form name='form", $i, "' action='../actions/faireSupprimerChoix.php' method='post'>";
                    echo "<input type='hidden' name='altCle' value='", $row[0], "'/>";
                    echo "<input type='hidden' name='tuteurRef' value='", $tuteurParam, "'/>";
                    echo "<input type='submit' value='Retirer'/>";
                    echo "</form></td>";
                    echo "</tr>";
                    $row = mysql_fetch_row($etudiants);
                    $i = $i + 1;
                }
                ?>
            </tbody>
        </table>

        <br/>


        <script type="text/javascript">
<?php
echo "layer = new Array(", $divs, ");";
echo "doModalAll(layer);";
//echo "closeAll()";
?>
        </script>
    </body>
</html>
