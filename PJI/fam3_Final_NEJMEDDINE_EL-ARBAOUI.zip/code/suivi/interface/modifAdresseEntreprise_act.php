<?php
// Auteur VIJ
require_once(ABS_START_PATH."/secure/auth.php");

 
        require_once(ABS_START_PATH."/dbmngtPDO/connectPDO.php");
        require_once(ABS_START_PATH."/dbmngtPDO/queriesPDO.php");
        require_once(ABS_START_PATH."/html/utils.php");
        require_once(ABS_START_PATH."/html/dbutils.php");


        $bdd=doConnectionPDO("stalt2");
?>

<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Accès aux pages d'administration</title>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
    
<div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">
		

<br/><br/>	

 <?php
 
  // partie relative a la modification de l'adresse de l'entreprise

 

            $modificationEntreprise = getParam("modifierEntreprise", "");

            if($modificationEntreprise==1){
  
 
                           $lebureau=getParam("lebureau", "");
                           $adresse = getParam("adresse", "");
                           $ville = getParam("ville", "");
                           $codePostal=getParam("codePostal", "");
                           $conn = doConnection();
                           $res= doQueryUpdateAdresseBureau($bdd , $lebureau,$adresse,  $ville, $codePostal ); 

                        if($res){ ?>
                           <script type="text/javascript">
                                 window.alert(" Modification avec succes. ");
                           </script>
                        <?php }else{ ?>
                           <script type="text/javascript">
                                  window.alert(" erreur : Impossible de modifier les informations de ce référent  ");
                           </script>

                       <?php }

            }


 
 // Ajout d'un petit formulaire permettant de ressaisir l'adresse
 
 $bureau = getParam("lebureau", "");

 $resultat= doQueryAvoirInfoDuBureau($bdd, $bureau );


       while ( $donnees = $resultat->fetch() ) {
   
       echo "<form  method = 'post' action=".ABS_START_URL."/index.php >
              <INPUT type='hidden' value='interface/modifAdresseEntreprise_act' name='page'>
             <INPUT type='hidden' value='1' name='modifierEntreprise'>
 
             <INPUT type='hidden' value='".$bureau."' name='lebureau'>

              <table witdh='400'>
                <tr>
                <td width='180'>
               Nom du bureau :</td><td>".$donnees['bureauCle']."<br/>
                          </td></tr>
		<tr><td>
               Adresse :</td><td><INPUT type=text name='adresse' value='".$donnees['adresse']."'><br/>
                          </td></tr><tr><td>
               Ville :    </td><td><INPUT type=text name='ville' value='".$donnees['ville']."'><br/>
                          </td></tr><tr><td>
               Code postal :</td><td><INPUT type=text name='codePostal' value='".$donnees['codePostal']."'><br/>
                          </td></tr><tr><td>
                          </td></tr><tr>
                            <td><INPUT type=submit value='Modifier' style='color:orange' onclick=\"return confirm('Etes-vous sur de modifier ces informations ?')\" /></td>
           
               </form>

                <form  method='post' action=".ABS_START_URL."/index.php >
               <input type='hidden' name='page' value='interface/listeEtudiantsParEntrepriseParSecr_act'/>
               <td colspan='2' align='center'><input type='submit' style='color:orange'  value=' Précédent '/></td></tr>
               </table>  </form>";
       }
      

?>
</div>
</div>
</body>
</html>
