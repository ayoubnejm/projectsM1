  <?php
require '../secure/auth.php';
require_once(ABS_START_PATH."/log/log.php");

if (!hasRole(RESP_ROLE) && !hasRole(PROF_ROLE))
    redirectAuth(null);
?>

<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Action</title>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
        <!--SCRIPT src='../ajax/inscrireReferent_modal.js' lang='javascript'></SCRIPT-->
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <?php
        /*
         * To change this template, choose Tools | Templates
         * and open the template in the editor.
         */
        ?>
        <!--h1>Etat de l'opération</h1-->


<?php
$action = $_REQUEST["action"];
//echo $action;
if ($action == "aucune") {
    //echo "CE MODE DE SELECTION D ACTIONS NE FONCTIONNE PAS ENCORE.<br/>
    //      COCHEZ LA CASE CORRESPONDANTE POUR L ETUDIANT ET PUIS CHOISISSEZ L ACTION EN BAS DE LA PAGE.";
    //die();
    $altCle = $_REQUEST["selection"][0];
    error_log("en action - altCle :  $altCle");

    $action = $_REQUEST["a_" . str_replace('.', '_', $altCle)];
     $keys=array_keys($_REQUEST);
      for ($i=0;$i<count($keys);$i++)
      error_log("en action - keys, values : ".$keys[$i]." - ".$_REQUEST[$keys[$i]]);
    error_log("en action - action et altcle :  $action - $altCle);

     
}
//echo ($action);
// Provisoir a mettre dans les actions ^^ JTA
/*if ($action == "genererOrdreDeMission") {
    require_once (ABS_START_PATH."/phpToPDF/genererOrdreDeMission.php");
    faireAction($_REQUEST["selection"]);
} else {*/
    require_once(ABS_START_PATH."/actions/" . $action . ".php");
    action_log($_SESSION[CK_ROLES], $_SESSION[CK_USER], $_REQUEST["action"], $_REQUEST["selection"]);

    faireAction($_REQUEST["selection"]);
//}
?>
        <!--hr/><br/-->
        <p>

        </p>
    </body>


</html>
