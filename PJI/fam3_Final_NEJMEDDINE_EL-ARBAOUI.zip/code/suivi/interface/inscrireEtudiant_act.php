<?php
    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE) || !hasRole(SECR_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queries.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/dbutils.php");

      $conn=doConnection();

      $formation=getParam("formation","L3MIAGEFA");

      $_SESSION["formation"]=$formation;

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Inscrire Etudiant</a></div>
<div class="menuitem2" id="item_1"><a href="#" onclick="changeClass(this)">Migrer Etudiants</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>

  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
  <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>

  <SCRIPT src='<?php echo ABS_START_URL; ?>/ajax/inscrireEntreprise_modal.js' lang='javascript'></SCRIPT>
  <script type='text/javascript'>generateInscrireEntrepriseForm();</script>

  <SCRIPT src='<?php echo ABS_START_URL; ?>/ajax/inscrireBureau_modal.js' lang='javascript'></SCRIPT>
  <script type='text/javascript'>generateInscrireBureauForm();</script>

  <SCRIPT src='<?php echo ABS_START_URL; ?>/ajax/inscrireReferent_modal.js' lang='javascript'></SCRIPT>
  <script type='text/javascript'>generateInscrireReferentForm();</script>


</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>

        <?php
          if (getCurrYear()>$_SESSION[REF_YEAR]) {
            die("<b>Impossible d'inscrire d'étudiants pour l'année ".$_SESSION[REF_YEAR]." !</b> </div></div>");
          }
        ?>
        <form id="form0" action="<?php echo ABS_START_URL; ?>/index.php" method="GET">
            <h1>Inscription pour l'année : <?php echo $_SESSION[REF_YEAR]; ?></h1>
            <table witdh="500">
                <tr><td>Choisissez la formation :</td><td>
                        <?php
                        $keysValues = constructGrantedGroupesKeys(true);
                        $formation=createSelectKeyValuesOnChange("formation",$keysValues,$formation,"");
                        //$formation=createSelectFormKeyValuesAndTargetPageOnChange("formForm","formation",$keysValues,$formation,"","","","");
                        ?>
                    </td></tr>
                <tr><td>Choisissez le tuteur:</td><td valign="middle">
                        <?php
                        //echo "Tuteur en mémoire", $tuteurParam;
                        $tuteurs = doQueryListTuteurs($conn);
                        $tuteur = mysql_fetch_row($tuteurs);
                        $keysTut[0] = "aucun";
                        $valuesTut[0] = "Aucun";
                        $tuteurNo = 1;
                        $i = 0;
                        while ($tuteur) {
                            $keysTut[$tuteurNo] = $tuteur[0];
                            $valuesTut[$tuteurNo] = $tuteur[1] . " " . $tuteur[2];
                            
                            $tuteur = mysql_fetch_row($tuteurs);
                            $tuteurNo++;
                        }
                        $keysValuesTuteur=array("keys"=>$keysTut,"values"=>$valuesTut);
                        //$tuteurParam=createSelectFormKeyValuesAndTargetPageOnChange("tuteurForm","tuteurParam",$keysValuesTuteur,"__sans tuteur__","","","","");
                        $tuteurParam=createSelectKeyValuesOnChange("tuteurParam",$keysValuesTuteur,"aucun","");

                        ?></td></tr>

                <tr>
                    <td width="250">
                        Nom : </td><td><input type="text" name="fa_etudiant_nom" value=""/>
                    </td></tr><tr><td>
                        Prenom : </td><td><input type="text" name="fa_etudiant_prenom" value=""/>
                    </td></tr><tr><td>
                        Email :</td><td><input type="text" name="fa_etudiant_mail" value=""/>
                    </td></tr><tr><td>
                        Téléphone :</td><td><input type="text" name="fa_etudiant_tel" value=""/>
                    </td></tr>
                <tr>
                    <td>
                        Entreprise :
                    </td>
                    <td>
                        <! Ajout du 26/01/2012 JTA; Modifier le 06/02/2012 />
                        <?php
                        createEntrepriseSelect($conn, "fa_entreprise_cle", "", "choix(this.form)");
                        echo "<a href='#' onclick=\"inscrireEntreprise('form".$i."','entr')\"/><font size='-1'>nouvelle Entreprise</font></a>";
                        ?>
                    </td>
                </tr>
                <tr>
                    <td> 
                        Bureau : </td><td>
                        <?php
                        createBureauSelect($conn,"fa_bureau_cle","__sans entreprise__","__sans entreprise___siege","showCoords('fa_bureau_cle')");
                        echo " <a  href=\"#\" onclick=\"window.location=getSelectedItemBureau('form".$i."','entr')\"><font size='-1'>nouveau bureau</font></a>
                            <br/>";
                        ?>
                    </td>
                </tr>
                <tr>
                    <td> 
                        Referent : </td><td>
                        <?php
                        createReferentSelect($conn,"fa_referent_cle","__sans entreprise__","__sans referent_____SANS ENTREPRISE__","showCoords('fa_referent_cle')");
                        echo "<a  href=\"#\" onclick=\"inscrireReferent('form".$i."','entr',1)\"><font size='-1'>nouveau référent</font></a>";
                        echo "<br/>";
                        ?>
                        </td>
                </tr><tr><td>
                        Mots clés :</td><td><input type="text" name="fa_mots_cles" size="60" value=""/>
                    </td></tr>
                
                <tr><td colspan="2" align="center"><input type="submit" style="color:orange" value="Inscrire"/></td></tr>
            </table>
            <input type="hidden" name="page" value="interface/faireInscrireEtudiant_act"/>
            
        </form>
          Note : <b>Si l'étudiant est déjà inscrit en FI ou en FA pour l'année <?php echo $_SESSION[REF_YEAR]; ?>, l'ensemble des informations seront perdues </b><br/>
        </div>
        <div id="cadre_1" class="contenu-item2 off"><br/>
          <h1>Migrer étudiants</h1>
          <form id="migrationForm" method="post" action="<?php echo ABS_START_URL; ?>/index.php">

            Vous pouvez migrer les étudiants déjà inscrits en
          
          <input type='hidden' name="page" value="interface/faireActionsEtudiants_act"/>
          <input type='hidden' name="action" value="migrerEtud_act"/>
          <input type='hidden' name="selection[]" value="ACT_MIGRATION_ETUD"/>
          <?php
            $keysValues = constructGrantedGroupesKeys(true,true,'FA/FI');
            $formation=createSelectKeyValuesOnChange("formationSource",$keysValues,"","");
            echo " - ";
            $years=getAvailableYears();
            $refYear=$_SESSION[REF_YEAR];
            createSelectWithOnChange(
                  "anneeSource",
                  $years,
                  $years,
                  $CURR_YEAR-$refYear+1,
                  "");
         ?>
          vers des nouvelles formations
          <input type="submit" value="Migrer" style="color:orange"/>
          
        </form>
    </div>
</div>
<script type="text/javascript">choix(form0)</script>