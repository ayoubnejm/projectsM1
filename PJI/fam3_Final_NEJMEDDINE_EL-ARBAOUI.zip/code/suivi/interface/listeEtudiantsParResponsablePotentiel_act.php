<?php

    require_once(ABS_START_PATH."/secure/auth.php");

    if (!hasRole(RESP_ROLE))
        redirectAuth(null);

        require_once(ABS_START_PATH."/dbmngt/connect.php");
        require_once(ABS_START_PATH."/dbmngt/queries.php");
        require_once(ABS_START_PATH."/html/utils.php");
        require_once(ABS_START_PATH."/html/dbutils.php");

        $formation=getParam("formation","%");
        $tuteurParam=getParam("tuteurParam","%");

        $_SESSION["tuteurParam"]=$tuteurParam;

        $_SESSION["formation"]=$formation;


        $conn=doConnection();

?>

        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/common.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/modal.js" lang="javascript"></SCRIPT>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/form.js" lang="javascript"></SCRIPT>
    <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 5 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Tableau de situation des étudiants</a></div>
<div class="menuitem2" id="item_1"><a href="#" onclick="changeClass(this)">Emails tuteurs Lille 1</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>
            
         <?php 
               echo '<form id="tuteurForm" action="'.ABS_START_URL.'/index.php" method="POST">
                      <input type="hidden" name="page" value="interface/listeEtudiantsParResponsablePotentiel_act"/>
                    Tuteurs enregistrés :';
            
                    //echo "Tuteur en mémoire", $tuteurParam;
                    $tuteurs=doQueryListTuteurs($conn);
                    $tuteur=mysql_fetch_row($tuteurs);
                    $keysTut[0]="%";$valuesTut[0]="Tous";
                    $tuteurNo=1; $i=0;
                    while ($tuteur)
                    {
                        $keysTut[$tuteurNo]=$tuteur[0];
                        $valuesTut[$tuteurNo]=$tuteur[1]." ".$tuteur[2];
                        if (strcmp($tuteurParam,$tuteur[0])==0)
                            $i=$tuteurNo;
                        $tuteur=mysql_fetch_row($tuteurs);
                        $tuteurNo++;
                    }
                    createSelectWithOnChange("tuteurParam",$keysTut,$valuesTut,$i,"javascript:submit();");
            echo '<br/></form>';
         ?>

         <form id="formationForm" action="<?php  echo ABS_START_URL;?>/index.php" method="POST">
           <input type="hidden" name="page" value="interface/listeEtudiantsParResponsablePotentiel_act"/>
            Choisissez la formation :
            <?php
            $keysValues=constructGrantedGroupesKeys();
                           $keys=$keysValues["keys"];
                           $values=$keysValues["values"];
                           $i=0;
                           for (;($i<count($keys)) AND ($keys[$i]!==$formation);$i++);
                           if ($i==count($keys)) {
                               $i=0;
                               $formation=$keys[$i];
                           }

                           createSelectWithOnChange("formation",$keys,$values,$i,"javascript:submit();");
            ?>
        </form>

        <?php
            $i=0;
            $divs="'head'";
            
            $tuteurs2=doQueryListTuteursLike($conn,$tuteurParam);
            $aliasMailTuteurs="";
            
            $tuteur=mysql_fetch_row($tuteurs2);
            while ($tuteur) 
            {
                $etudiants=doQueryTuteursEtTuteursPotentielsParFormation($conn,$formation,$tuteur[2]);
                    if (!mysql_num_rows($etudiants))
                    {
                       //echo "<h4 style='color:red'>Aucun étudiant</h4>";
                       $tuteur=mysql_fetch_row($tuteurs2);
                    }
                    if (!mysql_num_rows($etudiants))
                        continue;
                    echo "<H2>".$tuteur[1]." ".$tuteur[0]."</H2>";
                    $aliasMailTuteurs.=",".$tuteur[3];
        ?>
            
        <table border="1">
                <thead><tr>
                        <td>Nom</td>
                        <td>Prenom</td>
                        <td>Formation</td>
                        <td>Ville</td>
                        <td>Entreprise</td>
                        <td><div id="head"><!--for backward comp--></div><!--a href="#" onClick="javascript:openAll(layer);">details</a--></td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    
                    
                    $row=mysql_fetch_row($etudiants);
                    while ($row)
                    {
                        //echo "fa_temp_tuteurs ".$row[16]."\n";
                        //if ($row[16]===NULL)
                            echo "<tr>";
//                        else
//                            echo "<tr style='color:yellow'>";
                        echo "<td>",$row[1],"</td>";
                        echo "<td>",$row[2],"</td>";
                        
                        echo "<td>",$row[3],"</td>";

                        echo "<td>",$row[4],"</td>";
                        echo "<td>",$row[7],"</td>";
                        
                        echo "<td>".$row[15]." <div id='td",$i,"'><a name=\"x",$i,"\"/>";
                        echo "<div style='top:30%;left:15%;width:60%;border:3px solid black;background-color:rgba(100,100,100,1);'>";
                        echo "<table border='1' bgcolor='#aaaaaa'>";
                        echo "<tr><td>Referent</td>","<td>",$row[5] ,"</td></tr>";
                        echo "<tr><td>Missions</td>","<td>",$row[8] ,"</td></tr>";
                        echo "<tr><td>Services</td>","<td>",$row[9] ,"</td></tr>";
                        echo "<tr><td>Clients</td>","<td>",$row[10] ,"</td></tr>";
                        echo "<tr><td>Envirnmnt Tech.</td>", "<td>",$row[11] ,"</td></tr>";
                        echo "</table><input type='button' value='Cacher' onClick='javascript:showHideModal(\"td",$i,"\");'/></div>";
                        echo "</div><a href='#",$i,"' onClick='javascript:showHideModal(\"td",$i,"\");'>détails</a></td>";           $divs=$divs.",'td".$i."'";
                        echo "</tr>";
                        $row=mysql_fetch_row($etudiants);
                        $i=$i+1;
                    }
                    $nbDivs=$i;
                    
                    ?>
                </tbody>
            </table>
            <?php
                $tuteur=mysql_fetch_row($tuteurs2);
                }
            ?>
                
            <br/>

            <?php
                echo "<H2>Mails tuteurs</H2>\n";
                echo substr($aliasMailTuteurs,1);
                echo "\n<br/>\n";

            ?>
         <script type="text/javascript">
<?php
echo "layer = new Array(",$divs,");";
echo "doModalAll(layer);";
//echo "closeAll()";
?>
            </script>
        </div>
        </div>
