<?php

       require_once(ABS_START_PATH."/secure/auth.php");

       if (!hasRole(STUD_ROLE))
            redirectAuth(null);

       require_once(ABS_START_PATH."/dbmngt/connect.php");
       require_once(ABS_START_PATH."/dbmngt/queriesEtud.php");

       
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<div class="contenu">
  <div id="cadre_0" class="contenu-item2 on">
      <?php
                $conn = doConnection();

                $student=$_SESSION[CK_USER];
                //$student="amand.dupretz";
                $altRef=doGetAltRefForStudent($conn,$student);
                $tuteur=doGetTuteurInfoForStudent($conn,$student);
                $formation=doGetFormationForStudent($conn,$student);
                $_SESSION[REF_FORMATIONTYPE]=substr($formation,strlen($formation)-2,2);
                $formationType=($_SESSION[REF_FORMATIONTYPE]=="FA")?"alternance":"stage"; 

      ?>
      <h1>Bienvenue <?php echo $student." (".$formation." - ".$_SESSION[REF_YEAR].")"; ?> !</h1>
      <?php
        if ($altRef==null) {
          die ("Vous êtes inscrit(e) dans aucune formation F.I.L. pour l'année ".$_SESSION[REF_YEAR].". Contactez votre responsable de formation!");
        }
      ?>
      <h2>Informations</h2>
      <ul>
          <li>Votre tuteur :
          <?php

                
                if ($tuteur===FALSE)
                    echo "Aucun tuteur ne vous a été assigné pour l'instant!";
                else
                    {
                        
                        echo "<a href='mailto:".$tuteur[2]."'>".$tuteur[1]." ".$tuteur[0]."</a>";
                    }
          ?>
          </li>
      </ul>
      <br/>
      <h2>Opérations</h2>
      <h3>
         <ul>
        <li>
              <form action="<?php echo ABS_START_URL."/index.php"; ?>" target="main" method="post">
                <input type="hidden" name="page" value="interface/faireActionsEtudiantsParEtud_act"/>
                <input type="hidden" name="selection[]" value="<?php echo $altRef?>"/>
                <!--input type="hidden" name="action" value="majInfoRensEtud_act"/-->
                <input type="hidden" name="action" value="majEtape0_act"/>
                <input type="submit" value="Mise à jour information <?php echo $formationType; ?>"/>
              </form>
        </li><li>
            <form action="<?php echo ABS_START_URL."/index.php"; ?>" target="main" method="post">
                <input type="hidden" name="page" value="interface/faireActionsEtudiantsParEtud_act"/>
                <input type="hidden" name="selection[]" value="<?php echo $altRef?>"/>
                <input type="hidden" name="action" value="majInfoMissionEtud_act"/>
                <input type="submit" value="Mise à jour mission <?php echo $formationType; ?>"/>
              </form>
        </li></ul>

      </h3>
      <h3>Livret <?php echo $formationType; ?></h3>
      <ul> 
        <li>
          <form action="<?php echo ABS_START_URL."/index.php"; ?>" target="main" method="post">
              <input type="hidden" name="page" value="interface/faireActionsEtudiantsParEtud_act"/>
              <input type="hidden" name="selection[]" value="<?php echo $altRef?>"/>
              <input type="hidden" name="action" value="majEtape1Etud_act"/>
              <input type="submit" value="Recontre avec tuteur"/>
          </form>
        </li>
        <li>
            <form action="<?php echo ABS_START_URL."/index.php"; ?>" target="main" method="post">
              <input type="hidden" name="page" value="interface/faireActionsEtudiantsParEtud_act"/>
              <input type="hidden" name="selection[]" value="<?php echo $altRef?>"/>
              <input type="hidden" name="action" value="majEtape2Etud_act"/>
              <input type="submit" value="Première visite en entreprise"/>
            </form>
        </li>
        <?php
          if (strcmp($formation,"M1MIAGEFA")!=0 && $formationType=="alternance")
            echo "<li>
                <form action=\"".ABS_START_URL."/index.php\" target=\"main\" method=\"post\">
                  <input type='hidden' name='page' value='interface/faireActionsEtudiantsParEtud_act'/>
                  <input type='hidden' name='selection[]' value='".$altRef."'/>
                    <input type='hidden' name='action' value='majEtapeMissionSoutenanceEtud_act'/>
                  <input type='submit' value='Sujet de la mission '/>
                </form>
            </li>";
        ?>
        <?php
          if ($formationType=="alternance") {
        ?>
        <li>
            <form action="<?php echo ABS_START_URL."/index.php"; ?>" target="main" method="post">
              <input type="hidden" name="page" value="interface/faireActionsEtudiantsParEtud_act"/>
              <input type="hidden" name="selection[]" value="<?php echo $altRef?>"/>
              <input type="hidden" name="action" value="majEtapeBilanEtud_act"/>
              <input type="submit" value="Deuxième visite en entreprise"/>
            </form>
        </li>
      </ul>

      <?php
        }
          if (strcmp($formation,"M1MIAGEFA")!=0) {
            echo "<h3>Rapport et soutenance</h3>
                  <ul>
                      <li><form action=\"".ABS_START_URL."/index.php\" target='main' method='post'>
                    <input type='hidden' name='page' value='interface/informationsSoutenanceEtRapport_act'/>

                    <input type='submit' value='Dates & consignes générales'/>
                  </form></li>
                  </ul>";
          }

          ?>

      <h3>
          <a href="<?php echo ABS_START_URL.'/disconnect.php';?>" target="_top" >Deconnexion</a>
      </h3>
  </div>
</div>
