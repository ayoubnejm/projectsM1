<?php
require_once(ABS_START_PATH."/secure/auth.php");
if (!hasRole(RESP_ROLE))
    redirectAuth(null);

require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/dbmngt/queries.php");
require_once(ABS_START_PATH."/dbmngt/queriesSout.php");
require_once(ABS_START_PATH."/html/utils.php");

$conn = doConnection();


$formation = getParam("formation","");
$_SESSION["formation"]=$formation;

if ($formation==FALSE) {
  die("Veuillez choisir une formation avant d'arriver sur cette page!");
}
?>

<div class="menuitem2" id="item_0">M.a.j. des informations concernant le rapport et la soutenance</a></div>

 <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on">


      
        <?php
       

            echo "<h2> " . $formation . " ( ".$_SESSION[REF_YEAR]." ) </h2>";
            $req = doQueryDetailsSoutenanceRapport($conn, $formation);
            if ($req) {
                $res = mysql_fetch_row($req);
            } else {
                $res = array();
            }
            echo "<form action='".ABS_START_URL."/index.php' method='post'>
              <input type='hidden' name='formation' value='".$formation."'/>\n".
              "<input type='hidden' name='page' value='interface/faireMajInformationsSoutenanceEtRapportParProf_act'/>\n
            
              <table style='font-size:9pt' width='95%'>
              ";
            
              
             
            
        echo "
        <tr>
          <td>
            <b>Date de remise du rapport</b>
          </td>
          <td><input type='text' name='dateRemise' value='".to_text($res[1])."' size='58'/>".
            "</td>
        </tr>

      <tr><td><b>Dates de soutenances</b></td><td><input type='text' name='datesSoutenance' value=\"".
            to_text($res[2]) . "\" size='58'/></td></tr>
      

      <tr><td><b>Longueur du rapport</b></td><td><input type='text' name='longueurRapport' value=\"". to_text($res[3]) . "\" size='58'/></td></tr>


      <tr><td><b>Durée de la soutenance</b></td><td><input type='text' name='dureeSoutenance' value=\"". to_text($res[4]) . "\" size='58'/></td></tr>
      
      <tr><td><b>Lien externe (à ce site)</b></td><td><input type='text' name='lienExterne' value=\"". to_text($res[7]) . "\" size='58'/></td></tr>

      <tr><td><b>Observations <br> (réservées aux étudiants)</b></td><td><textarea rows='3' name='obsEtuds' cols='50'>" . to_text($res[5]) . "</textarea></td></tr>
      <tr><td><b>Observations <br/> (réservées aux tuteurs uniquement)</b></td><td><textarea rows='3' name='obsTuteurs' cols='50'>" . to_text($res[6]) . "</textarea></td></tr>
      ";
     echo "<tr><td colspan='2' align='right'>
                <input type='submit' name='maj' value='Mettre à jour'/>\n
              
          </td></tr>";
    echo "</table></form>";
    echo "<br/><hr width='800pt' align='left'/><br/>";
           
        
        ?>

        </div>
 </div>
