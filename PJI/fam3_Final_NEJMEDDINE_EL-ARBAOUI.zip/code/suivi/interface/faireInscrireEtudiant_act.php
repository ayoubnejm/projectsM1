<?php
    require_once(ABS_START_PATH."/secure/auth.php");

     if (!hasRole(RESP_ROLE) || !hasRole(SECR_ROLE))
        redirectAuth(null);
?>
  <?php
      require_once(ABS_START_PATH."/dbmngt/connect.php");
      require_once(ABS_START_PATH."/dbmngt/queries.php");
      require_once(ABS_START_PATH."/html/utils.php");
      require_once(ABS_START_PATH."/html/dbutils.php");
      require_once(ABS_START_PATH."/dbmngt/inscrire.php");

      $conn=doConnection();

      $formation=getParam("formation","L3MIAGEFA");
      $tuteurRef = getParam("tuteurParam", null);
      if ($tuteurRef == "aucun")
            $tuteurRef = null;

      $_SESSION["formation"]=$formation;

      ?>
      <div class="menuinterne2">
<script type="text/javascript">
<!--
var dernierItem = 2 ;
-->
</script>
<div class="menuitem2" id="item_0"><a href="#" onclick="changeClass(this)">Inscrire Etudiant</a></div>

<script type="text/javascript">
<!--
  document.getElementById("item_"+0).className = 'menuitem2-current';
-->
</script>
</div>
        <div id="contenu">
        <div id="cadre_0" class="contenu-item2 on"><br/>

        <?php
        require_once (ABS_START_PATH."/dbmngt/connect.php");
        require_once (ABS_START_PATH."/dbmngt/inscrire.php");

        $prenom = trim(getParam("fa_etudiant_prenom", null));
        $nom = trim(strtoupper(getParam("fa_etudiant_nom", null)));
        $mail = trim(getParam("fa_etudiant_mail", null));
        $tel = trim(getParam("fa_etudiant_tel", null));
        $motsCles = trim(getParam("fa_mots_cles", null));

        $etudCle=trim(getParam("etudCle",null));
        $et_entrCle = trim(getParam("fa_entreprise_cle", null));

        //$ville = str_replace("'","\\'",getParam("fa_referent_ville",null));// A modifier car il faut prendre la ville du bureau

        $formation = trim(getParam("formation", null) . "1");

        

        if ($prenom != null && $nom != null && $formation != null){
            echo "<b>", $prenom, " ", $nom, "</b> <br/>";
        }else{
            die("<h2>Problème</h2>Vous devez renseigner le nom, le prenom et la formation de l'étudiant! <br/><a href='#' onclick='javascript:history.go(-1);'>Revenir</a>");}


        /*
         * Ajout JTA le 06/02/2012 recuperation du bureau de l'etudiant et du referent 
         */

        $bureau = getParam("fa_bureau_cle", '');
        $referent = getParam("fa_referent_cle",'');
		
        $res = faireInscrireEtudiant($formation, $nom, $prenom, $tel, $mail, $et_entrCle, $tuteurRef, $motsCles, $_SESSION[REF_YEAR], $bureau,$referent,$etudCle);

        echo $res;
        if (strcmp($res,"Echec")==0)
          echo "<b>Echec d'insertion de $nom $prenom en $formation pour l'année ".$_SESSION[REF_YEAR]."</b>";
        else if (strcmp($res,"En attente")==0)
            echo "<b>En attente</b>";
        else
            echo "<b>Insertion réussie de $nom $prenom en $formation pour l'année ".$_SESSION[REF_YEAR]."</b>";
               ?>
    </div>
</div>
