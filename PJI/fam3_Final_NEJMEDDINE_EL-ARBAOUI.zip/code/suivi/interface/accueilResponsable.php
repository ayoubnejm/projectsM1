<?php
    require '../secure/auth.php';
    //error_log("accueilTuteur for ".getParam(CK_USER,"UNKOWNN"));

    $CURR_YEAR=getCurrYear();
    $refYear=getParam(REF_YEAR,$CURR_YEAR);
    $_SESSION[REF_YEAR]=$refYear;

    $refFormationRef=getParam(REF_FORMATIONTYPE,"FA");
    $_SESSION[REF_FORMATIONTYPE]=$refFormationRef;

    checkAllRoles();
    
    if (!hasRole(RESP_ROLE))
        redirectAuth(null);

    
?>
<html>
     <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Responsables</title>
        <SCRIPT src="<?php echo ABS_START_URL; ?>/js/toogleDivs.js" lang="javascript"></SCRIPT>
        <link href="../styles/Css_autentification.css" rel="stylesheet" type="text/css" />
    </head>
    <frameset rows="60pt,*">
        <frame name="menu" src="menuResponsable.php"/>
        <frame name="main" src="welcomeResponsable.php"/>
    </frameset>
</html>