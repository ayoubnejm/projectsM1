<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once ABS_START_PATH."/ldap/updateStudUIDs.php";

updateAllUIDs();
//updateUID("m2miagefa1VS9","VELAY","Sébastien");

?>
