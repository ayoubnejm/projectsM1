<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once ABS_START_PATH."/secure/auth.php";

if (!hasRole(RESP_ROLE))
  die("Only for responsable persons here!");


require_once (ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/ldap/ldap.php");

function updateAllMails() {

  echo "<h1>Looking for students not having Lille 1 mails</h1>";
  $query="(select etudCle,mail,mailLille1 from etudiant
            where
                length(mailLille1)=0 or mailLille1 is null".
                //and etudCle not like concat(lower(groupeRef),'%')
          ")";

  //echo $query;
  $conn=doConnection();
  $result=mysql_query($query,$conn);

  $row=mysql_fetch_row($result);
  $connDept=doConnection("fil_dept");

  while ($row)
  {
    updateMailFor($row[0],$connDept);

    $row=mysql_fetch_row($result);


  }
}

function updateMailFor($uid,$conn)
{
  echo "Updating mail for : ".$uid;
    $mail=getEtudMail($uid);
    if ($mail) {
      $updateQuery="update etudiant set mailLille1='$mail' where etudCle='$uid'";
      mysql_query($updateQuery,$conn);
      $updateQuery="update etudiant set mail='$mail' where etudCle='$uid' and length(mail)=0";
      mysql_query($updateQuery,$conn);
      echo "<b style='color:green'> with address $mail done </b><br/>";
    } else {
      echo "<b style='color:red'>unable to retrieve address : check etudCle </b><br/>";
    }
}


?>
