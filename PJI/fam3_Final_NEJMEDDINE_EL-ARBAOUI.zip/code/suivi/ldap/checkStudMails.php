<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once (ABS_START_PATH."/dbmngt/connect.php");
require_once (ABS_START_PATH."/ldap/ldap.php");

echo "Mails having some problems : ";

//$query="(select mail from fa_etudiant)";
//$conn=doConnection();

$query="(select mail from etudiant)";
$conn=doConnection("fil_dept");
$result=mysql_query($query,$conn);

$row=mysql_fetch_row($result);

while ($row)
{ 
  if (!checkEtudMail($row[0]))
    echo $row[0]." Wrong address <br/>";

  $row=mysql_fetch_row($result);
    
}

?>
