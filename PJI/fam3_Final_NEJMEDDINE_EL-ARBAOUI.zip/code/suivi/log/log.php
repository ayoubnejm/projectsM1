<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
  function action_log($role,$user,$action,$subjects) {
      //$today=getdate();
      $logMessage="";
      $logMessage=
        "<a><time>".date(DATE_RFC822)."</time><user>".$user."</user><subject>".
          implode(";",count($subjects)>0?$subjects:array())."</subject></a>\n";
          
      $namelog=$action.".pxml";
      //if (file_exists("../xml/log_".$namelog)==TRUE) {
      $namelog=ABS_START_PATH."/xml/log_".$namelog;
      $flog=fopen($namelog,"a");

      if ($flog!=FALSE)
      {
        error_log("Logging to $namelog action : $logMessage");

        fprintf($flog,$logMessage);
        fclose($flog);
      }
      else
        error_log("Unable to log $namelog action : $logMessage");
      
      //echo "logging to ".$namelog."<br/>";
      
  }

?>

