<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once (ABS_START_PATH."/dbmngt/queries.php");
require_once (ABS_START_PATH."/html/utils.php");

function createTuteurSelect($conn, $nomSelect, $currentTuteurRef, $avecNULL, $onChange) {
    if ($onChange == null)
        $onChange = '';

    $tuteurs = doQueryListTuteurs($conn);
    $tuteur = mysql_fetch_row($tuteurs);
    if ($avecNULL) {
        $keysTut[0] = "NULL";
        $valuesTut[0] = "aucun";
        $tuteurNo = 1;
    } else {
        $tuteurNo = 0;
    }

    $i = 0;
    while ($tuteur) {
        $keysTut[$tuteurNo] = $tuteur[0];
        $valuesTut[$tuteurNo] = $tuteur[1] . " " . $tuteur[2];
        if (strcmp($currentTuteurRef, $tuteur[0]) == 0)
            $i = $tuteurNo;
        $tuteur = mysql_fetch_row($tuteurs);
        $tuteurNo++;
    }
    createSelectWithOnChange($nomSelect, $keysTut, $valuesTut, $i, $onChange);
}

function createSelectFromRows($rows, $nomSelect, $current, $onChange=NULL) {        
    $row = mysql_fetch_row($rows);
    $rowNo = 0;
    $keys=array("aucune");
    $values=array("aucune");
    $i = 0;
    while ($row) {
        $keys[$rowNo] = $row[0];
        $values[$rowNo] = $row[1];
        if (strcmp($current, $row[0]) == 0)
            $i = $rowNo;
        $row = mysql_fetch_row($rows);
        $rowNo++;
    }

    createSelectWithOnChange($nomSelect, $keys, $values, $i, $onChange);
}

function createOPCASelect($conn, $nomSelect, $currentOPCA, $onChange=NULL) {

    createSelectFromRows(doQueryListOPCA($conn), $nomSelect, $currentOPCA, $onChange);
}

function createEntrepriseSelect($conn, $nomSelect, $currentEntr, $onChange=NULL) {    
    createSelectFromRows(doQueryListEntr($conn), $nomSelect, $currentEntr, $onChange);
}

function convertRowsToArray($rows) {
  $row = mysql_fetch_row($rows);
  $_rows=array();
  while ($row) {
      $_rows[]=$row;
      $row = mysql_fetch_row($rows);
  }
  return $_rows;
}

function createSelectFromArray($keysValues,$nomSelect, $currentEntr, $startsWith=NULL, $onChange=NULL) {
    $rowNo=0;
    if ($startsWith=="") $startsWith=null;
    $selectedRowNo=0;
    for ($i=0;$i<count($keysValues);$i++) {
        //error_log("comparing ".$keysValues[$i][0]." with ".$startsWith);
        if ($startsWith!=null &&
          strcmp(
              substr(strtolower($keysValues[$i][0]),0,strlen($startsWith)),
              $startsWith)!=0)
            continue;
        //error_log("recording new option ".$rowNo);
        $keys[$rowNo] = $keysValues[$i][0];
        $values[$rowNo] = $keysValues[$i][1];
        if ($keys[$rowNo]==$currentEntr)
          $selectedRowNo=$rowNo;
        $rowNo++;
    }

    createSelectWithOnChange($nomSelect, $keys, $values, $selectedRowNo, $onChange);
    return $keys[$selectedRowNo];
}


//Ajout du 26/01/2012 JTA 

function createBureauSelectEmpty($conn,$nomSelect,$currEntr,$currBureau,$onchange){
    //$values[0]= "SANS BUREAU";
    createSelectFromRows(doQueryListBureau($conn,$currEntr),$nomSelect,$currBureau,$onChange);
}

function createReferentSelect($conn,$nomSelect,$currEntr,$currReferent,$onchange){
    
    createSelectFromRows(doQueryListReferent($conn,$currEntr),$nomSelect,$currReferent,$onchange);

}

function createBureauSelect($conn,$nomSelect,$fa_entreprise_cle,$currentBur, $onChange=NULL)
{
    createSelectFromRows(doQueryListBureau($conn,$fa_entreprise_cle),$nomSelect,$currentBur,$onChange);
}
//Fin ajout

function createSelectFormKeyValuesAndTargetPage($id,$paramName,$keysValues,$defaultValue,$page,$text) {
  
  return createSelectFormKeyValuesAndTargetPageOnChange($id,$paramName,$keysValues,$defaultValue,$page,$text,"javascript:submit();","Change");
}

function createSelectFormKeyValuesAndTargetPageOnChange($id,$paramName,$keysValues,$defaultValue,$page,$text,$onChange,$submit) {
  echo "<form action='".ABS_START_URL."/index.php' method='post' id='".$id."'>
          <input type='hidden' name='page' value='".$page."'/>".$text;

   $keys=$keysValues["keys"];
   $values=$keysValues["values"];
   $i=0;
   for (;($i<count($keys)) AND ($keys[$i]!==$defaultValue);$i++);
   if ($i==count($keys)) {
       $i=0;
       $defaultValue=$keys[$i];
   }

   createSelectWithOnChange($paramName,$keys,$values,$i,$onChange);
   if (strlen($submit)>0) echo "<input type='submit' value='".$submit."'/>";
   echo "</form>";
  return $defaultValue;
}

function createSelectKeyValuesOnChange($paramName,$keysValues,$defaultValue,$onChange) {

   $keys=$keysValues["keys"];
   $values=$keysValues["values"];
   $i=0;
   for (;($i<count($keys)) AND ($keys[$i]!==$defaultValue);$i++);
   if ($i==count($keys)) {
       $i=0;
       $defaultValue=$keys[$i];
   }

   createSelectWithOnChange($paramName,$keys,$values,$i,$onChange);

  return $defaultValue;
}


?>
