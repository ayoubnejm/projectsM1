<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
  require_once (ABS_START_PATH."/secure/auth.php");
  if (!hasRole(SECR_ROLE) && !hasRole(RESP_ROLE))
      redirectAuth();
?>
<div class="menuligne3" style="background-color:#FFDA77">
  <?php
    $menuItem=array("interface/listeEtudiantsParFormationParSecr_act",
                  "interface/listeEtudiantsParEntrepriseParSecr_act",
                	"interface/listeEtudiantParTuteurParSecr_act", 
                	"interface/listeReferentsParEntrepriseParSecr_act",
			"interface/gestionBureaux_act");

    $menuItemLabel=array("Etudiants par formation", " Etudiants par entreprise ", "Etudiants par tuteur","Referents par entreprise"," Gestion des Bureaux");
    for ($i=0;$i<=count($menuItem)-1;$i++) {
      echo "| <a ".($page==$menuItem[$i]?"class='highlight'":"")." href='".INDEX_PAGE."/index.php?mode=".SECR_MODE."&page=".$menuItem[$i]."'>".$menuItemLabel[$i]."</a>";
    }

    ?>
</div>
