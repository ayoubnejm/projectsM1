<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>

<?php require_once (ABS_START_PATH."/main/functMenu.php") ?>

<!--div id="main"-->
     <!-- STOP - NE PAS INDEXER -->
     <script type="text/javascript">
<!--
// Cette fonction cacherContenus() cache le contenu ce tous les cadres sauf le premier
// On aurait pu s'en dispenser en mettant <div id="cadre_x" class="contenu-item2 off">  (avec 0<x<=dernierItem) au lieu de on
// mais comme ça, tous les cadres s'affichent si le javascript n'est pas interprété par le navigateur
function cacherContenus(){
for (var i=1; i<=dernierItem; i++)
  document.getElementById("cadre_"+i).className = 'contenu-item2 off';
}
// cette fonction changeClass(eltId) change le style de l'onglet qui vient d'être cliqué et rend visible (display: block au lieu de none) le cadre correspondant
function changeClass(elt) {
	for (var i=0; i<=dernierItem; i++) {
		if ( "item_"+i == elt.parentNode.id ) {
			document.getElementById("item_"+i).className = 'menuitem2-current';
			document.getElementById("cadre_"+i).className = 'contenu-item2 on';
		} else {

			document.getElementById("item_"+i).className = 'menuitem2';
			document.getElementById("cadre_"+i).className = 'contenu-item2 off';
		}
	}
}
-->
</script>
<!-- MENU  -->


     <?php if (hasRole("")) {
                require_once (ABS_START_PATH."/".$page.".php");
            } else
                echo "
                <h2>Vous n'êtes pas reconnus par l'application FAM2.<br/> Veuillez-vous enregister!</h2>
                <form action='interface/enregNouveauUtilisateur.php' method='post'>
                Nom:<input type='text' name='nom'/><br/>
                Prenom:<input type='text' name='prenom'/><br/>
                <!--Email:<input type='text' name='mail'/><br/>-->
                <input type='hidden' name='uid' value='".$_SESSION[CK_USER]."'/>
                Rôle :<select name='role'><option value='prof'>Enseignant</option><option value='etud'>Etudiant</option></select>
                <br/><input type='submit' value='je m enregistre!'/>
              </form>";
     ?>
     </div>
 <!--/div-->