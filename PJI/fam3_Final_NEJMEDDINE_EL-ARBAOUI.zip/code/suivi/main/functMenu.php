<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
 require_once (ABS_START_PATH."/secure/auth.php");

 if (hasRole(RESP_ROLE)) {
   if ($_SESSION[MODE]==RESP_MODE) {
    require_once (ABS_START_PATH."/main/functProfMenu.php");
	require_once (ABS_START_PATH."/main/functSecrMenu.php");
    require_once (ABS_START_PATH."/main/functRespMenu.php");
   } else {
     require_once (ABS_START_PATH."/main/functRespMenu.php");
	 require_once (ABS_START_PATH."/main/functSecrMenu.php");
     require_once (ABS_START_PATH."/main/functProfMenu.php");
   }
 }
 else
 if (hasRole(PROF_ROLE)) require_once (ABS_START_PATH."/main/functProfMenu.php");
 else
 if (hasRole(STUD_ROLE)) require_once (ABS_START_PATH."/main/functEtudMenu.php");
 else
 if (hasRole(SECR_ROLE)) require_once (ABS_START_PATH."/main/functSecrMenu.php");
?>
