<?php
require_once (ABS_START_PATH.'/dbmngt/queries.php');
require_once (ABS_START_PATH.'/html/utils.php');
require_once (ABS_START_PATH.'/dbmngt/connect.php');

class calculDistance {



    // constructeur 
    
    function __construct() {        
    }    


    // renvoi un lien avec un itinéraire google map de la cité scientifique a l'adresse en parametre
    function getLien($adresse) {
        $depart = "Cité Scientifique 59655 Villeneuve dAscq";
        $retour = "http://maps.google.com/maps?saddr=" . $depart . "&daddr=" . $adresse;
        return $retour;
    }


    // calcul la distance de la cité scientifique a l'adresse donnée en parametre 
    function getDistance($adresse2) {

        if (isset($this->lieu[$adresse2])) {
            return $this->lieu[$adresse2];
        } else {
            if ($adresse2=="") return -1;
            time_nanosleep(0, 500000000);
            $adresse1 = "Cité+Scientifique+59655+Villeneuve%20d%20Ascq";
            //$adresse1 = str_replace(" ", "+", $adresse1);
            $adresse2 = str_replace(" ", "%20", $adresse2);
            $url = 'http://maps.google.com/maps/api/directions/xml?language=fr&origin=' . $adresse1 . '&destination=' . $adresse2 . '&sensor=false';
            error_log($url);
            $xml = file_get_contents($url);
            $root = simplexml_load_string($xml);
            

            if ($root->status == "OK") {
                $distance = $root->route->leg->distance->value;
                $ladistance = intval($distance / 1000);
                $this->lieu[$adresse2] = $ladistance;
                /*if($ladistance==0){
                    $ladistance=-1;
                }*/
                error_log($root->status." -> ".$ladistance);
                return $ladistance;
            } else {
              error_log($root->status." -> -1");
                return -1;
            }
        }
    }

	

		// Calcul de distance en utilisant des cordonées GPS : renvoi la distance en mètres
	function getDistanceCoorGPS($x2, $y2) {
	  $x1=50.611588 ;
	  $y1=3.142495199999985;
	
	$lat1 = deg2rad($x1);
	$lat2 = deg2rad($x2);
	$lon1 = deg2rad($y1);
	$lon2 = deg2rad($y2);

	$R = 6371;
	$dLat = $lat2 - $lat1;
	$dLong = $lon2 - $lon1;
	$a= pow(sin($dLat/2), 2) + cos($lat1) * cos($lat2) * pow(sin($dLong/2), 2);
	$c= 2 * atan2(sqrt($a),sqrt(1-$a));
	$d= $R * $c;
	//recuperation altitude en km
	$alt1 = round($alt1,2)/1000;
	$alt2 = round($alt2,2);
	//Pythagore a dit que :
	$h = sqrt(pow($d,2)+pow((alt2-alt1),2));
	return $h;
	}




    // calcul la distance entre deux adresses en parametres
        function getDistance2($adresse1,$adresse2) {

        if (isset($this->lieu[$adresse2])) {
            return $this->lieu[$adresse2];
        } else {
            time_nanosleep(0, 500000000);
           
            $adresse1 = str_replace(" ", "+", $adresse1);
            $adresse2 = str_replace(" ", "+", $adresse2);
            $url = 'http://maps.google.com/maps/api/directions/xml?language=fr&origin=' . $adresse1 . '&destination=' . $adresse2 . '&sensor=false';
            $xml = file_get_contents($url);
            $root = simplexml_load_string($xml);            

            if ($root->status == "OK") {
                $distance = $root->route->leg->distance->value;
                $ladistance = intval($distance / 1000);
                $this->lieu[$adresse2] = $ladistance;
                if($ladistance==0){
                    $ladistance=-1;
                }
                return $ladistance;
            } else {
                return -1;
            }
        }
    }
    
    
    /////////// ajout également dans queries.php pour les requetes ! et dans admin.php pour le lien
    //et pour le recalcul j'ai ajouter la page recalcul.php qui execute la fonction
     function recalculerDistance() {
      $instance = new calculDistance();
      
       $conn = doConnection();
       $res = doQueryDonneeDistance($conn);
       
        while ( $distances = mysql_fetch_row($res)) {
              // appliquer la fonction calcul a l'adresse 
               //$d=$distances[1].' '.$distances[2];
               $d=$distances[2];
              echo "Recalculer distance pour $distances[0] situé à $d ...";

               $ladistance=  $instance->getDistance($d);
               echo $ladistance."km -> done <br/>\n";
              // reinserer dans la base
              if ($ladistance!=-1)
                doQueryInsertDistance($conn, $ladistance, $distances[0]);

            }
       
    }
    
    
    
}

?>
