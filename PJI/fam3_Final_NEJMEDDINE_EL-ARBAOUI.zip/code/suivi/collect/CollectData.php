
<html>
<head>
<META http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>
</title>
</head>
<body>
<?php
    require_once("../mail/sendMail.php");
    $today=getdate();
    $nom=$_REQUEST["fa_etudiant_nom"];
    $prenom=$_REQUEST["fa_etudiant_prenom"];
    $formation=$_REQUEST["fa_etudiant_groupeRef"];

    $filename=sprintf("../xml/data%s%ld%s%s.xml",
        $formation,
        $today[0],
        $nom{0},
        $prenom{0});

    //printf("%s<br/>",$filename);
    
    $data=fopen($filename,"w+");
    $msg="";
    fprintf($data,"<item>\n");
    foreach ($_REQUEST as $key=>$value)
    {
        $msg.=$key."\n------\n".$value."\n-----\n\n\n";
        fprintf($data,"<%s>%s</%s>\n",$key,$value,$key);

    }
    fprintf($data,"</item>\n");
    fclose($data);
    sendAuthenticatedMail("marius.bilasco@lifl.Fr","marius.bilasco@lifl.Fr","[stalt][new] $nom $prenom $formation",$msg)
?>

<?php
    $data2=fopen("../xml/data.pxml","a+");
    fprintf($data2,"<item>\n");
    foreach ($_REQUEST as $key=>$value)
    {
        fprintf($data2,"<%s>%s</%s>\n",$key,$value,$key);

    }
    fprintf($data2,"</item>\n");
    fclose($data2);
?>
<h2>Informations enregistrées avec succès!</h2>

L'équipe assurant le suivi des alternants vous remercie de votre disponibilité! <br/> <br/>

<a href="http://www.fil.univ-lille1.fr">www.fil.univ-lille1.fr</a>
</body>
</html>
