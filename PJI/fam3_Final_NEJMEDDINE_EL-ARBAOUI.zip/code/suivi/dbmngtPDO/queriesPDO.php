<?php
require_once (ABS_START_PATH."/config/main.ini.php");

    function doQuerieListEtudiantParEntreprise($bdd,$bureau,$formation, $user) {
    	$yearRef=$_SESSION[REF_YEAR];
    	$reponse = $bdd->query("select
            contrat.alternanceCle,
            etudiant.nom as nom_etud,
            etudiant.prenom as nom_prenom,
            if (groupeCle not like concat(formationCle,'%'),concat(groupeCle),formation.formationCle) as formation, 
            if (bureau.ville='SANS SIEGE','',bureau.ville) as ville ,
            if (referent.nom='__sans','', referent.nom) as referent,
            referent.mail as mail_referent,
            bureau.entrepriseRef as entreprise, 
            bureau.bureauCle as bureau   ,  
            membre.profCle as secr ,  
            etudiant.etudCle,
           etudiant.mailLille1 as mailEtud, 
            bureau.adresse as adresse,
            bureau.codePostal as codePostal,
		etudiant.mailLille1 as mail_etud
        from
    	membre,contrat inner join etudiant on contrat.etudRef=etudiant.etudCle
                        inner join etudiant_groupe on etudiant.etudCle=etudiant_groupe.etudRef and contrat.anneeCle=etudiant_groupe.annee
                        inner join groupe on etudiant_groupe.groupeRef=groupe.groupeCle
                        inner join formation on groupe.formationRef=formation.formationCle
                    inner join
                referent on contrat.referentRef=referent.referentCle 
                left join
                etapeetudtut on contrat.alternanceCle=etapeetudtut.alternanceRef                          
                left join
                infoetud on contrat.alternanceCle=infoetud.alternanceRef                      
                left join 
                bureau on contrat.bureauRef = bureau.bureauCle

     where '".$formation."'  like concat('%',formationRef,'%') and anneeCle in  (".$yearRef.")  
    and membre.profCle='".$user."'
    and bureau.bureauCle ='".$bureau."'
          order by etudiant.nom, formationRef");

    	return $reponse;

    }

    function doQuerieListEtudiantParFormation($bdd,$formation, $user) {
    	$yearRef=$_SESSION[REF_YEAR];
    	$reponse = $bdd->query("select
            contrat.alternanceCle as cleAlt,
            etudiant.nom as nom_etud,
            etudiant.prenom as nom_prenom,
            if (groupeCle not like concat(formationCle,'%'),concat(groupeCle),formation.formationCle) as formation, 
            if (bureau.ville='SANS SIEGE','',bureau.ville) as ville ,
            if (referent.nom='__sans','', referent.nom) as referent,
            referent.mail as mail_referent,
            bureau.entrepriseRef as entreprise,      
            membre.profCle as secr ,  
            etudiant.etudCle,
           etudiant.mailLille1 as mailEtud, 
            bureau.adresse as adresse,
            bureau.codePostal as codePostal
        from
    	membre,contrat inner join etudiant on contrat.etudRef=etudiant.etudCle
                        inner join etudiant_groupe on etudiant.etudCle=etudiant_groupe.etudRef and contrat.anneeCle=etudiant_groupe.annee
                        inner join groupe on etudiant_groupe.groupeRef=groupe.groupeCle
                        inner join formation on groupe.formationRef=formation.formationCle
                    inner join
                membre as resp1 on resp1.profCle=formation.responsableRef
                left join
                membre as resp2 on resp2.profCle=formation.responsableRef2
                left join
                referent on contrat.referentRef=referent.referentCle 
                left join
                etapeetudtut on contrat.alternanceCle=etapeetudtut.alternanceRef                          
                left join
                infoetud on contrat.alternanceCle=infoetud.alternanceRef                      
                left join 
                bureau on contrat.bureauRef = bureau.bureauCle

     where '".$formation."'  like concat('%',formationRef,'%') and anneeCle in (".$yearRef.") 
    and etudiant.obsolete='0' and membre.profCle='".$user."'
          order by etudiant.nom, formationRef");

    	return $reponse;

    }


	    function doQuerieListEtudiantInnactifsParFormation($bdd,$formation, $user) {
    	$yearRef=$_SESSION[REF_YEAR];
    	$reponse = $bdd->query("select
            contrat.alternanceCle as cleAlt,
            etudiant.nom as nom_etud,
            etudiant.prenom as nom_prenom,
            if (groupeCle not like concat(formationCle,'%'),concat(groupeCle),formation.formationCle) as formation, 
            if (bureau.ville='SANS SIEGE','',bureau.ville) as ville ,
            if (referent.nom='__sans','', referent.nom) as referent,
            referent.mail as mail_referent,
            bureau.entrepriseRef as entreprise,      
            membre.profCle as secr ,  
            etudiant.etudCle,
           etudiant.mailLille1 as mailEtud, 
            bureau.adresse as adresse,
            bureau.codePostal as codePostal
        from
    	membre,contrat inner join etudiant on contrat.etudRef=etudiant.etudCle
                        inner join etudiant_groupe on etudiant.etudCle=etudiant_groupe.etudRef and contrat.anneeCle=etudiant_groupe.annee
                        inner join groupe on etudiant_groupe.groupeRef=groupe.groupeCle
                        inner join formation on groupe.formationRef=formation.formationCle
                    inner join
                membre as resp1 on resp1.profCle=formation.responsableRef
                left join
                membre as resp2 on resp2.profCle=formation.responsableRef2
                left join
                referent on contrat.referentRef=referent.referentCle 
                left join
                etapeetudtut on contrat.alternanceCle=etapeetudtut.alternanceRef                          
                left join
                infoetud on contrat.alternanceCle=infoetud.alternanceRef                      
                left join 
                bureau on contrat.bureauRef = bureau.bureauCle

     where '".$formation."'  like concat('%',formationRef,'%') and anneeCle in (".$yearRef.") 
    and etudiant.obsolete='1' and membre.profCle='".$user."'
          order by etudiant.nom, formationRef");

    	return $reponse;

    }

    function doQueryAvoirInfoDuBureau($bdd , $bureau ) {
        $reponse = $bdd->query("select bureau.bureauCle ,  bureau.adresse as adresse, bureau.ville as ville , bureau.codePostal as codePostal
                                from  bureau 
                                where bureau.bureauCle like '".$bureau."' ");
        return $reponse;
    }


    function doQueryUpdateAdresseBureau($bdd , $bureau, $adresse,  $ville, $codePostal ) {
        $reponse = $bdd->query("update bureau set adresse = '".$adresse."' , ville = '".$ville."' 
                                ,  codePostal = '".$codePostal."' where bureauCle like '".$bureau."'  ");
        return $reponse;
    }




    function doQueryListTuteursInactifsParAnnee($bdd,$yearRef=null) {
         if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];
      
        $reponse = $bdd->query("select profCle, nom, prenom, mail, bureau,inscription from membre 
                                where  anneeReference <= ".$yearRef." and obsolete='1' order by nom  ") ;
        return $reponse;
    } 

    function doQueryNombreEtudiantsEncadresParUnTuteur($bdd,$tuteur, $yearRef=null) {
         if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];
      
        $reponse = $bdd->query("SELECT COUNT(contrat.etudRef) as nbreEtudiant FROM contrat where contrat.tuteurRef='".$tuteur."' 
                                and contrat.anneeCle= '".$yearRef."'") ;
        return $reponse;
    } 

    function doQueryNombreTotalEtudiantsEncadresParUnTuteur($bdd,$tuteur, $yearRef=null) {
         if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];     
        $reponse = $bdd->query("SELECT COUNT(contrat.etudRef) as nbreEtudiant FROM contrat where contrat.tuteurRef='".$tuteur."'") ;
        return $reponse;
    } 


    function getEtudClesSecrListFromAlternanceCle($bdd, $alts) {
       
        $reponse = $bdd->query("select etudRef from contrat where alternanceCle in (" . $alts . ")");

        $list = '';
       
        while ($donnees = $reponse->fetch()){
      
            $list.=",'" . $donnees['etudRef'] . "'";
          
        }

        if (strlen($list) > 0)
            return substr($list, 1);

        return $list;
    }


    function  doQuerieListReferentParEntreprise($bdd,$entreprise){
        $reponse= $bdd->query(" select nom,prenom,tel,mail,bureauRef,fonction from referent 
                                    where entrepriseRef= '".$entreprise."' ");
        return $reponse;

    }

      function  doQuerieListMailReferents($bdd,$entreprise){
	$yearRef=$_SESSION[REF_YEAR];
    	
        $reponse= $bdd->query(" select nom,prenom,mail,bureauRef,fonction from referent where entrepriseRef='".$entreprise."' ");
        return $reponse;

    }
 

    function  desactiverEtud_Secr($bdd, $etudCles){
        $reponse= $bdd->query("update etudiant set obsolete='1' where etudCle in (".$etudCles.")   ");
        return $reponse;

    }

  function  activerEtud_Secr($bdd, $etudCles){
        $reponse= $bdd->query("update etudiant set obsolete='0' where etudCle in (".$etudCles.")   ");
        return $reponse;

    }


   function doQueryActiverBureau($bdd,$bureauCle) {   
         $reponse = $bdd->query("Update bureau set obsolete='0' where bureauCle ='".$bureauCle."'") ;
       return $reponse;
    } 


?>
