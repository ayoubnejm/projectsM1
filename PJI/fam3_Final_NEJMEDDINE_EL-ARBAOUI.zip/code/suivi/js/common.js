function getElt(whichLayer)
{
    if( document.getElementById ) // this is the way the standards work
        elem = document.getElementById( whichLayer );
    else if( document.all ) // this is the way old msie versions work
            elem = document.all[whichLayer];
         else if( document.layers ) // this is the way nn4 works
            elem = document.layers[whichLayer];

    return elem;
}

function getFormCtrl(whichForm,whichCtrl)
{
    if( document.getElementById ) // this is the way the standards work
        elem = document.getElementById( whichLayer );
    else if( document.all ) // this is the way old msie versions work
            elem = document.all[whichLayer];
         else if( document.layers ) // this is the way nn4 works
            elem = document.layers[whichLayer];

    return elem.namedItem(formField);
}