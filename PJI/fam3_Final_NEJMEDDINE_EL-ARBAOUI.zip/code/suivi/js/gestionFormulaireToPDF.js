//Auteur JTA
function gestionMoyenDeTransport(formName)
{
   // alert(formName);
    var form=getElt(formName);
   // alert(form);
    form.transportAller.options.length = 0;
    form.transportRetour.options.length=0;
    form.TransportAllerEscale.options.length = 0;
    form.TransportRetourEscale.options.length = 0;
    if(form.train.checked)
    {                              
        document.getElementById("divInfoTrain").style.display="";
        
        
        form.transportAller[form.transportAller.options.length] = new Option("Train");
        form.transportRetour[form.transportRetour.options.length] = new Option("Train");
        form.TransportAllerEscale[form.TransportAllerEscale.options.length] = new Option("Train");
        form.TransportRetourEscale[form.TransportRetourEscale.options.length] = new Option("Train");
        
    }    
    else
    {       
        document.getElementById("divInfoTrain").style.display="none";        
    }    
    if(form.avion.checked)
    {                      
        form.transportAller[form.transportAller.options.length] = new Option("Avion");
        form.transportRetour[form.transportRetour.options.length] = new Option("Avion");
        form.TransportAllerEscale[form.TransportAllerEscale.options.length] = new Option("Avion");
        form.TransportRetourEscale[form.TransportRetourEscale.options.length] = new Option("Avion");        
    }
    if(form.voiture.checked)
    {                         
        document.getElementById("divInfoVoiture").style.display="";
                
        form.transportAller[form.transportAller.options.length] = new Option("Voiture");
        form.transportRetour[form.transportRetour.options.length] = new Option("Voiture");                      
        form.TransportAllerEscale[form.TransportAllerEscale.options.length] = new Option("Voiture");
        form.TransportRetourEscale[form.TransportRetourEscale.options.length] = new Option("Voiture");
    }
    else
    {        
        document.getElementById("divInfoVoiture").style.display="none";
    }
    if(form.taxi.checked)
    {                
        form.transportAller[form.transportAller.options.length] = new Option("Taxi");
        form.transportRetour[form.transportRetour.options.length] = new Option("Taxi");                   
        form.TransportAllerEscale[form.TransportAllerEscale.options.length] = new Option("Taxi");
        form.TransportRetourEscale[form.TransportRetourEscale.options.length] = new Option("Taxi");
    }
    if(form.metro.checked)
    {
        form.transportAller[form.transportAller.options.length] = new Option("Trans. en commun");
        form.transportRetour[form.transportRetour.options.length] = new Option("Trans. en commun");
        form.TransportAllerEscale[form.TransportAllerEscale.options.length] = new Option("Trans. en commun");
        form.TransportRetourEscale[form.TransportRetourEscale.options.length] = new Option("Trans. en commun");
    }
    if(form.velo.checked)
    {
        form.transportAller[form.transportAller.options.length] = new Option("Vélo");
        form.transportRetour[form.transportRetour.options.length] = new Option("Vélo");
        form.TransportAllerEscale[form.TransportAllerEscale.options.length] = new Option("Vélo");
        form.TransportRetourEscale[form.TransportRetourEscale.options.length] = new Option("Vélo");
    }
    if(form.velo.checked && form.metro.checked)
    {
        form.transportAller[form.transportAller.options.length] = new Option("Trans. com. + Vélo");
        form.transportRetour[form.transportRetour.options.length] = new Option("Trans. com. + Vélo");
        form.TransportAllerEscale[form.TransportAllerEscale.options.length] = new Option("Trans. com. + Vélo");
        form.TransportRetourEscale[form.TransportRetourEscale.options.length] = new Option("Trans. com. + Vélo");
    }
    if(form.locationVoiture.checked)
    {        
        document.getElementById("divInfoVoitureLocation").style.display="";
        
        form.transportAller[form.transportAller.options.length] = new Option("Voiture de location");
        form.transportRetour[form.transportRetour.options.length] = new Option("Voiture de location");
        form.TransportAllerEscale[form.TransportAllerEscale.options.length] = new Option("Voiture de location");
        form.TransportRetourEscale[form.TransportRetourEscale.options.length] = new Option("Voiture de location");
    }
    else
    {
        document.getElementById("divInfoVoitureLocation").style.display="none";
    }
    
    if(form.DepartDifferentLille1.checked)
    {
        document.getElementById("divDepartDifferent").style.display="";   
    }
    else{
        document.getElementById("divDepartDifferent").style.display="none";      
    }
    
    if(form.EscaleAller.checked)
    {
        document.getElementById("divEscaleAller").style.display="";
    }else{
        document.getElementById("divEscaleAller").style.display="none";
    }
    
    if(form.EscaleRetour.checked)
    {
        document.getElementById("divEscaleRetour").style.display="";
    }else{
        document.getElementById("divEscaleRetour").style.display="none";
    }
}

function gestionDate(form)
{
     
    if(form.DateRetourDifferente.checked)
    {        
        document.getElementById("dateRetourDiv").style.display="";
    }
    else
    {     
        document.getElementById("dateRetourDiv").style.display="none";
    }
}



function valider()
{        
    form=document.forms['formulaire'];
    var erreur = false;
            
    if(form.horaireDepartAller.value == "")
    {
        erreur = true;
        document.getElementById("erreurHeureDepartAller").style.display="";
        
        document.getElementById("erreurHeureDepartAllerFormat").style.display="none";
    }
    else
    {
        document.getElementById("erreurHeureDepartAller").style.display="none";    
        // Verification format heure de depart aller 
        heureDepartAller = parseInt(form.horaireDepartAller.value[0]+form.horaireDepartAller.value[1]); 
        minuteDepartAller = parseInt(form.horaireDepartAller.value[3]+form.horaireDepartAller.value[4]); 
        if(isNaN(heureDepartAller) || isNaN(minuteDepartAller) || form.horaireDepartAller.value[2] != ":" || heureDepartAller>23 || heureDepartAller<0 || minuteDepartAller<0 || minuteDepartAller>59 )
        {
            erreur = true;
            document.getElementById("erreurHeureDepartAllerFormat").style.display="";
        }
        else
        {
            document.getElementById("erreurHeureDepartAllerFormat").style.display="none";
        }
    }
    
    if(form.horaireArriverAller.value == "")
    {
        erreur = true;
        document.getElementById("erreurHeureArriverAller").style.display="";
        document.getElementById("erreurHeureArriverAllerFormat").style.display="none";
    }
    else
    {
        document.getElementById("erreurHeureArriverAller").style.display="none";    
        // Verification format heure de arriver aller 
        heureArriverAller = parseInt(form.horaireArriverAller.value[0]+form.horaireArriverAller.value[1]); 
        minuteArriverAller = parseInt(form.horaireArriverAller.value[3]+form.horaireArriverAller.value[4]); 
        if(isNaN(heureArriverAller) || isNaN(minuteArriverAller) || form.horaireArriverAller.value[2] != ":" || heureArriverAller>23 || heureArriverAller<0 || minuteArriverAller<0 || minuteArriverAller>59 )
        {
            erreur = true;   
            document.getElementById("erreurHeureArriverAllerFormat").style.display="";
        }
        else
        {
            document.getElementById("erreurHeureArriverAllerFormat").style.display="none";
        }  
    }                    
    
    if(form.horaireDepartRetour.value == "")
    {
        erreur = true;
        document.getElementById("erreurHeureDepartRetour").style.display="";
        document.getElementById("erreurHeureDepartRetourFormat").style.display="none";
    }
    else
    {
        document.getElementById("erreurHeureDepartRetour").style.display="none";  
        // Verification format heure de depart retour 
        heureDepartRetour = parseInt(form.horaireDepartRetour.value[0]+form.horaireDepartRetour.value[1]); 
        minuteDepartRetour = parseInt(form.horaireDepartRetour.value[3]+form.horaireDepartRetour.value[4]); 
        if(isNaN(heureDepartRetour) || isNaN(minuteDepartRetour) || form.horaireDepartRetour.value[2] != ":" || heureDepartRetour>23 || heureDepartRetour<0 || minuteDepartRetour<0 || minuteDepartRetour>59  ) 
        {
            erreur = true;   
            document.getElementById("erreurHeureDepartRetourFormat").style.display="";
        }
        else
        {
            document.getElementById("erreurHeureDepartRetourFormat").style.display="none";
        }
    }
    
    if(form.horaireArriverRetour.value == "")
    {
        erreur = true;
        document.getElementById("erreurHeureArriverRetour").style.display="";
        document.getElementById("erreurHeureArriverRetourFormat").style.display="none";
    }
    else
    {
        document.getElementById("erreurHeureArriverRetour").style.display="none"; 
    
    
        // Verification format heure de arriver retour 
        heureArriverRetour = parseInt(form.horaireArriverRetour.value[0]+form.horaireArriverRetour.value[1]); 
        minuteArriverRetour = parseInt(form.horaireArriverRetour.value[3]+form.horaireArriverRetour.value[4]); 
        if(isNaN(heureArriverRetour) || isNaN(minuteArriverRetour) || form.horaireArriverRetour.value[2] != ":" || heureArriverRetour>23 || heureArriverRetour<0 || minuteArriverRetour<0 || minuteArriverRetour>59  )
        {
            erreur = true;
            document.getElementById("erreurHeureArriverRetourFormat").style.display="";
        }
        else
        {
            document.getElementById("erreurHeureArriverRetourFormat").style.display="none";
        } 
    }
    
            
    if(form.transportAller.value.toString() == "")
    {
        erreur = true;
        document.getElementById("erreurTransportAller").style.display="";
        document.getElementById("erreurTransportRetour").style.display="";
    }
    else
    {
        document.getElementById("erreurTransportAller").style.display="none";
        document.getElementById("erreurTransportRetour").style.display="none";
    }            
        
    var dateAller = form.dateAller.value;
    var dateRetour = form.dateRetour.value;
    
    var anneeAller = parseInt(dateAller[0]+dateAller[1]+dateAller[2]+dateAller[3]);
    var anneeRetour = parseInt(dateRetour[0]+dateRetour[1]+dateRetour[2]+dateRetour[3]);
    
    var moisAller = parseInt(dateAller[5]+dateAller[6]);
    var moisRetour = parseInt(dateRetour[5]+dateRetour[6]);
    
    var jourAller =parseInt(dateAller[8]+dateAller[9]);
    var jourRetour = parseInt(dateRetour[8]+dateRetour[9]);
    
    //Verification que la date aller est complétement renseignier 
    if(anneeAller == 0 || moisAller == 0 || jourAller == 0)
    {
        erreur = true;
        document.getElementById("erreurDateAller").style.display="";
    }
    else
    {
        document.getElementById("erreurDateAller").style.display="none";
    }
    
    //Verification champs voiture
    if(form.transportAller.value.toString() == "Voiture" || form.transportRetour.value.toString() == "Voiture")
    {
        retour = validerDonnerSurTransportVoiture();
        if(retour)
        {
            erreur = true;
        }
    }
    else{
        document.getElementById("erreurImmatriculationVoiture").style.display="none";
        document.getElementById("erreurPuissanceVoiture").style.display="none";
        document.getElementById("erreurPuissanceVoitureObligatoire").style.display="none";
    }
    
    if(form.transportAller.value.toString() == "Train" || form.transportRetour.value.toString() == "Train" ){
        retour = validerDonnerSurTransportTrain();
        if(retour)
        {
            erreur = true;
        }
    }else{
        document.getElementById("erreurReductionTrain").style.display="none";
    }      
    
    // Gestion des champs voiture de location
    if(form.transportAller.value.toString() == "Voiture de location" || form.transportRetour.value.toString() == "Voiture de location")
    {
        retour = validerDonnerSurTransportVoitureLocation();
        if(retour)
        {
            erreur = true;
        }
    }
    else{
        document.getElementById("erreurNbPersonneLocationObligatoire").style.display="none";
        document.getElementById("erreurNbPersonneLocation").style.display="none";
    }
    
    //Verifications date retour > date aller 
    if(form.DateRetourDifferente.checked)
    {
        //Verification que la date retour est complétement renseignier 
        if(anneeRetour == 0 || moisRetour == 0 || jourRetour ==0)
        {
            erreur = true;   
            document.getElementById("erreurDateRetour").style.display="";
            document.getElementById("erreurDateRetourFormat").style.display="none";
        }
        else
        {            
            document.getElementById("erreurDateRetour").style.display="none";
            var d1 = new Date(dateAller);
            var d2 = new Date(dateRetour);
            if(d1>d2)
            {
                erreur = true; 
                document.getElementById("erreurDateRetourFormat").style.display="";
            }
            else
            {
                document.getElementById("erreurDateRetourFormat").style.display="none";
            }
        }                
    }
    else
    {
        document.getElementById("erreurDateRetour").style.display="none";
    }
    
    
    //Verification ville de depart differente 
    if(form.DepartDifferentLille1.checked)
    {
        if(form.departAller.value == "")
        {
            erreur = true;
            document.getElementById("erreurVilleDepartObligatoire").style.display="";
            document.getElementById("erreurVilleDepart").style.display="none";
        }else{  
            if(form.departAller.value.length > 19)
            {
                erreur = true;
                document.getElementById("erreurVilleDepart").style.display="";
            }
            else{
                document.getElementById("erreurVilleDepart").style.display="none";
            }
            document.getElementById("erreurVilleDepartObligatoire").style.display="none";
        }
        
    /* if(form.kmaller.value == "")
        {
            erreur = true;
            document.getElementById("erreurKmObligatoire").style.display="";
        }else{
            kmAllerEnInt = parseInt(form.kmaller.value);
            if(isNaN(kmAllerEnInt) || kmAllerEnInt <=0)
            {
                erreur = true;                     
                document.getElementById("erreurKm").style.display="";
            }
            else{
                document.getElementById("erreurKm").style.display="none";
            }
            document.getElementById("erreurKmObligatoire").style.display="none";
        }*/
    }else
    {
        document.getElementById("erreurVilleDepartObligatoire").style.display="none";
        // document.getElementById("erreurKmObligatoire").style.display="none";
        // document.getElementById("erreurKm").style.display="none";
        document.getElementById("erreurVilleDepart").style.display="none";
    }
    
    
    //Verifications champs observations inferieur a 50 chars 
    if(form.observations.value.length >50)
    {
        erreur = true;
        document.getElementById("erreurObservation").style.display="";
    }   
    else
    {
        document.getElementById("erreurObservation").style.display="none";
    }
    
    
    //Gestion des escales 
    //Escale aller
    if(form.EscaleAller.checked)
    {
        leTransoprtAllerEscale = form.TransportAllerEscale.value;
        if(leTransoprtAllerEscale == "")
        {
            erreur = true;
            document.getElementById("erreurTransportAllerEscaleObligatoire").style.display="";
        }else{
            //Verification de la validiter des champs             
            if(leTransoprtAllerEscale == "Train")
            {
                retour = validerDonnerSurTransportTrain();
                if(retour)
                {
                    erreur = true;
                }
            }
            if(leTransoprtAllerEscale == "Voiture")
            {
                retour = validerDonnerSurTransportVoiture();
                if(retour)
                {
                    erreur = true;
                }
            }
            if(leTransoprtAllerEscale == "Voiture de location")
            {
                retour = validerDonnerSurTransportVoitureLocation();
                if(retour)
                {
                    erreur = true;
                }
            }            
            document.getElementById("erreurTransportAllerEscaleObligatoire").style.display="none";
        }
        
        if(form.villeEscaleAller.value.toString() == "")
        {
            erreur = true;
            document.getElementById("erreurEscaleAllerObligatoire").style.display ="";
            document.getElementById("erreurVilleEscaleAller").style.display="none";
        }else
        {
            if(form.villeEscaleAller.value.length > 19)
            {
                erreur = true;
                document.getElementById("erreurVilleEscaleAller").style.display="";
            }
            else{
                document.getElementById("erreurVilleEscaleAller").style.display="none";
            }   
            document.getElementById("erreurEscaleAllerObligatoire").style.display ="none";    
        }
        //Verification heure depart aller 
        if(form.horaireDepartAllerEscale.value.toString() == "")
        {
            erreur = true;
            document.getElementById("erreurHeureDepartEscaleAllerFormat").style.display="none";
            document.getElementById("erreurHeureDepartEscaleAller").style.display="";
        }else{
            // Verification format heure de depart aller pour l'escale 
            heureDepartAllerEscale = parseInt(form.horaireDepartAllerEscale.value[0]+form.horaireDepartAllerEscale.value[1]); 
            minuteDepartAllerEscale = parseInt(form.horaireDepartAllerEscale.value[3]+form.horaireDepartAllerEscale.value[4]); 
            if(isNaN(heureDepartAllerEscale) || isNaN(minuteDepartAllerEscale) || form.horaireDepartAllerEscale.value[2] != ":" || heureDepartAllerEscale>23 || heureDepartAllerEscale<0 || minuteDepartAllerEscale<0 || minuteDepartAllerEscale>59  )
            {
                erreur = true;                
                document.getElementById("erreurHeureDepartEscaleAllerFormat").style.display="";
            }else{
                document.getElementById("erreurHeureDepartEscaleAllerFormat").style.display="none";
            }            
            document.getElementById("erreurHeureDepartEscaleAller").style.display="none";
        }
        //Verif heure heure arriver aller
        if(form.horaireArriverAllerEscale.value.toString() == "")
        {
            erreur = true;
            document.getElementById("erreurHeureArriverEscaleAllerFormat").style.display="none";
            document.getElementById("erreurHeureArriverEscaleAller").style.display="";
        }else{            
            heureArriverAllerEscale = parseInt(form.horaireArriverAllerEscale.value[0]+form.horaireArriverAllerEscale.value[1]); 
            minuteArriverAllerEscale = parseInt(form.horaireArriverAllerEscale.value[3]+form.horaireArriverAllerEscale.value[4]); 
            if(isNaN(heureArriverAllerEscale) || isNaN(minuteArriverAllerEscale) || form.horaireArriverAllerEscale.value[2] != ":" || heureArriverAllerEscale>23 || heureArriverAllerEscale<0 || minuteArriverAllerEscale<0 || minuteArriverAllerEscale>59  )
            {
                erreur = true;                
                document.getElementById("erreurHeureArriverEscaleAllerFormat").style.display="";
            }else{
                document.getElementById("erreurHeureArriverEscaleAllerFormat").style.display="none";
            }            
            document.getElementById("erreurHeureArriverEscaleAller").style.display="none";
        }        
    }else{
        //Desactivation des champs d'erreur
        document.getElementById("erreurTransportAllerEscaleObligatoire").style.display="none";
        document.getElementById("erreurHeureArriverEscaleAller").style.display="none";
        document.getElementById("erreurHeureArriverEscaleAllerFormat").style.display="none";
        document.getElementById("erreurHeureDepartEscaleAllerFormat").style.display="none";    
        document.getElementById("erreurHeureDepartEscaleAller").style.display="none";
        document.getElementById("erreurVilleEscaleAller").style.display="none";
        document.getElementById("erreurEscaleAllerObligatoire").style.display ="none";    
    }
    
    
    //Verification des champs de l'escale du retour
    if(form.EscaleRetour.checked)
    {                     
        
        leTransoprtRetourEscale = form.TransportRetourEscale.value;
        if(leTransoprtRetourEscale == "")
        {
            erreur = true;
            document.getElementById("erreurTransportRetourEscaleObligatoire").style.display="";
        }else{
            //Verification de la validiter des champs             
            if(leTransoprtRetourEscale == "Train")
            {
                retour = validerDonnerSurTransportTrain();
                if(retour)
                {
                    erreur = true;
                }
            }
            if(leTransoprtRetourEscale == "Voiture")
            {
                retour = validerDonnerSurTransportVoiture();
                if(retour)
                {
                    erreur = true;
                }
            }
            if(leTransoprtRetourEscale == "Voiture de location")
            {
                retour = validerDonnerSurTransportVoitureLocation();
                if(retour)
                {
                    erreur = true;
                }
            }
            document.getElementById("erreurTransportRetourEscaleObligatoire").style.display="none";
        }  
        
        if(form.villeEscaleRetour.value.toString() == "")
        {
            erreur = true;
            document.getElementById("erreurEscaleRetourObligatoire").style.display ="";
            document.getElementById("erreurVilleEscaleRetour").style.display="none";
        }else
        {
            if(form.villeEscaleRetour.value.length > 19)
            {
                erreur = true;
                document.getElementById("erreurVilleEscaleRetour").style.display="";
            }
            else{
                document.getElementById("erreurVilleEscaleRetour").style.display="none";
            } 
            document.getElementById("erreurEscaleRetourObligatoire").style.display ="none";
        }
        //Verif heure depart retour 
        if(form.horaireDepartRetourEscale.value.toString() == "")
        {
            erreur = true;
            document.getElementById("erreurHeureDepartEscaleRetourFormat").style.display="none";
            document.getElementById("erreurHeureDepartEscaleRetour").style.display="";
        }else{            
            heureDepartRetourEscale = parseInt(form.horaireDepartRetourEscale.value[0]+form.horaireDepartRetourEscale.value[1]); 
            minuteDepartRetourEscale = parseInt(form.horaireDepartRetourEscale.value[3]+form.horaireDepartRetourEscale.value[4]); 
            if(isNaN(heureDepartRetourEscale) || isNaN(minuteDepartRetourEscale) || form.horaireDepartRetourEscale.value[2] != ":" || heureDepartRetourEscale>23 || heureDepartRetourEscale<0 || minuteDepartRetourEscale<0 || minuteDepartRetourEscale>59  )
            {
                erreur = true;                
                document.getElementById("erreurHeureDepartEscaleRetourFormat").style.display="";
            }else{
                document.getElementById("erreurHeureDepartEscaleRetourFormat").style.display="none";
            }            
            document.getElementById("erreurHeureDepartEscaleRetour").style.display="none";
        }
        //Verif heure arriver retour
        if(form.horaireArriverRetourEscale.value.toString() == "")
        {
            erreur = true;
            document.getElementById("erreurHeureArriverEscaleRetourFormat").style.display="none";
            document.getElementById("erreurHeureArriverEscaleRetour").style.display="";
        }else{            
            heureArriverRetourEscale = parseInt(form.horaireArriverRetourEscale.value[0]+form.horaireArriverRetourEscale.value[1]); 
            minuteArriverRetourEscale = parseInt(form.horaireArriverRetourEscale.value[3]+form.horaireArriverRetourEscale.value[4]); 
            if(isNaN(heureArriverRetourEscale) || isNaN(minuteArriverRetourEscale) || form.horaireArriverRetourEscale.value[2] != ":" || heureArriverRetourEscale>23 || heureArriverRetourEscale<0 || minuteArriverRetourEscale<0 || minuteArriverRetourEscale>59  )
            {
                erreur = true;                
                document.getElementById("erreurHeureArriverEscaleRetourFormat").style.display="";
            }else{
                document.getElementById("erreurHeureArriverEscaleRetourFormat").style.display="none";
            }            
            document.getElementById("erreurHeureArriverEscaleRetour").style.display="none";
        }
            
    }else{
        //Désactivation des champs d'erreur
        document.getElementById("erreurTransportRetourEscaleObligatoire").style.display="none";
        document.getElementById("erreurHeureDepartEscaleRetour").style.display="none";
        document.getElementById("erreurHeureDepartEscaleRetourFormat").style.display="none";
        document.getElementById("erreurHeureArriverEscaleRetour").style.display="none";
        document.getElementById("erreurHeureArriverEscaleRetourFormat").style.display="none";
        document.getElementById("erreurEscaleRetourObligatoire").style.display ="none";
        document.getElementById("erreurVilleEscaleRetour").style.display="none";
    }
    
    
    return !erreur;    
}

function validerDonnerSurTransportVoiture()
{
    form=document.forms['formulaire'];
    var erreur = false;
    
    //Verification champs voiture    
    if(form.cv.value == "")
    {
        erreur = true;
        document.getElementById("erreurPuissanceVoitureObligatoire").style.display="";        
    }
    else
    {
        puissanceEnInt = parseInt(form.cv.value);
        if(isNaN(puissanceEnInt) || puissanceEnInt <=0 || puissanceEnInt >20)
        {
            erreur = true;
            document.getElementById("erreurPuissanceVoiture").style.display="";
        }
        else{
            document.getElementById("erreurPuissanceVoiture").style.display="none";
        }
        document.getElementById("erreurPuissanceVoitureObligatoire").style.display="none";
    }
        
    if(form.immatriculation.value == "")
    {
        erreur = true;
        document.getElementById("erreurImmatriculationVoiture").style.display="";
    }else{
        document.getElementById("erreurImmatriculationVoiture").style.display="none";
    }                    
    
    return erreur;
}

function validerDonnerSurTransportTrain() 
{
    form=document.forms['formulaire'];
    var erreur = false;
    //Gestion des champs du train     
    if(form.reductionTrain.value != "")
    {
        laReduc = parseInt(form.reductionTrain.value);
        if(isNaN(laReduc) || laReduc < 0 || laReduc > 100)
        {
            erreur = true;
            document.getElementById("erreurReductionTrain").style.display="";
        }else{
            document.getElementById("erreurReductionTrain").style.display="none";
        }
    }else{
        document.getElementById("erreurReductionTrain").style.display="none";
    }
    return erreur;
}

function validerDonnerSurTransportVoitureLocation()
{
    form=document.forms['formulaire'];
    var erreur = false;
    // Gestion des champs voiture de location    
    if(form.nbPersVoitureLocation.value == "")
    {
        erreur = true;
        document.getElementById("erreurNbPersonneLocationObligatoire").style.display="";
    }else{
        nbPersEnInt = parseInt(form.nbPersVoitureLocation.value);
        if(isNaN(nbPersEnInt) || nbPersEnInt <=0 || nbPersEnInt > 10)
        {
            erreur = true;                
            document.getElementById("erreurNbPersonneLocation").style.display="";
        }else
        {
            document.getElementById("erreurNbPersonneLocation").style.display="none";
        }
        document.getElementById("erreurNbPersonneLocationObligatoire").style.display="none";
    }    
    return erreur;
}

