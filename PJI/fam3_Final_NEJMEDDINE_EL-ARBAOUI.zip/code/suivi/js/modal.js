//var modalWinID=new Array();
//REQUIRES common.js
var visible=null;

function showHideModal(id)
{
    var visible;
    el=getElt(id);
    
    el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
    
    if (visible!=null && visible!=el)
    {   visible.style.visibility="hidden"; }
    visible=el;
}

function doModal(id)
{
    el=getElt(id);
    el.style.visibility = "hidden";
    el.style.position = "absolute";
    el.style.left="0px";
    el.style.top=getElt(id).offsetTop+"px";
    el.style.width="100%";
    el.style.height="100%";
    el.style.textAlign="center";
    el.style.zIndex="1000";
    //el.style.border="3px solid black";
    if (el.style.backgroundColor)
       el.style.backgroundColor="rgba(0,200,0,1)";
    if (el.style.bgColor)
       el.style.bgColor="rgba(0,200,0,1)";
    el.style.padding="25px";
    el.style.fontSize="100%";
    //modalWinID[nbModals++]=id;
}

function doModalAll(layer) {
    nbVis=layer.length;
    for (i=0;i<nbVis;i++)
    {
        doModal(layer[i]);
    }
}
