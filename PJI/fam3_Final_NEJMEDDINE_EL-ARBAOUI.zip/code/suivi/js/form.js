function getElt(whichLayer)
{
    var elem;
    if( document.getElementById ) // this is the way the standards work
        elem = document.getElementById( whichLayer );
    else if( document.all ) // this is the way old msie versions work
            elem = document.all[whichLayer];
         else if( document.layers ) // this is the way nn4 works
            elem = document.layers[whichLayer];

    return elem;

}

function setFieldValue(formName,formField,value)
{
    var elements=getElt(formName).elements;
    var node=elements.namedItem(formField);
    node.value=value;
}

function getFieldValue(formName,formField)
{
    //alert("get "+formName+" - "+formField);
    var elements=getElt(formName).elements;
    var node=elements.namedItem(formField);
    return node.value;
}

function getOptionCle(formName,formField)
{
    //alert("get "+formName+" - "+formField);
    var elements=getElt(formName).elements;
    var node=elements.namedItem(formField);
    //if (node.selectedIndex<node.length) {
      return node.options[node.selectedIndex].value;
    //} else return "";
}

function getOptionLabel(formName,formField)
{
    //alert("get "+formName+" - "+formField);
    var elements=getElt(formName).elements;
    var node=elements.namedItem(formField);
    //if (node.selectedIndex<node.length) {
      return node.options[node.selectedIndex].label;
    //} else return "";
}

function getFormCtrl(whichLayer,whichCtrl)
{
    var elements=getElt(whichLayer).elements;
    
    return elements.namedItem(whichCtrl);
}

function checkAll(formName,chkboxName,value)
{
    var elts=getElt(formName).elements;
    for (i=0;i<elts.length;i++)
    {
        if (elts[i].name==chkboxName || elts[i].name.substr(0,chkboxName.length)==chkboxName)
            elts[i].checked=value;
    }
}

//Ajout JTA le 17/08/2012

function getXMLHttpRequest() {
    var xhr = null;	
    if (window.XMLHttpRequest || window.ActiveXObject) {
        if (window.ActiveXObject) {
            try {
                xhr = new ActiveXObject("Msxml2.XMLHTTP");
            } catch(e) {
                xhr = new ActiveXObject("Microsoft.XMLHTTP");
            }
        } else {
            xhr = new XMLHttpRequest(); 
        }
    } else {
        alert("Votre navigateur ne supporte pas l'objet XMLHTTPRequest...");
        return null;
    }	
    return xhr;
}

var fa_entreprise_cle;
var fa_entreprise_nom;
var fa_regie_cle;
var fa_regie_nom;

function choix(form){    
    //Gestion AJAX            
    fa_entreprise_cle=form.fa_entreprise_cle.options[form.fa_entreprise_cle.selectedIndex].value;
    fa_entreprise_nom=form.fa_entreprise_cle.options[form.fa_entreprise_cle.selectedIndex].text;    
    if(fa_entreprise_nom == "SANS ENTREPRISE")
    {
        fa_entreprise_cle = "__sans entreprise__";
        fa_entreprise_nom = "";
    }

    
    var xhr   = getXMLHttpRequest();
	
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {                    
            readData(xhr.responseXML,form);			
        }			    
    };
	
    xhr.open("POST", "dbmngt/gestionListeLieesAJAX.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send("entrepriseCle=" + fa_entreprise_cle);
}

function updateBureau(form,bureau,entrCle) {
  var xhr = getXMLHttpRequest();
  xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            readBureau(xhr.responseXML,form,bureau);
        }
    };
  xhr.open("POST","dbmngt/gestionListeLieesAJAX.php",true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.send("entrepriseCle=" + entrCle);
}

function readBureau(oData,form,bureau) {
    var nodes=oData.getElementsByTagName("item");

    var i=0;
    //Vidange anciennes valeurs
    bureauElt=getElt(form).elements.namedItem(bureau);
    bureauElt.options.length = 0;
    var y = 0;
    for (i=0, c=nodes.length; i<c; i++) {
        if(nodes[i].getAttribute("id").toString() == "bureau")
        {
            bureauElt.options[y++] = new Option(nodes[i].getAttribute("value").toString(),nodes[i].getAttribute("name").toString());
        }
    }
}

function updateReferent(form,referent,entrCle) {
  var xhr = getXMLHttpRequest();
  xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            readReferent(xhr.responseXML,form,referent);
        }
    };
  xhr.open("POST","dbmngt/gestionListeLieesAJAX.php",true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.send("entrepriseCle=" + entrCle);
}

function readReferent(oData,form,bureau) {
    var nodes=oData.getElementsByTagName("item");

    var i=0;
    //Vidange anciennes valeurs
    refElt=getElt(form).elements.namedItem(bureau);
    refElt.options.length = 0;
    var y = 0;
    for (i=0, c=nodes.length; i<c; i++) {
        if(nodes[i].getAttribute("id").toString() == "referent")
        {
            refElt.options[y++] = new Option(nodes[i].getAttribute("value").toString(),nodes[i].getAttribute("name").toString());
        }
    }
}

function choixRegie(form){
    //Gestion AJAX
    fa_regie_cle=form.fa_regie_cle.options[form.fa_regie_cle.selectedIndex].value;
    fa_regie_nom=form.fa_regie_cle.options[form.fa_regie_cle.selectedIndex].text;
    if(fa_regie_nom == "SANS ENTREPRISE")
    {
        fa_regie_cle = null;
        fa_regie_nom = null;
    }
    var xhr   = getXMLHttpRequest();

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            readDataRegie(xhr.responseXML,form);
        }
    };

    xhr.open("POST", "dbmngt/gestionListeLieesAJAX.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send("entrepriseCle=" + fa_regie_cle);
}

function readData(oData,form) { 
    var nodes=oData.getElementsByTagName("item");		
    
    var i=0;
    //Vidange anciennes valeurs 
    form.fa_bureau_cle.options.length = 0;
    form.fa_referent_cle.options.length = 0;
    if (form.fa_referent2_cle) form.fa_referent2_cle.options.length = 0;
    var y = 0;
    for (i=0, c=nodes.length; i<c; i++) {
        if(nodes[i].getAttribute("id").toString() == "bureau")
        {
            form.fa_bureau_cle.options[i] = new Option(nodes[i].getAttribute("value").toString(),nodes[i].getAttribute("name").toString());
        }else if(nodes[i].getAttribute("id").toString() == "referent"){
            form.fa_referent_cle.options[y] = new Option(nodes[i].getAttribute("value").toString(),nodes[i].getAttribute("name").toString());
            if (form.fa_referent2_cle) form.fa_referent2_cle.options[y] = new Option(nodes[i].getAttribute("value").toString(),nodes[i].getAttribute("name").toString());
            y++;
        }
        
    }
    showCoords("fa_bureau_cle");
    showCoords("fa_referent_cle");
    if (form.fa_referent2_cle) showCoords("fa_referent2_cle");
}

function readDataRegie(oData,form) {
    var nodes=oData.getElementsByTagName("item");

    var i=0;
    //Vidange anciennes valeurs
    form.fa_regie_bureau_cle.options.length = 0;
    form.fa_regie_referent_cle.options.length = 0;
    form.fa_regie_referent2_cle.options.length = 0;

    var y = 0;
    for (i=0, c=nodes.length; i<c; i++) {
        
        if(nodes[i].getAttribute("id").toString() == "bureau")
        {
            form.fa_regie_bureau_cle.options[i] = new Option(nodes[i].getAttribute("value").toString(),nodes[i].getAttribute("name").toString());
        }
        else if(nodes[i].getAttribute("id").toString() == "referent"){
            form.fa_regie_referent_cle.options[y] = new Option(nodes[i].getAttribute("value").toString(),nodes[i].getAttribute("name").toString());
            form.fa_regie_referent2_cle.options[y] = new Option(nodes[i].getAttribute("value").toString(),nodes[i].getAttribute("name").toString());
            y++;
        }
    }
    showCoords("fa_regie_bureau_cle");
    showCoords("fa_regie_referent_cle");
    showCoords("fa_regie_referent2_cle");
}



function showCoords(elt) {
  //alert(elt);
  if (!getElt('form0')) return;
  
  var elem=getElt('form0').elements.namedItem(elt);

  //alert(elt+"_coords");
  //alert(elem.toString()+" - "+elem.selectedIndex);
  //alert(elt+" "+(elt.indexOf("bureau")));
  if (elt.indexOf("referent")==-1) {
    if (getElt(elt+"_coords")) getElt(elt+"_coords").style.display=
        (getOptionLabel('form0',elt).substr(0,5)=="SIEGE")?"block":"none";
  } else {
    //alert(getElt(elt+"_coords").style.display+" - "+(elem.selectedIndex));
    if (getElt(elt+"_coords")) getElt(elt+"_coords").style.display=(elem.selectedIndex>0)?"block":"none";
    //alert(getElt(elt+"_coords").style.display+" - "+(elem.selectedIndex));
  }
  
}
//Fin ajout 
