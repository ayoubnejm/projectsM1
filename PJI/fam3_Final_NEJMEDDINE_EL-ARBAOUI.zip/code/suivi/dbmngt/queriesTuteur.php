<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function doTuteurQueryChoosedFormations($conn,$tuteurRef)
{
    $queryString="select distinct if(length(formation.nom)>0,formation.nom,formation.formationCle), formation.formationCle from
                    membre inner join temp_tuteurs on membre.profCle=temp_tuteurs.tuteurRef
                    inner join contrat on contrat.alternanceCle = temp_tuteurs.alternanceRef
                    inner join etudiant on contrat.etudRef=etudiant.etudCle
                    inner join etudiant_groupe on etudiant.etudCle=etudiant_groupe.etudRef
                    inner join groupe on etudiant_groupe.groupeRef=groupe.groupeCle
                    inner join formation on groupe.formationRef=formation.formationCle
                where membre.profCle = '".$tuteurRef."' and etudiant_groupe.annee=".$_SESSION[REF_YEAR]." order by formation.nom;";

    //echo "querying ",$queryString;
    $result=mysql_query($queryString,$conn);
    return $result;
}
// Modification JTA 10/05/2012 Inclusion de la ville du bureau + distance
function doTuteurQueryListChoices($conn,$tuteurRef)
{
    $queryString="select distinct contrat.alternanceCle, etudiant.nom,etudiant.prenom,formation.nom ,bureau.ville,entreprise.nom,bureau.distance,bureau.adresse,bureau.codePostal from
                    membre inner join temp_tuteurs on membre.profCle=temp_tuteurs.tuteurRef
                    inner join contrat on contrat.alternanceCle = temp_tuteurs.alternanceRef
                    inner join etudiant on contrat.etudRef=etudiant.etudCle
                    inner join etudiant_groupe on etudiant.etudCle=etudiant_groupe.etudRef
                    inner join groupe on etudiant_groupe.groupeRef=groupe.groupeCle
                    inner join formation on groupe.formationRef=formation.formationCle
                    left join referent on contrat.referentRef=referent.referentCle
                    left join entreprise on referent.entrepriseRef=entreprise.entrepriseCle
                    left join bureau on contrat.bureauRef = bureau.bureauCle
                where membre.profCle = '".$tuteurRef."' and etudiant_groupe.annee=".$_SESSION[REF_YEAR]." order by etudiant.nom;";

    //echo "querying ",$queryString;
    $result=mysql_query($queryString,$conn);
    return $result;
}


function doDeleteChoixTuteurPourEtudiant($conn,$alternance,$tuteur)
{
    $deleteString="delete from temp_tuteurs where alternanceRef='".$alternance."' and tuteurRef='".$tuteur."';";
    $result=mysql_query($deleteString,$conn);

    if (!$result)
       return false;
    return true;
}
?>
