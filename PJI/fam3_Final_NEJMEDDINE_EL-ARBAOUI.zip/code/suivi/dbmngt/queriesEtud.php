<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function doGetTuteurInfoForStudent($conn,$student,$yearRef=null)
{
    if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];
    $query="select membre.nom, membre.prenom,membre.mail from
                        membre inner join contrat on tuteurRef=profCle where
                        etudRef = '".$student."' and anneeCle=".$yearRef." and notifAttribTuteur>0;";

    //echo $query;
    $tuteurs = mysql_query($query,$conn);
    if ($tuteurs===FALSE)
        return FALSE;
    else
        return mysql_fetch_row($tuteurs);
    
}

function doGetAltRefForStudent($conn,$student,$yearRef=null)
{
    if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];
    $query="select alternanceCle from contrat where etudRef='".$student."' and anneeCle=".$yearRef.";";
    $cles = mysql_query($query,$conn);
    if ($cles===FALSE)
        return FALSE;
    else {
        $cle=mysql_fetch_row($cles);
        return $cle[0];
    }
}

function doGetFormationForStudent($conn,$student,$yearRef=null)
{
    if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];
    $query="select formationRef from etudiant e inner join etudiant_groupe eg
                    on e.etudCle=eg.etudRef inner join groupe g on eg.groupeRef=g.groupeCle
         where etudCle='".$student."' and eg.annee=".$yearRef.";";
    //echo $query;
    $cles = mysql_query($query,$conn);
    if ($cles===FALSE)
        return FALSE;
    else {
        $cle=mysql_fetch_row($cles);
        return $cle[0];
    }
}
?>
