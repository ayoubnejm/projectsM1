<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function doQueryDetailsSoutenanceRapportByEtud($conn,$etudRef,$yearRef=null) {
    if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];
    $queryString="select formationRef,
                          dateRemise,
                          datesSoutenances,
                         	longueurRapport,
                         	duréeSoutenance,
                         	observationsTous,
                         	observationsTuteurs,
                         	lienExterne
                  from
                    soutenance
                  where formationRef in
                  (
                    select formationCle from
                      formation inner join groupe on
                        formationRef=formationCle
                      where groupeCle in 
                        (
                         select groupeRef from etudiant_groupe
                         where etudRef like '".$etudRef."' and
                         annee=$yearRef
                        )
                  ) and anneeReference<=$yearRef and obsolete=0 order by anneeReference limit 1;";

    
    $result=mysql_query($queryString,$conn);
    //echo "querying ",$queryString,"<br/>",mysql_error();
    return $result;
}

function doQueryDetailsSoutenanceRapport($conn,$formation,$yearRef=null) {
    if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];
    $queryString="select formationRef,
                          dateRemise,
                          datesSoutenances,
                         	longueurRapport,
                         	duréeSoutenance,
                         	observationsTous,
                         	observationsTuteurs,
                         	lienExterne
                  from
                    soutenance
                  where formationRef like '".$formation."'
                        and anneeReference <= $yearRef and obsolete=0  ;";

    //echo "querying ",$queryString;
    $result=mysql_query($queryString,$conn);
    return $result;
}

function doTuteurQueryFormationsResponsable($conn,$roles,$yearRef=null) {
    if ($yearRef==null) $yearRef=$_SESSION[REF_YEAR];
  $queryString="select f.formationCle,f.formationCle
                  from
                    formation f 
                  where f.formationCle in ('".str_replace(array(" ","_RESP"),array("','",""),$roles)."')";

                    //and s.anneeReference <= $yearRef and s.obsolete=0 ;";

    //echo "querying ",$queryString;
    $result=mysql_query($queryString,$conn);
    return $result;
}
?>
