<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
    function doConnection($dbname="stalt2")
    {
        $conn = mysql_connect('127.0.0.1', 'root', 'root');

        if (!$conn) {
            die('Problème avec le serveur de la base de données. '.$dbname.' Veuillez revenir plus tard . ');
        }

        mysql_select_db($dbname,$conn);
        
        mysql_query('SET NAMES \'utf8\'', $conn);
        
        return $conn;

    }
    
?>
