<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once(ABS_START_PATH."/dbmngt/connect.php");
require_once(ABS_START_PATH."/ldap/ldap.php");
//Ajout JTA 
require_once(ABS_START_PATH."/distance/calculDistance.php");
require_once(ABS_START_PATH."/html/escaping.php");
// Fin Ajout
require_once(ABS_START_PATH."/dbmngt/delete.php");


function faireInscrireOPCA(
$nom, $url, $representant, $mail, $tel, $anneesFinancees, $commentaires) {

    //error_log("faire inscrire");
    $conn = doConnection("fil_entr");
    if (strlen($nom) == 0)
        return "Saisissez un nom pour OPCA!";

    $queryString = "select nom from opca where upper(nom) like '" .
            (str_replace("-", "%", str_replace("_", "%", str_replace(" ", "%", strtoupper($nom)))))
            . "';";
    //echo $queryString;
    $opcas = mysql_query($queryString, $conn);
    $ligne = mysql_fetch_row($opcas);
    if ($ligne) {
        return "Une OPCA portant ce nom (" . $ligne[0] . ") se trouve déjà dans la base!";
    }
    $cle = str_replace("-", "_", str_replace(" ", "_", strtolower($nom)));

    $queryString = "insert into opca(`nom`, `commentaires`, `anneesFinancees`, `representant`, `tel`, `mail`, `opcaCle`, `url`)
            values" .
            "('" . $nom . "'," .
            "'" . $commentaires . "'," .
            "'" . $anneesFinancees . "'," .
            "'" . $representant . "'," .
            "'" . $tel . "'," .
            "'" . $mail . "'," .
            "'" . $cle . "'," .
            "'" . $url . "'" .
            ")";
    //echo $queryString;
    $opcas = mysql_query($queryString, $conn);

    if ($opcas == FALSE) {
        return "Problème avec la requête: $queryString - Raison : " . mysql_error($conn);
    }
}

function faireInscrireentr(
$nom, $fa_entr_adresse, $fa_entr_tel, $fa_entr_ville, $fa_entr_cp, $fa_entr_opcaRef
) {
//error_log("faire inscrire");
    $conn = doConnection("fil_entr");
    if (strlen($nom) == 0)
        return "NOK : Saisissez un nom pour Entreprise!";

    $queryString = "select nom from entreprise where upper(nom) like '" .
            (str_replace("-", "%", str_replace("_", "%", str_replace(" ", "%",
                     str_replace("'","%",strtoupper($nom))))))
            . "';";
    //echo $queryString;
    $opcas = mysql_query($queryString, $conn);
    $ligne = mysql_fetch_row($opcas);
    if ($ligne) {
        return "NOK : Une entreprise portant un nom très similaire (" . $ligne[0] . ") se trouve déjà dans la base! Contactez marius.bilasco@lifl.fr !";
    }
    $cle = str_replace("'","_",str_replace("-", "_", str_replace(" ", "_", strtolower($nom))));

    $res=TRUE;
    $queryString = "set autocommit=0";
    $res = $res && !(!mysql_query($queryString, $conn));
    
    $queryString = "insert into entreprise(`nom`, `adresse`, `tel`, `ville`, `codePostal`, `opcaRef`, `entrepriseCle`)
            values" .
            "('" . doDBEscape($nom) . "'," .
            "'" . doDBEscape($fa_entr_adresse) . "'," .
            "'" . doDBEscape($fa_entr_tel) . "'," .
            "'" . doDBEscape($fa_entr_ville) . "'," .
            "'" . doDBEscape($fa_entr_cp) . "'," .
            "'" . doDBEscape($fa_entr_opcaRef) . "'," .
            "'" . $cle . "'" .
            ")";
    //echo $queryString;
    $res = mysql_query($queryString, $conn);
    if (!($res == FALSE)) {
      $Distance = new calculDistance();
      $DistanceTmp = $Distance->getDistance($fa_bur_adresse." ".$fa_bur_cp." ".$fa_bur_ville);

      $queryString = "insert into bureau(`bureauCle`, `entrepriseRef`, `adresse`, `codePostal`, `ville`, `tel`,`distance`)
      values" .
            "('" . $cle . "_siege'," .
            "'" . $cle . "'," .
            "'" . doDBEscape($fa_entr_adresse) . "'," .
            "'" . doDBEscape($fa_entr_cp) . "'," .
            "'" . doDBEscape($fa_entr_ville) . "'," .
            "'" . doDBEscape($fa_entr_tel) . "'," .
            "'" . $DistanceTmp . "'" .
            ")";
      
      $res = mysql_query($queryString, $conn);
      error_log ($queryString." - ".mysql_error());
      //error_log("res inscrire Bureau : ".$res);
    }
    if (!($res == FALSE)) {
      $queryString = "insert into referent (`referentCle`, `entrepriseRef`,`nom`,`prenom`)
      values ('__sans referent___".strtoupper($cle)."','$cle','__sans','referent__')";
      $res = mysql_query($queryString, $conn);
      error_log ($queryString." - ".mysql_error());
      error_log("res inscrire Referent : ".$res);
    }
    if (!($res != FALSE && substr($res,0,3)!="NOK")) {
        return "NOK : Problème avec la requête: $queryString - Raison : " . mysql_error($conn);
        mysql_query("rollback",$conn);
    } else {
        mysql_query("commit",$conn);
    }

    return "OK : ".$cle;
}

// Ajout du 30/01/2012 JTA Gestion de l'inscription d'un bureau

function faireInscrireBureau($fa_bur_adresse, $fa_bur_tel, $fa_bur_ville, $fa_bur_cp, $entreprise, $fa_latitude, $fa_longitude, $distance) {
    $conn = doConnection("fil_entr");
    if (strlen($fa_bur_adresse) == 0)
        return "NOK : Veuillez saisire une adresse s'il vous plait ";
	 if ((strlen($fa_latitude) == 0) || (strlen($fa_longitude) == 0))
        return "NOK : Veuillez appuyer sur le boutton verifier !!";
    if (strlen($fa_bur_ville) == 0)
        return "NOK : Veuillez saisire une ville s'il vous plait ";
    
     $nom = $entreprise . "_" . $fa_bur_ville . "_" . $fa_bur_adresse;
    // Verification de l'uniciter de la cle bureau (Primary KEY)
    $queryString = "select * from bureau where upper(bureauCle) like '" . 
              str_replace("'","%",(str_replace("-", "%", str_replace("_", "%", str_replace(" ", "%", strtoupper($entreprise))))))
            ."';";
    $resultSet = mysql_query($queryString, $conn);
    if ($resultSet) {
        $ligne = mysql_fetch_row($resultSet);
        if ($ligne) {
            return "NOK : Un bureau avec à cette adresse pour l'entreprise " . $entreprise . " existe déjà !";
        }
    }

    //Verification que l'entreprise existe (Foreign KEY )    
    $queryString = "select * from entreprise where upper(entrepriseCle) like '" .
            str_replace("'","%",(str_replace("-", "%", str_replace("_", "%", str_replace(" ", "%", strtoupper($entreprise))))))
            . "';";
   // echo $queryString;
    $resultSet = mysql_query($queryString, $conn);
    if ($resultSet) {
        $ligne = mysql_fetch_row($resultSet);
        if (!$ligne) {// Si le resultat est null cela veut dire que l'entreprise n'existe pas !
            return "NOK : L'entreprise n'éxiste pas ! Une entreprise inexistante ne peut avoir de bureau !";
        }
    }

    $cle = str_replace("'", "_",str_replace("-", "_", str_replace(" ", "_", strtolower($nom))));
	 // On calcule la distance avant dans la page inscrireBureau_modal, plus besoin de passer par la classe calculDistance()    
	 //$Distance = new calculDistance();    
     // $DistanceTmp = $Distance->getDistance($fa_bur_adresse." ".$fa_bur_cp." ".$fa_bur_ville);
	 //Calcule de la distance a partir des coordonées GPS
	 //$DistanceGPS = $Distance->getDistanceCoorGPS($fa_latitude, $fa_longitude);
	
	//Ajout de deux variable latitude et longitude par an et se
    $queryString = "insert into bureau(`bureauCle`, `entrepriseRef`, `adresse`, `codePostal`, `ville`, `tel`,`latitude`,`longitude`,`distance`)
      values" .
            "('" . doDBEscape($cle) . "'," .
            "'" . doDBEscape($entreprise) . "'," .
            "'" . doDBEscape($fa_bur_adresse) . "'," .
            "'" . doDBEscape($fa_bur_cp) . "'," .
            "'" . doDBEscape($fa_bur_ville) . "'," .
            "'" . doDBEscape($fa_bur_tel) . "'," .
			"'" . doDBEscape($fa_latitude) . "'," .
			"'" . doDBEscape($fa_longitude) . "'," .
            "'" . doDBEscape($distance) . "'" .
            ")";
    //error_log ($queryString);
    $res = mysql_query($queryString, $conn);

    if ($res == FALSE) {
        return "NOK : Problème avec la requête: $queryString - Raison : " . mysql_error($conn);
    }

    return "OK : ".$cle;
}

function faireInscrireReferent($fa_ref_nom, $fa_ref_prenom, $fa_ref_email, $fa_ref_tel,$fa_ref_fonction,$fa_ref_bureau, $entreprise) {
    $fa_ref_nom=trim(strtoupper($fa_ref_nom));
    $fa_ref_prenom=(trim($fa_ref_prenom));
    $fa_ref_prenom=(substr(strtoupper($fa_ref_prenom),0,1).substr(strtolower($fa_ref_prenom),1));
    $fa_ref_email=(trim($fa_ref_email));
    $fa_ref_tel=(trim($fa_ref_tel));
    $fa_ref_fonction=(trim($fa_ref_fonction));
    $fa_ref_bureau=(trim($fa_ref_bureau));
    //$entreprise=trim($entreprise);
    
    $conn = doConnection("fil_entr");
    if (strlen($fa_ref_nom) == 0)
        return "NOK : Veuillez saisire un nom s'il vous plait ";
    if (strlen($fa_ref_prenom) == 0)
        return "NOK : Veuillez saisire un prenom s'il vous plait ";
    if (strlen($fa_ref_email) == 0)
        return "NOK : Veuillez saisir un email s'il vous plait ";
    //$nom = $entreprise . "_" . $fa_ref_nom . "_" . $fa_ref_prenom;
    // Verification de l'uniciter de la cle referent (Primary KEY)

    //Verification que l'entreprise existe (Foreign KEY )    
    $queryString = "select * from entreprise where upper(entrepriseCle) like '" .
            (str_replace("'", "%",str_replace("-", "%", str_replace("_", "%", str_replace(" ", "%", strtoupper($entreprise))))))
            . "';";
   // echo $queryString;
    $resultSet = mysql_query($queryString, $conn);
    if ($resultSet) {
        $ligne = mysql_fetch_row($resultSet);
        if (!$ligne) {// Si le resultat est null cela veut dire que l'entreprise n'existe pas !
            return "NOK : L'entreprise n'éxiste pas ! Une entreprise inexistante ne peut avoir de referent !";
        }
    }
    
    //Verification que le bureau existe ( Foreign KEY ) 
    $queryString = "select * from bureau where upper(bureauCle) like '" .
            (str_replace("'", "%",str_replace("-", "%", str_replace("_", "%", str_replace(" ", "%", strtoupper($fa_ref_bureau))))))
            . "';";
   // echo $queryString;
    $resultSet = mysql_query($queryString, $conn);
    if ($resultSet) {
        $ligne = mysql_fetch_row($resultSet);
        if (!$ligne) {// Si le resultat est null cela veut dire que l'entreprise n'existe pas !
            return "NOK : Le bureau n'existe pas ! Un bureau inexistant ne peut avoir de referent !";
        }
    }
    

    $cle = $fa_ref_nom.'_'.$fa_re_prenom.'_'
      .strtoupper($entreprise).'_'.date("YmdGis");
    

    $queryString = "insert into referent(`referentCle`, `entrepriseRef`, `nom`, `prenom`, `mail`, `tel`,`fonction`,`bureauRef`)
      values" .
            "('" . doDBEscape($cle) . "'," .
            "'" . doDBEscape($entreprise) . "'," .
            "'" . doDBEscape($fa_ref_nom) . "'," .
            "'" . doDBEscape($fa_ref_prenom) . "'," .
            "'" . doDBEscape($fa_ref_email). "'," .
            "'" . doDBEscape($fa_ref_tel). "'," .
            "'" . doDBEscape($fa_ref_fonction). "'," .
            "'" . doDBEscape($fa_ref_bureau). "'" .
            ")";
//echo $queryString;
    $res = mysql_query($queryString, $conn);

    if ($res == FALSE) {
        return "NOK : Problème avec la requête: $queryString - Raison : " . mysql_error($conn);
    }

    return "OK : ".$cle;
}


// Fin ajout 

//Modification JTA 
function faireInscrireEtudiant($groupeRef, $nom, $prenom, $tel, $mail, $et_entrCle, $tuteurRef, $motsCles, $annee, $fa_bureau_cle,$fa_referent_cle,$etudCle=null) {
    $nom=doDBEscape(trim(strtoupper($nom)));
    $prenom=doDBEscape(trim($prenom));
    $prenom=(strtoupper(substr($prenom,0,1))).strtolower(substr($prenom,1));
    $tel=doDBEscape(trim($tel));
    $mail=doDBEscape(trim($mail));
    $motsCles=doDBEscape(trim($motsCles));
    //if ($annee==$ && strcmp(substr($lastGroupeRef,0,2),"M2")==0 && strcmp(substr($lastGroupeRef,strlen($lastGroupeRef)-3,2),"FA")==0)

    $conn = doConnection("fil_dept");
    
    $mailLille1 = NULL;

    $res = true;

    $queryString = "set autocommit=0";
    $res = $res && !(!mysql_query($queryString, $conn));
    $queryString = "begin ";
    $res = $res && !(!mysql_query($queryString, $conn));

    if ($etudCle==null) {
      //error_log("check for ldap id");
      $etudCle = strtolower($groupeRef) . $nom[0] . $prenom[0] . rand(0, 100);
      $res = getEtudMailAndUIDByNameWithApprox($nom, $prenom);
      //$res=array();
      //Attention mise en dur car travail en localhost
      //$mailLille1 = "jimmy.tahoulas@univ-lille1.fr";
      //$etudCle = "jimmy.tahoulas2";
      //Fin mise en dur

      if (count($res) == 1 && $res[0]["details"] === "OK") {
          $etudCle = $res[0]["uid"];
          $mailLille1 = $res[0]["mail"];
      } else {
          $result = " ID temporaire. Utilisez la fonctionnalité de maj d'ID.";
      }


      $res = true;
      $queryString = "Select * from fil_dept.etudiant where  etudCle like '" . $etudCle . "' and anneeReference<=$annee and obsolete=0";
      //error_log($queryString);
      $query = mysql_query($queryString, $conn);
      $row = mysql_fetch_row($query);
      if ($row) {
          echo "Etudiant déjà inscrit dans l'appli mais dans un autre groupe probablement. La migration est en cours. <br/>";
      } else {
          $row = null;
      }

      $queryString = "Select etudCle,nom,prenom,annee,groupeRef,tuteurRef from fil_dept.etudiant inner join etudiant_groupe eg on etudCle=eg.etudRef
                      inner join stalt.contrat c on c.etudRef=etudCle and eg.annee=c.anneeCle
                            where  ((nom like '" . $nom . "' ".
                              "and prenom like '".$prenom."')or etudCle='$etudCle') and anneeReference<=$annee and obsolete=0 order by annee desc";
      $query = mysql_query($queryString, $conn);
      //error_log("INSCRIRE : ".$queryString." - ".mysql_error());

      $row=mysql_fetch_row($query);
      if ($row) {
        echo "Un ou plusieurs étudiants portant le même nom sont toujours inscrits au FIL <ul>";

        $outputString="";
        $count=0;
        $lastEtudCle="";
        $lastTuteurParam="";
        while ($row) {
          if ($row[3]==$annee && $row[4]==$groupeRef) {
            //error_log("INSCRIRE : skipping ".$row[0]." - ".$row[3]." - ".$row[4]." ! ");
            $count=0;
            $row=false;
            continue;
          }
          if (strcmp($lastEtudCle,$row[0])!=0) {
            $lastEtudCle=$row[0];
            $count++;
          }

          $outputString.= "<li><form action='".ABS_START_URL."/index.php' target='_blank' method='post'>";
          $outputString.=  "<input type='hidden' name='page' value='interface/faireInscrireEtudiant_act'/>";
          $outputString.=  $row[2]." ".$row[1]." inscrit en ".$row[3]." en ".$row[4]." suivi par ".$row[5];
          /*$requestKeys=array_keys($_REQUEST);
          for ($i=0;$i<count($requestKeys);$i++)
            echo "<input type='hidden' name='".$requestKeys[$i]."' value='".$_REQUEST[$requestKeys[$i]]."'/>";
          */
  

          $outputString.= "<input type='hidden' name='fa_entreprise_cle' value=\"".doDBEscape($et_entrCle)."\"/>";
          $outputString.= "<input type='hidden' name='fa_bureau_cle' value=\"".doDBEscape($fa_bureau_cle)."\"/>";
          $outputString.= "<input type='hidden' name='fa_referent_cle' value=\"".doDBEscape($fa_referent_cle)."\"/>";
          $outputString.= "<input type='hidden' name='fa_etudiant_prenom' value=\"".doDBEscape($prenom)."\"/>";
          $outputString.= "<input type='hidden' name='fa_etudiant_nom' value=\"".doDBEscape($nom)."\"/>";
          $outputString.= "<input type='hidden' name='fa_etudiant_mail' value=\"".doDBEscape($mail)."\"/>";
          $outputString.= "<input type='hidden' name='fa_etudiant_tel' value=\"".doDBEscape($tel)."\"/>";
          $outputString.= "<input type='hidden' name='fa_mots_cles' value=\"".doDBEscape($motsCles)."\"/>";
          $lastAnnee=$row[3];
          $lastGroupeRef=$row[4];
          

          //error_log("INSCRIRE tuteur : ".$lastAnnee." - ".$annee." - ".substr($lastGroupeRef,0,2)." - ".substr($lastGroupeRef,strlen($lastGroupeRef)-3,2)." ! ");

          if ($lastAnnee==$annee-1 && strcmp(substr($lastGroupeRef,0,2),"M1")==0 && strcmp(substr($lastGroupeRef,strlen($lastGroupeRef)-3,2),"FA")==0)
            $lastTuteurParam=doDBEscape($row[5]);

          if ($lastAnnee==$annee)
            $lastTuteurParam="";

          $outputString.= "<input type='hidden' name='tuteurParam' value=\"".$lastTuteurParam."\"/>";
          $outputString.= "<input type='hidden' name='formation' value=\"".substr($groupeRef,0,strlen($groupeRef)-1)."\"/>";
          

          $outputString.= "<input type='hidden' name='etudCle' value='".$row[0]."'/>";
          
          $outputString.= "<input type='submit' value='Migrer'/>";
          $outputString.= "</form></li>";
          $row=mysql_fetch_row($query);
        }
        //error_log("INSCRIRE : counting $count");
        if ($count==0)
          return "<b style='color:orange'>déjà inscrit dans cette formation ".$groupeRef."</b>";
        else
          if ($count>1) echo $outputString;
        else
          return faireInscrireEtudiant($groupeRef, doDBEscape($nom), doDBEscape($prenom), doDBEscape($tel), doDBEscape($mail), doDBEscape($et_entrCle), $lastTuteurParam, doDBEscape($motsCles), $annee, doDBEscape($fa_bureau_cle),doDBEscape($fa_referent_cle),$lastEtudCle);
        echo("</ul>");
        return "<font color='blue'>En attente</font>";
      }

      if ($row) {

      } else {

            $queryString = "INSERT INTO " .
                  "`etudiant` ( " .
                  "`nom`, `prenom`, `tel`, `mail`, `mailLille1`, `anneeReference`,`etudcle`) VALUES ";

            $queryString = $queryString . "('" . $nom . "',";
            $queryString = $queryString . "'" . $prenom . "',";
            $queryString = $queryString . "'" . $tel . "',";
            $queryString = $queryString . "'" . $mail . "',";
            $queryString = $queryString . "'" . $mailLille1 . "',";
            $queryString = $queryString . "" . $annee . ",";
            //TODO ... consider the precise group. Now only one groupe (1) by Formation
            $queryString = $queryString . "'" . $etudCle . "');";
            echo $queryString . "<br/>";
            mysql_query($queryString, $conn);
            echo mysql_error($conn);
            $res = $res && (mysql_errno($conn) == 0);

      }
    }

    if ($res != false) {
        //groupe
        $queryString = "Select * from fil_dept.etudiant_groupe where  etudRef like '".$etudCle."' and annee=$annee";
        $query = mysql_query($queryString, $conn);
        $row = mysql_fetch_row($query);
        
        if ($row) {
            $res = $res && (deleteFromEtudiantGroupe($annee,$etudCle,$conn) == 0);
        };
            
        if ($res!=false) {
          $queryString = "INSERT INTO " .
                  "`etudiant_groupe` ( " .
                  "`annee`, `groupeRef`,`etudRef`) VALUES ";

          $queryString = $queryString . "('" . $annee . "',";
          $queryString = $queryString . "'" . $groupeRef . "',";
          $queryString = $queryString . "'" . $etudCle . "');";
          echo $queryString . "<br/>";

          mysql_query($queryString, $conn);
          echo mysql_error($conn);
          $res = $res && (mysql_errno($conn) == 0);
       }
       
    }

    if ($res != false) {
        $result.="<font color='green'><br>Inscrire Etudiant ok</font>";
    } else {
        $queryString = "rollback;";
        echo $queryString . "<br/>";
        mysql_query($queryString, $conn);
        echo mysql_error($conn);
        $res = $res && (mysql_errno($conn) == 0);
        return "<font color='red'>Echec inscrire étudiant!</font>";
    }

    $refID = $fa_referent_cle;//Modif ICI
    $altCle = $etudCle . "A";
    $connALT = doConnection("stalt");

    $refID = $fa_referent_cle;
    $altCle = $etudCle."_".$annee;

    /*if ($res != false) { inutile
        //$queryString="Insert into fa_referent (`referentCle`, `entrepriseRef`, `ville`) ";
        //$queryString.="values ('".$refID."','".$et_entrCle."','".$ville."');";
        $queryString = "Insert into fa_referent (`referentCle`, `entrepriseRef`) ";
        $queryString.="values ('" . $refID . "','__sans entreprise__');";
        echo $queryString . "<br/>";
        mysql_query($queryString, $connALT);
        echo mysql_error($connALT);
        $res = $res && (mysql_errno($connALT) == 0);
    }*/
// JTA Modif


    if ($res != false ) {
      $queryString="select * from contrat where etudRef='$etudCle' and anneeCle=$annee";
      $rows=mysql_query($queryString,$conn);
      $row=mysql_fetch_row($rows);

      if ($row==false || strlen($tuteurRef)!=0 || strlen($fa_bureau_cle)!=0) {
        
        $res = $res && (deleteFromContrat($altCle,$conn) == 0);

        if ($res!=false) {
          $queryString = "Insert into contrat (`referentRef`, `etudRef`, `tuteurRef`,`alternanceCle`,`opcaRef`,`bureauRef`,`anneeCle`) ";
          $queryString.="values ('" . $refID . "','" . $etudCle . "','" . $tuteurRef . "','" . $altCle . "','__sans opca__','" . doDBEscape($fa_bureau_cle) . "',$annee);";
          echo $queryString . "<br/>";
          mysql_query($queryString, $connALT);
          echo mysql_error($connALT);
          $res = $res && (mysql_errno($connALT) == 0);
        }
      }
    }

    if ($res != false) {
        $queryString = "select * from infoetud where alternanceRef='".$altCle."';";
        $query=mysql_query($queryString, $connALT);
        echo $queryString."<br/>".mysql_error();
        $row=mysql_fetch_row($query);
        if ($row)
        {} else
        {
          $queryString = "Insert into infoetud (`alternanceRef`,`motscles`) ";
          $queryString.="values ('" . $altCle . "','" . $motsCles . "');";
          echo $queryString . "<br/>";
          mysql_query($queryString, $connALT);
          echo mysql_error($connALT);
          $res = $res && (mysql_errno($connALT) == 0);
        }
    }

    if ($res != false) {
        $queryString = "commit;";
        echo $queryString . "<br/>";
        mysql_query($queryString, $connALT);
        echo mysql_error($connALT);
        $res = $res && (mysql_errno($connALT) == 0);
    }

    if ($res != false) {
        $result.="<font color='green'><br/>Inscription Stage/Alternance ok</font>";
        return $result;
    } else {
        $queryString = "rollback;";
        echo $queryString . "<br/>";
        mysql_query($queryString, $connALT);
        $res = $res && (mysql_errno($connALT) == 0);
        return "<font color='red'>Echec</font>";
    }
}



//08/03/2013


function faireInscrireTuteur($nom, $prenom, $tel, $mail, $profCle,$bureau,$anneeReference) {
    $conn = doConnection("fil_dept");
    $obsolete=0;


    $queryString = "insert into membre(`anneeReference`, `obsolete`, `nom`, `prenom`, `tel`, `mail`,`bureau`, `profCle`)
      values" .
            "('" . doDBEscape($anneeReference) . "'," .
            "'" . doDBEscape($obsolete) . "'," .
            "'" . doDBEscape($nom) . "'," .
            "'" . doDBEscape($prenom) . "'," .
            "'" . doDBEscape($tel) . "'," .
            "'" . doDBEscape($mail) . "'," .
            "'" . doDBEscape($bureau) . "'," .
            "'" . doDBEscape($profCle) . "'" .
            ")";
    //error_log ($queryString);
    $res = mysql_query($queryString, $conn);

return $res;
}


?>
